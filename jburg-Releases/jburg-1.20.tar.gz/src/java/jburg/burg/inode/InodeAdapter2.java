package jburg.burg.inode;


public interface InodeAdapter2
{
    /**
     *  Retrieve a node's arity, if it can be determined at compiler-compile time.
     *  @param operator - the opcode of the node whose arity is to be checked. 
     *  @return the node's compiler-compile-time constant arity, or null if the arity 
     *    must be computed at compile time.
     */
    public Integer getConstantArity(String operator);
    
    /**
     *  Up to what child number does a node need special-case handling?
     *  @param operator - the opcode of the node whose maximum "variant" child is requested
     *  @return the highest numbered child that needs special-case handling at compiler-compile time.
     *  @see genGetDefaultChild, which returns children that don't need special handling.
     */
    public Integer getMaxNthChildChoice(String operator);

    /**
     *  @param opcode - the opcode of the node at the root of this production's pattern.
     *  @param node_path - the path to the node whose child is to be returned.
     *  @param emitter - the language-specific code emitter in use. 
     *  @return an expression that fetches a child node at the specified index.
     */
    public String genGetNthChild(String operator, String node_path, int index, jburg.emitter.EmitLang emitter);
    
    /**
     *  Generate the code to retrieve a child node that doesn't require special handling.
     *  @param opcode - the opcode of the node at the root of this production's pattern.
     *  @param node_path - the path to the node whose child is to be returned.
     *  @param emitter - the language-specific code emitter in use. 
     *  @return an expression that fetches child node at the specified index.
     */
    public String genGetDefaultChild(String operator, String node_path, String index, jburg.emitter.EmitLang emitter);
    
    /**
     * @return a snippet that fetches the node's semantic content, e.g. the value of a literal
     * or the name of an identifier.
     * @param operator - the opcode of the node at the root of this production's pattern.
     * @param goal_state - the state this node is being reduced to.
     * @param subgoal_states - the nonterminal states satisfied by the production's subgoals.
     * @param emitter - the language-specific code emitter in use. 
     */
    public String genGetContent(String operator, String node_path, String goal_state, jburg.emitter.EmitLang emitter);
}
