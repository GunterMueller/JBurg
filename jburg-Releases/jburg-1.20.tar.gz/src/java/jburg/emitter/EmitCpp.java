package jburg.emitter;

import java.io.PrintStream;
import java.lang.reflect.Modifier;

import java.util.Map;
import java.util.Set;
import java.util.Vector;

import org.antlr.stringtemplate.StringTemplate;

import jburg.burg.JBurgGenerator;
import jburg.burg.JBurgPatternMatcher;
import jburg.burg.inode.InodeAdapter;
import jburg.parser.JBurgTokenTypes;

/**
 *
 *  Emit a BURM in C++.
 * 
 * <ul>
 * <li>TODO: Should output into a .h &amp; a .cpp file (perhaps file output should be handled in this class?)
 * <li>TODO: Perhaps handle all data in the Emit**** interface &amp; derive methods ??
 * <li>TODO: Is the use of smart pointers the best way to deal with pointers in the action_nnn routines ?
 * <li>TODO: How should "jburgsupp.h" be handled ? place in resources ?
 * 
 * @author Nick Brereton
 * @author Tom Harwood
 *
 */

@SuppressWarnings("nls")
public class EmitCpp implements EmitLang, JBurgTokenTypes
{
	private int blockCount = 0;

	private String m_className;
	
	public String iNodeType;

    private TemplateGroup templates = new TemplateGroup("templates", "EmitCpp");
	
	@Override
    public void setINodeType(String inode_type)
	{
	    this.iNodeType = inode_type;
	}

    String ntType = "int";

    @Override
    public void setNtType(String nt_type)
    {
        this.ntType = nt_type;
    }
	
	/** Operator type, defaults to int */
    String operatorType = "int";
    
    @Override
    public void setOpcodeType(String operator_type)
    {
        this.operatorType = operator_type;
    }

    @Override
    public boolean supportsSpecializedAnnotations()
    {
        return false;
    }
    
    /**
     * Pseudorandom suffix for static data, in case two BURMs live in one load module.
     */
    int staticsSuffix = Math.abs(new java.util.Random().nextInt());

    @Override
    public StringTemplate getTemplate(String name, Object ... attrValue)
    {
        return this.templates.getTemplate(name, attrValue);
    }

	@Override
    public void emitHeader(
        String className,
        String packageName,
        String headerBlock,
        String baseClassName,
        Vector<String> InterfaceNames,
        boolean debugMode,
        PrintStream output
        )
	{
		int i;

		m_className = className;

        if ( baseClassName != null )
            throw new IllegalStateException("C++ target unimplemented: extends attribute");

		// add c++ imports: note: STL is required (also required for ANTLR...so shouldn't be a problem
		output.print("#include <iostream>\n");
		output.print("#include <string>\n");
		output.print("#include <stack>\n");
		output.print("#include <exception>\n");
		output.print("#include <memory>\n");
		output.print("#include <sstream>\n");
		if(debugMode)
			output.print("#include <fstream>\n");
		
        //  define  getOperator(node) so jburgsupp.h
		//  can work from an a priori interface.  
		output.print("namespace jburgsupp");
		output.print(genBeginBlock());
        output.print(
            declareMethod(
                0,
                "int", //  TODO: Return the operator type
                "getOperator",
                new String[][]{
                    new String[] { this.iNodeType, "node" }
                },
                null
            )
        );

        output.print( genBeginBlock() );

        output.print("\treturn " + m_inodeAdapter.genGetOperator("node", this) + ";");
        output.print( genEndBlock() );
        
        output.print( genEndBlock() );  // namespace jburgsupp
            
		output.print("#include \"jburgsupp.h\"\n");

		// java package is regarded as being equivalent to a c++ namespace
		if (packageName != null)
			output.print("// nested namespace (JBurg package property)" +
									"\nnamespace " + packageName + "\n{\n\n");

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n\n");
		}

		output.print("class " + m_className);

		if (InterfaceNames.size() > 0) {
			output.print(": ");

			for (i = 0; i < InterfaceNames.size(); i++) {
				if (i > 0) {
					output.print(", ");
				}

				output.print("public "+InterfaceNames.elementAt(i).toString());
			}
		}

		output.print(
			"\n{\nprivate:\n\n\tstd::stack<void*> __reducedValues;\n\n");

		output.print("\tint\t*antecedentRules;\n\n");

		// output a constructor
		output.print("public:\n\n");
		output.print("\t" + m_className + "() {\n");
		output.print("\t\tantecedentRules = new int[nStates];\n");
		output.print("\t}\n\n");

		// d'tor
		output.print("\t~" + m_className + "() {\n");
		output.print("\t\tif( antecedentRules ) delete[] antecedentRules;\n");
		output.print("\t}\n\n");
	}
	
	@Override
    public void emitStatics(int max_action, Map<Integer, Vector<JBurgPatternMatcher>> rules_by_action, PrintStream output)
	{
	    output.println();
        output.println(genLine("public: static std::vector<std::vector<JBurgAnnotation<" + iNodeType + ">::JBurgSubgoal> > subgoals_by_rule" + staticsSuffix + ";"));
        output.print(genLine(genComment("Static initializer code for the subgoals lookup table.")));
        output.print(genLine("public: class SubgoalsByRuleInitializerHack"));
        output.print(genBeginBlock());
        output.print(genLine("public: SubgoalsByRuleInitializerHack()"));
        output.print(genBeginBlock());
        output.print(genLine(m_className + "::subgoals_by_rule" + staticsSuffix + ".resize(" + Integer.toString(max_action + 1) + ");"));
        for ( Integer rule_num: rules_by_action.keySet() )
        {
            //  Emit the subgoals in reverse order so they are reduced and pushed
            //  onto the stack in the correct order.
            Vector<JBurgPatternMatcher> matchers = rules_by_action.get(rule_num); 
            
            for ( int pattern_num = matchers.size() -1; pattern_num >= 0; pattern_num--  )
            {
                JBurgPatternMatcher matcher = matchers.elementAt(pattern_num);
                
                String pattern_init = "rule_" + rule_num + "_pattern_" + pattern_num;
                
                output.print(genLine("std::vector<int> " + pattern_init + ";"));
                for ( JBurgPatternMatcher.PathElement idx: matcher.generateAccessPath() )
                    output.print(genLine(pattern_init + ".push_back(" + Integer.toString(idx.index) + ");"));
                
                output.print(genBeginLine());
                output.print(m_className + "::subgoals_by_rule" + staticsSuffix + "[" + rule_num + "].push_back(");
                output.print("JBurgAnnotation<" + iNodeType + ">::JBurgSubgoal(");
                output.print(genGetGoalState(matcher.getSubgoal() ));
                output.print(",");
                if ( matcher.isNary() )
                {
                    output.print("true,");
                    output.print(matcher.getPositionInParent());
                    output.print(",");
                }
                else
                {
                    output.print("false,0,");
                }
                output.print(pattern_init);
                output.print("))");
                output.println(genEndStmt());
            }
        }
        output.print(genEndBlock()); // end ctor
        output.print(genLine("static SubgoalsByRuleInitializerHack init_hack" + staticsSuffix + ";"));
        output.print(genEndBlock()); //  end initializer hack
        output.println(genEndStmt());
        output.println();
	}
	
	

	@Override
    public void emitTrailer(
        String className, 
        String iNodeClass, 
        Set<String> subgoals, 
        Map<String, String> burm_properties, 
        boolean debugMode, 
        String default_error_handler, 
        Map<Integer,String> prologue_blocks,
        PrintStream output
        ) 
    {
		output.print("\n\n\tvoid reduce ( JBurgAnnotation<"+iNodeClass+" >* p, int goalState");

		if (debugMode)
			output.print(", std::ostream &debugOutput ");

		output.print(" )\n\t{");
		output.print("\n\t\tint iRule = -1;");

		output.print(
			"\n\n\t\tif ( goalState > 0 ) {\n\t\t\tiRule = p->getRule(goalState);\n\t\t} else {" +
			"\n\t\t\t//  Find the minimum-cost path.\n\t\t\tint minCost = MAX_INT_VALUE;\n\t\t\t" +
			"for (int i = 0; i <= nStates ; ++i ) {\n\t\t\t\tif ( p->getCost(i) < minCost ) {\n\t\t\t\t\tiRule = p->getRule(i);" +
			"\n\t\t\t\t\tminCost = p->getCost(i);\n\t\t\t\t\tgoalState = i;\n\t\t\t\t}\n\t\t\t}\n\t\t}");

		output.print("\n\n\t\tif ( iRule > 0 )\n\t\t{\n\t\t\t");

		if (debugMode) {
			output.print("\n\t\t\tdebugOutput << \"<reduction>\"; ");
			output.print(
				"\n\t\t\tdebugOutput << \"<node>\" << p->getNode()->toString() << \"</node>\";");
			output.print(
				"\n\t\t\tdebugOutput << \"<goal>\" << stateName[goalState] << \"</goal>\";");
			output.print(
				"\n\t\t\tdebugOutput << \"<rule>\" << iRule << \"</rule>\";\n\n\t\t\t");
			output.print("\n\t\t\tdebugOutput << \"</reduction>\"; ");
		}

		output.print("\n\t\t\treduceAntecedentStates(p, goalState);");

		output.print("\n\t\t\treduceSubgoals(p, iRule);");
		output.print("\n\n\t\t\tdispatchAction ( p, iRule );");
		output.print("\n\t\t}\n\t\telse\n\t\t{");
        if ( default_error_handler != null )
        {
            output.print(default_error_handler);
        }
        else
        {
            output.print(  "\n\t\t\tstd::stringstream s;"
                     + "\n\t\t\ts << \"Unable to find a rule to process \";"
					 + "\n\t\t\ts << p->getNode()->toString();"
					 + "\n\t\t\ts << \" (\" << p->getOperator() << \") {\" << goalState << \"}\";"
					 + "\n\t\t\tthrow new std::runtime_error ( s.str() );"
					 + "\n\t\t}\n\t}\n" );
         }

		output.print("\n\tvoid reduceAntecedentStates( JBurgAnnotation<" + this.iNodeType + " >* p, int goalState)");
		output.print("\n\t{");
		output.print("\n\t\tint   currentState = goalState;");

		output.print("\n\t\tstd::vector<int> antecedent_states;");
		output.print("\n\t\tstd::vector<int> antecedent_rules;");
		output.print("\n");

		output.print("\n\t\t//  If X is antecedent of Y, then the reduce action");
		output.print("\n\t\t//  for X must occur before the reduce action of Y.");
		output.print("\n\t\t//  The antecdents must therefore be processed ");
		output.print("\n\t\t//  from \"back\" to \"front.\"");
		output.print("\n\t\twhile ( p->hasAntecedent(currentState)  )");
		output.print("\n\t\t{");
		output.print("\n\t\t\tcurrentState = p->getAntecedent(currentState);");
		output.print("\n\t\t\tantecedent_states.push_back(currentState);");
		output.print("\n\t\t\tantecedent_rules.push_back(p->getRule(currentState));");
		output.print("\n\t\t}");
		output.print("\n\t\twhile ( ! antecedent_states.empty() )");
		output.print("\n\t\t{");
		output.print("\n\t\t\treduceSubgoals(p, antecedent_rules.back());");
		output.print("\n\t\t\tdispatchAction( p, antecedent_rules.back());");
		output.print("\n\t\t\tantecedent_states.pop_back();");
		output.print("\n\t\t\tantecedent_rules.pop_back();");
		output.print("\n\t\t}");
		output.print("\n\t}");

		output.print("\n\tvoid reduceSubgoals( JBurgAnnotation<" + this.iNodeType + " >* p, int rule_num)");
		output.print("\n\t{");
		output.print("\n\t\tfor ( int i = 0; i < subgoals_by_rule" + staticsSuffix + "[rule_num].size(); i++)");
		output.print("\n\t\t{");
		output.print("\n\t\t\tJBurgAnnotation<" + this.iNodeType + ">::JBurgSubgoal sg = subgoals_by_rule" + staticsSuffix + "[rule_num][i];");
		output.print("\n\t\t\treduce ( sg.getNode(p), sg.getGoalState());");
		output.print("\n\t\t}");
		output.print("\n\t}");

		//  Print the emitter functions.
		output.print("\n\npublic:\n\n");
		output.print("\tvoid burm ( " + iNodeClass + "*" + " root )\n\t{");
        output.print("\t\tburm(root,0);");
        output.print("\t}");
		output.print("\tvoid burm ( " + iNodeClass + "*" + " root, int goal_state )\n\t{");
		output.print("\n\t\tJBurgAnnotation<" + iNodeClass + " >* annotatedTree = label(root);");

		if (debugMode) {
			output.print(
				"\n\n\t\tstatic const char *stateName[] = { \"\" ");

			for (String s : subgoals )
            {
				output.print("\"" + s + "\",");
			}

			output.println("};");
			
			output.println("\t\tthis->stateName = (char**)stateName;");

			output.print(
				"\n\t\tstd::ofstream debugOutput(\"" +
				m_className + "_jburg.xml\");");
			// re-include when the 'finally' statement issue has been resolved
			// output.print("\n\ttry\n\t{");
			output.print("\n\t\t{");
			output.print(
				"\n\t\t\tdebugOutput << \"<?xml version=\\\"1.0\\\"?><jburg><label>\" << std::endl; ");
			output.print("\n\t\t\tdescribeNode(annotatedTree, debugOutput);");
			output.print(
				"\n\t\t\tdebugOutput << \"</label><reductions>\" << std::endl;");
		}

		output.print("\n\t\treduce ( annotatedTree, goal_state");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");");

		if (debugMode) {
			output.print(
				"\n\t\tdebugOutput << \"</reductions></jburg>\" << std::endl;");
			// TODO: what happens with this 'finally' statement...not exactly C++...
			//output.print("\n\t}\n\tfinally\n\t\t{ debugOutput.flush(); }");
			output.print("\n\t\t}\n\t\tdebugOutput.close();");
		}

		output.print("\n\t\tdelete annotatedTree;");
		output.print("\n\t}");
		
		//  getResult() 
		output.print("\n\n\tvoid* getResult() {\n\t\treturn __reducedValues.top();\n\t}");
        output.print("\n");

		if (debugMode)
		{
			//  Print out tree-dumping logic.
			output.print(
				"\n\n\tvoid describeNode ( JBurgAnnotation<"+iNodeClass+" >* node, std::ostream &debugOutput ) ");

			//  Print a table of human-readable state names.

			output.print("\n\t{\n\t\tif ( !node ) return;");
			output.print(
				"\n\t\tdebugOutput << \"<node operator=\\\"\" << node->getOperator() << \"\\\">\" << std::endl;");
			output.print(
				"\n\t\tdebugOutput << \"<selfDescription>\" << node->getNode()->toString() << \"</selfDescription>\";");

			output.print(
				"\n\n\t\tfor (int i = 0; i <= nStates ; i++ )\n\t\t{\n\t\t\tif ( node->getRule(i) != 0 )\n\t\t\t{");
			output.print("\n\t\t\t\tdebugOutput << \"<goal\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" name=\\\"\" << stateName[i] << \"\\\"\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" rule=\\\"\" << node->getRule(i) << \"\\\"\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" cost=\\\"\" << node->getCost(i) << \"\\\"\";");
			output.print("\n\t\t\t\tdebugOutput << \"/>\" << std::endl;");
			output.print("\n\t\t\t}");
			output.print("\n\t\t}");
			output.print("\n\t\tfor(size_t idx = 0; idx < node->getArity(); i++ ) {");
			output.print("\n\t\t\tdescribeNode ( node->getNthChild(idx), debugOutput );");
			output.print("\n\t\t}");
			output.print("\n\t\tdebugOutput << \"</node>\" << std::endl;");
			output.print("\n\t}");
			
			output.print("\tchar **stateName;");

		}

		//  Emit BURM properties and their get/set methods.
		if(burm_properties.size() > 0)
			output.print("\n\npublic:");

		for (String sName : burm_properties.keySet() )
        {
			String sType = burm_properties.get(sName);

			StringBuffer canonicalName = new StringBuffer(sName.toLowerCase());
			canonicalName.setCharAt(0,
				Character.toUpperCase(canonicalName.charAt(0)));

			output.print("\n\n\t//  BURM property, from the specification\n\t");
			output.print(sType + " " + sName + ";");
			output.print("\n\tvoid set" + canonicalName + "(" + sType +
				" setting)\n\t{");
			output.print("\n\t\tthis->" + sName + " = setting;\n\t}");
			output.print("\n\tpublic " + sType + " get" + canonicalName +
				"()\n\t{");
			output.print("\n\t\treturn this->" + sName + ";\n\t}");
		}
		
		//  getNaryCost(node, goalState)
		//  n-ary pattern matchers generate calls to this routine.
		output.print( genBeginLine() );
		output.print("int getNaryCost( JBurgAnnotation<"+iNodeClass+">* node, int goalState, int startIndex)");
		output.print( genBeginBlock() );
		output.print( genLocalVar ( "int", "i", "0" ));
		output.print( genLocalVar ( "int", "accum", "0" ));

		output.print( genBeginLine() );
		output.print( "for ( i = startIndex; i < " + m_inodeAdapter.genGetArity("node", this) + "; i++ )");
		output.print( genBeginBlock() );

		output.print( genBeginLine() );
		output.print( "accum += node->getCost(goalState)");
		output.print( genEndStmt() );

		output.print( genEndBlock() );

		output.print( genBeginLine() );
		output.print( genReturnValue( "accum" ) );
		output.print( genEndStmt() );

		output.print( genEndBlock() );

		//  Close the class definition.
		output.print("\n\n};\n");
		
		//  Emit the static data.
		output.println("std::vector<std::vector<JBurgAnnotation<" + iNodeType +">::JBurgSubgoal> > " + m_className + "::subgoals_by_rule" + staticsSuffix + ";");
		output.println(m_className + "::SubgoalsByRuleInitializerHack " + m_className + "::SubgoalsByRuleInitializerHack::init_hack" + staticsSuffix + ";");

	}

	@Override
    public String genActionRoutineParameter(String stackName, String paramType, String paramName)
	{
		StringBuffer result = new StringBuffer();

		result.append( genBeginLine() );

		if ( hasTrailingStar( paramType ) )
		{
			result.append( "std::auto_ptr<" );
			convertType ( paramType, false, result );
			result.append( "> " );
		}
		else
		{
			convertType( paramType, false, result );
			result.append( " " );
		}

		result.append( paramName );
		result.append( genCast(paramType, stackName + ".top()") );
		result.append( genEndStmt() );

		result.append( stackName + ".pop()" );
		result.append( genEndStmt() );

		return result.toString();
	}

	@Override
    public String genCheckPtr(String paramName, boolean checkForNull) {
		if(checkForNull)
			return new String("!" + paramName);
		return paramName;
	}

	@Override
    public String genAccessMember(String parentName, String memberName) {
		return new String(parentName + "->" + memberName);
	}

	@Override
    public String genCallMethod(String parentName, String methodName, String ... params)
	{
		String s;
		
		if ( parentName != null )
		{
			s = new String(parentName + "->" + methodName + "(");
		}
		else
		{
			s = new String( methodName + "(");
		}

		if(params != null) {
			for(int x=0; x<params.length; ++x) {
				if(x!=0) s += ", ";
				s += params[x];
			}
		}
		s+=")";
		return s;
	}
	
	public EmitCpp() {
		super();
	}

	@Override
    public void emitInclass(String className, Vector<? extends Object> inclassBlocks, PrintStream output) {
		for( Object icb: inclassBlocks ) {
			output.print("\n"+icb.toString()+"\n");
		}
	}

	@Override
    public String genCmpEquality(String lhs, String rhs, boolean bEquality) {
		return new String(lhs + ( bEquality==true ? "==" : "!=" ) + rhs);
	}

	@Override
    public String genLogicalAnd(String lhs, String rhs)
	{
	    if ( lhs != null && rhs != null)
	           return new String(lhs + " && " + rhs);
	       else if ( null == lhs )
	           return rhs;
	       else
	           return lhs;
	}

	@Override
    public boolean accept(String langName)
	{
		boolean accepted = ( langName !=null && langName .equalsIgnoreCase("cpp") );

		return accepted;
	}

	InodeAdapter m_inodeAdapter;
	@Override
    public void setInodeAdapter(InodeAdapter adapter)
	{
		this.m_inodeAdapter = adapter;
	}

	@Override
    public String genIf( String condition )
	{
		return "if ( " + condition + " )";
	}

	@Override
    public String genElse()
	{
		return "else";
	}

	@Override
    public String genBeginBlock()
	{
		//  Replace with " " to get something like 1TBS
		String leadingSpace = genBeginLine();

		blockCount++;
		return leadingSpace + "{" + genBeginLine();
	}

	@Override
    public String genEndBlock()
	{
		blockCount--;

		if ( blockCount < 0 )
		{
			throw new IllegalStateException("Invalid block count " + String.valueOf(blockCount) );
		}

		return genBeginLine() + "}" + genBeginLine();
	}

	@Override
    public String genBeginLine()
	{
		StringBuffer result = new StringBuffer("\n");

		for ( int i = 0; i < blockCount; i++ )
		{
			result.append("\t");
		}

		return result.toString();
	}

	@Override
    public String genCmpLess( String lhs, String rhs )
	{
		return "( " + lhs + " > " + rhs + " ) ";
	}
	
	@Override
    public String genCmpGtEq(String lhs, String rhs)
    {
        return "(" + lhs + " >= " + rhs + ")";
    }

	@Override
    public String genNot( String operand )
	{
		return "!(" + operand + ")";
	}

	@Override
    public String genGetGoalState ( Object p )
    {
       // Enum nonterminals not supported yet.
       return genGetUndecoratedGoalState(p);
    }

    @Override
    public String genGetUndecoratedGoalState ( Object p )
    {
       if ( p instanceof JBurgGenerator.JBurgRule )
           return "__" + ((JBurgGenerator.JBurgRule)p).getGoalState() + "_NT";
       else
           return "__" + p.toString() + "_NT";
    }

	@Override
    public String genComment( String text )
	{
		return "/* " + text + " */\n";
	}

	@Override
    public String genEndStmt()
	{
		return ";" + genBeginLine();
	}

	@Override
    public String genAddition( String a1, String a2 )
	{
		if ( a1.equals("0") )
			return a2;
		if ( a2.equals("0") )
			return a1;
		else
			return " (" + a1 + " + " + a2 + ") ";
	}

	@Override
    public String genAssignment( String lvar, String rvalue )
	{
		return lvar + " = " + rvalue + genEndStmt();
	}

	@Override
    public String genCast( String newClass, String target )
	{
		StringBuffer result = new StringBuffer("((");

		convertType( newClass, true, result );
		result.append(")");
		result.append(target);
		result.append(")");

		return result.toString();
	}

	@Override
    public String genSwitch( String selectionCriterion )
	{
		return "switch( " + selectionCriterion + " )";
	}

	@Override
    public String genEndSwitch()
	{
		return genEndBlock();
	}

	@Override
    public String genCase( String criterionValue )
	{
		return "case " + criterionValue + ":" + genBeginBlock();
	}

	@Override
    public String genEndCase()
	{
		return "break;" + genEndBlock();
	}

	@Override
    public String genLocalVar ( String type, String name, String initializer )
	{
		StringBuffer result = new StringBuffer();

		convertType(type, true, result);

		result.append( " " );
		result.append( name );

		if ( initializer != null )
		{
			result.append(" = ");
			result.append(initializer);
		}

		result.append( genEndStmt() );
		return result.toString();
	}
	
	@Override
    public String genLine(String line)
	{
	    return genBeginLine() + line;
	}

	@SuppressWarnings("rawtypes")
	@Override
    public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
	{
		StringBuffer result = new StringBuffer();

		decodeModifiers(modifiers, result);
		convertType( returnClass, true, result );
		result.append( " " );
		result.append( name );
		result.append( "( " );

		for ( int i = 0; i < plist.length; i++ )
		{
			if ( i > 0 )
			{
				result.append(", " );
			}

			convertType( plist[i][0], true, result );
			result.append( " " );
			result.append( plist[i][1] );
		}

		result.append(" )" );

		//  Igoring exception decls in C++.

		return result.toString();
	}

	@Override
    public String genThrow( String diagnostic )
	{
		return "throw std::string(" + diagnostic + ")";

	}

	@Override
    public String genDefaultCase()
	{
		return "default:";
	}

	@Override
    public String genReturnValue( String value )
	{
		return "return (" + value + ")";
	}

	@Override
    public String genInstanceField ( int modifiers, String type, String name, String initializer )
	{
		StringBuffer result = new StringBuffer();

		decodeModifiers( modifiers, result );
		convertType( type, true, result );

		result.append( " " );
		result.append( name );

		if ( initializer != null )
		{
			result.append( " = " );
			result.append( initializer );
		}

		result.append( genEndStmt() );

		return result.toString();
	}

	private void decodeModifiers( int modifiers, StringBuffer result )
	{
		if ( Modifier.isPublic(modifiers) )
		{
			result.append("public:");
			result.append( genBeginLine() );
		}
		else if ( Modifier.isPrivate(modifiers) )
		{
			result.append("private:");
			result.append( genBeginLine() );
		}

		if ( Modifier.isStatic(modifiers) )
		{
			result.append("static ");
		}

		if ( Modifier.isFinal(modifiers) )
		{
			result.append("const ");
		}
	}

	private boolean hasTrailingStar ( String inType )
	{
		return ( '*' == inType.charAt( inType.length() - 1 ) );
	}

	private void convertType( String inType, boolean isReference, StringBuffer result )
	{
		if ( inType.equals("JBurgAnnotation") )
		{
			//  This is a parameterized type in C++ BURMs.
			result.append("JBurgAnnotation<" + iNodeType + ">");

			if ( isReference && ! hasTrailingStar( inType ) )
			{
				result.append("*");
			}
		}
		else if ( inType.equals(this.iNodeType))
		{
		    result.append(inType);
		    result.append("*");
		}
		else if ( inType.startsWith("int") || inType.startsWith("long") || inType.startsWith("void") || inType.startsWith("std::string") )
		{
			result.append( inType );

			if ( !isReference && hasTrailingStar( inType ) )
			{
				result.deleteCharAt(  result.length() - 1 );
			}
		}
		else if ( inType.equals(genNaryContainerType("void*")) )
		{
			result.append( inType );
			result.append("*");
		}
		else
		{
		    if ( isReference && ! hasTrailingStar( inType ) )
            {
                result.append("*");
            }
		}
	}

	@Override
    public String genMaxIntValue()
	{
		return "MAX_INT_VALUE";
	}

	@Override
    public String genPushToStack(String stackName, String value )
	{
		return String.format("%s.push( (void*)(%s))", stackName, value);
	}

    @Override
    public String genPopFromStack(String stackName, String type)
    {
        return String.format("((%s)%s.pop()", type, stackName);
    }

	@Override
    public String genNewObject( String type, String ... parameters )
	{
		StringBuffer result = new StringBuffer("new ");

		convertType( type, false, result );

		result.append("(");

		if (parameters != null )
		{
			for ( int i = 0; i < parameters.length; i++ )
			{
				if ( i > 0 )
				{
					result.append(",");
				}
				result.append(parameters[i]);
			}
		}

		result.append(")");

		return result.toString();
	}

	@Override
    public String genNullPointer()
	{
		return "NULL";
	}

	@Override
    public String genWhileLoop( String test_condition )
	{
		return "while ( " + test_condition + ")";
	}

	@Override
    public String genNaryContainerType(String base_type)
	{
		return "std::vector<" + base_type + ">";
	}

    @Override
    public String genOverflowSafeAdd(Object expr1, Object expr2)
    {
        if ( expr1 == null || expr1.equals("0") )
            return expr2.toString();
        else if ( expr2 == null || expr2.equals("0") )
            return expr1.toString();
        else
            return String.format("addAllCosts(%s,%s)", expr1, expr2);
    }

    @Override
    public Object getAnnotationType()
    {
        return String.format("JBurgAnnotation<%s>*", this. iNodeType);
    }

    /**
     * Set a default attribute in the template manager.
     * @param key the attribute's name.
     * @param value the attribute's value.
     */
    public void setDefaultAttribute(String key, Object value)
    {
        this.templates.setDefaultAttribute(key, value);
    }
}
