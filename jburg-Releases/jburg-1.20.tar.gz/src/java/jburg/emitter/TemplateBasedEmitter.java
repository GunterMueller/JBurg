package jburg.emitter;

import java.io.PrintStream;
import java.lang.reflect.Modifier;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.Vector;

import jburg.burg.JBurgGenerator;
import jburg.burg.JBurgPatternMatcher;

import jburg.parser.JBurgTokenTypes;

import org.antlr.stringtemplate.*;

/**
 * An emitter that uses string templates to build up constructs.
 */
@SuppressWarnings({"nls","rawtypes"})
public abstract class TemplateBasedEmitter implements EmitLang
{
    /**
     * Construct an emitter and load its templates.
     */
	protected TemplateBasedEmitter(String templateGroupName)
    {
        this.templates = new TemplateGroup("templates", templateGroupName + "Snippets");
        this.boilerplate = new TemplateGroup("templates", templateGroupName + "Boilerplate");
        // Assume the nonterminal names are ints.
        this.ntType = "int";
        this.ntIterator = new CodeFragment("ntIteratorInt");
        this.ntStateName = new CodeFragment("ntStateNameInt");
        // Assume the operator type is int.
        this.operatorType = "int";
	}

    @Override
	public abstract boolean accept(String langName);
    
	/** I-node adapter in use. */
	protected jburg.burg.inode.InodeAdapter inodeAdapter;
	
	/** Prefix to internal BURM names. */
	protected String internalPrefix = "__";

    /** Operator type, defaults to int */
    protected String operatorType;

    /** Nonterminal type, defaults to int */
    protected String ntType;

    /** A for-loop header to iterate over the nonterminals. */
    protected Object ntIterator;

    /** The name of the i'th state */
    protected Object ntStateName;

    /** Enumerated nonterminals don't get decorated. */
    private boolean enumeratedNonterminals = false;

    /**
     * The string templates that build up the pattern matchers and dynamic programming engine.
     */
    protected TemplateGroup templates;

    /**
     * String templates for largely pre-written source, copied into the generated code.
     */
    private TemplateGroup boilerplate;

    public void setOpcodeType(String operator_type)
    {
        this.operatorType = operator_type;
    }

    public void setNtType(String nt_type)
    {
        this.ntType = nt_type;
        this.enumeratedNonterminals = !(nt_type.equals("int"));

        if ( this.enumeratedNonterminals )
        {
            this.ntIterator = new CodeFragment("ntIteratorEnumerated", "ntType", this.ntType );
            this.ntStateName = new CodeFragment("ntStateNameEnumerated");
        }
    }
	
	protected String reducerStack()
	{
	    return internalPrefix + "reducedValues";
	}
	
	protected String subgoalArray()
	{
	    return internalPrefix + "_subgoals_by_rule";
	}
	
	private Stack<CodeFragment> activeBlocks = new Stack<CodeFragment>();

    @Override
    public boolean supportsSpecializedAnnotations()
    {
        return true;
    }

    @Override
    public StringTemplate getTemplate(String name, Object ... attrValue)
    {
        return this.templates.getTemplate(name, attrValue);
    }
    

    @Override
    public void emitHeader(
        String className,
        String packageName,
        String headerBlock,
        String baseClassName,
        Vector<String> interfaceNames,
        boolean debugMode,
        PrintStream output
        )
	{
		int i;

		if (packageName != null)
			output.print(new CodeFragment( "packageHeader", "packageName", packageName ));

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n");
		}

        output.print(new CodeFragment( "classHeader", "className", className, "baseClassName", baseClassName, "interfaceNames", interfaceNames ));
        // The entire class is too large to enclose in a block.
		printFragment(output, "beginEmitterBody", "reducerStack", reducerStack());
	}
    
    /**
     *  Emit the static subgoal arrays.
     */
    public void emitStatics(int max_action, Map<Integer, Vector<JBurgPatternMatcher>> rules_by_action, PrintStream output)
    {
        output.println();
        CodeFragment outerBlock = new CodeFragment("arrayLiteral");
        CodeFragment subgoalTableHeader = new CodeFragment(
            "subgoalTableHeader",
            "subgoalArrayName", subgoalArray(),
            "declContents", outerBlock
        );
        for ( int i = 0; i <= max_action; i++ )
        {
            if ( rules_by_action.containsKey(i))
            {
                CodeFragment innerBlock = new CodeFragment("arrayLiteral");
                // TODO: Parameterize the function
                outerBlock.add(innerBlock);
                
                //  Emit the subgoals in reverse order so they are reduced and pushed
                //  onto the stack in the correct order.
                Vector<JBurgPatternMatcher> matchers = rules_by_action.get(i); 
                for ( int j = matchers.size() -1; j >= 0; j--  )
                {
                    JBurgPatternMatcher matcher = matchers.elementAt(j);
                    Vector<JBurgPatternMatcher.PathElement> accessPath = matcher.generateAccessPath();
                    innerBlock.add(
                        new CodeFragment(
                            "subgoalDeclaration",
                            "subgoal", genGetGoalState(matcher.getSubgoal()),
                            "initialPosition",
                                matcher.isNary() ?
                                    new CodeFragment("subgoalInitialNary", "position", matcher.getPositionInParent()):
                                    new CodeFragment("subgoalInitialFixed"),
                            "accessPath",
                                accessPath.size() > 0?
                                    accessPath:
                                    null
                        )
                    );
                }
            }
            else
            {
                outerBlock.add(new CodeFragment("subgoalMissing"));
            }
        }
        output.println(subgoalTableHeader);
    }


	public void emitAnnotation(String iNodeClass, PrintStream output) 
	{
        output.println(
            boilerplate.getTemplate(
                "annotation",
                "iNodeClass", iNodeClass,
                "opcodeClass", this.operatorType,
                "getOperator", inodeAdapter.genGetOperator("m_node", this),
                "ntType", this.ntType
            )
        );
	}

    @Override
	public void emitTrailer(
			String strClassName, 
			String iNodeClass, 
			Set<String> goalStateNames, 
			Map<String, String> burm_properties, 
			boolean debugMode, 
            String default_error_handler,
            Map<Integer,String> prologue_blocks,
			PrintStream output
		)
	{
        String problemTree = "__problemTree";

        StringTemplate trailer = boilerplate.getTemplate(
            "trailer",
            "iNodeClass", iNodeClass,
            "defaultErrorHandler", default_error_handler,
            "debugMode", new Boolean(debugMode),
            "problemTree", problemTree,
            "ntType", this.ntType,
            "ntIterator", this.ntIterator,
            "wildcardGoal",
                enumeratedNonterminals?
                    new CodeFragment("ntMissingEnumerated"):
                    new CodeFragment("ntMissingInt")
        );

        // Emit prologue blocks if they were specified.
        if ( prologue_blocks.size() > 0 )
        {
            ArrayList<CodeFragment> prologueCases = new ArrayList<CodeFragment>();
            trailer.setAttribute("prologueCases", prologueCases);

            for ( Integer rule: prologue_blocks.keySet() )
            {
                prologueCases.add(new CodeFragment(
                    "switchCase",
                    "label", rule,
                    "contents", prologue_blocks.get(rule)));
            }
        }

		//  Emit BURM properties and their get/set methods.
        for ( Map.Entry entry: burm_properties.entrySet() )
		{
            String propertyName = entry.getKey().toString();
            String propertyType = entry.getValue().toString();

			//  Convert the property's name to canonical form, for inclusion
			//  in the get/set method names.
			StringBuffer canonicalName = new StringBuffer(propertyName.toLowerCase());
			canonicalName.setCharAt( 0, Character.toUpperCase( canonicalName.charAt( 0 )));

            output.println(new CodeFragment(
                "BURMProperty",
                "propertyType", propertyType,
                "propertyName", propertyName,
                "canonicalName", canonicalName
            ).toString());

		}

        output.println(trailer);

		// Emit dump routines.
		if (debugMode) 
		{
            StringTemplate debuggingSupport = boilerplate.getTemplate(
                "debuggingSupport",
                "iNodeClass", iNodeClass,
                "problemTree", problemTree,
                "stateNames", goalStateNames,
                "ntStateName", this.ntStateName,
                "ntIterator", this.ntIterator,
                "getOperator", inodeAdapter.genGetOperator("node.getNode()", this)
            );

			output.println(debuggingSupport);
		}

		//  Emit the JBurgAnnotation classes.
		emitAnnotation(iNodeClass, output);

		//  Close the class definition.
		output.print( genEndClass() );
	}

	public String genActionRoutineParameter(String stackName, String paramType, String paramName)
	{
        return new CodeFragment(
            "actionRoutineParameter",
            "paramType", paramType,
            "paramName", paramName,
            "initialValue", genPopFromStack(stackName, paramType)
        ).toString();
	}

    public String genPopFromStack(String stackName, String valueType)
    {
        return new CodeFragment(
            "popFromStack",
            "valueType", valueType,
            "stackName", stackName
        ).toString();
    }

	public String genPushToStack(String stackName, String value )
	{
        return new CodeFragment(
            "pushToStack",
            "stackName", stackName,
            "value", value
        ).toString();
	}

	public String genCheckPtr(String paramName, boolean checkForNull)
	{
        CodeFragment result = 
            checkForNull?
                new CodeFragment("equals"):
                new CodeFragment("notEquals")
            ;
        result.setAttribute("lhs", paramName);
        result.setAttribute("rhs", "null");
		return result.toString();
	}

	public String genAccessMember(String parentName, String memberName)
	{
		return new CodeFragment(
            "memberAccess",
            "stem", parentName,
            "member", memberName
        ).toString();
	}

	public String genCallMethod(String parentName, String methodName, String ... params)
	{
		return new CodeFragment(
            "callMethod",
            "params", params,
            "nameElements", parentName,
            "nameElements", methodName
        ).toString();
	}
	
	public void setInodeAdapter(jburg.burg.inode.InodeAdapter adapter)
	{
		this.inodeAdapter = adapter;
	}
	
	@Override
	public void emitInclass(String strClassName, Vector<? extends Object> inclassBlocks, PrintStream output) 
	{
		output.println(new CodeFragment("adHocDirectives", "directives", inclassBlocks));
	}

	public String genCmpEquality(String lhs, String rhs, boolean testEquals)
	{
        CodeFragment result = testEquals?
            new CodeFragment("equals", "lhs", lhs, "rhs", rhs):
            new CodeFragment("notEquals", "lhs", lhs, "rhs", rhs);

		return result.toString();
	}

	public String genLogicalAnd(String lhs, String rhs)
	{
	   if ( lhs != null && rhs != null) {
           return new CodeFragment(
               "logicalAnd",
               "lhs", lhs,
               "rhs", rhs
           ).toString();
       } else if ( null == lhs ) {
	       return rhs;
       } else {
	       return lhs;
       }
	}

	public String genIf( String condition )
	{
		return new CodeFragment("if", "condition", condition).toString();
	}


	public String genBeginBlock()
	{
		return " {";
	}

	public String genEndBlock()
	{
		return genBeginLine() + "}";
	}
	
	public String genBeginLine()
	{
		return "\n";
	}

	public String genLine(String line)
    {
		return genBeginLine() + line;
    }

	public String genLine(Object line)
	{
		return genBeginLine() + line.toString();
	}
	
	public String genCmpLess( String lhs, String rhs )
	{
        // FIXME: This is lhs > rhs, i.e., greaterThan
        return new CodeFragment("greaterThan", "lhs", lhs, "rhs", rhs).toString();
	}

	public String genCmpGtEq(String lhs, String rhs)
	{
        return new CodeFragment("greaterThanOrEquals", "lhs", lhs, "rhs", rhs).toString();
	}
	public String genNot( String operand )
	{
        return new CodeFragment("not", "operand", operand).toString();
	}

	public String genGetGoalState(Object p)
	{
       String undecoratedState = genGetUndecoratedGoalState(p);
       return enumeratedNonterminals ?
           new CodeFragment("goalStateEnumerated", "className", this.ntType, "nt", undecoratedState).toString():
           new CodeFragment("goalStateInteger", "nt", undecoratedState).toString()
       ;
	}

    public String genGetUndecoratedGoalState( Object p )
    {
       String rawNT = p instanceof JBurgGenerator.JBurgRule ?
           ((JBurgGenerator.JBurgRule)p).getGoalState():
	       p.toString();

       return enumeratedNonterminals ?
           rawNT:
           new CodeFragment("goalStateUndecorated", "nt", rawNT).toString();
    }

	public String genComment( String text )
	{
        return new CodeFragment("comment", "text", text).toString();
	}

	public String genEndStmt()
	{
        return new CodeFragment("endStatement").toString();
	}

	public String genAddition( String a1, String a2 )
	{
		if ( a1 == null || a1.equals("0") )
			return a2;
		if ( a2 == null || a2.equals("0") )
			return a1;
		else
            return new CodeFragment("add", "lhs", a1, "rhs", a2).toString();
	}

	public String genAssignment( String lvar, String rvalue )
	{
        return new CodeFragment("assign", "lvar", lvar, "rvalue", rvalue).toString();
	}

	public String genCast( String newClass, String target )
	{
		return new CodeFragment("cast", "newClass", newClass, "target", target).toString();
	}

	public String genSwitch( String selectionCriterion )
	{
		return "switch( " + selectionCriterion + " )";
	}

	public String genEndSwitch()
	{
		return genEndBlock();
	}

	public String genCase( String criterionValue )
	{
		return genBeginLine() + "case " + criterionValue + ":" + genBeginBlock();
	}

	public String genEndCase()
	{
		return genLine("break;") + genEndBlock();
	}

	public String genElse()
	{
		return genBeginLine() + "else";
	}

	public String genLocalVar ( String type, String name, String initializer )
	{
		CodeFragment result = new CodeFragment(
                "declareInstanceField",
                "name", name,
                "type", type,
                "initializer", initializer
        );
		return result.toString();
	}

	/**
	 *  Declare a method.
	 *  @param modifiers - java.lang.reflect.Modifier flags for public/private visibility.
	 *  @param returnClass - the method's return type.  null if the method is a constructor.
	 *  @param name - the method's name.
	 *  @param plist - an array of type/name parameter declarations.
	 *  @param exceptions - exceptions the method may throw.  
	 *  @return a snippet with the method's declaration.
	 */
	public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
	{       
		return genLine(methodDeclaration(modifiers,returnClass,name,plist,exceptions));
	}

	private CodeFragment methodDeclaration( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
    {
		CodeFragment result = new CodeFragment(
            "declareMethod",
            "name", name,
            "returnType", returnClass
        );

		decodeModifiers(modifiers, result);

		for ( int i = 0; i < plist.length; i++ )
		{
			if ( plist[i].length != 2 )
				throw new IllegalStateException( "Parameter list elements must be parameter pairs" );

			result.setAttribute("parameters", new CodeFragment("declareFormalParameter", "elements", plist[i]));
		}

        // TODO: Use a renderer so these can go straight in.
		if ( exceptions != null )
        {
			for ( int j = 0; j < exceptions.length; j++ )
				result.setAttribute( "exceptions", exceptions[j].getName() );
		}

        return result;
    }


	public String genThrow( String diagnostic )
	{
		return new CodeFragment("throwDiagnostic", "diagnostic", diagnostic).toString();
	}

	public String genDefaultCase()
	{
		return "default:";
	}

	public String genReturnValue( String value )
	{
		return new CodeFragment( "returnValue", "value", value).toString();
	}

	public String genEndClass()
	{
		return new CodeFragment("endEmitterBody").toString();
	}

	public String genCountingLoop( String controlVar, String startValue, String endValue, boolean inclusive )
	{
        return new CodeFragment(
            "forLoop",
            "controlVar", controlVar,
            "startValue", startValue,
            "endValue", endValue,
            "comparison", (inclusive? "<=":"<")
        ).toString();
	}

	public String genInstanceField ( int modifiers, String type, String name, String initializer )
	{
		CodeFragment result = new CodeFragment(
                "declareInstanceField",
                "name", name,
                "type", type,
                "initializer", initializer
        );

		decodeModifiers(modifiers, result);
		return genLine(result.toString());
	}

	private void decodeModifiers( int modifiers, CodeFragment result )
	{
		if ( Modifier.isPublic( modifiers ) )
			result.setAttribute("modifiers", "public" );
		else if ( Modifier.isProtected( modifiers ) )
			result.setAttribute("modifiers", "protected" );
		else if ( Modifier.isPrivate( modifiers ) )
			result.setAttribute("modifiers", "private" );

		if ( Modifier.isStatic( modifiers ) )
			result.setAttribute("modifiers", "static" );

		if ( Modifier.isFinal( modifiers ) )
			result.setAttribute("modifiers", "final" );
	}

	public String genMaxIntValue()
	{
		return new CodeFragment("maxIntValue").toString();
	}

    @Override
	public String genNewObject( String type, String ... parameters )
	{
        return new CodeFragment(
            "newObject",
            "type", type,
            "parameters", parameters
        ).toString();
	}

    @Override
	public String genNullPointer()
	{
		return "null";
	}

    @Override
	public String genWhileLoop( String test_condition )
	{
		return new CodeFragment(
            "whileHeader",
            "test", test_condition
        ).toString();
	}

    @Override
	public String genNaryContainerType(String contentsType)
	{
        return new CodeFragment("declareContainer", "contentsType", contentsType).toString();
	}
	
    @Override
	public void setINodeType(String inode_type)
	{
	    //  No effect in the Java emitter.
	}

    @Override
    public String genOverflowSafeAdd(Object expr1, Object expr2)
    {
		if ( expr1 == null || expr1.equals("0") )
			return expr2.toString();
		else if ( expr2 == null || expr2.equals("0") )
			return expr1.toString();
        else
            return new CodeFragment("normalizedAdd", "expr1", expr1, "expr2", expr2).toString();
    }

    protected void printFragment(PrintStream output, String name, Object... attributePairs)
    {
        output.print(new CodeFragment(name, attributePairs));
    }

    /**
     * Convenience wrapper around templates.
     */
    protected class CodeFragment
    {
        public CodeFragment(String name, Object... attributePairs)
        {
            this.templ = TemplateBasedEmitter.this.getTemplate(name, attributePairs);
        }

        private StringTemplate templ;

        /**
         * Delegate to the template's setAttribute().
         * @param key the attribute name.  Not required to be unique.
         * @param value the attribute's value (or one of its values).
         * @return the value passed.
         */
        Object setAttribute(String key, Object value)
        {
            this.templ.setAttribute(key, value);
            return value;
        }

        public String toString()
        {
            return this.templ.toString();
        }

        Object add(Object stmt)
        {
            return setAttribute("contents", stmt);
        }
    }

    /**
     * Set a default attribute in the template manager.
     * @param key the attribute's name.
     * @param value the attribute's value.
     */
    public void setDefaultAttribute(String key, Object value)
    {
        this.templates.setDefaultAttribute(key, value);
        this.boilerplate.setDefaultAttribute(key, value);
    }
}
