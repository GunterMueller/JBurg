package jburg.emitter;

@SuppressWarnings({"nls","rawtypes"})
public class EmitJavascript extends TemplateBasedEmitter implements EmitLang
{
    /**
     * Construct an emitter and load its templates.
     */
	public EmitJavascript()
    {
        super("Javascript");
	}

    @Override
	public boolean accept(String langName)
	{
        return "javascript".equalsIgnoreCase(langName);
	}

    @Override
    public Object getAnnotationType()
    {
        // Javascript is typeless.
        return "";
    }
}
