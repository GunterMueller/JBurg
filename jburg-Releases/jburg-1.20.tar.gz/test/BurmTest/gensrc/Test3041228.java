
/*  Generated Wed Mar 13 15:45:15 EDT 2013 by JBurg version 1.20 */

    import java.util.Vector;
    @SuppressWarnings("unchecked")
public class Test3041228  implements burmTest.ArithmeticOpcodes{
    java.util.Stack __reducedValues = new java.util.Stack();


public static final int __expression_NT = 1;
public static final int nStates = 1;

public JBurgAnnotation label(burmTest.TestINode to_be_labelled)  {
    JBurgAnnotation result = null;
    int i = 0;
    int arity = to_be_labelled.getArity();
    result = this.getJBurgAnnotation(to_be_labelled);
    while((arity > i)) {
        result.addChild(this.label(((burmTest.TestINode)to_be_labelled.getNthChild(i))));
        i = (i + 1);
    }
    return (result);
}


/* expression */
private Integer action_1(burmTest.TestINode __p) throws java.lang.Exception {Integer r = (Integer)__reducedValues.pop();Integer lhs = (Integer)__reducedValues.pop();
		{
		    return lhs.intValue() + r.intValue();
		}
}

/* expression */
private Integer action_2(burmTest.TestINode __p) throws java.lang.Exception {
		{
		    return Integer.parseInt(__p.getUserObject().toString());
		}
}

/* expression */
private Integer action_3(burmTest.TestINode __p) throws java.lang.Exception {java.util.Vector<Integer> operands = (java.util.Vector<Integer>)__reducedValues.pop();
		{
		
		    int result = 0;
		
		    for ( Integer i: (java.util.Vector<Integer>)operands )
		    {
		        System.out.println("i is " + i);
		        result += i;
		    }
		
		    return result;
		}
}
private void dispatchAction(JBurgAnnotation ___node,int iRule) throws java.lang.Exception {
burmTest.TestINode __p = ___node.getNode();

switch( iRule ) {
case 1: {
__reducedValues.push(this.action_1(__p));
break;
}
case 2: {
__reducedValues.push(this.action_2(__p));
break;
}
case 3: {
__reducedValues.push(this.action_3(__p));
break;
}
default: {
throw new IllegalStateException("Unmatched reduce action " + iRule);
}
}
}

class JBurgAnnotation_ADD_1_n  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private int cachedCostFor_expression = -1;
    private java.util.Vector<JBurgAnnotation> narySubtrees = new java.util.Vector<JBurgAnnotation>();

    public  JBurgAnnotation_ADD_1_n(burmTest.TestINode node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __expression_NT: {
                result = getCostForRule0(goalState);
                result = Math.min(result,getCostForRule1(goalState));
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __expression_NT: {
                if ((cachedCostFor_expression == -1)) {
                    cachedCostFor_expression = getPatternMatchCost(__expression_NT);
                } 
                result = cachedCostFor_expression;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __expression_NT: {
                int bestCost = Integer.MAX_VALUE;
                int currentCost = getCostForRule0(goalState);
                if ((bestCost > currentCost)) {
                    bestCost = currentCost;
                    rule = 1;
                } 
                currentCost = getCostForRule1(goalState);
                if ((bestCost > currentCost)) {
                    rule = 3;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return ((1 + narySubtrees.size()));
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            default: {
                result = narySubtrees.get((index - 1));
            }
            break;
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else  {
            narySubtrees.add(child);
        } 
    }

    private int getCostForRule0(int goalState)  {
        if ((this.getArity() == 2)) {
            return (normalizedAdd(1, normalizedAdd(this.getNthChild(1).getCost(__expression_NT), this.getNthChild(0).getCost(__expression_NT))));
        } else  {
            return (Integer.MAX_VALUE);
        } 
    }

    private int getCostForRule1(int goalState)  {
        if ((this.getArity() == 1) && (this.getNthChild(0).getArity() >= 1) && (this.getNthChild(0).getOperator() == PAREN)) {
            return (getNaryCost(this.getNthChild(0),__expression_NT,0));
        } else  {
            return (Integer.MAX_VALUE);
        } 
    }
}



class JBurgAnnotation_INT_0  extends JBurgSpecializedAnnotation 
{


    public  JBurgAnnotation_INT_0(burmTest.TestINode node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __expression_NT: {
                result = 1;
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __expression_NT: {
                result = getPatternMatchCost(__expression_NT);
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __expression_NT: {
                rule = 2;
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (0);
    }
}



public JBurgAnnotation getJBurgAnnotation(burmTest.TestINode node)  {
    switch(node.getOperator()) {
        case ADD: {
            if ((node.getArity() >= 1)) {
                return (new JBurgAnnotation_ADD_1_n(node));
            } 
        }
        break;
        case INT: {
            if ((node.getArity() == 0)) {
                return (new JBurgAnnotation_INT_0(node));
            } 
        }
        break;
    }
    return (new PlaceholderAnnotation(node,node.getArity()));
}

private static final JBurgSubgoal[][] ___subgoals_by_rule = 
{
    null,
    {
        new JBurgSubgoal(__expression_NT,false, 0,0),
        new JBurgSubgoal(__expression_NT,false, 0,1)
    },
    null,
    {
        new JBurgSubgoal(__expression_NT,true, 0,0)
    }
};

    /**
     * Reduce a labeled subtree.
     * @param p the annotation describing the root of the subtree.
     * @param goalState the required goal state.
     */
    public void reduce(JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		reduceAntecedent(p,goalState);
		// Release the annotation's data.
		p.release();
	}

    public void reduceAntecedent(JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
        int iRule  = -1;

		if ( ( goalState != 0 )  )
		{
            iRule = p.getRule(goalState);
		}
		else
		{
			// Find the minimum-cost path.
            int minCost  = Integer.MAX_VALUE;

            for(int i = 0; i <= nStates; i++)
			{
				if ( ( minCost > p.getCost(i) )  )
				{
                    iRule = p.getRule(i);
                    minCost = p.getCost(i);
                    goalState = i;
				}
			}
		}
		if ( ( iRule > 0 )  )
		{
			reduceSubgoals(p, iRule);
			dispatchAction(p, iRule );
		}
		else
		{
			throw new IllegalStateException ( String.format("Unable to find a rule to process \"%s\", operator=%s, goal=%s", p, p.getOperator(), goalState) );
		}
	}

    private void reduceSubgoals(JBurgAnnotation p,int rule_num) throws java.lang.Exception
	{
		if ( ___subgoals_by_rule[rule_num] != null )
		{
			for ( JBurgSubgoal sg : ___subgoals_by_rule[rule_num] )
			{
				if ( !sg.isNary() )
				{
					reduce ( sg.getNode(p), sg.getGoalState());
				}
				else
				{
					// Aggregate the operands of an n-ary operator into a single container.
					JBurgAnnotation sub_parent = sg.getNode(p);
					java.util.Vector<Object> variadic_result = new java.util.Vector<Object>(sub_parent.getArity() - sg.startIndex);
					for ( int j = sg.startIndex; j < sub_parent.getArity(); j++ )
					{
						reduce(sub_parent.getNthChild(j), sg.getGoalState());
						variadic_result.add(__reducedValues.pop());
					}
					__reducedValues.push(variadic_result);
				}
			}
		}
	}

    /**
     * Get the cost of an n-ary tail of candidate reductions.
     * @param Node the parent of the candidates.
     * @param goalState the desired goal state.
     * @param startIndex the starting position of
     * the n-ary tail in the parent's children.
     * @return the sum of the n-ary children's costs
     * for the desired goal state, capped at 
     * Integer.MAX_VALUE - 1 if all child costs
     * were strictly less than Integer.MAX_VALUE.
     */
    private int getNaryCost(JBurgAnnotation node, int goalState, int startIndex)
	{
		long accumCost = 0;
		for ( int i = startIndex; accumCost < Integer.MAX_VALUE && i < node.getArity(); i++ )
        {
            // Don't allow the cost of a series of feasible child reductions
            // to rise above MAX_VALUE; the concept of "feasability" and the
            // concept of "cost" need to be disconnected.
            int  childCost = node.getNthChild(i).getCost(goalState);

            if ( childCost >= Integer.MAX_VALUE )
                return Integer.MAX_VALUE;
            else
                accumCost += childCost;
        }

		return accumCost < Integer.MAX_VALUE? (int)accumCost: Integer.MAX_VALUE - 1;
	}
	
    /**
     * Reduce a subtree to the least-cost solution available.
     * @param root the root of the subtree.
     */
    public void burm(burmTest.TestINode root) throws java.lang.Exception
	{
		/* Use the least-cost goal state available. */
		burm(root, 0);
	}
	
    /**
     * Reduce a subtree to a specific goal state.
     * @param root the root of the subtree.
     * @param goal_state the desired goal.
     */
    public void burm(burmTest.TestINode root, int goal_state) throws java.lang.Exception
	{
		JBurgAnnotation annotatedTree = label(root);

		reduce(annotatedTree, goal_state);
	}
	
    /**
     * Get the (presumably only) final
     * result of a series of reductions.
     */
    public Object getResult()
	{
		return __reducedValues.pop();
	}

    /**
     * @return the sum of the input costs, normalized as follows:
     * <li>If either parameter equals Integer.MAX_VALUE, return Integer.MAX_VALUE.
     * <li>If the sum is less than Integer.MAX_VALUE, return the sum.
     * <li>Otherwise return Integer.MAX_VALUE-1.
     */
    public int normalizedAdd(int c1, int c2)
    {
        int result = Integer.MAX_VALUE;

        if ( c1 < Integer.MAX_VALUE && c2 < Integer.MAX_VALUE )
        {
            long accum = (long)c1 + (long)c2;
            result = accum < Integer.MAX_VALUE?
                (int)accum:
                Integer.MAX_VALUE-1;
        }

        return result;
    }
	/** 
     *  JBurgAnnotation is a data structure internal to the
	 *  JBurg-generated BURM that annotates a burmTest.TestINode with
	 *  information used for dynamic programming and reduction.
	 */
	public abstract static class JBurgAnnotation
	{
		/**  The INode this JBurgAnnotation describes.  */
		burmTest.TestINode m_node; 
		JBurgAnnotation ( burmTest.TestINode newNode)
		{
			m_node = newNode;
		}
		/** @return this node's operator. */
		public int getOperator() 
		{
			return m_node.getOperator();
		}

		/** @return this node's wrapped burmTest.TestINode. */ 
		public burmTest.TestINode getNode()  
		{
			return m_node; 
		}

		/** @return the nth child of this node.  */
		public abstract JBurgAnnotation getNthChild(int idx);

		/** @return this node's child count.  */
		public abstract int getArity();

		/** Add a new child to this node.  */
		public abstract void addChild(JBurgAnnotation new_child);

		/** Release this node's data.  */
		public abstract void release();

		/** @return the wrapped node's toString().  */
		public String toString() 
		{
			return m_node.toString(); 
		}

		/** @return the current best cost to reach a goal state.  */
		public abstract int getCost( int goalState ) ;

		/** Set the cost/rule configuration of a goal state.
		 * @throws IllegalArgumentException if this node has a fixed cost/rule.
         */
        public abstract void reset ( int goalState, int cost, int rule );

		/** * @return the rule to fire for a specific goal state. */
		public abstract int getRule ( int goalState ) ;

		/**
		 *  A closure's transformation rule succeeded.
		 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
		 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
		 *  transition back to a goal state that has already been reduced).*/
		public abstract void recordAntecedent ( int iGoalState, int newAntecedentState );
	
	}

    /**
     * Common superclass of node-specific annotations.
     */
	abstract static class JBurgSpecializedAnnotation extends JBurgAnnotation
	{
		JBurgSpecializedAnnotation(burmTest.TestINode node)
		{
			super(node);
		}
		public JBurgAnnotation getNthChild(int idx)
		{
			throw new IllegalStateException(this.getClass().getName() + " has no children.");
		}
		public void addChild(JBurgAnnotation new_child)
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot have children.");
		}
		public void reset ( int goalState, int cost, int rule )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot be reset.");
		}
		public void release ()
		{
		}
		public void recordAntecedent ( int iGoalState, int newAntecedentState )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot record antecedents.");
		}
	}

    /**
     * An annotation that denotes an unused node in the tree.
     */
	private static class PlaceholderAnnotation extends JBurgSpecializedAnnotation
	{
		PlaceholderAnnotation(burmTest.TestINode node, int capacity)
		{
			super(node);
            this.children = new JBurgAnnotation[capacity];
		}

        JBurgAnnotation [] children;
        int actualChildCount = 0;

		public int getRule(int state) { return -1; }
		public int getCost(int state) { return Integer.MAX_VALUE; }
		public int getArity() { return actualChildCount; }

		public JBurgAnnotation getNthChild(int idx)
		{
			return children[idx];
		}
		public void addChild(JBurgAnnotation newChild)
		{
			children[actualChildCount++] = newChild;
		}
	}

    /**
     * An annotation that describes a pattern-match failure.
     */
    private final static JBurgAnnotation errorAnnotation = new JBurgSpecializedAnnotation(null)
    {
		public int getRule(int state) { return -1; }
		public int getCost(int state) { return Integer.MAX_VALUE; }
		public int getArity() { return 0; }
    };

    /**
     * JBurgSubgoal describes a possible reduction of a subtree.
     */
	static class JBurgSubgoal
	{
        /** The goal state that this subgoal produces. */
		private int goalState;
        /** Is this subgoal an n-ary tail? */
		private boolean isNary;
        /** If this is an n-ary subgoal, where does it start? */
		private int startIndex ;
        /** Path from the ancestor node to the root of the subtree. */
		private int[] accessPath ;

        public  JBurgSubgoal(int goal_state,boolean is_nary,int start_index,int... access_path)
		{
			this.goalState = goal_state;
			this.isNary = is_nary;
			this.startIndex = start_index;
			this.accessPath = access_path;
		}
		public int getGoalState() { return this.goalState; }
		public boolean isNary() { return this.isNary; }
        /**
         * Traverse the access path from the ancestor subtree
         * to the root of this subgoal's subtree.
         * @param ancestor the ancestor node.
         */
		public JBurgAnnotation getNode(JBurgAnnotation ancestor)
		{
			JBurgAnnotation result = ancestor;
			for ( int idx: this.accessPath )
				result = result.getNthChild(idx);
			return result;
		}
	
	}
}