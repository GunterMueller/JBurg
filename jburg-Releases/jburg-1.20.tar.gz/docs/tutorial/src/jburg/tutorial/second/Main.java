package jburg.tutorial.second;

import java.io.*;

import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;

/**
 * Parse a source file and generate MIPS assembly.
 */
public class Main
{
    public static void main(String[] argv)
    throws Exception
    {
        CommonTree tree = parse(argv[0]);
        PrintWriter writer = new PrintWriter(argv[1]);
        // Write the source tree for documentation.
        writer.printf( "# %s\n", tree.toStringTree());
        writer.flush();
        writer.println(generateCode(tree));
        writer.close();
    }

    /**
     * Parse the source file.
     * @return the parsed AST.
     */
    private static CommonTree parse(String srcFile)
    throws Exception
    {
        ANTLRInputStream input = new ANTLRInputStream(new FileInputStream(srcFile));
        secondLexer lexer = new secondLexer(input);
        TokenRewriteStream tokens = new TokenRewriteStream(lexer);
        secondParser parser = new secondParser(tokens);
        // TODO: Check for errors in the parse.
        return (CommonTree)parser.compilationUnit().getTree();
    }

    /**
     * Generate code.
     * @param tree the root of the subtree which
     * is to be converted into code.
     */
    private static Object generateCode(CommonTree tree)
    throws Exception
    {
        SecondTreeParser burm = new SecondTreeParser();
        try
        {
            burm.burm(tree);
            return burm.getResult();
        }
        catch ( IllegalStateException ex )
        {
            burm.dump(tree, new PrintWriter("/tmp/failedBurm.xml"));
            throw ex;
        }
    }
}

