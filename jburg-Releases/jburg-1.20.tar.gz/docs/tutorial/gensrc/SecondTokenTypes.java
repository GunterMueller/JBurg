package jburg.tutorial.second;
public abstract class SecondTokenTypes{
  public static final int T__29=29;
  public static final int COMPILATION_UNIT=4;
  public static final int ID=5;
  public static final int INT_TYPE=6;
  public static final int EQUALS=7;
  public static final int PRINT=8;
  public static final int BRACE_START=9;
  public static final int BRACE_END=10;
  public static final int IF=11;
  public static final int PAREN_START=12;
  public static final int PAREN_END=13;
  public static final int ELSE=14;
  public static final int WHILE=15;
  public static final int PLUS=16;
  public static final int MINUS=17;
  public static final int INT_LITERAL=18;
  public static final int STRING_LITERAL=19;
  public static final int EQUAL_EQUAL=20;
  public static final int LT=21;
  public static final int STRING=22;
  public static final int LETTER=23;
  public static final int DIGIT=24;
  public static final int ESC=25;
  public static final int WS=26;
  public static final int COMMENT=27;
  public static final int LINE_COMMENT=28;
}
