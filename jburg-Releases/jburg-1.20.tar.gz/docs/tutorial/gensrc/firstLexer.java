// $ANTLR 3.3 Nov 30, 2010 12:50:56 /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g 2013-03-20 10:47:08

package jburg.tutorial.first;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class firstLexer extends Lexer {
    public static final int EOF=-1;
    public static final int T__16=16;
    public static final int COMPILATION_UNIT=4;
    public static final int ID=5;
    public static final int INT_TYPE=6;
    public static final int EQUALS=7;
    public static final int PRINT=8;
    public static final int PLUS=9;
    public static final int INT_LITERAL=10;
    public static final int LETTER=11;
    public static final int DIGIT=12;
    public static final int WS=13;
    public static final int COMMENT=14;
    public static final int LINE_COMMENT=15;

    // delegates
    // delegators

    public firstLexer() {;} 
    public firstLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public firstLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "/Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g"; }

    // $ANTLR start "T__16"
    public final void mT__16() throws RecognitionException {
        try {
            int _type = T__16;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:7:7: ( ';' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:7:9: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__16"

    // $ANTLR start "EQUALS"
    public final void mEQUALS() throws RecognitionException {
        try {
            int _type = EQUALS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:81:7: ( '=' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:81:8: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "EQUALS"

    // $ANTLR start "INT_TYPE"
    public final void mINT_TYPE() throws RecognitionException {
        try {
            int _type = INT_TYPE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:82:9: ( 'int' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:82:10: 'int'
            {
            match("int"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT_TYPE"

    // $ANTLR start "PLUS"
    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:83:5: ( '+' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:83:6: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PLUS"

    // $ANTLR start "PRINT"
    public final void mPRINT() throws RecognitionException {
        try {
            int _type = PRINT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:84:6: ( 'print' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:84:7: 'print'
            {
            match("print"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PRINT"

    // $ANTLR start "ID"
    public final void mID() throws RecognitionException {
        try {
            int _type = ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:87:5: ( LETTER ( '_' | LETTER | DIGIT )* )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:87:9: LETTER ( '_' | LETTER | DIGIT )*
            {
            mLETTER(); 
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:87:16: ( '_' | LETTER | DIGIT )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='Z')||LA1_0=='_'||(LA1_0>='a' && LA1_0<='z')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ID"

    // $ANTLR start "INT_LITERAL"
    public final void mINT_LITERAL() throws RecognitionException {
        try {
            int _type = INT_LITERAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:90:13: ( ( ( DIGIT )+ ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:90:15: ( ( DIGIT )+ )
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:90:15: ( ( DIGIT )+ )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:90:16: ( DIGIT )+
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:90:16: ( DIGIT )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='0' && LA2_0<='9')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:90:16: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT_LITERAL"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:93:7: ( ( 'a' .. 'z' | 'A' .. 'Z' ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:93:9: ( 'a' .. 'z' | 'A' .. 'Z' )
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "DIGIT"
    public final void mDIGIT() throws RecognitionException {
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:97:2: ( '0' .. '9' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:97:4: '0' .. '9'
            {
            matchRange('0','9'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end "DIGIT"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:99:5: ( ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )+ )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:99:8: ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )+
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:99:8: ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )+
            int cnt3=0;
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>='\t' && LA3_0<='\n')||(LA3_0>='\f' && LA3_0<='\r')||LA3_0==' ') ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt3 >= 1 ) break loop3;
                        EarlyExitException eee =
                            new EarlyExitException(3, input);
                        throw eee;
                }
                cnt3++;
            } while (true);

            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "COMMENT"
    public final void mCOMMENT() throws RecognitionException {
        try {
            int _type = COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:103:5: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:103:9: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:103:14: ( options {greedy=false; } : . )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0=='*') ) {
                    int LA4_1 = input.LA(2);

                    if ( (LA4_1=='/') ) {
                        alt4=2;
                    }
                    else if ( ((LA4_1>='\u0000' && LA4_1<='.')||(LA4_1>='0' && LA4_1<='\uFFFF')) ) {
                        alt4=1;
                    }


                }
                else if ( ((LA4_0>='\u0000' && LA4_0<=')')||(LA4_0>='+' && LA4_0<='\uFFFF')) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:103:42: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            match("*/"); 

            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMENT"

    // $ANTLR start "LINE_COMMENT"
    public final void mLINE_COMMENT() throws RecognitionException {
        try {
            int _type = LINE_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:107:5: ( '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:107:7: '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n'
            {
            match("//"); 

            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:107:12: (~ ( '\\n' | '\\r' ) )*
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>='\u0000' && LA5_0<='\t')||(LA5_0>='\u000B' && LA5_0<='\f')||(LA5_0>='\u000E' && LA5_0<='\uFFFF')) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:107:12: ~ ( '\\n' | '\\r' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop5;
                }
            } while (true);

            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:107:26: ( '\\r' )?
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0=='\r') ) {
                alt6=1;
            }
            switch (alt6) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:107:26: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 
            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LINE_COMMENT"

    public void mTokens() throws RecognitionException {
        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:8: ( T__16 | EQUALS | INT_TYPE | PLUS | PRINT | ID | INT_LITERAL | WS | COMMENT | LINE_COMMENT )
        int alt7=10;
        alt7 = dfa7.predict(input);
        switch (alt7) {
            case 1 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:10: T__16
                {
                mT__16(); 

                }
                break;
            case 2 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:16: EQUALS
                {
                mEQUALS(); 

                }
                break;
            case 3 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:23: INT_TYPE
                {
                mINT_TYPE(); 

                }
                break;
            case 4 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:32: PLUS
                {
                mPLUS(); 

                }
                break;
            case 5 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:37: PRINT
                {
                mPRINT(); 

                }
                break;
            case 6 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:43: ID
                {
                mID(); 

                }
                break;
            case 7 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:46: INT_LITERAL
                {
                mINT_LITERAL(); 

                }
                break;
            case 8 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:58: WS
                {
                mWS(); 

                }
                break;
            case 9 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:61: COMMENT
                {
                mCOMMENT(); 

                }
                break;
            case 10 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:1:69: LINE_COMMENT
                {
                mLINE_COMMENT(); 

                }
                break;

        }

    }


    protected DFA7 dfa7 = new DFA7(this);
    static final String DFA7_eotS =
        "\3\uffff\1\6\1\uffff\1\6\4\uffff\2\6\2\uffff\1\20\1\6\1\uffff\1"+
        "\6\1\23\1\uffff";
    static final String DFA7_eofS =
        "\24\uffff";
    static final String DFA7_minS =
        "\1\11\2\uffff\1\156\1\uffff\1\162\3\uffff\1\52\1\164\1\151\2\uffff"+
        "\1\60\1\156\1\uffff\1\164\1\60\1\uffff";
    static final String DFA7_maxS =
        "\1\172\2\uffff\1\156\1\uffff\1\162\3\uffff\1\57\1\164\1\151\2\uffff"+
        "\1\172\1\156\1\uffff\1\164\1\172\1\uffff";
    static final String DFA7_acceptS =
        "\1\uffff\1\1\1\2\1\uffff\1\4\1\uffff\1\6\1\7\1\10\3\uffff\1\11\1"+
        "\12\2\uffff\1\3\2\uffff\1\5";
    static final String DFA7_specialS =
        "\24\uffff}>";
    static final String[] DFA7_transitionS = {
            "\2\10\1\uffff\2\10\22\uffff\1\10\12\uffff\1\4\3\uffff\1\11\12"+
            "\7\1\uffff\1\1\1\uffff\1\2\3\uffff\32\6\6\uffff\10\6\1\3\6\6"+
            "\1\5\12\6",
            "",
            "",
            "\1\12",
            "",
            "\1\13",
            "",
            "",
            "",
            "\1\14\4\uffff\1\15",
            "\1\16",
            "\1\17",
            "",
            "",
            "\12\6\7\uffff\32\6\4\uffff\1\6\1\uffff\32\6",
            "\1\21",
            "",
            "\1\22",
            "\12\6\7\uffff\32\6\4\uffff\1\6\1\uffff\32\6",
            ""
    };

    static final short[] DFA7_eot = DFA.unpackEncodedString(DFA7_eotS);
    static final short[] DFA7_eof = DFA.unpackEncodedString(DFA7_eofS);
    static final char[] DFA7_min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
    static final char[] DFA7_max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
    static final short[] DFA7_accept = DFA.unpackEncodedString(DFA7_acceptS);
    static final short[] DFA7_special = DFA.unpackEncodedString(DFA7_specialS);
    static final short[][] DFA7_transition;

    static {
        int numStates = DFA7_transitionS.length;
        DFA7_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA7_transition[i] = DFA.unpackEncodedString(DFA7_transitionS[i]);
        }
    }

    class DFA7 extends DFA {

        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = DFA7_eot;
            this.eof = DFA7_eof;
            this.min = DFA7_min;
            this.max = DFA7_max;
            this.accept = DFA7_accept;
            this.special = DFA7_special;
            this.transition = DFA7_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__16 | EQUALS | INT_TYPE | PLUS | PRINT | ID | INT_LITERAL | WS | COMMENT | LINE_COMMENT );";
        }
    }
 

}