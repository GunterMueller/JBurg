// $ANTLR 3.3 Nov 30, 2010 12:50:56 /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g 2013-03-20 10:47:08

package jburg.tutorial.first;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class firstParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "COMPILATION_UNIT", "ID", "INT_TYPE", "EQUALS", "PRINT", "PLUS", "INT_LITERAL", "LETTER", "DIGIT", "WS", "COMMENT", "LINE_COMMENT", "';'"
    };
    public static final int EOF=-1;
    public static final int T__16=16;
    public static final int COMPILATION_UNIT=4;
    public static final int ID=5;
    public static final int INT_TYPE=6;
    public static final int EQUALS=7;
    public static final int PRINT=8;
    public static final int PLUS=9;
    public static final int INT_LITERAL=10;
    public static final int LETTER=11;
    public static final int DIGIT=12;
    public static final int WS=13;
    public static final int COMMENT=14;
    public static final int LINE_COMMENT=15;

    // delegates
    // delegators


        public firstParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public firstParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return firstParser.tokenNames; }
    public String getGrammarFileName() { return "/Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g"; }


    public static class compilationUnit_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compilationUnit"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:22:1: compilationUnit : ( decl | stmt )* EOF -> ^( COMPILATION_UNIT ( decl )* ( stmt )* ) ;
    public final firstParser.compilationUnit_return compilationUnit() throws RecognitionException {
        firstParser.compilationUnit_return retval = new firstParser.compilationUnit_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token EOF3=null;
        firstParser.decl_return decl1 = null;

        firstParser.stmt_return stmt2 = null;


        Object EOF3_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_stmt=new RewriteRuleSubtreeStream(adaptor,"rule stmt");
        RewriteRuleSubtreeStream stream_decl=new RewriteRuleSubtreeStream(adaptor,"rule decl");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:22:16: ( ( decl | stmt )* EOF -> ^( COMPILATION_UNIT ( decl )* ( stmt )* ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:23:5: ( decl | stmt )* EOF
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:23:5: ( decl | stmt )*
            loop1:
            do {
                int alt1=3;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==INT_TYPE) ) {
                    alt1=1;
                }
                else if ( (LA1_0==ID||LA1_0==PRINT) ) {
                    alt1=2;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:23:6: decl
            	    {
            	    pushFollow(FOLLOW_decl_in_compilationUnit57);
            	    decl1=decl();

            	    state._fsp--;

            	    stream_decl.add(decl1.getTree());

            	    }
            	    break;
            	case 2 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:23:11: stmt
            	    {
            	    pushFollow(FOLLOW_stmt_in_compilationUnit59);
            	    stmt2=stmt();

            	    state._fsp--;

            	    stream_stmt.add(stmt2.getTree());

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            EOF3=(Token)match(input,EOF,FOLLOW_EOF_in_compilationUnit63);  
            stream_EOF.add(EOF3);



            // AST REWRITE
            // elements: stmt, decl
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 23:22: -> ^( COMPILATION_UNIT ( decl )* ( stmt )* )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:23:25: ^( COMPILATION_UNIT ( decl )* ( stmt )* )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(COMPILATION_UNIT, "COMPILATION_UNIT"), root_1);

                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:23:44: ( decl )*
                while ( stream_decl.hasNext() ) {
                    adaptor.addChild(root_1, stream_decl.nextTree());

                }
                stream_decl.reset();
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:23:50: ( stmt )*
                while ( stream_stmt.hasNext() ) {
                    adaptor.addChild(root_1, stream_stmt.nextTree());

                }
                stream_stmt.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compilationUnit"

    public static class decl_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "decl"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:29:1: decl : type ID ';' -> ^( type ID ) ;
    public final firstParser.decl_return decl() throws RecognitionException {
        firstParser.decl_return retval = new firstParser.decl_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ID5=null;
        Token char_literal6=null;
        firstParser.type_return type4 = null;


        Object ID5_tree=null;
        Object char_literal6_tree=null;
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_16=new RewriteRuleTokenStream(adaptor,"token 16");
        RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:29:5: ( type ID ';' -> ^( type ID ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:29:7: type ID ';'
            {
            pushFollow(FOLLOW_type_in_decl89);
            type4=type();

            state._fsp--;

            stream_type.add(type4.getTree());
            ID5=(Token)match(input,ID,FOLLOW_ID_in_decl91);  
            stream_ID.add(ID5);

            char_literal6=(Token)match(input,16,FOLLOW_16_in_decl93);  
            stream_16.add(char_literal6);



            // AST REWRITE
            // elements: ID, type
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 29:19: -> ^( type ID )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:29:22: ^( type ID )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_type.nextNode(), root_1);

                adaptor.addChild(root_1, stream_ID.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "decl"

    public static class type_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "type"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:32:1: type : INT_TYPE ;
    public final firstParser.type_return type() throws RecognitionException {
        firstParser.type_return retval = new firstParser.type_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token INT_TYPE7=null;

        Object INT_TYPE7_tree=null;

        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:32:5: ( INT_TYPE )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:32:7: INT_TYPE
            {
            root_0 = (Object)adaptor.nil();

            INT_TYPE7=(Token)match(input,INT_TYPE,FOLLOW_INT_TYPE_in_type113); 
            INT_TYPE7_tree = (Object)adaptor.create(INT_TYPE7);
            adaptor.addChild(root_0, INT_TYPE7_tree);


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "type"

    public static class stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "stmt"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:38:1: stmt : ( assignment | pseudo );
    public final firstParser.stmt_return stmt() throws RecognitionException {
        firstParser.stmt_return retval = new firstParser.stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        firstParser.assignment_return assignment8 = null;

        firstParser.pseudo_return pseudo9 = null;



        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:38:5: ( assignment | pseudo )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==ID) ) {
                alt2=1;
            }
            else if ( (LA2_0==PRINT) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:38:7: assignment
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_assignment_in_stmt127);
                    assignment8=assignment();

                    state._fsp--;

                    adaptor.addChild(root_0, assignment8.getTree());

                    }
                    break;
                case 2 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:39:7: pseudo
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_pseudo_in_stmt135);
                    pseudo9=pseudo();

                    state._fsp--;

                    adaptor.addChild(root_0, pseudo9.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "stmt"

    public static class assignment_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:42:1: assignment : ID EQUALS expression ';' -> ^( EQUALS ID expression ) ;
    public final firstParser.assignment_return assignment() throws RecognitionException {
        firstParser.assignment_return retval = new firstParser.assignment_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ID10=null;
        Token EQUALS11=null;
        Token char_literal13=null;
        firstParser.expression_return expression12 = null;


        Object ID10_tree=null;
        Object EQUALS11_tree=null;
        Object char_literal13_tree=null;
        RewriteRuleTokenStream stream_EQUALS=new RewriteRuleTokenStream(adaptor,"token EQUALS");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_16=new RewriteRuleTokenStream(adaptor,"token 16");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:42:11: ( ID EQUALS expression ';' -> ^( EQUALS ID expression ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:42:13: ID EQUALS expression ';'
            {
            ID10=(Token)match(input,ID,FOLLOW_ID_in_assignment147);  
            stream_ID.add(ID10);

            EQUALS11=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_assignment149);  
            stream_EQUALS.add(EQUALS11);

            pushFollow(FOLLOW_expression_in_assignment151);
            expression12=expression();

            state._fsp--;

            stream_expression.add(expression12.getTree());
            char_literal13=(Token)match(input,16,FOLLOW_16_in_assignment153);  
            stream_16.add(char_literal13);



            // AST REWRITE
            // elements: EQUALS, expression, ID
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 42:38: -> ^( EQUALS ID expression )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:42:41: ^( EQUALS ID expression )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_EQUALS.nextNode(), root_1);

                adaptor.addChild(root_1, stream_ID.nextNode());
                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment"

    public static class pseudo_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pseudo"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:48:1: pseudo : PRINT expression ';' -> ^( PRINT expression ) ;
    public final firstParser.pseudo_return pseudo() throws RecognitionException {
        firstParser.pseudo_return retval = new firstParser.pseudo_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PRINT14=null;
        Token char_literal16=null;
        firstParser.expression_return expression15 = null;


        Object PRINT14_tree=null;
        Object char_literal16_tree=null;
        RewriteRuleTokenStream stream_PRINT=new RewriteRuleTokenStream(adaptor,"token PRINT");
        RewriteRuleTokenStream stream_16=new RewriteRuleTokenStream(adaptor,"token 16");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:48:7: ( PRINT expression ';' -> ^( PRINT expression ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:49:5: PRINT expression ';'
            {
            PRINT14=(Token)match(input,PRINT,FOLLOW_PRINT_in_pseudo182);  
            stream_PRINT.add(PRINT14);

            pushFollow(FOLLOW_expression_in_pseudo184);
            expression15=expression();

            state._fsp--;

            stream_expression.add(expression15.getTree());
            char_literal16=(Token)match(input,16,FOLLOW_16_in_pseudo186);  
            stream_16.add(char_literal16);



            // AST REWRITE
            // elements: expression, PRINT
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 49:26: -> ^( PRINT expression )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:49:29: ^( PRINT expression )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_PRINT.nextNode(), root_1);

                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;
            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pseudo"

    public static class expression_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:58:1: expression : ( term | term ( PLUS term )+ -> ^( PLUS ( term )+ ) );
    public final firstParser.expression_return expression() throws RecognitionException {
        firstParser.expression_return retval = new firstParser.expression_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PLUS19=null;
        firstParser.term_return term17 = null;

        firstParser.term_return term18 = null;

        firstParser.term_return term20 = null;


        Object PLUS19_tree=null;
        RewriteRuleTokenStream stream_PLUS=new RewriteRuleTokenStream(adaptor,"token PLUS");
        RewriteRuleSubtreeStream stream_term=new RewriteRuleSubtreeStream(adaptor,"rule term");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:58:11: ( term | term ( PLUS term )+ -> ^( PLUS ( term )+ ) )
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==ID||LA4_0==INT_LITERAL) ) {
                int LA4_1 = input.LA(2);

                if ( (LA4_1==16) ) {
                    alt4=1;
                }
                else if ( (LA4_1==PLUS) ) {
                    alt4=2;
                }
                else {
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 1, input);

                    throw nvae;
                }
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:59:5: term
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_term_in_expression212);
                    term17=term();

                    state._fsp--;

                    adaptor.addChild(root_0, term17.getTree());

                    }
                    break;
                case 2 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:61:5: term ( PLUS term )+
                    {
                    pushFollow(FOLLOW_term_in_expression224);
                    term18=term();

                    state._fsp--;

                    stream_term.add(term18.getTree());
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:61:10: ( PLUS term )+
                    int cnt3=0;
                    loop3:
                    do {
                        int alt3=2;
                        int LA3_0 = input.LA(1);

                        if ( (LA3_0==PLUS) ) {
                            alt3=1;
                        }


                        switch (alt3) {
                    	case 1 :
                    	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:61:11: PLUS term
                    	    {
                    	    PLUS19=(Token)match(input,PLUS,FOLLOW_PLUS_in_expression227);  
                    	    stream_PLUS.add(PLUS19);

                    	    pushFollow(FOLLOW_term_in_expression229);
                    	    term20=term();

                    	    state._fsp--;

                    	    stream_term.add(term20.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt3 >= 1 ) break loop3;
                                EarlyExitException eee =
                                    new EarlyExitException(3, input);
                                throw eee;
                        }
                        cnt3++;
                    } while (true);



                    // AST REWRITE
                    // elements: PLUS, term
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 61:23: -> ^( PLUS ( term )+ )
                    {
                        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:61:26: ^( PLUS ( term )+ )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_PLUS.nextNode(), root_1);

                        if ( !(stream_term.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_term.hasNext() ) {
                            adaptor.addChild(root_1, stream_term.nextTree());

                        }
                        stream_term.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class term_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "term"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:64:1: term : factor ;
    public final firstParser.term_return term() throws RecognitionException {
        firstParser.term_return retval = new firstParser.term_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        firstParser.factor_return factor21 = null;



        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:64:5: ( factor )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:65:5: factor
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_factor_in_term256);
            factor21=factor();

            state._fsp--;

            adaptor.addChild(root_0, factor21.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "term"

    public static class factor_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "factor"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:68:1: factor : primary ;
    public final firstParser.factor_return factor() throws RecognitionException {
        firstParser.factor_return retval = new firstParser.factor_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        firstParser.primary_return primary22 = null;



        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:68:7: ( primary )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:69:5: primary
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_primary_in_factor272);
            primary22=primary();

            state._fsp--;

            adaptor.addChild(root_0, primary22.getTree());

            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "factor"

    public static class primary_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "primary"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:72:1: primary : ( ID | INT_LITERAL );
    public final firstParser.primary_return primary() throws RecognitionException {
        firstParser.primary_return retval = new firstParser.primary_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set23=null;

        Object set23_tree=null;

        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:72:8: ( ID | INT_LITERAL )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/first/first.g:
            {
            root_0 = (Object)adaptor.nil();

            set23=(Token)input.LT(1);
            if ( input.LA(1)==ID||input.LA(1)==INT_LITERAL ) {
                input.consume();
                adaptor.addChild(root_0, (Object)adaptor.create(set23));
                state.errorRecovery=false;
            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "primary"

    // Delegated rules


 

    public static final BitSet FOLLOW_decl_in_compilationUnit57 = new BitSet(new long[]{0x0000000000000160L});
    public static final BitSet FOLLOW_stmt_in_compilationUnit59 = new BitSet(new long[]{0x0000000000000160L});
    public static final BitSet FOLLOW_EOF_in_compilationUnit63 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_decl89 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_ID_in_decl91 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_decl93 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INT_TYPE_in_type113 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignment_in_stmt127 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_pseudo_in_stmt135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_assignment147 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_EQUALS_in_assignment149 = new BitSet(new long[]{0x0000000000000420L});
    public static final BitSet FOLLOW_expression_in_assignment151 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_assignment153 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRINT_in_pseudo182 = new BitSet(new long[]{0x0000000000000420L});
    public static final BitSet FOLLOW_expression_in_pseudo184 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_16_in_pseudo186 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term_in_expression212 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term_in_expression224 = new BitSet(new long[]{0x0000000000000200L});
    public static final BitSet FOLLOW_PLUS_in_expression227 = new BitSet(new long[]{0x0000000000000420L});
    public static final BitSet FOLLOW_term_in_expression229 = new BitSet(new long[]{0x0000000000000202L});
    public static final BitSet FOLLOW_factor_in_term256 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_primary_in_factor272 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_primary0 = new BitSet(new long[]{0x0000000000000002L});

}