package jburg.tutorial.first;
public abstract class TokenTypes{
  public static final int T__16=16;
  public static final int COMPILATION_UNIT=4;
  public static final int ID=5;
  public static final int INT_TYPE=6;
  public static final int EQUALS=7;
  public static final int PRINT=8;
  public static final int PLUS=9;
  public static final int INT_LITERAL=10;
  public static final int LETTER=11;
  public static final int DIGIT=12;
  public static final int WS=13;
  public static final int COMMENT=14;
  public static final int LINE_COMMENT=15;
}
