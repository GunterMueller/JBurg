
/*  Generated Wed Mar 20 10:47:09 EDT 2013 by JBurg version 1.20 */
package jburg.tutorial.second;
    import java.util.ArrayList;
    import java.util.List;

    import org.antlr.runtime.tree.*;
    import org.antlr.stringtemplate.*;

    import jburg.tutorial.common.TemplateManager;

    // TokenTypes is a class generated from ANTLR's
    // tokens file; these constants are the "opcodes"
    // of the ANTLR-generated AST.
    import static jburg.tutorial.second.SecondTokenTypes.*;
public class SecondTreeParser  {
    java.util.Stack __reducedValues = new java.util.Stack();
    /**
     * Back end: StringTemplate manager.
     */
    private TemplateManager templateManager = new TemplateManager("templates", "MIPS");

    /**
     * Stack management: since this compiler only handles int values,
     * its locals are always one word long. The stack manager is a
     * simple list of names, and assumes they're all one word long.
     */
    private List<String> localVariables = new ArrayList<String>();

    /**
     * Declare a local variable.
     * @param varName the variable's name.
     * @throws IllegalStateException if
     * the variable is already declared.
     */
    private void declareVariable(String varName)
    {
        if ( localVariables.contains(varName) )
            throw new IllegalStateException(String.format("Reference to undefined name %s",varName));
        localVariables.add(varName);
    }

    /**
     * Get the offset of a local variable.
     * @param varName the variable's name.
     * @return the corresponding offset.
     * @throws IllegalStateException if the variable
     * name is not declared.
     */
    private int offsetOf(String varName)
    {
        int index = localVariables.indexOf(varName);
        if ( index >= 0 )
            return index * sizeOfInt;
        else
            throw new IllegalStateException(String.format("Reference to undefined name %s",varName));
    }

    /** Size of an int variable in this system. */
    public static final int sizeOfInt = 4;

    /**
     * Data Segment management: a list of
     * the templates that declare intialized data items.
     */
    List<Object> dataSegmentItems = new ArrayList<Object>();

    /**
     * Register allocation: next available temp register.
     * Note that no register spill facility is available,
     * so computations can't be very deeply nested or the
     * compiler will exhaust its supply of temps.
     */
    int nextTemp = 0;

    /**
     * Register allocation:
     * Allocate a temporary register for a computation.
     * @param template the template that requires a temp register.
     * The template must refer to this register as &lt;register&gt;.
     * @return the template.
     */
    private StringTemplate allocateTemp(StringTemplate template)
    {
        if ( nextTemp < 7 )
            template.setAttribute("register", String.format("$t%d", nextTemp++));
        else
            throw new IllegalStateException("out of temporary registers.");

        return template;
    }

    /**
     * Register allocation: reset the temp register.
     * @param template a template (typically a statement)
     * that guarantees no temps are live past its boundaries.
     * @return the given template.
     */
    private StringTemplate resetTemps(StringTemplate template)
    {
        this.nextTemp = 0;
        return template;
    }

    /**
     * Control flow management:
     * Next available label number.
     */
    private int nextLabel = 0;


public static final int __stringExpression_NT = 1;
public static final int __statement_NT = 2;
public static final int __intConstant_NT = 3;
public static final int __compilationUnit_NT = 4;
public static final int __name_NT = 5;
public static final int __conditional_NT = 6;
public static final int __intExpression_NT = 7;
public static final int __stringConstant_NT = 8;
public static final int nStates = 8;

public JBurgAnnotation label(CommonTree to_be_labelled)  {
    JBurgAnnotation result = null;
    int i = 0;
    int arity = to_be_labelled.getChildCount();
    result = this.getJBurgAnnotation(to_be_labelled);
    while((arity > i)) {
        result.addChild(this.label(((CommonTree)to_be_labelled.getChild(i))));
        i = (i + 1);
    }
    return (result);
}


/* compilationUnit */
private Object action_1(CommonTree __p) throws java.lang.Exception {java.util.Vector<Object> statements = (java.util.Vector<Object>)__reducedValues.pop();
		{
		    return templateManager.getTemplate(
		        "compilationUnit",
		        "textSegmentItems", statements,
		        "dataSegmentItems", this.dataSegmentItems
		    );
		}
}

/* statement */
private Object action_2(CommonTree __p) throws java.lang.Exception {String name = (String)__reducedValues.pop();
		{
		    this.declareVariable(name);
		    return null;
		}
}

/* statement */
private Object action_3(CommonTree __p) throws java.lang.Exception {Object rvalue = (Object)__reducedValues.pop();String lvalue = (String)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate("storeLocal", "offset", offsetOf(lvalue), "rvalue", rvalue));
		}
}

/* statement */
private Object action_4(CommonTree __p) throws java.lang.Exception {Object consequent = (Object)__reducedValues.pop();Object rhs = (Object)__reducedValues.pop();Object lhs = (Object)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate(
		        "ifThenEQ",
		        "lhs", lhs,
		        "rhs", rhs,
		        "consequent", consequent,
		        "branchOutLabelID", nextLabel++
		    ));
		}
}

/* statement */
private Object action_5(CommonTree __p) throws java.lang.Exception {Object elseClause = (Object)__reducedValues.pop();Object consequent = (Object)__reducedValues.pop();Object rhs = (Object)__reducedValues.pop();Object lhs = (Object)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate(
		        "ifThenElseEQ",
		        "lhs", lhs, "rhs", rhs,
		        "consequent", consequent,
		        "elseClause", elseClause,
		        "branchOutLabelID", nextLabel++,
		        "elseLabelID", nextLabel++
		    ));
		}
}

/* statement */
private Object action_6(CommonTree __p) throws java.lang.Exception {Object consequent = (Object)__reducedValues.pop();Object condition = (Object)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate(
		        "ifThen",
		        "condition", condition,
		        "consequent", consequent,
		        "branchOutLabelID", nextLabel++
		    ));
		}
}

/* statement */
private Object action_7(CommonTree __p) throws java.lang.Exception {Object elseClause = (Object)__reducedValues.pop();Object consequent = (Object)__reducedValues.pop();Object condition = (Object)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate(
		        "ifThenElse",
		        "condition", condition,
		        "consequent", consequent,
		        "elseClause", elseClause,
		        "branchOutLabelID", nextLabel++,
		        "elseLabelID", nextLabel++
		    ));
		}
}

/* statement */
private Object action_8(CommonTree __p) throws java.lang.Exception {Object body = (Object)__reducedValues.pop();Object condition = (Object)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate(
		        "while",
		        "condition", condition,
		        "body", body,
		        "loopHeadLabelID", nextLabel++,
		        "branchOutLabelID", nextLabel++
		    ));
		}
}

/* statement */
private Object action_9(CommonTree __p) throws java.lang.Exception {Object expr = (Object)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate("printInteger", "expr", expr));
		}
}

/* statement */
private Object action_10(CommonTree __p) throws java.lang.Exception {Object expr = (Object)__reducedValues.pop();
		{
		    return resetTemps(templateManager.getTemplate("printString", "expr", expr));
		}
}

/* statement */
private Object action_11(CommonTree __p) throws java.lang.Exception {java.util.Vector<Object> contents = (java.util.Vector<Object>)__reducedValues.pop();
		{
		    return templateManager.getTemplate("block", "contents", contents);
		}
}

/* intExpression */
private Object action_12(CommonTree __p) throws java.lang.Exception {Object rhs = (Object)__reducedValues.pop();Object lhs = (Object)__reducedValues.pop();
		{
		    return allocateTemp(templateManager.getTemplate("add", "lhs", lhs, "rhs", rhs));
		}
}

/* intExpression */
private Object action_13(CommonTree __p) throws java.lang.Exception {Object rhs = (Object)__reducedValues.pop();Object lhs = (Object)__reducedValues.pop();
		{
		    return allocateTemp(templateManager.getTemplate("sub", "lhs", lhs, "rhs", rhs));
		}
}

/* intExpression */
private Object action_14(CommonTree __p) throws java.lang.Exception {Integer intConstant = (Integer)__reducedValues.pop();
		{
		    return allocateTemp(templateManager.getTemplate("li", "expr", intConstant));
		}
}

/* intExpression */
private Object action_15(CommonTree __p) throws java.lang.Exception {String name = (String)__reducedValues.pop();
		{
		    return allocateTemp(templateManager.getTemplate("loadLocal", "offset", offsetOf(name)));
		}
}

/* stringExpression */
private Object action_16(CommonTree __p) throws java.lang.Exception {Object stringConstant = (Object)__reducedValues.pop();
		{
		    String name = String.format("__literal_x%h", this.dataSegmentItems.size());
		    this.dataSegmentItems.add(
		        templateManager.getTemplate(
		            "declareStringConstant",
		            "name", name,
		            "initializer", stringConstant
		        )
		    );
		
		    return allocateTemp(templateManager.getTemplate("la", "lvalue", name));
		}
}

/* conditional */
private Object action_17(CommonTree __p) throws java.lang.Exception {Object rhs = (Object)__reducedValues.pop();Object lhs = (Object)__reducedValues.pop();
		{
		    return allocateTemp(templateManager.getTemplate("lt", "lhs", lhs, "rhs", rhs));
		}
}

/* name */
private String action_18(CommonTree __p) throws java.lang.Exception {
		{
		    return __p.getText();
		}
}

/* intConstant */
private Integer action_19(CommonTree __p) throws java.lang.Exception {
		{
		    return Integer.parseInt(__p.getText());
		}
}

/* stringConstant */
private Object action_20(CommonTree __p) throws java.lang.Exception {
		{
		    return __p.getText();
		}
}
private void dispatchAction(JBurgAnnotation ___node,int iRule) throws java.lang.Exception {
CommonTree __p = ___node.getNode();

switch( iRule ) {
case 1: {
__reducedValues.push(this.action_1(__p));
break;
}
case 2: {
__reducedValues.push(this.action_2(__p));
break;
}
case 3: {
__reducedValues.push(this.action_3(__p));
break;
}
case 4: {
__reducedValues.push(this.action_4(__p));
break;
}
case 5: {
__reducedValues.push(this.action_5(__p));
break;
}
case 6: {
__reducedValues.push(this.action_6(__p));
break;
}
case 7: {
__reducedValues.push(this.action_7(__p));
break;
}
case 8: {
__reducedValues.push(this.action_8(__p));
break;
}
case 9: {
__reducedValues.push(this.action_9(__p));
break;
}
case 10: {
__reducedValues.push(this.action_10(__p));
break;
}
case 11: {
__reducedValues.push(this.action_11(__p));
break;
}
case 12: {
__reducedValues.push(this.action_12(__p));
break;
}
case 13: {
__reducedValues.push(this.action_13(__p));
break;
}
case 14: {
this.reduceAntecedent(___node,__intConstant_NT);
__reducedValues.push(this.action_14(__p));
break;
}
case 15: {
this.reduceAntecedent(___node,__name_NT);
__reducedValues.push(this.action_15(__p));
break;
}
case 16: {
this.reduceAntecedent(___node,__stringConstant_NT);
__reducedValues.push(this.action_16(__p));
break;
}
case 17: {
__reducedValues.push(this.action_17(__p));
break;
}
case 18: {
__reducedValues.push(this.action_18(__p));
break;
}
case 19: {
__reducedValues.push(this.action_19(__p));
break;
}
case 20: {
__reducedValues.push(this.action_20(__p));
break;
}
default: {
throw new IllegalStateException("Unmatched reduce action " + iRule);
}
}
}

class JBurgAnnotation_BRACE_START_0_n  extends JBurgSpecializedAnnotation 
{

    private int cachedCostFor_statement = -1;
    private java.util.Vector<JBurgAnnotation> narySubtrees = new java.util.Vector<JBurgAnnotation>();

    public  JBurgAnnotation_BRACE_START_0_n(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                result = normalizedAdd(1, getNaryCost(this,__statement_NT,0));
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                if ((cachedCostFor_statement == -1)) {
                    cachedCostFor_statement = getPatternMatchCost(__statement_NT);
                } 
                result = cachedCostFor_statement;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __statement_NT: {
                if ((Integer.MAX_VALUE > normalizedAdd(1, getNaryCost(this,__statement_NT,0)))) {
                    rule = 11;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (narySubtrees.size());
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            default: {
                result = narySubtrees.get(index);
            }
            break;
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        narySubtrees.add(child);
    }
}



class JBurgAnnotation_COMPILATION_UNIT_0_n  extends JBurgSpecializedAnnotation 
{

    private int cachedCostFor_compilationUnit = -1;
    private java.util.Vector<JBurgAnnotation> narySubtrees = new java.util.Vector<JBurgAnnotation>();

    public  JBurgAnnotation_COMPILATION_UNIT_0_n(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __compilationUnit_NT: {
                result = normalizedAdd(1, getNaryCost(this,__statement_NT,0));
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __compilationUnit_NT: {
                if ((cachedCostFor_compilationUnit == -1)) {
                    cachedCostFor_compilationUnit = getPatternMatchCost(__compilationUnit_NT);
                } 
                result = cachedCostFor_compilationUnit;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __compilationUnit_NT: {
                if ((Integer.MAX_VALUE > normalizedAdd(1, getNaryCost(this,__statement_NT,0)))) {
                    rule = 1;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (narySubtrees.size());
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            default: {
                result = narySubtrees.get(index);
            }
            break;
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        narySubtrees.add(child);
    }
}



class JBurgAnnotation_EQUALS_2  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private JBurgAnnotation subtree1;
    private int cachedCostFor_statement = -1;

    public  JBurgAnnotation_EQUALS_2(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                result = getCostForRule0(goalState);
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                if ((cachedCostFor_statement == -1)) {
                    cachedCostFor_statement = getPatternMatchCost(__statement_NT);
                } 
                result = cachedCostFor_statement;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __statement_NT: {
                if ((Integer.MAX_VALUE > getCostForRule0(goalState))) {
                    rule = 3;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (2);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            case 1: {
                result = subtree1;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else if ( subtree1 == null ) {
            subtree1 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule0(int goalState)  {
        return (normalizedAdd(1, normalizedAdd(this.getNthChild(1).getCost(__intExpression_NT), this.getNthChild(0).getCost(__name_NT))));
    }
}



class JBurgAnnotation_ID_0  extends JBurgSpecializedAnnotation 
{


    public  JBurgAnnotation_ID_0(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __name_NT: {
                result = 1;
            }
            break;
        }
        return (result);
    }

    private int getClosureCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intExpression_NT: {
                int cost_name = this.getPatternMatchCost(__name_NT);
                int cost_intExpression = normalizedAdd(1, cost_name);
                result = cost_intExpression;
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intExpression_NT: {
                result = getClosureCost(__intExpression_NT);
            }
            break;
            case __name_NT: {
                result = getPatternMatchCost(__name_NT);
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __intExpression_NT: {
                rule = 15;
            }
            break;
            case __name_NT: {
                rule = 18;
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (0);
    }
}



class JBurgAnnotation_IF_2  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private JBurgAnnotation subtree1;
    private int cachedCostFor_statement = -1;

    public  JBurgAnnotation_IF_2(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                result = getCostForRule1(goalState);
                result = Math.min(result,getCostForRule2(goalState));
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                if ((cachedCostFor_statement == -1)) {
                    cachedCostFor_statement = getPatternMatchCost(__statement_NT);
                } 
                result = cachedCostFor_statement;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __statement_NT: {
                int bestCost = Integer.MAX_VALUE;
                int currentCost = getCostForRule1(goalState);
                if ((bestCost > currentCost)) {
                    bestCost = currentCost;
                    rule = 4;
                } 
                currentCost = getCostForRule2(goalState);
                if ((bestCost > currentCost)) {
                    rule = 6;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (2);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            case 1: {
                result = subtree1;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else if ( subtree1 == null ) {
            subtree1 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule1(int goalState)  {
        JBurgAnnotation factoredPath_0 = (this.getNthChild(0).getArity() > 0? this.getNthChild(0).getNthChild(0): errorAnnotation);
        JBurgAnnotation factoredPath_1 = (this.getNthChild(0).getArity() > 1? this.getNthChild(0).getNthChild(1): errorAnnotation);
        if ((this.getNthChild(0).getArity() == 2) && (this.getNthChild(0).getOperator() == EQUAL_EQUAL)) {
            return (normalizedAdd(1, normalizedAdd(normalizedAdd(this.getNthChild(1).getCost(__statement_NT), factoredPath_1.getCost(__intExpression_NT)), factoredPath_0.getCost(__intExpression_NT))));
        } else  {
            return (Integer.MAX_VALUE);
        } 
    }

    private int getCostForRule2(int goalState)  {
        return (normalizedAdd(5, normalizedAdd(this.getNthChild(1).getCost(__statement_NT), this.getNthChild(0).getCost(__conditional_NT))));
    }
}



class JBurgAnnotation_IF_3  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private JBurgAnnotation subtree1;
    private JBurgAnnotation subtree2;
    private int cachedCostFor_statement = -1;

    public  JBurgAnnotation_IF_3(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                result = getCostForRule3(goalState);
                result = Math.min(result,getCostForRule4(goalState));
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                if ((cachedCostFor_statement == -1)) {
                    cachedCostFor_statement = getPatternMatchCost(__statement_NT);
                } 
                result = cachedCostFor_statement;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __statement_NT: {
                int bestCost = Integer.MAX_VALUE;
                int currentCost = getCostForRule3(goalState);
                if ((bestCost > currentCost)) {
                    bestCost = currentCost;
                    rule = 5;
                } 
                currentCost = getCostForRule4(goalState);
                if ((bestCost > currentCost)) {
                    rule = 7;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (3);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            case 1: {
                result = subtree1;
            }
            break;
            case 2: {
                result = subtree2;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else if ( subtree1 == null ) {
            subtree1 = child;
        } else if ( subtree2 == null ) {
            subtree2 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule3(int goalState)  {
        JBurgAnnotation factoredPath_0 = (this.getNthChild(0).getArity() > 0? this.getNthChild(0).getNthChild(0): errorAnnotation);
        JBurgAnnotation factoredPath_1 = (this.getNthChild(0).getArity() > 1? this.getNthChild(0).getNthChild(1): errorAnnotation);
        JBurgAnnotation factoredPath_2 = (this.getNthChild(2).getArity() > 0? this.getNthChild(2).getNthChild(0): errorAnnotation);
        if ((this.getNthChild(0).getArity() == 2) && (this.getNthChild(0).getOperator() == EQUAL_EQUAL) && (this.getNthChild(2).getArity() == 1) && (this.getNthChild(2).getOperator() == ELSE)) {
            return (normalizedAdd(1, normalizedAdd(normalizedAdd(normalizedAdd(factoredPath_2.getCost(__statement_NT), this.getNthChild(1).getCost(__statement_NT)), factoredPath_1.getCost(__intExpression_NT)), factoredPath_0.getCost(__intExpression_NT))));
        } else  {
            return (Integer.MAX_VALUE);
        } 
    }

    private int getCostForRule4(int goalState)  {
        JBurgAnnotation factoredPath_2 = (this.getNthChild(2).getArity() > 0? this.getNthChild(2).getNthChild(0): errorAnnotation);
        if ((this.getNthChild(2).getArity() == 1) && (this.getNthChild(2).getOperator() == ELSE)) {
            return (normalizedAdd(5, normalizedAdd(normalizedAdd(factoredPath_2.getCost(__statement_NT), this.getNthChild(1).getCost(__statement_NT)), this.getNthChild(0).getCost(__conditional_NT))));
        } else  {
            return (Integer.MAX_VALUE);
        } 
    }
}



class JBurgAnnotation_INT_LITERAL_0  extends JBurgSpecializedAnnotation 
{


    public  JBurgAnnotation_INT_LITERAL_0(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intConstant_NT: {
                result = 1;
            }
            break;
        }
        return (result);
    }

    private int getClosureCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intExpression_NT: {
                int cost_intConstant = this.getPatternMatchCost(__intConstant_NT);
                int cost_intExpression = normalizedAdd(1, cost_intConstant);
                result = cost_intExpression;
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intConstant_NT: {
                result = getPatternMatchCost(__intConstant_NT);
            }
            break;
            case __intExpression_NT: {
                result = getClosureCost(__intExpression_NT);
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __intConstant_NT: {
                rule = 19;
            }
            break;
            case __intExpression_NT: {
                rule = 14;
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (0);
    }
}



class JBurgAnnotation_INT_TYPE_1  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private int cachedCostFor_statement = -1;

    public  JBurgAnnotation_INT_TYPE_1(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                result = getCostForRule5(goalState);
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                if ((cachedCostFor_statement == -1)) {
                    cachedCostFor_statement = getPatternMatchCost(__statement_NT);
                } 
                result = cachedCostFor_statement;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __statement_NT: {
                if ((Integer.MAX_VALUE > getCostForRule5(goalState))) {
                    rule = 2;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (1);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule5(int goalState)  {
        return (normalizedAdd(1, this.getNthChild(0).getCost(__name_NT)));
    }
}



class JBurgAnnotation_LT_2  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private JBurgAnnotation subtree1;
    private int cachedCostFor_conditional = -1;

    public  JBurgAnnotation_LT_2(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __conditional_NT: {
                result = getCostForRule6(goalState);
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __conditional_NT: {
                if ((cachedCostFor_conditional == -1)) {
                    cachedCostFor_conditional = getPatternMatchCost(__conditional_NT);
                } 
                result = cachedCostFor_conditional;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __conditional_NT: {
                if ((Integer.MAX_VALUE > getCostForRule6(goalState))) {
                    rule = 17;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (2);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            case 1: {
                result = subtree1;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else if ( subtree1 == null ) {
            subtree1 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule6(int goalState)  {
        return (normalizedAdd(1, normalizedAdd(this.getNthChild(1).getCost(__intExpression_NT), this.getNthChild(0).getCost(__intExpression_NT))));
    }
}



class JBurgAnnotation_MINUS_2  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private JBurgAnnotation subtree1;
    private int cachedCostFor_intExpression = -1;

    public  JBurgAnnotation_MINUS_2(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intExpression_NT: {
                result = getCostForRule7(goalState);
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intExpression_NT: {
                if ((cachedCostFor_intExpression == -1)) {
                    cachedCostFor_intExpression = getPatternMatchCost(__intExpression_NT);
                } 
                result = cachedCostFor_intExpression;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __intExpression_NT: {
                if ((Integer.MAX_VALUE > getCostForRule7(goalState))) {
                    rule = 13;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (2);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            case 1: {
                result = subtree1;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else if ( subtree1 == null ) {
            subtree1 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule7(int goalState)  {
        return (normalizedAdd(1, normalizedAdd(this.getNthChild(1).getCost(__intExpression_NT), this.getNthChild(0).getCost(__intExpression_NT))));
    }
}



class JBurgAnnotation_PLUS_2  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private JBurgAnnotation subtree1;
    private int cachedCostFor_intExpression = -1;

    public  JBurgAnnotation_PLUS_2(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intExpression_NT: {
                result = getCostForRule8(goalState);
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __intExpression_NT: {
                if ((cachedCostFor_intExpression == -1)) {
                    cachedCostFor_intExpression = getPatternMatchCost(__intExpression_NT);
                } 
                result = cachedCostFor_intExpression;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __intExpression_NT: {
                if ((Integer.MAX_VALUE > getCostForRule8(goalState))) {
                    rule = 12;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (2);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            case 1: {
                result = subtree1;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else if ( subtree1 == null ) {
            subtree1 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule8(int goalState)  {
        return (normalizedAdd(1, normalizedAdd(this.getNthChild(1).getCost(__intExpression_NT), this.getNthChild(0).getCost(__intExpression_NT))));
    }
}



class JBurgAnnotation_PRINT_1  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private int cachedCostFor_statement = -1;

    public  JBurgAnnotation_PRINT_1(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                result = getCostForRule9(goalState);
                result = Math.min(result,getCostForRulea(goalState));
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                if ((cachedCostFor_statement == -1)) {
                    cachedCostFor_statement = getPatternMatchCost(__statement_NT);
                } 
                result = cachedCostFor_statement;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __statement_NT: {
                int bestCost = Integer.MAX_VALUE;
                int currentCost = getCostForRule9(goalState);
                if ((bestCost > currentCost)) {
                    bestCost = currentCost;
                    rule = 9;
                } 
                currentCost = getCostForRulea(goalState);
                if ((bestCost > currentCost)) {
                    rule = 10;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (1);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRule9(int goalState)  {
        return (normalizedAdd(1, this.getNthChild(0).getCost(__intExpression_NT)));
    }

    private int getCostForRulea(int goalState)  {
        return (normalizedAdd(1, this.getNthChild(0).getCost(__stringExpression_NT)));
    }
}



class JBurgAnnotation_STRING_LITERAL_0  extends JBurgSpecializedAnnotation 
{


    public  JBurgAnnotation_STRING_LITERAL_0(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __stringConstant_NT: {
                result = 1;
            }
            break;
        }
        return (result);
    }

    private int getClosureCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __stringExpression_NT: {
                int cost_stringConstant = this.getPatternMatchCost(__stringConstant_NT);
                int cost_stringExpression = normalizedAdd(1, cost_stringConstant);
                result = cost_stringExpression;
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __stringConstant_NT: {
                result = getPatternMatchCost(__stringConstant_NT);
            }
            break;
            case __stringExpression_NT: {
                result = getClosureCost(__stringExpression_NT);
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __stringConstant_NT: {
                rule = 20;
            }
            break;
            case __stringExpression_NT: {
                rule = 16;
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (0);
    }
}



class JBurgAnnotation_WHILE_2  extends JBurgSpecializedAnnotation 
{

    private JBurgAnnotation subtree0;
    private JBurgAnnotation subtree1;
    private int cachedCostFor_statement = -1;

    public  JBurgAnnotation_WHILE_2(CommonTree node)  {
        super(node);
    }

    private int getPatternMatchCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                result = getCostForRuleb(goalState);
            }
            break;
        }
        return (result);
    }

    public int getCost(int goalState)  {
        int result = Integer.MAX_VALUE;
        switch(goalState) {
            case __statement_NT: {
                if ((cachedCostFor_statement == -1)) {
                    cachedCostFor_statement = getPatternMatchCost(__statement_NT);
                } 
                result = cachedCostFor_statement;
            }
            break;
        }
        return (result);
    }

    public int getRule(int goalState)  {
        int rule = -1;
        switch(goalState) {
            case __statement_NT: {
                if ((Integer.MAX_VALUE > getCostForRuleb(goalState))) {
                    rule = 8;
                } 
            }
            break;
        }
        return (rule);
    }

    public int getArity()  {
        return (2);
    }

    public JBurgAnnotation getNthChild(int index)  {
        JBurgAnnotation result = null;
        switch(index) {
            case 0: {
                result = subtree0;
            }
            break;
            case 1: {
                result = subtree1;
            }
            break;
            default: {
                throw new IllegalStateException("Invalid index " + index);
            }
        }
        return (result);
    }

    public void addChild(JBurgAnnotation child)  {
        if (subtree0 == null) {
            subtree0 = child;
        } else if ( subtree1 == null ) {
            subtree1 = child;
        } else  {
            throw new IllegalStateException("too many children");
        } 
    }

    private int getCostForRuleb(int goalState)  {
        return (normalizedAdd(1, normalizedAdd(this.getNthChild(1).getCost(__statement_NT), this.getNthChild(0).getCost(__conditional_NT))));
    }
}



public JBurgAnnotation getJBurgAnnotation(CommonTree node)  {
    switch(node.getType()) {
        case BRACE_START: {
            if ((node.getChildCount() >= 0)) {
                return (new JBurgAnnotation_BRACE_START_0_n(node));
            } 
        }
        break;
        case COMPILATION_UNIT: {
            if ((node.getChildCount() >= 0)) {
                return (new JBurgAnnotation_COMPILATION_UNIT_0_n(node));
            } 
        }
        break;
        case EQUALS: {
            if ((node.getChildCount() == 2)) {
                return (new JBurgAnnotation_EQUALS_2(node));
            } 
        }
        break;
        case ID: {
            if ((node.getChildCount() == 0)) {
                return (new JBurgAnnotation_ID_0(node));
            } 
        }
        break;
        case IF: {
            if ((node.getChildCount() == 2)) {
                return (new JBurgAnnotation_IF_2(node));
            } 
            if ((node.getChildCount() == 3)) {
                return (new JBurgAnnotation_IF_3(node));
            } 
        }
        break;
        case INT_LITERAL: {
            if ((node.getChildCount() == 0)) {
                return (new JBurgAnnotation_INT_LITERAL_0(node));
            } 
        }
        break;
        case INT_TYPE: {
            if ((node.getChildCount() == 1)) {
                return (new JBurgAnnotation_INT_TYPE_1(node));
            } 
        }
        break;
        case LT: {
            if ((node.getChildCount() == 2)) {
                return (new JBurgAnnotation_LT_2(node));
            } 
        }
        break;
        case MINUS: {
            if ((node.getChildCount() == 2)) {
                return (new JBurgAnnotation_MINUS_2(node));
            } 
        }
        break;
        case PLUS: {
            if ((node.getChildCount() == 2)) {
                return (new JBurgAnnotation_PLUS_2(node));
            } 
        }
        break;
        case PRINT: {
            if ((node.getChildCount() == 1)) {
                return (new JBurgAnnotation_PRINT_1(node));
            } 
        }
        break;
        case STRING_LITERAL: {
            if ((node.getChildCount() == 0)) {
                return (new JBurgAnnotation_STRING_LITERAL_0(node));
            } 
        }
        break;
        case WHILE: {
            if ((node.getChildCount() == 2)) {
                return (new JBurgAnnotation_WHILE_2(node));
            } 
        }
        break;
    }
    return (new PlaceholderAnnotation(node,node.getChildCount()));
}

private static final JBurgSubgoal[][] ___subgoals_by_rule = 
{
    null,
    {
        new JBurgSubgoal(__statement_NT,true, 0)
    },
    {
        new JBurgSubgoal(__name_NT,false, 0,0)
    },
    {
        new JBurgSubgoal(__name_NT,false, 0,0),
        new JBurgSubgoal(__intExpression_NT,false, 0,1)
    },
    {
        new JBurgSubgoal(__intExpression_NT,false, 0,0,0),
        new JBurgSubgoal(__intExpression_NT,false, 0,0,1),
        new JBurgSubgoal(__statement_NT,false, 0,1)
    },
    {
        new JBurgSubgoal(__intExpression_NT,false, 0,0,0),
        new JBurgSubgoal(__intExpression_NT,false, 0,0,1),
        new JBurgSubgoal(__statement_NT,false, 0,1),
        new JBurgSubgoal(__statement_NT,false, 0,2,0)
    },
    {
        new JBurgSubgoal(__conditional_NT,false, 0,0),
        new JBurgSubgoal(__statement_NT,false, 0,1)
    },
    {
        new JBurgSubgoal(__conditional_NT,false, 0,0),
        new JBurgSubgoal(__statement_NT,false, 0,1),
        new JBurgSubgoal(__statement_NT,false, 0,2,0)
    },
    {
        new JBurgSubgoal(__conditional_NT,false, 0,0),
        new JBurgSubgoal(__statement_NT,false, 0,1)
    },
    {
        new JBurgSubgoal(__intExpression_NT,false, 0,0)
    },
    {
        new JBurgSubgoal(__stringExpression_NT,false, 0,0)
    },
    {
        new JBurgSubgoal(__statement_NT,true, 0)
    },
    {
        new JBurgSubgoal(__intExpression_NT,false, 0,0),
        new JBurgSubgoal(__intExpression_NT,false, 0,1)
    },
    {
        new JBurgSubgoal(__intExpression_NT,false, 0,0),
        new JBurgSubgoal(__intExpression_NT,false, 0,1)
    },
    null,
    null,
    null,
    {
        new JBurgSubgoal(__intExpression_NT,false, 0,0),
        new JBurgSubgoal(__intExpression_NT,false, 0,1)
    },
    null,
    null,
    null
};

    /**
     * Reduce a labeled subtree.
     * @param p the annotation describing the root of the subtree.
     * @param goalState the required goal state.
     */
    public void reduce(JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		reduceAntecedent(p,goalState);
		// Release the annotation's data.
		p.release();
	}

    public void reduceAntecedent(JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
        int iRule  = -1;

		if ( ( goalState != 0 )  )
		{
            iRule = p.getRule(goalState);
		}
		else
		{
			// Find the minimum-cost path.
            int minCost  = Integer.MAX_VALUE;

            for(int i = 0; i <= nStates; i++)
			{
				if ( ( minCost > p.getCost(i) )  )
				{
                    iRule = p.getRule(i);
                    minCost = p.getCost(i);
                    goalState = i;
				}
			}
		}
		if ( ( iRule > 0 )  )
		{
			reduceSubgoals(p, iRule);
			dispatchAction(p, iRule );
		}
		else
		{
			throw new IllegalStateException ( String.format("Unable to find a rule to process \"%s\", operator=%s, goal=%s", p, p.getOperator(), goalState) );
		}
	}

    private void reduceSubgoals(JBurgAnnotation p,int rule_num) throws java.lang.Exception
	{
		if ( ___subgoals_by_rule[rule_num] != null )
		{
			for ( JBurgSubgoal sg : ___subgoals_by_rule[rule_num] )
			{
				if ( !sg.isNary() )
				{
					reduce ( sg.getNode(p), sg.getGoalState());
				}
				else
				{
					// Aggregate the operands of an n-ary operator into a single container.
					JBurgAnnotation sub_parent = sg.getNode(p);
					java.util.Vector<Object> variadic_result = new java.util.Vector<Object>(sub_parent.getArity() - sg.startIndex);
					for ( int j = sg.startIndex; j < sub_parent.getArity(); j++ )
					{
						reduce(sub_parent.getNthChild(j), sg.getGoalState());
						variadic_result.add(__reducedValues.pop());
					}
					__reducedValues.push(variadic_result);
				}
			}
		}
	}

    /**
     * Get the cost of an n-ary tail of candidate reductions.
     * @param Node the parent of the candidates.
     * @param goalState the desired goal state.
     * @param startIndex the starting position of
     * the n-ary tail in the parent's children.
     * @return the sum of the n-ary children's costs
     * for the desired goal state, capped at 
     * Integer.MAX_VALUE - 1 if all child costs
     * were strictly less than Integer.MAX_VALUE.
     */
    private int getNaryCost(JBurgAnnotation node, int goalState, int startIndex)
	{
		long accumCost = 0;
		for ( int i = startIndex; accumCost < Integer.MAX_VALUE && i < node.getArity(); i++ )
        {
            // Don't allow the cost of a series of feasible child reductions
            // to rise above MAX_VALUE; the concept of "feasability" and the
            // concept of "cost" need to be disconnected.
            int  childCost = node.getNthChild(i).getCost(goalState);

            if ( childCost >= Integer.MAX_VALUE )
                return Integer.MAX_VALUE;
            else
                accumCost += childCost;
        }

		return accumCost < Integer.MAX_VALUE? (int)accumCost: Integer.MAX_VALUE - 1;
	}
	
    /**
     * Reduce a subtree to the least-cost solution available.
     * @param root the root of the subtree.
     */
    public void burm(CommonTree root) throws java.lang.Exception
	{
		/* Use the least-cost goal state available. */
		burm(root, 0);
	}
	
    /**
     * Reduce a subtree to a specific goal state.
     * @param root the root of the subtree.
     * @param goal_state the desired goal.
     */
    public void burm(CommonTree root, int goal_state) throws java.lang.Exception
	{
		JBurgAnnotation annotatedTree = label(root);

        try
        {
            reduce(annotatedTree, goal_state);
        }
        catch ( Exception cant_reduce )
        {
            this.__problemTree = annotatedTree;
            throw cant_reduce;
        }
	}
	
    /**
     * Get the (presumably only) final
     * result of a series of reductions.
     */
    public Object getResult()
	{
		return __reducedValues.pop();
	}

    /**
     * @return the sum of the input costs, normalized as follows:
     * <li>If either parameter equals Integer.MAX_VALUE, return Integer.MAX_VALUE.
     * <li>If the sum is less than Integer.MAX_VALUE, return the sum.
     * <li>Otherwise return Integer.MAX_VALUE-1.
     */
    public int normalizedAdd(int c1, int c2)
    {
        int result = Integer.MAX_VALUE;

        if ( c1 < Integer.MAX_VALUE && c2 < Integer.MAX_VALUE )
        {
            long accum = (long)c1 + (long)c2;
            result = accum < Integer.MAX_VALUE?
                (int)accum:
                Integer.MAX_VALUE-1;
        }

        return result;
    }

	private JBurgAnnotation __problemTree;
	
    public void dump(java.io.PrintWriter debug_output)
	{
		if ( null == __problemTree )
		{
			debug_output.print("<bailed reason=\"no problem tree\"/>");
			
			return;
		}
		debug_output.print("<jburg>");
		dumpSubgoals(debug_output);
		debug_output.print("<label>");
		describeNode(__problemTree,debug_output);
		debug_output.print("</label></jburg>");
	}
	
    public void dump(CommonTree node,java.io.PrintWriter debug_output)
	{
		JBurgAnnotation anno = label(node);
		debug_output.println("<?xml version=\"1.0\"?>");
		debug_output.println("<BurmDump date=\"" + new java.util.Date() + "\">");
		debug_output.println("<jburg>");
		dumpSubgoals(debug_output);
		debug_output.println("<label>");
		describeNode(anno,debug_output);
		debug_output.println("</label>\n</jburg>\n</BurmDump>");
		debug_output.flush();
	
	}

    public void describeNode(JBurgAnnotation node,java.io.PrintWriter debug_output)
	{
		if ( node == null )
            return;

		String self_description;
		try
		{
			self_description = java.net.URLEncoder.encode(node.getNode().toString(),"UTF-8");
		
		}
		catch ( Exception cant_encode )
		{
			self_description = node.getNode().toString();
		
		}
		debug_output.print("<node operator=\"" + node.getNode().getType() + "\" selfDescription=\"" + self_description + "\">");
		for(int i = 0; i <= nStates; i++)
		{
			if ( node.getCost(i) < Integer.MAX_VALUE )
			{
				debug_output.print ( "<goal");
				debug_output.print ( " name=\"" + stateName[i] + "\"");
				debug_output.print ( " rule=\"" + node.getRule(i) + "\"");
				debug_output.print ( " cost=\"" + node.getCost(i) + "\"");
				debug_output.println ( "/>" );
			
			}
		}

		for (int i = 0; i < node.getArity(); i++ )
            describeNode ( node.getNthChild(i),debug_output);
		debug_output.println ( "</node>" );
	
	}

    private void dumpSubgoals(java.io.PrintWriter debug_output)
	{
		for ( int rule_num = 0; rule_num < ___subgoals_by_rule.length; rule_num++ )
        {
            if ( ___subgoals_by_rule[rule_num] != null )
            {
                debug_output.printf("<subgoals rule=\"%d\">\n", rule_num);

                for ( JBurgSubgoal sg : ___subgoals_by_rule[rule_num] )
                {
                    debug_output.printf("<subgoal goal=\"%s\" nary=\"%s\" startIndex=\"%s\"", stateName[sg.getGoalState()], sg.isNary(), sg.startIndex);

                    if ( sg.accessPath.length > 0 )
                    {
                        debug_output.println(">");
                        for ( int idx: sg.accessPath )
                        debug_output.printf("<accessPath index=\"%d\"/>\n", idx);
                        debug_output.printf("</subgoal>\n");
                    }
                    else
                    {
                        debug_output.println("/>");
                    }
                }
                debug_output.printf("</subgoals>\n");
            }
		}
	}

    static final String[] stateName = new String[] { null, "stringExpression","statement","intConstant","compilationUnit","name","conditional","intExpression","stringConstant" };
	/** 
     *  JBurgAnnotation is a data structure internal to the
	 *  JBurg-generated BURM that annotates a CommonTree with
	 *  information used for dynamic programming and reduction.
	 */
	public abstract static class JBurgAnnotation
	{
		/**  The INode this JBurgAnnotation describes.  */
		CommonTree m_node; 
		JBurgAnnotation ( CommonTree newNode)
		{
			m_node = newNode;
		}
		/** @return this node's operator. */
		public int getOperator() 
		{
			return m_node.getType();
		}

		/** @return this node's wrapped CommonTree. */ 
		public CommonTree getNode()  
		{
			return m_node; 
		}

		/** @return the nth child of this node.  */
		public abstract JBurgAnnotation getNthChild(int idx);

		/** @return this node's child count.  */
		public abstract int getArity();

		/** Add a new child to this node.  */
		public abstract void addChild(JBurgAnnotation new_child);

		/** Release this node's data.  */
		public abstract void release();

		/** @return the wrapped node's toString().  */
		public String toString() 
		{
			return m_node.toString(); 
		}

		/** @return the current best cost to reach a goal state.  */
		public abstract int getCost( int goalState ) ;

		/** Set the cost/rule configuration of a goal state.
		 * @throws IllegalArgumentException if this node has a fixed cost/rule.
         */
        public abstract void reset ( int goalState, int cost, int rule );

		/** * @return the rule to fire for a specific goal state. */
		public abstract int getRule ( int goalState ) ;

		/**
		 *  A closure's transformation rule succeeded.
		 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
		 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
		 *  transition back to a goal state that has already been reduced).*/
		public abstract void recordAntecedent ( int iGoalState, int newAntecedentState );
	
	}

    /**
     * Common superclass of node-specific annotations.
     */
	abstract static class JBurgSpecializedAnnotation extends JBurgAnnotation
	{
		JBurgSpecializedAnnotation(CommonTree node)
		{
			super(node);
		}
		public JBurgAnnotation getNthChild(int idx)
		{
			throw new IllegalStateException(this.getClass().getName() + " has no children.");
		}
		public void addChild(JBurgAnnotation new_child)
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot have children.");
		}
		public void reset ( int goalState, int cost, int rule )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot be reset.");
		}
		public void release ()
		{
		}
		public void recordAntecedent ( int iGoalState, int newAntecedentState )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot record antecedents.");
		}
	}

    /**
     * An annotation that denotes an unused node in the tree.
     */
	private static class PlaceholderAnnotation extends JBurgSpecializedAnnotation
	{
		PlaceholderAnnotation(CommonTree node, int capacity)
		{
			super(node);
            this.children = new JBurgAnnotation[capacity];
		}

        JBurgAnnotation [] children;
        int actualChildCount = 0;

		public int getRule(int state) { return -1; }
		public int getCost(int state) { return Integer.MAX_VALUE; }
		public int getArity() { return actualChildCount; }

		public JBurgAnnotation getNthChild(int idx)
		{
			return children[idx];
		}
		public void addChild(JBurgAnnotation newChild)
		{
			children[actualChildCount++] = newChild;
		}
	}

    /**
     * An annotation that describes a pattern-match failure.
     */
    private final static JBurgAnnotation errorAnnotation = new JBurgSpecializedAnnotation(null)
    {
		public int getRule(int state) { return -1; }
		public int getCost(int state) { return Integer.MAX_VALUE; }
		public int getArity() { return 0; }
    };

    /**
     * JBurgSubgoal describes a possible reduction of a subtree.
     */
	static class JBurgSubgoal
	{
        /** The goal state that this subgoal produces. */
		private int goalState;
        /** Is this subgoal an n-ary tail? */
		private boolean isNary;
        /** If this is an n-ary subgoal, where does it start? */
		private int startIndex ;
        /** Path from the ancestor node to the root of the subtree. */
		private int[] accessPath ;

        public  JBurgSubgoal(int goal_state,boolean is_nary,int start_index,int... access_path)
		{
			this.goalState = goal_state;
			this.isNary = is_nary;
			this.startIndex = start_index;
			this.accessPath = access_path;
		}
		public int getGoalState() { return this.goalState; }
		public boolean isNary() { return this.isNary; }
        /**
         * Traverse the access path from the ancestor subtree
         * to the root of this subgoal's subtree.
         * @param ancestor the ancestor node.
         */
		public JBurgAnnotation getNode(JBurgAnnotation ancestor)
		{
			JBurgAnnotation result = ancestor;
			for ( int idx: this.accessPath )
				result = result.getNthChild(idx);
			return result;
		}
	
	}
}