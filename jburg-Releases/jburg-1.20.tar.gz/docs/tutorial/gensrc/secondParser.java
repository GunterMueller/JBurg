// $ANTLR 3.3 Nov 30, 2010 12:50:56 /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g 2013-03-20 10:47:08

package jburg.tutorial.second;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class secondParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "COMPILATION_UNIT", "ID", "INT_TYPE", "EQUALS", "PRINT", "BRACE_START", "BRACE_END", "IF", "PAREN_START", "PAREN_END", "ELSE", "WHILE", "PLUS", "MINUS", "INT_LITERAL", "STRING_LITERAL", "EQUAL_EQUAL", "LT", "STRING", "LETTER", "DIGIT", "ESC", "WS", "COMMENT", "LINE_COMMENT", "';'"
    };
    public static final int EOF=-1;
    public static final int T__29=29;
    public static final int COMPILATION_UNIT=4;
    public static final int ID=5;
    public static final int INT_TYPE=6;
    public static final int EQUALS=7;
    public static final int PRINT=8;
    public static final int BRACE_START=9;
    public static final int BRACE_END=10;
    public static final int IF=11;
    public static final int PAREN_START=12;
    public static final int PAREN_END=13;
    public static final int ELSE=14;
    public static final int WHILE=15;
    public static final int PLUS=16;
    public static final int MINUS=17;
    public static final int INT_LITERAL=18;
    public static final int STRING_LITERAL=19;
    public static final int EQUAL_EQUAL=20;
    public static final int LT=21;
    public static final int STRING=22;
    public static final int LETTER=23;
    public static final int DIGIT=24;
    public static final int ESC=25;
    public static final int WS=26;
    public static final int COMMENT=27;
    public static final int LINE_COMMENT=28;

    // delegates
    // delegators


        public secondParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public secondParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return secondParser.tokenNames; }
    public String getGrammarFileName() { return "/Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g"; }


    public static class compilationUnit_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "compilationUnit"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:22:1: compilationUnit : ( decl | stmt )* EOF -> ^( COMPILATION_UNIT ( decl )* ( stmt )* ) ;
    public final secondParser.compilationUnit_return compilationUnit() throws RecognitionException {
        secondParser.compilationUnit_return retval = new secondParser.compilationUnit_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token EOF3=null;
        secondParser.decl_return decl1 = null;

        secondParser.stmt_return stmt2 = null;


        Object EOF3_tree=null;
        RewriteRuleTokenStream stream_EOF=new RewriteRuleTokenStream(adaptor,"token EOF");
        RewriteRuleSubtreeStream stream_stmt=new RewriteRuleSubtreeStream(adaptor,"rule stmt");
        RewriteRuleSubtreeStream stream_decl=new RewriteRuleSubtreeStream(adaptor,"rule decl");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:22:16: ( ( decl | stmt )* EOF -> ^( COMPILATION_UNIT ( decl )* ( stmt )* ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:23:5: ( decl | stmt )* EOF
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:23:5: ( decl | stmt )*
            loop1:
            do {
                int alt1=3;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==INT_TYPE) ) {
                    alt1=1;
                }
                else if ( (LA1_0==ID||(LA1_0>=PRINT && LA1_0<=BRACE_START)||LA1_0==IF||LA1_0==WHILE) ) {
                    alt1=2;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:23:6: decl
            	    {
            	    pushFollow(FOLLOW_decl_in_compilationUnit57);
            	    decl1=decl();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_decl.add(decl1.getTree());

            	    }
            	    break;
            	case 2 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:23:11: stmt
            	    {
            	    pushFollow(FOLLOW_stmt_in_compilationUnit59);
            	    stmt2=stmt();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_stmt.add(stmt2.getTree());

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            EOF3=(Token)match(input,EOF,FOLLOW_EOF_in_compilationUnit63); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EOF.add(EOF3);



            // AST REWRITE
            // elements: decl, stmt
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 23:22: -> ^( COMPILATION_UNIT ( decl )* ( stmt )* )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:23:25: ^( COMPILATION_UNIT ( decl )* ( stmt )* )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot((Object)adaptor.create(COMPILATION_UNIT, "COMPILATION_UNIT"), root_1);

                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:23:44: ( decl )*
                while ( stream_decl.hasNext() ) {
                    adaptor.addChild(root_1, stream_decl.nextTree());

                }
                stream_decl.reset();
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:23:50: ( stmt )*
                while ( stream_stmt.hasNext() ) {
                    adaptor.addChild(root_1, stream_stmt.nextTree());

                }
                stream_stmt.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "compilationUnit"

    public static class decl_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "decl"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:29:1: decl : type ID ';' -> ^( type ID ) ;
    public final secondParser.decl_return decl() throws RecognitionException {
        secondParser.decl_return retval = new secondParser.decl_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ID5=null;
        Token char_literal6=null;
        secondParser.type_return type4 = null;


        Object ID5_tree=null;
        Object char_literal6_tree=null;
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_29=new RewriteRuleTokenStream(adaptor,"token 29");
        RewriteRuleSubtreeStream stream_type=new RewriteRuleSubtreeStream(adaptor,"rule type");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:29:5: ( type ID ';' -> ^( type ID ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:29:7: type ID ';'
            {
            pushFollow(FOLLOW_type_in_decl89);
            type4=type();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_type.add(type4.getTree());
            ID5=(Token)match(input,ID,FOLLOW_ID_in_decl91); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ID.add(ID5);

            char_literal6=(Token)match(input,29,FOLLOW_29_in_decl93); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_29.add(char_literal6);



            // AST REWRITE
            // elements: type, ID
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 29:19: -> ^( type ID )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:29:22: ^( type ID )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_type.nextNode(), root_1);

                adaptor.addChild(root_1, stream_ID.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "decl"

    public static class type_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "type"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:32:1: type : INT_TYPE ;
    public final secondParser.type_return type() throws RecognitionException {
        secondParser.type_return retval = new secondParser.type_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token INT_TYPE7=null;

        Object INT_TYPE7_tree=null;

        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:32:5: ( INT_TYPE )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:32:7: INT_TYPE
            {
            root_0 = (Object)adaptor.nil();

            INT_TYPE7=(Token)match(input,INT_TYPE,FOLLOW_INT_TYPE_in_type113); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            INT_TYPE7_tree = (Object)adaptor.create(INT_TYPE7);
            adaptor.addChild(root_0, INT_TYPE7_tree);
            }

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "type"

    public static class stmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "stmt"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:38:1: stmt : ( assignment | pseudo | block | ifStmt | whileStmt );
    public final secondParser.stmt_return stmt() throws RecognitionException {
        secondParser.stmt_return retval = new secondParser.stmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        secondParser.assignment_return assignment8 = null;

        secondParser.pseudo_return pseudo9 = null;

        secondParser.block_return block10 = null;

        secondParser.ifStmt_return ifStmt11 = null;

        secondParser.whileStmt_return whileStmt12 = null;



        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:38:5: ( assignment | pseudo | block | ifStmt | whileStmt )
            int alt2=5;
            switch ( input.LA(1) ) {
            case ID:
                {
                alt2=1;
                }
                break;
            case PRINT:
                {
                alt2=2;
                }
                break;
            case BRACE_START:
                {
                alt2=3;
                }
                break;
            case IF:
                {
                alt2=4;
                }
                break;
            case WHILE:
                {
                alt2=5;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:38:7: assignment
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_assignment_in_stmt127);
                    assignment8=assignment();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, assignment8.getTree());

                    }
                    break;
                case 2 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:39:7: pseudo
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_pseudo_in_stmt135);
                    pseudo9=pseudo();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, pseudo9.getTree());

                    }
                    break;
                case 3 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:40:7: block
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_block_in_stmt143);
                    block10=block();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, block10.getTree());

                    }
                    break;
                case 4 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:41:7: ifStmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_ifStmt_in_stmt151);
                    ifStmt11=ifStmt();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, ifStmt11.getTree());

                    }
                    break;
                case 5 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:42:7: whileStmt
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_whileStmt_in_stmt159);
                    whileStmt12=whileStmt();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, whileStmt12.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "stmt"

    public static class assignment_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignment"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:45:1: assignment : ID EQUALS expression ';' -> ^( EQUALS ID expression ) ;
    public final secondParser.assignment_return assignment() throws RecognitionException {
        secondParser.assignment_return retval = new secondParser.assignment_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ID13=null;
        Token EQUALS14=null;
        Token char_literal16=null;
        secondParser.expression_return expression15 = null;


        Object ID13_tree=null;
        Object EQUALS14_tree=null;
        Object char_literal16_tree=null;
        RewriteRuleTokenStream stream_EQUALS=new RewriteRuleTokenStream(adaptor,"token EQUALS");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_29=new RewriteRuleTokenStream(adaptor,"token 29");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:45:11: ( ID EQUALS expression ';' -> ^( EQUALS ID expression ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:45:13: ID EQUALS expression ';'
            {
            ID13=(Token)match(input,ID,FOLLOW_ID_in_assignment171); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ID.add(ID13);

            EQUALS14=(Token)match(input,EQUALS,FOLLOW_EQUALS_in_assignment173); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_EQUALS.add(EQUALS14);

            pushFollow(FOLLOW_expression_in_assignment175);
            expression15=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression15.getTree());
            char_literal16=(Token)match(input,29,FOLLOW_29_in_assignment177); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_29.add(char_literal16);



            // AST REWRITE
            // elements: EQUALS, expression, ID
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 45:38: -> ^( EQUALS ID expression )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:45:41: ^( EQUALS ID expression )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_EQUALS.nextNode(), root_1);

                adaptor.addChild(root_1, stream_ID.nextNode());
                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignment"

    public static class pseudo_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "pseudo"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:51:1: pseudo : PRINT expression ';' -> ^( PRINT expression ) ;
    public final secondParser.pseudo_return pseudo() throws RecognitionException {
        secondParser.pseudo_return retval = new secondParser.pseudo_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PRINT17=null;
        Token char_literal19=null;
        secondParser.expression_return expression18 = null;


        Object PRINT17_tree=null;
        Object char_literal19_tree=null;
        RewriteRuleTokenStream stream_PRINT=new RewriteRuleTokenStream(adaptor,"token PRINT");
        RewriteRuleTokenStream stream_29=new RewriteRuleTokenStream(adaptor,"token 29");
        RewriteRuleSubtreeStream stream_expression=new RewriteRuleSubtreeStream(adaptor,"rule expression");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:51:7: ( PRINT expression ';' -> ^( PRINT expression ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:52:5: PRINT expression ';'
            {
            PRINT17=(Token)match(input,PRINT,FOLLOW_PRINT_in_pseudo206); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_PRINT.add(PRINT17);

            pushFollow(FOLLOW_expression_in_pseudo208);
            expression18=expression();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_expression.add(expression18.getTree());
            char_literal19=(Token)match(input,29,FOLLOW_29_in_pseudo210); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_29.add(char_literal19);



            // AST REWRITE
            // elements: expression, PRINT
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 52:26: -> ^( PRINT expression )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:52:29: ^( PRINT expression )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_PRINT.nextNode(), root_1);

                adaptor.addChild(root_1, stream_expression.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "pseudo"

    public static class block_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "block"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:55:1: block : BRACE_START ( stmt )* BRACE_END -> ^( BRACE_START ( stmt )* ) ;
    public final secondParser.block_return block() throws RecognitionException {
        secondParser.block_return retval = new secondParser.block_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token BRACE_START20=null;
        Token BRACE_END22=null;
        secondParser.stmt_return stmt21 = null;


        Object BRACE_START20_tree=null;
        Object BRACE_END22_tree=null;
        RewriteRuleTokenStream stream_BRACE_START=new RewriteRuleTokenStream(adaptor,"token BRACE_START");
        RewriteRuleTokenStream stream_BRACE_END=new RewriteRuleTokenStream(adaptor,"token BRACE_END");
        RewriteRuleSubtreeStream stream_stmt=new RewriteRuleSubtreeStream(adaptor,"rule stmt");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:55:6: ( BRACE_START ( stmt )* BRACE_END -> ^( BRACE_START ( stmt )* ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:55:8: BRACE_START ( stmt )* BRACE_END
            {
            BRACE_START20=(Token)match(input,BRACE_START,FOLLOW_BRACE_START_in_block230); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_BRACE_START.add(BRACE_START20);

            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:55:20: ( stmt )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==ID||(LA3_0>=PRINT && LA3_0<=BRACE_START)||LA3_0==IF||LA3_0==WHILE) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:55:20: stmt
            	    {
            	    pushFollow(FOLLOW_stmt_in_block232);
            	    stmt21=stmt();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_stmt.add(stmt21.getTree());

            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            BRACE_END22=(Token)match(input,BRACE_END,FOLLOW_BRACE_END_in_block235); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_BRACE_END.add(BRACE_END22);



            // AST REWRITE
            // elements: stmt, BRACE_START
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 55:36: -> ^( BRACE_START ( stmt )* )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:55:39: ^( BRACE_START ( stmt )* )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_BRACE_START.nextNode(), root_1);

                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:55:53: ( stmt )*
                while ( stream_stmt.hasNext() ) {
                    adaptor.addChild(root_1, stream_stmt.nextTree());

                }
                stream_stmt.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class ifStmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "ifStmt"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:1: ifStmt : IF PAREN_START condition PAREN_END stmt ( ( ELSE )=> elseClause )? -> ^( IF condition stmt ( elseClause )? ) ;
    public final secondParser.ifStmt_return ifStmt() throws RecognitionException {
        secondParser.ifStmt_return retval = new secondParser.ifStmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token IF23=null;
        Token PAREN_START24=null;
        Token PAREN_END26=null;
        secondParser.condition_return condition25 = null;

        secondParser.stmt_return stmt27 = null;

        secondParser.elseClause_return elseClause28 = null;


        Object IF23_tree=null;
        Object PAREN_START24_tree=null;
        Object PAREN_END26_tree=null;
        RewriteRuleTokenStream stream_PAREN_START=new RewriteRuleTokenStream(adaptor,"token PAREN_START");
        RewriteRuleTokenStream stream_PAREN_END=new RewriteRuleTokenStream(adaptor,"token PAREN_END");
        RewriteRuleTokenStream stream_IF=new RewriteRuleTokenStream(adaptor,"token IF");
        RewriteRuleSubtreeStream stream_condition=new RewriteRuleSubtreeStream(adaptor,"rule condition");
        RewriteRuleSubtreeStream stream_stmt=new RewriteRuleSubtreeStream(adaptor,"rule stmt");
        RewriteRuleSubtreeStream stream_elseClause=new RewriteRuleSubtreeStream(adaptor,"rule elseClause");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:7: ( IF PAREN_START condition PAREN_END stmt ( ( ELSE )=> elseClause )? -> ^( IF condition stmt ( elseClause )? ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:9: IF PAREN_START condition PAREN_END stmt ( ( ELSE )=> elseClause )?
            {
            IF23=(Token)match(input,IF,FOLLOW_IF_in_ifStmt251); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_IF.add(IF23);

            PAREN_START24=(Token)match(input,PAREN_START,FOLLOW_PAREN_START_in_ifStmt253); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_PAREN_START.add(PAREN_START24);

            pushFollow(FOLLOW_condition_in_ifStmt255);
            condition25=condition();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_condition.add(condition25.getTree());
            PAREN_END26=(Token)match(input,PAREN_END,FOLLOW_PAREN_END_in_ifStmt257); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_PAREN_END.add(PAREN_END26);

            pushFollow(FOLLOW_stmt_in_ifStmt259);
            stmt27=stmt();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_stmt.add(stmt27.getTree());
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:49: ( ( ELSE )=> elseClause )?
            int alt4=2;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==ELSE) ) {
                int LA4_1 = input.LA(2);

                if ( (synpred1_second()) ) {
                    alt4=1;
                }
            }
            switch (alt4) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:50: ( ELSE )=> elseClause
                    {
                    pushFollow(FOLLOW_elseClause_in_ifStmt266);
                    elseClause28=elseClause();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_elseClause.add(elseClause28.getTree());

                    }
                    break;

            }



            // AST REWRITE
            // elements: condition, stmt, elseClause, IF
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 57:71: -> ^( IF condition stmt ( elseClause )? )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:74: ^( IF condition stmt ( elseClause )? )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_IF.nextNode(), root_1);

                adaptor.addChild(root_1, stream_condition.nextTree());
                adaptor.addChild(root_1, stream_stmt.nextTree());
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:94: ( elseClause )?
                if ( stream_elseClause.hasNext() ) {
                    adaptor.addChild(root_1, stream_elseClause.nextTree());

                }
                stream_elseClause.reset();

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "ifStmt"

    public static class elseClause_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "elseClause"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:59:1: elseClause : ELSE stmt -> ^( ELSE stmt ) ;
    public final secondParser.elseClause_return elseClause() throws RecognitionException {
        secondParser.elseClause_return retval = new secondParser.elseClause_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ELSE29=null;
        secondParser.stmt_return stmt30 = null;


        Object ELSE29_tree=null;
        RewriteRuleTokenStream stream_ELSE=new RewriteRuleTokenStream(adaptor,"token ELSE");
        RewriteRuleSubtreeStream stream_stmt=new RewriteRuleSubtreeStream(adaptor,"rule stmt");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:59:11: ( ELSE stmt -> ^( ELSE stmt ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:59:13: ELSE stmt
            {
            ELSE29=(Token)match(input,ELSE,FOLLOW_ELSE_in_elseClause288); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ELSE.add(ELSE29);

            pushFollow(FOLLOW_stmt_in_elseClause290);
            stmt30=stmt();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_stmt.add(stmt30.getTree());


            // AST REWRITE
            // elements: ELSE, stmt
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 59:23: -> ^( ELSE stmt )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:59:26: ^( ELSE stmt )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_ELSE.nextNode(), root_1);

                adaptor.addChild(root_1, stream_stmt.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "elseClause"

    public static class whileStmt_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "whileStmt"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:61:1: whileStmt : WHILE PAREN_START condition PAREN_END stmt -> ^( WHILE condition stmt ) ;
    public final secondParser.whileStmt_return whileStmt() throws RecognitionException {
        secondParser.whileStmt_return retval = new secondParser.whileStmt_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token WHILE31=null;
        Token PAREN_START32=null;
        Token PAREN_END34=null;
        secondParser.condition_return condition33 = null;

        secondParser.stmt_return stmt35 = null;


        Object WHILE31_tree=null;
        Object PAREN_START32_tree=null;
        Object PAREN_END34_tree=null;
        RewriteRuleTokenStream stream_PAREN_START=new RewriteRuleTokenStream(adaptor,"token PAREN_START");
        RewriteRuleTokenStream stream_PAREN_END=new RewriteRuleTokenStream(adaptor,"token PAREN_END");
        RewriteRuleTokenStream stream_WHILE=new RewriteRuleTokenStream(adaptor,"token WHILE");
        RewriteRuleSubtreeStream stream_condition=new RewriteRuleSubtreeStream(adaptor,"rule condition");
        RewriteRuleSubtreeStream stream_stmt=new RewriteRuleSubtreeStream(adaptor,"rule stmt");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:61:10: ( WHILE PAREN_START condition PAREN_END stmt -> ^( WHILE condition stmt ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:61:12: WHILE PAREN_START condition PAREN_END stmt
            {
            WHILE31=(Token)match(input,WHILE,FOLLOW_WHILE_in_whileStmt305); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_WHILE.add(WHILE31);

            PAREN_START32=(Token)match(input,PAREN_START,FOLLOW_PAREN_START_in_whileStmt307); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_PAREN_START.add(PAREN_START32);

            pushFollow(FOLLOW_condition_in_whileStmt309);
            condition33=condition();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_condition.add(condition33.getTree());
            PAREN_END34=(Token)match(input,PAREN_END,FOLLOW_PAREN_END_in_whileStmt311); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_PAREN_END.add(PAREN_END34);

            pushFollow(FOLLOW_stmt_in_whileStmt313);
            stmt35=stmt();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) stream_stmt.add(stmt35.getTree());


            // AST REWRITE
            // elements: condition, stmt, WHILE
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (Object)adaptor.nil();
            // 61:55: -> ^( WHILE condition stmt )
            {
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:61:58: ^( WHILE condition stmt )
                {
                Object root_1 = (Object)adaptor.nil();
                root_1 = (Object)adaptor.becomeRoot(stream_WHILE.nextNode(), root_1);

                adaptor.addChild(root_1, stream_condition.nextTree());
                adaptor.addChild(root_1, stream_stmt.nextTree());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "whileStmt"

    public static class expression_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expression"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:69:1: expression : condition ;
    public final secondParser.expression_return expression() throws RecognitionException {
        secondParser.expression_return retval = new secondParser.expression_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        secondParser.condition_return condition36 = null;



        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:69:11: ( condition )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:69:13: condition
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_condition_in_expression332);
            condition36=condition();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, condition36.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expression"

    public static class condition_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "condition"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:71:1: condition : ( arithmetic_expr | arithmetic_expr logical arithmetic_expr -> ^( logical ( arithmetic_expr )+ ) );
    public final secondParser.condition_return condition() throws RecognitionException {
        secondParser.condition_return retval = new secondParser.condition_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        secondParser.arithmetic_expr_return arithmetic_expr37 = null;

        secondParser.arithmetic_expr_return arithmetic_expr38 = null;

        secondParser.logical_return logical39 = null;

        secondParser.arithmetic_expr_return arithmetic_expr40 = null;


        RewriteRuleSubtreeStream stream_logical=new RewriteRuleSubtreeStream(adaptor,"rule logical");
        RewriteRuleSubtreeStream stream_arithmetic_expr=new RewriteRuleSubtreeStream(adaptor,"rule arithmetic_expr");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:71:10: ( arithmetic_expr | arithmetic_expr logical arithmetic_expr -> ^( logical ( arithmetic_expr )+ ) )
            int alt5=2;
            alt5 = dfa5.predict(input);
            switch (alt5) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:72:5: arithmetic_expr
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_arithmetic_expr_in_condition343);
                    arithmetic_expr37=arithmetic_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, arithmetic_expr37.getTree());

                    }
                    break;
                case 2 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:74:5: arithmetic_expr logical arithmetic_expr
                    {
                    pushFollow(FOLLOW_arithmetic_expr_in_condition355);
                    arithmetic_expr38=arithmetic_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_arithmetic_expr.add(arithmetic_expr38.getTree());
                    pushFollow(FOLLOW_logical_in_condition357);
                    logical39=logical();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_logical.add(logical39.getTree());
                    pushFollow(FOLLOW_arithmetic_expr_in_condition359);
                    arithmetic_expr40=arithmetic_expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_arithmetic_expr.add(arithmetic_expr40.getTree());


                    // AST REWRITE
                    // elements: logical, arithmetic_expr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 74:45: -> ^( logical ( arithmetic_expr )+ )
                    {
                        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:74:48: ^( logical ( arithmetic_expr )+ )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_logical.nextNode(), root_1);

                        if ( !(stream_arithmetic_expr.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_arithmetic_expr.hasNext() ) {
                            adaptor.addChild(root_1, stream_arithmetic_expr.nextTree());

                        }
                        stream_arithmetic_expr.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "condition"

    public static class arithmetic_expr_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "arithmetic_expr"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:76:1: arithmetic_expr : ( term | term ( PLUS term )+ -> ^( PLUS ( term )+ ) | term ( MINUS term )+ -> ^( MINUS ( term )+ ) );
    public final secondParser.arithmetic_expr_return arithmetic_expr() throws RecognitionException {
        secondParser.arithmetic_expr_return retval = new secondParser.arithmetic_expr_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token PLUS43=null;
        Token MINUS46=null;
        secondParser.term_return term41 = null;

        secondParser.term_return term42 = null;

        secondParser.term_return term44 = null;

        secondParser.term_return term45 = null;

        secondParser.term_return term47 = null;


        Object PLUS43_tree=null;
        Object MINUS46_tree=null;
        RewriteRuleTokenStream stream_PLUS=new RewriteRuleTokenStream(adaptor,"token PLUS");
        RewriteRuleTokenStream stream_MINUS=new RewriteRuleTokenStream(adaptor,"token MINUS");
        RewriteRuleSubtreeStream stream_term=new RewriteRuleSubtreeStream(adaptor,"rule term");
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:76:16: ( term | term ( PLUS term )+ -> ^( PLUS ( term )+ ) | term ( MINUS term )+ -> ^( MINUS ( term )+ ) )
            int alt8=3;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==ID) ) {
                switch ( input.LA(2) ) {
                case PAREN_END:
                case EQUAL_EQUAL:
                case LT:
                case 29:
                    {
                    alt8=1;
                    }
                    break;
                case PLUS:
                    {
                    alt8=2;
                    }
                    break;
                case MINUS:
                    {
                    alt8=3;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 8, 1, input);

                    throw nvae;
                }

            }
            else if ( ((LA8_0>=INT_LITERAL && LA8_0<=STRING_LITERAL)) ) {
                switch ( input.LA(2) ) {
                case PAREN_END:
                case EQUAL_EQUAL:
                case LT:
                case 29:
                    {
                    alt8=1;
                    }
                    break;
                case PLUS:
                    {
                    alt8=2;
                    }
                    break;
                case MINUS:
                    {
                    alt8=3;
                    }
                    break;
                default:
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 8, 2, input);

                    throw nvae;
                }

            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:77:5: term
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_term_in_arithmetic_expr379);
                    term41=term();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, term41.getTree());

                    }
                    break;
                case 2 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:79:5: term ( PLUS term )+
                    {
                    pushFollow(FOLLOW_term_in_arithmetic_expr391);
                    term42=term();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_term.add(term42.getTree());
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:79:10: ( PLUS term )+
                    int cnt6=0;
                    loop6:
                    do {
                        int alt6=2;
                        int LA6_0 = input.LA(1);

                        if ( (LA6_0==PLUS) ) {
                            alt6=1;
                        }


                        switch (alt6) {
                    	case 1 :
                    	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:79:11: PLUS term
                    	    {
                    	    PLUS43=(Token)match(input,PLUS,FOLLOW_PLUS_in_arithmetic_expr394); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_PLUS.add(PLUS43);

                    	    pushFollow(FOLLOW_term_in_arithmetic_expr396);
                    	    term44=term();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_term.add(term44.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt6 >= 1 ) break loop6;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(6, input);
                                throw eee;
                        }
                        cnt6++;
                    } while (true);



                    // AST REWRITE
                    // elements: term, PLUS
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 79:23: -> ^( PLUS ( term )+ )
                    {
                        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:79:26: ^( PLUS ( term )+ )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_PLUS.nextNode(), root_1);

                        if ( !(stream_term.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_term.hasNext() ) {
                            adaptor.addChild(root_1, stream_term.nextTree());

                        }
                        stream_term.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 3 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:81:5: term ( MINUS term )+
                    {
                    pushFollow(FOLLOW_term_in_arithmetic_expr419);
                    term45=term();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_term.add(term45.getTree());
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:81:10: ( MINUS term )+
                    int cnt7=0;
                    loop7:
                    do {
                        int alt7=2;
                        int LA7_0 = input.LA(1);

                        if ( (LA7_0==MINUS) ) {
                            alt7=1;
                        }


                        switch (alt7) {
                    	case 1 :
                    	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:81:11: MINUS term
                    	    {
                    	    MINUS46=(Token)match(input,MINUS,FOLLOW_MINUS_in_arithmetic_expr422); if (state.failed) return retval; 
                    	    if ( state.backtracking==0 ) stream_MINUS.add(MINUS46);

                    	    pushFollow(FOLLOW_term_in_arithmetic_expr424);
                    	    term47=term();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) stream_term.add(term47.getTree());

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt7 >= 1 ) break loop7;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(7, input);
                                throw eee;
                        }
                        cnt7++;
                    } while (true);



                    // AST REWRITE
                    // elements: MINUS, term
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (Object)adaptor.nil();
                    // 81:24: -> ^( MINUS ( term )+ )
                    {
                        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:81:27: ^( MINUS ( term )+ )
                        {
                        Object root_1 = (Object)adaptor.nil();
                        root_1 = (Object)adaptor.becomeRoot(stream_MINUS.nextNode(), root_1);

                        if ( !(stream_term.hasNext()) ) {
                            throw new RewriteEarlyExitException();
                        }
                        while ( stream_term.hasNext() ) {
                            adaptor.addChild(root_1, stream_term.nextTree());

                        }
                        stream_term.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "arithmetic_expr"

    public static class term_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "term"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:84:1: term : factor ;
    public final secondParser.term_return term() throws RecognitionException {
        secondParser.term_return retval = new secondParser.term_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        secondParser.factor_return factor48 = null;



        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:84:5: ( factor )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:85:5: factor
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_factor_in_term451);
            factor48=factor();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, factor48.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "term"

    public static class factor_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "factor"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:88:1: factor : primary ;
    public final secondParser.factor_return factor() throws RecognitionException {
        secondParser.factor_return retval = new secondParser.factor_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        secondParser.primary_return primary49 = null;



        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:88:7: ( primary )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:89:5: primary
            {
            root_0 = (Object)adaptor.nil();

            pushFollow(FOLLOW_primary_in_factor467);
            primary49=primary();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, primary49.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "factor"

    public static class primary_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "primary"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:92:1: primary : ( ID | literal );
    public final secondParser.primary_return primary() throws RecognitionException {
        secondParser.primary_return retval = new secondParser.primary_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token ID50=null;
        secondParser.literal_return literal51 = null;


        Object ID50_tree=null;

        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:92:8: ( ID | literal )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==ID) ) {
                alt9=1;
            }
            else if ( ((LA9_0>=INT_LITERAL && LA9_0<=STRING_LITERAL)) ) {
                alt9=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:93:5: ID
                    {
                    root_0 = (Object)adaptor.nil();

                    ID50=(Token)match(input,ID,FOLLOW_ID_in_primary483); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ID50_tree = (Object)adaptor.create(ID50);
                    adaptor.addChild(root_0, ID50_tree);
                    }

                    }
                    break;
                case 2 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:95:5: literal
                    {
                    root_0 = (Object)adaptor.nil();

                    pushFollow(FOLLOW_literal_in_primary495);
                    literal51=literal();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, literal51.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "primary"

    public static class literal_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "literal"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:98:1: literal : ( INT_LITERAL | STRING_LITERAL );
    public final secondParser.literal_return literal() throws RecognitionException {
        secondParser.literal_return retval = new secondParser.literal_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set52=null;

        Object set52_tree=null;

        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:98:8: ( INT_LITERAL | STRING_LITERAL )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:
            {
            root_0 = (Object)adaptor.nil();

            set52=(Token)input.LT(1);
            if ( (input.LA(1)>=INT_LITERAL && input.LA(1)<=STRING_LITERAL) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (Object)adaptor.create(set52));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "literal"

    public static class logical_return extends ParserRuleReturnScope {
        Object tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "logical"
    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:104:1: logical : ( EQUAL_EQUAL | LT );
    public final secondParser.logical_return logical() throws RecognitionException {
        secondParser.logical_return retval = new secondParser.logical_return();
        retval.start = input.LT(1);

        Object root_0 = null;

        Token set53=null;

        Object set53_tree=null;

        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:104:8: ( EQUAL_EQUAL | LT )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:
            {
            root_0 = (Object)adaptor.nil();

            set53=(Token)input.LT(1);
            if ( (input.LA(1)>=EQUAL_EQUAL && input.LA(1)<=LT) ) {
                input.consume();
                if ( state.backtracking==0 ) adaptor.addChild(root_0, (Object)adaptor.create(set53));
                state.errorRecovery=false;state.failed=false;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                MismatchedSetException mse = new MismatchedSetException(null,input);
                throw mse;
            }


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (Object)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (Object)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "logical"

    // $ANTLR start synpred1_second
    public final void synpred1_second_fragment() throws RecognitionException {   
        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:50: ( ELSE )
        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:57:51: ELSE
        {
        match(input,ELSE,FOLLOW_ELSE_in_synpred1_second263); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_second

    // Delegated rules

    public final boolean synpred1_second() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_second_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA5 dfa5 = new DFA5(this);
    static final String DFA5_eotS =
        "\13\uffff";
    static final String DFA5_eofS =
        "\13\uffff";
    static final String DFA5_minS =
        "\1\5\2\15\1\uffff\2\5\1\uffff\4\15";
    static final String DFA5_maxS =
        "\1\23\2\35\1\uffff\2\23\1\uffff\4\35";
    static final String DFA5_acceptS =
        "\3\uffff\1\1\2\uffff\1\2\4\uffff";
    static final String DFA5_specialS =
        "\13\uffff}>";
    static final String[] DFA5_transitionS = {
            "\1\1\14\uffff\2\2",
            "\1\3\2\uffff\1\4\1\5\2\uffff\2\6\7\uffff\1\3",
            "\1\3\2\uffff\1\4\1\5\2\uffff\2\6\7\uffff\1\3",
            "",
            "\1\7\14\uffff\2\10",
            "\1\11\14\uffff\2\12",
            "",
            "\1\3\2\uffff\1\4\3\uffff\2\6\7\uffff\1\3",
            "\1\3\2\uffff\1\4\3\uffff\2\6\7\uffff\1\3",
            "\1\3\3\uffff\1\5\2\uffff\2\6\7\uffff\1\3",
            "\1\3\3\uffff\1\5\2\uffff\2\6\7\uffff\1\3"
    };

    static final short[] DFA5_eot = DFA.unpackEncodedString(DFA5_eotS);
    static final short[] DFA5_eof = DFA.unpackEncodedString(DFA5_eofS);
    static final char[] DFA5_min = DFA.unpackEncodedStringToUnsignedChars(DFA5_minS);
    static final char[] DFA5_max = DFA.unpackEncodedStringToUnsignedChars(DFA5_maxS);
    static final short[] DFA5_accept = DFA.unpackEncodedString(DFA5_acceptS);
    static final short[] DFA5_special = DFA.unpackEncodedString(DFA5_specialS);
    static final short[][] DFA5_transition;

    static {
        int numStates = DFA5_transitionS.length;
        DFA5_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA5_transition[i] = DFA.unpackEncodedString(DFA5_transitionS[i]);
        }
    }

    class DFA5 extends DFA {

        public DFA5(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 5;
            this.eot = DFA5_eot;
            this.eof = DFA5_eof;
            this.min = DFA5_min;
            this.max = DFA5_max;
            this.accept = DFA5_accept;
            this.special = DFA5_special;
            this.transition = DFA5_transition;
        }
        public String getDescription() {
            return "71:1: condition : ( arithmetic_expr | arithmetic_expr logical arithmetic_expr -> ^( logical ( arithmetic_expr )+ ) );";
        }
    }
 

    public static final BitSet FOLLOW_decl_in_compilationUnit57 = new BitSet(new long[]{0x0000000000008B60L});
    public static final BitSet FOLLOW_stmt_in_compilationUnit59 = new BitSet(new long[]{0x0000000000008B60L});
    public static final BitSet FOLLOW_EOF_in_compilationUnit63 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_type_in_decl89 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_ID_in_decl91 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_decl93 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INT_TYPE_in_type113 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignment_in_stmt127 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_pseudo_in_stmt135 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_block_in_stmt143 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ifStmt_in_stmt151 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_whileStmt_in_stmt159 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_assignment171 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_EQUALS_in_assignment173 = new BitSet(new long[]{0x00000000000C0020L});
    public static final BitSet FOLLOW_expression_in_assignment175 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_assignment177 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_PRINT_in_pseudo206 = new BitSet(new long[]{0x00000000000C0020L});
    public static final BitSet FOLLOW_expression_in_pseudo208 = new BitSet(new long[]{0x0000000020000000L});
    public static final BitSet FOLLOW_29_in_pseudo210 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_BRACE_START_in_block230 = new BitSet(new long[]{0x0000000000008F60L});
    public static final BitSet FOLLOW_stmt_in_block232 = new BitSet(new long[]{0x0000000000008F60L});
    public static final BitSet FOLLOW_BRACE_END_in_block235 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_in_ifStmt251 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_PAREN_START_in_ifStmt253 = new BitSet(new long[]{0x00000000000C0020L});
    public static final BitSet FOLLOW_condition_in_ifStmt255 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_PAREN_END_in_ifStmt257 = new BitSet(new long[]{0x0000000000008B60L});
    public static final BitSet FOLLOW_stmt_in_ifStmt259 = new BitSet(new long[]{0x0000000000004002L});
    public static final BitSet FOLLOW_elseClause_in_ifStmt266 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSE_in_elseClause288 = new BitSet(new long[]{0x0000000000008B60L});
    public static final BitSet FOLLOW_stmt_in_elseClause290 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_in_whileStmt305 = new BitSet(new long[]{0x0000000000001000L});
    public static final BitSet FOLLOW_PAREN_START_in_whileStmt307 = new BitSet(new long[]{0x00000000000C0020L});
    public static final BitSet FOLLOW_condition_in_whileStmt309 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_PAREN_END_in_whileStmt311 = new BitSet(new long[]{0x0000000000008B60L});
    public static final BitSet FOLLOW_stmt_in_whileStmt313 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_condition_in_expression332 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_arithmetic_expr_in_condition343 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_arithmetic_expr_in_condition355 = new BitSet(new long[]{0x0000000000300000L});
    public static final BitSet FOLLOW_logical_in_condition357 = new BitSet(new long[]{0x00000000000C0020L});
    public static final BitSet FOLLOW_arithmetic_expr_in_condition359 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term_in_arithmetic_expr379 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_term_in_arithmetic_expr391 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_PLUS_in_arithmetic_expr394 = new BitSet(new long[]{0x00000000000C0020L});
    public static final BitSet FOLLOW_term_in_arithmetic_expr396 = new BitSet(new long[]{0x0000000000010002L});
    public static final BitSet FOLLOW_term_in_arithmetic_expr419 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_MINUS_in_arithmetic_expr422 = new BitSet(new long[]{0x00000000000C0020L});
    public static final BitSet FOLLOW_term_in_arithmetic_expr424 = new BitSet(new long[]{0x0000000000020002L});
    public static final BitSet FOLLOW_factor_in_term451 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_primary_in_factor467 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_primary483 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_literal_in_primary495 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_literal0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_logical0 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ELSE_in_synpred1_second263 = new BitSet(new long[]{0x0000000000000002L});

}