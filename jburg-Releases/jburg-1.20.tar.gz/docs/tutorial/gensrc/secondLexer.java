// $ANTLR 3.3 Nov 30, 2010 12:50:56 /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g 2013-03-20 10:47:09

package jburg.tutorial.second;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class secondLexer extends Lexer {
    public static final int EOF=-1;
    public static final int T__29=29;
    public static final int COMPILATION_UNIT=4;
    public static final int ID=5;
    public static final int INT_TYPE=6;
    public static final int EQUALS=7;
    public static final int PRINT=8;
    public static final int BRACE_START=9;
    public static final int BRACE_END=10;
    public static final int IF=11;
    public static final int PAREN_START=12;
    public static final int PAREN_END=13;
    public static final int ELSE=14;
    public static final int WHILE=15;
    public static final int PLUS=16;
    public static final int MINUS=17;
    public static final int INT_LITERAL=18;
    public static final int STRING_LITERAL=19;
    public static final int EQUAL_EQUAL=20;
    public static final int LT=21;
    public static final int STRING=22;
    public static final int LETTER=23;
    public static final int DIGIT=24;
    public static final int ESC=25;
    public static final int WS=26;
    public static final int COMMENT=27;
    public static final int LINE_COMMENT=28;

    // delegates
    // delegators

    public secondLexer() {;} 
    public secondLexer(CharStream input) {
        this(input, new RecognizerSharedState());
    }
    public secondLexer(CharStream input, RecognizerSharedState state) {
        super(input,state);

    }
    public String getGrammarFileName() { return "/Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g"; }

    // $ANTLR start "T__29"
    public final void mT__29() throws RecognitionException {
        try {
            int _type = T__29;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:7:7: ( ';' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:7:9: ';'
            {
            match(';'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "T__29"

    // $ANTLR start "BRACE_START"
    public final void mBRACE_START() throws RecognitionException {
        try {
            int _type = BRACE_START;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:109:12: ( '{' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:109:13: '{'
            {
            match('{'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BRACE_START"

    // $ANTLR start "BRACE_END"
    public final void mBRACE_END() throws RecognitionException {
        try {
            int _type = BRACE_END;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:110:10: ( '}' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:110:11: '}'
            {
            match('}'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "BRACE_END"

    // $ANTLR start "ELSE"
    public final void mELSE() throws RecognitionException {
        try {
            int _type = ELSE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:111:5: ( 'else' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:111:6: 'else'
            {
            match("else"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ELSE"

    // $ANTLR start "EQUAL_EQUAL"
    public final void mEQUAL_EQUAL() throws RecognitionException {
        try {
            int _type = EQUAL_EQUAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:112:12: ( '==' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:112:13: '=='
            {
            match("=="); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "EQUAL_EQUAL"

    // $ANTLR start "EQUALS"
    public final void mEQUALS() throws RecognitionException {
        try {
            int _type = EQUALS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:113:7: ( '=' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:113:8: '='
            {
            match('='); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "EQUALS"

    // $ANTLR start "IF"
    public final void mIF() throws RecognitionException {
        try {
            int _type = IF;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:114:3: ( 'if' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:114:4: 'if'
            {
            match("if"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "IF"

    // $ANTLR start "INT_TYPE"
    public final void mINT_TYPE() throws RecognitionException {
        try {
            int _type = INT_TYPE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:115:9: ( 'int' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:115:10: 'int'
            {
            match("int"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT_TYPE"

    // $ANTLR start "LT"
    public final void mLT() throws RecognitionException {
        try {
            int _type = LT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:116:3: ( '<' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:116:4: '<'
            {
            match('<'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LT"

    // $ANTLR start "MINUS"
    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:117:6: ( '-' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:117:7: '-'
            {
            match('-'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "MINUS"

    // $ANTLR start "PAREN_START"
    public final void mPAREN_START() throws RecognitionException {
        try {
            int _type = PAREN_START;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:118:12: ( '(' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:118:13: '('
            {
            match('('); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PAREN_START"

    // $ANTLR start "PAREN_END"
    public final void mPAREN_END() throws RecognitionException {
        try {
            int _type = PAREN_END;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:119:10: ( ')' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:119:11: ')'
            {
            match(')'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PAREN_END"

    // $ANTLR start "PLUS"
    public final void mPLUS() throws RecognitionException {
        try {
            int _type = PLUS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:120:5: ( '+' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:120:6: '+'
            {
            match('+'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PLUS"

    // $ANTLR start "PRINT"
    public final void mPRINT() throws RecognitionException {
        try {
            int _type = PRINT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:121:6: ( 'print' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:121:7: 'print'
            {
            match("print"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "PRINT"

    // $ANTLR start "STRING"
    public final void mSTRING() throws RecognitionException {
        try {
            int _type = STRING;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:122:7: ( 'String' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:122:8: 'String'
            {
            match("String"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STRING"

    // $ANTLR start "WHILE"
    public final void mWHILE() throws RecognitionException {
        try {
            int _type = WHILE;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:123:6: ( 'while' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:123:7: 'while'
            {
            match("while"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WHILE"

    // $ANTLR start "ID"
    public final void mID() throws RecognitionException {
        try {
            int _type = ID;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:126:5: ( LETTER ( '_' | LETTER | DIGIT )* )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:126:9: LETTER ( '_' | LETTER | DIGIT )*
            {
            mLETTER(); 
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:126:16: ( '_' | LETTER | DIGIT )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>='0' && LA1_0<='9')||(LA1_0>='A' && LA1_0<='Z')||LA1_0=='_'||(LA1_0>='a' && LA1_0<='z')) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:
            	    {
            	    if ( (input.LA(1)>='0' && input.LA(1)<='9')||(input.LA(1)>='A' && input.LA(1)<='Z')||input.LA(1)=='_'||(input.LA(1)>='a' && input.LA(1)<='z') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "ID"

    // $ANTLR start "INT_LITERAL"
    public final void mINT_LITERAL() throws RecognitionException {
        try {
            int _type = INT_LITERAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:129:13: ( ( ( DIGIT )+ ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:129:15: ( ( DIGIT )+ )
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:129:15: ( ( DIGIT )+ )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:129:16: ( DIGIT )+
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:129:16: ( DIGIT )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>='0' && LA2_0<='9')) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:129:16: DIGIT
            	    {
            	    mDIGIT(); 

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);


            }


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "INT_LITERAL"

    // $ANTLR start "LETTER"
    public final void mLETTER() throws RecognitionException {
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:132:7: ( ( 'a' .. 'z' | 'A' .. 'Z' ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:132:9: ( 'a' .. 'z' | 'A' .. 'Z' )
            {
            if ( (input.LA(1)>='A' && input.LA(1)<='Z')||(input.LA(1)>='a' && input.LA(1)<='z') ) {
                input.consume();

            }
            else {
                MismatchedSetException mse = new MismatchedSetException(null,input);
                recover(mse);
                throw mse;}


            }

        }
        finally {
        }
    }
    // $ANTLR end "LETTER"

    // $ANTLR start "DIGIT"
    public final void mDIGIT() throws RecognitionException {
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:136:2: ( '0' .. '9' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:136:4: '0' .. '9'
            {
            matchRange('0','9'); 

            }

        }
        finally {
        }
    }
    // $ANTLR end "DIGIT"

    // $ANTLR start "STRING_LITERAL"
    public final void mSTRING_LITERAL() throws RecognitionException {
        try {
            int _type = STRING_LITERAL;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:139:2: ( '\"' ( ESC | ~ ( '\\\\' | '\"' ) )* '\"' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:139:4: '\"' ( ESC | ~ ( '\\\\' | '\"' ) )* '\"'
            {
            match('\"'); 
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:139:8: ( ESC | ~ ( '\\\\' | '\"' ) )*
            loop3:
            do {
                int alt3=3;
                int LA3_0 = input.LA(1);

                if ( (LA3_0=='\\') ) {
                    alt3=1;
                }
                else if ( ((LA3_0>='\u0000' && LA3_0<='!')||(LA3_0>='#' && LA3_0<='[')||(LA3_0>=']' && LA3_0<='\uFFFF')) ) {
                    alt3=2;
                }


                switch (alt3) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:139:9: ESC
            	    {
            	    mESC(); 

            	    }
            	    break;
            	case 2 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:139:15: ~ ( '\\\\' | '\"' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='!')||(input.LA(1)>='#' && input.LA(1)<='[')||(input.LA(1)>=']' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            match('\"'); 

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "STRING_LITERAL"

    // $ANTLR start "ESC"
    public final void mESC() throws RecognitionException {
        try {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:148:5: ( '\\\\' ( | '\"' | '\\\\' | . ) )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:148:7: '\\\\' ( | '\"' | '\\\\' | . )
            {
            match('\\'); 
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:149:3: ( | '\"' | '\\\\' | . )
            int alt4=4;
            int LA4_0 = input.LA(1);

            if ( (LA4_0=='\"') ) {
                alt4=2;
            }
            else if ( (LA4_0=='\\') ) {
                alt4=3;
            }
            else if ( ((LA4_0>='\u0000' && LA4_0<='!')||(LA4_0>='#' && LA4_0<='[')||(LA4_0>=']' && LA4_0<='\uFFFF')) ) {
                alt4=4;
            }
            else {
                alt4=1;}
            switch (alt4) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:150:3: 
                    {
                    }
                    break;
                case 2 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:150:5: '\"'
                    {
                    match('\"'); 

                    }
                    break;
                case 3 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:151:5: '\\\\'
                    {
                    match('\\'); 

                    }
                    break;
                case 4 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:152:5: .
                    {
                    matchAny(); 

                    }
                    break;

            }


            }

        }
        finally {
        }
    }
    // $ANTLR end "ESC"

    // $ANTLR start "WS"
    public final void mWS() throws RecognitionException {
        try {
            int _type = WS;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:155:5: ( ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )+ )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:155:8: ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )+
            {
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:155:8: ( ' ' | '\\r' | '\\t' | '\\u000C' | '\\n' )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( ((LA5_0>='\t' && LA5_0<='\n')||(LA5_0>='\f' && LA5_0<='\r')||LA5_0==' ') ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:
            	    {
            	    if ( (input.LA(1)>='\t' && input.LA(1)<='\n')||(input.LA(1)>='\f' && input.LA(1)<='\r')||input.LA(1)==' ' ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);

            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "WS"

    // $ANTLR start "COMMENT"
    public final void mCOMMENT() throws RecognitionException {
        try {
            int _type = COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:159:5: ( '/*' ( options {greedy=false; } : . )* '*/' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:159:9: '/*' ( options {greedy=false; } : . )* '*/'
            {
            match("/*"); 

            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:159:14: ( options {greedy=false; } : . )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0=='*') ) {
                    int LA6_1 = input.LA(2);

                    if ( (LA6_1=='/') ) {
                        alt6=2;
                    }
                    else if ( ((LA6_1>='\u0000' && LA6_1<='.')||(LA6_1>='0' && LA6_1<='\uFFFF')) ) {
                        alt6=1;
                    }


                }
                else if ( ((LA6_0>='\u0000' && LA6_0<=')')||(LA6_0>='+' && LA6_0<='\uFFFF')) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:159:42: .
            	    {
            	    matchAny(); 

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);

            match("*/"); 

            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "COMMENT"

    // $ANTLR start "LINE_COMMENT"
    public final void mLINE_COMMENT() throws RecognitionException {
        try {
            int _type = LINE_COMMENT;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:163:5: ( '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n' )
            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:163:7: '//' (~ ( '\\n' | '\\r' ) )* ( '\\r' )? '\\n'
            {
            match("//"); 

            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:163:12: (~ ( '\\n' | '\\r' ) )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( ((LA7_0>='\u0000' && LA7_0<='\t')||(LA7_0>='\u000B' && LA7_0<='\f')||(LA7_0>='\u000E' && LA7_0<='\uFFFF')) ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:163:12: ~ ( '\\n' | '\\r' )
            	    {
            	    if ( (input.LA(1)>='\u0000' && input.LA(1)<='\t')||(input.LA(1)>='\u000B' && input.LA(1)<='\f')||(input.LA(1)>='\u000E' && input.LA(1)<='\uFFFF') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse = new MismatchedSetException(null,input);
            	        recover(mse);
            	        throw mse;}


            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);

            // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:163:26: ( '\\r' )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0=='\r') ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:163:26: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 
            _channel=HIDDEN;

            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
    // $ANTLR end "LINE_COMMENT"

    public void mTokens() throws RecognitionException {
        // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:8: ( T__29 | BRACE_START | BRACE_END | ELSE | EQUAL_EQUAL | EQUALS | IF | INT_TYPE | LT | MINUS | PAREN_START | PAREN_END | PLUS | PRINT | STRING | WHILE | ID | INT_LITERAL | STRING_LITERAL | WS | COMMENT | LINE_COMMENT )
        int alt9=22;
        alt9 = dfa9.predict(input);
        switch (alt9) {
            case 1 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:10: T__29
                {
                mT__29(); 

                }
                break;
            case 2 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:16: BRACE_START
                {
                mBRACE_START(); 

                }
                break;
            case 3 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:28: BRACE_END
                {
                mBRACE_END(); 

                }
                break;
            case 4 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:38: ELSE
                {
                mELSE(); 

                }
                break;
            case 5 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:43: EQUAL_EQUAL
                {
                mEQUAL_EQUAL(); 

                }
                break;
            case 6 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:55: EQUALS
                {
                mEQUALS(); 

                }
                break;
            case 7 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:62: IF
                {
                mIF(); 

                }
                break;
            case 8 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:65: INT_TYPE
                {
                mINT_TYPE(); 

                }
                break;
            case 9 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:74: LT
                {
                mLT(); 

                }
                break;
            case 10 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:77: MINUS
                {
                mMINUS(); 

                }
                break;
            case 11 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:83: PAREN_START
                {
                mPAREN_START(); 

                }
                break;
            case 12 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:95: PAREN_END
                {
                mPAREN_END(); 

                }
                break;
            case 13 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:105: PLUS
                {
                mPLUS(); 

                }
                break;
            case 14 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:110: PRINT
                {
                mPRINT(); 

                }
                break;
            case 15 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:116: STRING
                {
                mSTRING(); 

                }
                break;
            case 16 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:123: WHILE
                {
                mWHILE(); 

                }
                break;
            case 17 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:129: ID
                {
                mID(); 

                }
                break;
            case 18 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:132: INT_LITERAL
                {
                mINT_LITERAL(); 

                }
                break;
            case 19 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:144: STRING_LITERAL
                {
                mSTRING_LITERAL(); 

                }
                break;
            case 20 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:159: WS
                {
                mWS(); 

                }
                break;
            case 21 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:162: COMMENT
                {
                mCOMMENT(); 

                }
                break;
            case 22 :
                // /Users/tharwood/projects/jburg/docs/tutorial/src/jburg/tutorial/second/second.g:1:170: LINE_COMMENT
                {
                mLINE_COMMENT(); 

                }
                break;

        }

    }


    protected DFA9 dfa9 = new DFA9(this);
    static final String DFA9_eotS =
        "\4\uffff\1\17\1\26\1\17\5\uffff\3\17\5\uffff\1\17\2\uffff\1\37\4"+
        "\17\2\uffff\1\17\1\uffff\1\45\3\17\1\51\1\uffff\3\17\1\uffff\1\55"+
        "\1\17\1\57\1\uffff\1\60\2\uffff";
    static final String DFA9_eofS =
        "\61\uffff";
    static final String DFA9_minS =
        "\1\11\3\uffff\1\154\1\75\1\146\5\uffff\1\162\1\164\1\150\4\uffff"+
        "\1\52\1\163\2\uffff\1\60\1\164\1\151\1\162\1\151\2\uffff\1\145\1"+
        "\uffff\1\60\1\156\1\151\1\154\1\60\1\uffff\1\164\1\156\1\145\1\uffff"+
        "\1\60\1\147\1\60\1\uffff\1\60\2\uffff";
    static final String DFA9_maxS =
        "\1\175\3\uffff\1\154\1\75\1\156\5\uffff\1\162\1\164\1\150\4\uffff"+
        "\1\57\1\163\2\uffff\1\172\1\164\1\151\1\162\1\151\2\uffff\1\145"+
        "\1\uffff\1\172\1\156\1\151\1\154\1\172\1\uffff\1\164\1\156\1\145"+
        "\1\uffff\1\172\1\147\1\172\1\uffff\1\172\2\uffff";
    static final String DFA9_acceptS =
        "\1\uffff\1\1\1\2\1\3\3\uffff\1\11\1\12\1\13\1\14\1\15\3\uffff\1"+
        "\21\1\22\1\23\1\24\2\uffff\1\5\1\6\5\uffff\1\25\1\26\1\uffff\1\7"+
        "\5\uffff\1\10\3\uffff\1\4\3\uffff\1\16\1\uffff\1\20\1\17";
    static final String DFA9_specialS =
        "\61\uffff}>";
    static final String[] DFA9_transitionS = {
            "\2\22\1\uffff\2\22\22\uffff\1\22\1\uffff\1\21\5\uffff\1\11\1"+
            "\12\1\uffff\1\13\1\uffff\1\10\1\uffff\1\23\12\20\1\uffff\1\1"+
            "\1\7\1\5\3\uffff\22\17\1\15\7\17\6\uffff\4\17\1\4\3\17\1\6\6"+
            "\17\1\14\6\17\1\16\3\17\1\2\1\uffff\1\3",
            "",
            "",
            "",
            "\1\24",
            "\1\25",
            "\1\27\7\uffff\1\30",
            "",
            "",
            "",
            "",
            "",
            "\1\31",
            "\1\32",
            "\1\33",
            "",
            "",
            "",
            "",
            "\1\34\4\uffff\1\35",
            "\1\36",
            "",
            "",
            "\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32\17",
            "\1\40",
            "\1\41",
            "\1\42",
            "\1\43",
            "",
            "",
            "\1\44",
            "",
            "\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32\17",
            "\1\46",
            "\1\47",
            "\1\50",
            "\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32\17",
            "",
            "\1\52",
            "\1\53",
            "\1\54",
            "",
            "\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32\17",
            "\1\56",
            "\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32\17",
            "",
            "\12\17\7\uffff\32\17\4\uffff\1\17\1\uffff\32\17",
            "",
            ""
    };

    static final short[] DFA9_eot = DFA.unpackEncodedString(DFA9_eotS);
    static final short[] DFA9_eof = DFA.unpackEncodedString(DFA9_eofS);
    static final char[] DFA9_min = DFA.unpackEncodedStringToUnsignedChars(DFA9_minS);
    static final char[] DFA9_max = DFA.unpackEncodedStringToUnsignedChars(DFA9_maxS);
    static final short[] DFA9_accept = DFA.unpackEncodedString(DFA9_acceptS);
    static final short[] DFA9_special = DFA.unpackEncodedString(DFA9_specialS);
    static final short[][] DFA9_transition;

    static {
        int numStates = DFA9_transitionS.length;
        DFA9_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA9_transition[i] = DFA.unpackEncodedString(DFA9_transitionS[i]);
        }
    }

    class DFA9 extends DFA {

        public DFA9(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 9;
            this.eot = DFA9_eot;
            this.eof = DFA9_eof;
            this.min = DFA9_min;
            this.max = DFA9_max;
            this.accept = DFA9_accept;
            this.special = DFA9_special;
            this.transition = DFA9_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( T__29 | BRACE_START | BRACE_END | ELSE | EQUAL_EQUAL | EQUALS | IF | INT_TYPE | LT | MINUS | PAREN_START | PAREN_END | PLUS | PRINT | STRING | WHILE | ID | INT_LITERAL | STRING_LITERAL | WS | COMMENT | LINE_COMMENT );";
        }
    }
 

}