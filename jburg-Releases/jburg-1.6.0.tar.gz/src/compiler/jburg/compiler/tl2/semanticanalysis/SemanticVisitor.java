package jburg.compiler.tl2.semanticanalysis;

import jburg.compiler.tl2.ir.TL2INode;

public interface SemanticVisitor
{
   void preOrderVisit  (TL2INode p);
   void postOrderVisit (TL2INode p);
}
