package jburg.compiler.tl2.ir;

import java.lang.reflect.Modifier;

import jburg.compiler.tl2.parser.TL2ParserConstants;

import jburg.compiler.tl2.semanticanalysis.SemanticConstants;
import jburg.compiler.tl2.semanticanalysis.AbstractClass;

import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.FieldGen;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.Type;

public class Symbol
implements
   SemanticConstants,
   TL2ParserConstants,
   org.apache.bcel.Constants
{
   private String         name  = null;
   private AbstractClass  clazz = null;

   private boolean isFinal  = false;
   private boolean isStatic = false;

   private Object staticConstantInitializer = null;

   private int     accessLevel = SYMBOL_ACCESS_DEFAULT;

   private int arrayDimension = 0;

   /**  FieldGen used if this Symbol represents a field in the class. */
   FieldGen fieldGen;

   /*
    * Local variable slot number; -1 means this is not a local variable.
    */
   private int slotNumber = -1;

   public Symbol ()
   {
   }

   public void setName ( String name )
   {
    this.name = name;
   }

   public String getName()
   {
    return this.name;
   }

   public void setSymbolClass( AbstractClass clazz )
   {
    this.clazz = clazz;
   }

   public void setPrimitiveType ( int pKind )
   {
    switch ( pKind )
    {
        case BOOLEAN_TYPE:
            this.clazz = AbstractClass.BOOLEAN;
            break;
        case INT_TYPE:
            this.clazz = AbstractClass.INT;
            break;
        case DOUBLE_TYPE:
            this.clazz = AbstractClass.DOUBLE;
            break;
        case FLOAT_TYPE:
            this.clazz = AbstractClass.FLOAT;
            break;
        case VOID_TYPE:
            this.clazz = AbstractClass.VOID;
            break;
        default:
            throw new IllegalStateException ( String.valueOf(pKind) );
    }
   }

   public AbstractClass getSymbolClass()
   {
    return this.clazz;
   }

   public boolean isFinal()
   {
    return this.isFinal;
   }

   public boolean isStatic()
   {
    return this.isStatic;
   }

   public int getAccess()
   {
    return this.accessLevel;
   }

   public boolean isPrivate()
   {
    return getAccess() == SYMBOL_ACCESS_PRIVATE;
   }

   public boolean isPackagePrivate()
   {
    return getAccess() == SYMBOL_ACCESS_DEFAULT;
   }

   public boolean isPublic()
   {
    return getAccess() == SYMBOL_ACCESS_PUBLIC;
   }

   /**
    *  Called by the parser as it processes a declaration's set of modifier tokens.
    *  @param pKind - the Token kind of this modifier.
    */
   public void appendModifier ( int pKind )
   {
    switch ( pKind )
    {
        case PUBLIC:
            if ( getAccess() == SYMBOL_ACCESS_PRIVATE )
                throw new IllegalArgumentException ( "public or private may only be specified once." );
            else
                this.accessLevel = SYMBOL_ACCESS_PUBLIC;
            break;

        case PRIVATE:
            if ( getAccess() == SYMBOL_ACCESS_PUBLIC )
                throw new IllegalArgumentException ( "public or private may only be specified once." );
            else
                this.accessLevel = SYMBOL_ACCESS_PRIVATE;
            break;

        case STATIC:
            this.isStatic = true;
            break;

        case FINAL:
            this.isFinal = true;
            break;

        default:
            //  Shouldn't get here.
            throw new IllegalStateException( String.valueOf ( pKind ) );
    }
   }

   /**
    *  Translate java.lang.reflect modifiers to Symbol settings.
    *  Called during construction of compiler-level representations
    *  of method and field data.
    */
   public void setModifiers ( int modifiers )
   {
    if ( Modifier.isStatic(modifiers) )
        this.isStatic = true;

    if ( Modifier.isFinal(modifiers) )
        this.isFinal = true;

    if ( Modifier.isPrivate(modifiers) )
        this.accessLevel = SYMBOL_ACCESS_PRIVATE;

    if ( Modifier.isPublic(modifiers) )
        this.accessLevel = SYMBOL_ACCESS_PUBLIC;
   }

   /**
    * @return this Symbol's access modifiers, translated to BCEL format.
    */
   public int getAccesslevel()
   {
    int result = 0;

    if ( this.isPublic() )
        result = ACC_PUBLIC;
    else if ( this.isPrivate() )
        result = ACC_PRIVATE;

    if ( this.isFinal() )
        result |= ACC_FINAL;

    if ( this.isStatic() )
        result |= ACC_STATIC;

    return result;
   }

   /** @return this Symbol's BCEL type. */
   public Type getType()
   {
    return this.clazz.getType();
   }

   /**
    * Set this symbol's slot number, which
    * implies it's a local variable.
    */
   public void setSlotnumber(int slot)
   {
    this.slotNumber = slot;
   }

   /**
    *  @return this Symbol's slot number,
    *    or -1 if it's not a local variable.
    */
   public int getSlotnumber()
   {
    return this.slotNumber;
   }

   /** @return true if this is a local variable. */
   public boolean isLocal()
   {
    return getSlotnumber() > -1;
   }

   /**
    *  Called when the parser sees the "[]" pseudo-modifier
    *  on a declaration.  May be called many times.
    */
   public void setDimension ( int i)
   {
    this.arrayDimension = i;
    setSymbolClass ( getSymbolClass().getArrayType( this.arrayDimension ) );
   }

   public int getDimension()
   {
    return this.arrayDimension;
   }

   /**
    *  @return this Symbol's class signature.
    */
   public String getSignature()
   {
    return this.clazz.getSignature();
   }


   /**
    *  This Symbol represents a field; give it a FieldGen.
    */
   public void makeField ( ConstantPoolGen cp )
   {
    this.fieldGen = new FieldGen ( getAccesslevel(), getType(), getName(), cp );

    if ( hasIntValue() )
        this.fieldGen.setInitValue( intValue() );
   }

   /** @return this Symbol's FieldGen, assuming it is a field; null otherwise. */
   public FieldGen getFieldGen()
   {
    return this.fieldGen;
   }

   /**
    *
    */
   public void setIntValue ( int initializer )
   {
    this.staticConstantInitializer = new Integer(initializer);
   }

   public boolean hasIntValue()
   {
    return this.staticConstantInitializer != null && this.staticConstantInitializer instanceof Integer;
   }

   public int intValue()
   {
    return ((Integer)this.staticConstantInitializer).intValue();
   }

   public String toString()
   {
	   return name;
   }
}
