/**
 *  Ina2CoerceParen tests compiler-compile time coercion of PAREN nodes.
 */
public class Ina2CoerceParen
    implements 
        jburg.burg.inode.InodeAdapter, 
        jburg.burg.inode.InodeAdapter2
{
    public boolean accept(String inode_class)
    {
        //  Instantiated directly.
        return false;
    }

    public String genGetArity(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getArity");
	}

	public String genGetNthChild(String stem, String index, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getNthChild", index);
	}

	public String genGetOperator(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getOperator");
	}

    public Integer getConstantArity(String opcode)
    {
        if ( "INT".equals(opcode) )
            return new Integer(0);
        else if ( "PAREN".equals(opcode) )
            return new Integer(1);
        else
            return null;
    }

    public String genGetNthChild(String operator, String stem, int index, jburg.burg.emitlangs.EmitLang emitter)
    {
        if ( "INT".equals(operator) )
            return "null";
        else
            return genGetNthChild(stem, Integer.toString(index), emitter);
    }

    public String genGetDefaultChild(String operator, String node_path, String index, jburg.burg.emitlangs.EmitLang emitter)
    {
        return genGetNthChild(node_path, index, emitter);
    }
    
    public String genGetContent(String operator, String node_path, String goal_state, jburg.burg.emitlangs.EmitLang emitter)
    {
        if ( "INT".equals(operator) )
        {
            return "Integer.parseInt(" + node_path + ".getUserObject().toString())";
        }
        else
        {
            return null;
        }
    }

    public Integer getMaxNthChildChoice(String operator)
    {
        if ( "PAREN".equals(operator) )
            return new Integer(1);
        else
            return null;
    }
}
