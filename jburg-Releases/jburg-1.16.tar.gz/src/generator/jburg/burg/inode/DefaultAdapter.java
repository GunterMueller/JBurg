package jburg.burg.inode;

import jburg.burg.JBurgGenerator;

public class DefaultAdapter
    implements InodeAdapter
{
	public boolean accept(String inodeClassName)
	{
		//  This adapter is directly instantiated
		//  by the generator if all other adapters fail.
		return false;
	}

	public String genGetArity(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getArity");
	}

	public String genGetNthChild(String stem, String index, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getNthChild", index );
	}

	public String genGetOperator(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getOperator");
	}
}
