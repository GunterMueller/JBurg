package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.lang.reflect.Modifier;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import jburg.burg.JBurgGenerator;
import jburg.burg.JBurgPatternMatcher;

import jburg.burg.inode.InodeAdapter;
import jburg.burg.emitlangs.EmitLang;

import jburg.parser.JBurgTokenTypes;

import org.antlr.stringtemplate.*;

@SuppressWarnings({"nls","rawtypes"})
public class EmitJava implements EmitLang, JBurgTokenTypes  
{
    /**
     * Construct an emitter and load its templates.
     */
	public EmitJava()
    {
        this.templates = new TemplateGroup("templates", "EmitJava");
	}
    
	/**  The current block nesting depth. */
	private int blockCount = 0;

	/** Manifest constant signature snippet for a method that throws Exception.  */
	final static Class[] throwsException = new Class[] { Exception.class };

	/** Manifest constant signature snippet for a method that doens't throw.  */
	final static Class[] throwsNothing   = null;

	/** I-node adapter in use. */
	jburg.burg.inode.InodeAdapter inodeAdapter;
	
	/** Prefix to internal BURM names. */
	String internalPrefix = "__";

    /** Operator type, defaults to int */
    String operatorType = "int";

    /** Nonterminal type, defaults to int */
    private String ntType = "int";

    /** A for-loop header to iterate over the nonterminals. */
    private Object ntIterator = "for(int i = 0; i <= nStates; i++)";
    

    /** Enumerated nonterminals don't get decorated. */
    private boolean enumeratedNonterminals = false;

    /**
     * The string templates that build up Java source.
     */
    private TemplateGroup templates;

    /**
     * String templates for largely pre-written source, copied into the generated code.
     */
    private TemplateGroup boilerplate = new TemplateGroup("templates", "JavaBoilerplate");

    public void setOpcodeType(String operator_type)
    {
        this.operatorType = operator_type;
    }

    public void setNtType(String nt_type)
    {
        this.ntType = nt_type;
        this.enumeratedNonterminals = !(nt_type.equals("int"));

        if ( this.enumeratedNonterminals )
            this.ntIterator = String.format("for ( %s i: %s.values() )", this.ntType, this.ntType );
    }
	
	private String reducerStack()
	{
	    return internalPrefix + "reducedValues";
	}
	
	private String subgoalArray()
	{
	    return internalPrefix + "_subgoals_by_rule";
	}
	
	/** 
	 *  Debugging aid, used while converting boilerplate code from
	 *  raw output of cut/pasted hand-built reducer logic to the
	 *  more language-independent format JBurg uses.
	 */
	public boolean noisyBlockCounts = "true".equalsIgnoreCase(System.getenv("JBURG_NOISY_BLOCK_COUNTS"));

    @Override
    public boolean supportsSpecializedAnnotations()
    {
        return true;
    }

    @Override
    public void emitHeader(
        String strClassName,
        String packageName,
        String headerBlock,
        String baseClassName,
        Vector<String> InterfaceNames,
        boolean debugMode,
        PrintStream output
        )
	{
		int i;

		if (packageName != null)
			output.print("\npackage " + packageName + ";\n\n");

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n");
		}

		output.print("public class " + strClassName);

        if ( baseClassName != null )
            output.print(" extends " + baseClassName);

		if (InterfaceNames.size() > 0) {
			output.print(" implements ");

			for (i = 0; i < InterfaceNames.size(); i++) {
				if (i > 0) {
					output.print(", ");
				}

				output.print(InterfaceNames.get(i));
			}
		}

		output.print( genLine(genBeginBlock()));
		output.print(genLine("java.util.Stack " + reducerStack() + " = new java.util.Stack();"));
	}
    
    /**
     *  Emit the static subgoal arrays.
     */
    public void emitStatics(int max_action, Map<Integer, Vector<JBurgPatternMatcher>> rules_by_action, PrintStream output)
    {
        output.println();
        output.print(genLine("private static final JBurgSubgoal[][] " + subgoalArray() + " = "));
        output.print(genBeginBlock());
        for ( int i = 0; i <= max_action; i++ )
        {
            if ( rules_by_action.containsKey(i))
            {
                output.print(genBeginBlock());
                
                //  Emit the subgoals in reverse order so they are reduced and pushed
                //  onto the stack in the correct order.
                Vector<JBurgPatternMatcher> matchers = rules_by_action.get(i); 
                for ( int j = matchers.size() -1; j >= 0; j--  )
                {
                    JBurgPatternMatcher matcher = matchers.elementAt(j);
                    output.print(genLine("new JBurgSubgoal("));
                    output.print(genGetGoalState(matcher.getSubgoal() ));
                    output.print(",");
                    if ( matcher.isNary() )
                    {
                        output.print("true,");
                        output.print(matcher.getPositionInParent());
                    }
                    else
                    {
                        output.print("false,0");
                    }
                    for (JBurgPatternMatcher.PathElement idx: matcher.generateAccessPath() )
                    {
                        output.print(",");
                        output.print(Integer.toString(idx.index));
                    }
                    
                    output.print("),");
                }
                output.print(genEndBlock());
                output.print(",");
            }
            else
            {
                output.print(genLine("null,"));
            }
        }
        output.print(genEndBlock());
        output.println(genEndStmt());
        output.println();
    }


	public void emitAnnotation(String iNodeClass, PrintStream output) 
	{
        output.println(
            boilerplate.getTemplate(
                "annotation",
                "iNodeClass", iNodeClass,
                "opcodeClass", this.operatorType,
                "getOperator", inodeAdapter.genGetOperator("m_node", this),
                "ntType", this.ntType
            )
        );
	}

    @Override
	public void emitTrailer(
			String strClassName, 
			String iNodeClass, 
			Set<String> goalStateNames, 
			Map<String, String> burm_properties, 
			boolean debugMode, 
            String default_error_handler,
            Map<Integer,String> prologue_blocks,
			PrintStream output
		)
	{
        String problemTree = "__problemTree";

        StringTemplate trailer = boilerplate.getTemplate(
            "trailer",
            "iNodeClass", iNodeClass,
            "defaultErrorHandler", default_error_handler,
            "debugMode", new Boolean(debugMode),
            "problemTree", problemTree,
            "ntType", this.ntType,
            "ntIterator", this.ntIterator,
            "wildcardGoal", enumeratedNonterminals? "null":"0"
        );

        // Emit prologue blocks if they were specified.
        if ( prologue_blocks.size() > 0 )
        {
            ArrayList<CodeFragment> prologueCases = new ArrayList<CodeFragment>();
            trailer.setAttribute("prologueCases", prologueCases);

            for ( Integer rule: prologue_blocks.keySet() )
            {
                prologueCases.add(new CodeFragment(
                    "switchCase",
                    "label", rule,
                    "stmts", prologue_blocks.get(rule)));
            }
        }

		//  Emit BURM properties and their get/set methods.
        for ( Map.Entry entry: burm_properties.entrySet() )
		{
            String propertyName = entry.getKey().toString();
            String propertyType = entry.getValue().toString();

			//  Convert the property's name to canonical form, for inclusion
			//  in the get/set method names.
			StringBuffer canonicalName = new StringBuffer(propertyName.toLowerCase());
			canonicalName.setCharAt( 0, Character.toUpperCase( canonicalName.charAt( 0 )));

            output.println(new CodeFragment(
                "BURMProperty",
                "propertyType", propertyType,
                "propertyName", propertyName,
                "canonicalName", canonicalName
            ).toString());

		}

        output.println(trailer);

		// Emit dump routines.
		if (debugMode) 
		{
            StringTemplate debuggingSupport = boilerplate.getTemplate(
                "debuggingSupport",
                "iNodeClass", iNodeClass,
                "problemTree", problemTree,
                "stateNames", goalStateNames,
                "ntIterator", this.ntIterator
            );

			output.println(debuggingSupport);
		}

		//  Emit the JBurgAnnotation classes.
		emitAnnotation(iNodeClass, output);

		//  Close the class definition.
		output.print( genEndClass() );
	}

	public String genActionRoutineParameter(String stackName, String paramType, String paramName)
	{
		return genLine( String.format("%s %s = %s;", paramType, paramName, genPopFromStack(stackName, paramType)));
	}

    public String genPopFromStack(String stackName, String valueType)
    {
        return String.format("(%s)%s.pop()", valueType, stackName);
    }

	public String genPushToStack(String stackName, String value )
	{
		return String.format("%s.push(%s)", stackName, value);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCheckPtr(java.lang.String, boolean)
	 */
	public String genCheckPtr(String paramName, boolean checkForNull)
	{
        CodeFragment result = 
            checkForNull?
                new CodeFragment("equals"):
                new CodeFragment("notEquals")
            ;
        result.setAttribute("lhs", paramName);
        result.setAttribute("rhs", "null");
		return result.toString();
	}

	public String genAccessMember(String parentName, String memberName)
	{
		return new CodeFragment(
            "memberAccess",
            "stem", parentName,
            "member", memberName
        ).toString();
	}

	public String genCallMethod(String parentName, String methodName, String ... params)
	{
		return new CodeFragment(
            "callMethod",
            "params", params,
            "nameElements", parentName,
            "nameElements", methodName
        ).toString();
	}
	
	public void setInodeAdapter(jburg.burg.inode.InodeAdapter adapter)
	{
		this.inodeAdapter = adapter;
	}
	
	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitInclass(java.lang.String, java.util.Vector, java.io.PrintStream)
	 */
	public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output) 
	{
		output.println(new CodeFragment("adHocDirectives", "directives", inclassBlocks));
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCmpEquality(java.lang.String, java.lang.String, boolean)
	 */
	public String genCmpEquality(String lhs, String rhs, boolean testEquals)
	{
        CodeFragment result = testEquals?
            new CodeFragment("equals", "lhs", lhs, "rhs", rhs):
            new CodeFragment("notEquals", "lhs", lhs, "rhs", rhs);

		return result.toString();
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genLogicalAnd(java.lang.String, java.lang.String)
	 */
	public String genLogicalAnd(String lhs, String rhs)
	{
	   if ( lhs != null && rhs != null)
	       return new String(lhs + " && " + rhs);
	   else if ( null == lhs )
	       return rhs;
	   else
	       return lhs;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#accept(java.lang.String)
	 */
	public boolean accept(String langName)
	{
        return "java".equalsIgnoreCase(langName);
	}

	public String genIf( String condition )
	{
		return new CodeFragment("if", "condition", condition).toString();
	}


	public String genBeginBlock()
	{
		//  Note: change to " " to get something like 1TBS.
		String leadingSpace = genBeginLine();

		blockCount++;
		if ( this.noisyBlockCounts )
		    trace ("<+ " + blockCount);
		return leadingSpace + "{";
	}

	public String genEndBlock()
	{
		blockCount--;
		
		if ( this.noisyBlockCounts )
		    trace("-> " + blockCount);

		if ( blockCount < 0 )
		{
			throw new IllegalStateException("Invalid block count " + String.valueOf(blockCount) );
		}
		

		return genBeginLine() + "}";
	}
	
	void trace(String msg)
	{
	    System.out.println(msg);
	    StackTraceElement[] stack = new Exception().getStackTrace();
	    for ( int i = 2; i < 5 && i < stack.length; i++)
	       System.out.println(stack[i]);
	}

	public String genBeginLine()
	{
		StringBuffer result = new StringBuffer("\n");

		for ( int i = 0; i < blockCount; i++ )
		{
			result.append("\t");
		}

		return result.toString();
	}

	public String genLine(String line)
    {
		return genBeginLine() + line;
    }

	public String genLine(Object line)
	{
		return genBeginLine() + line.toString();
	}
	
	private String genSingleLineBlock(String stmt)
	{
	    this.blockCount++;
	    try
	    {
	        return genLine(stmt);
	    }
	    finally
	    {
	        this.blockCount--;
	    }
	}

	public String genCmpLess( String lhs, String rhs )
	{
		return "( " + lhs + " > " + rhs + " ) ";
	}

	public String genCmpGtEq(String lhs, String rhs)
	{
	    return "(" + lhs + " >= " + rhs + ")";
	}
	public String genNot( String operand )
	{
		return "!(" + operand + ")";
	}

	public String genGetGoalState ( Object p )
	{
       String undecoratedState = genGetUndecoratedGoalState(p);
       return enumeratedNonterminals ?
           String.format("%s.%s", this.ntType, undecoratedState):
           undecoratedState;
	}

    public String genGetUndecoratedGoalState( Object p )
    {
       String rawNT = p instanceof JBurgGenerator.JBurgRule ?
           ((JBurgGenerator.JBurgRule)p).getGoalState():
	       p.toString();

       return enumeratedNonterminals ?
           rawNT:
           String.format("__%s_NT", rawNT);
    }

	public String genComment( String text )
	{
		return "/* " + text + " */";
	}

	public String genEndStmt()
	{
		return ";";
	}

	public String genAddition( String a1, String a2 )
	{
		if ( a1 == null || a1.equals("0") )
			return a2;
		if ( a2 == null || a2.equals("0") )
			return a1;
		else
			return " (" + a1 + " + " + a2 + ") ";
	}

	public String genAssignment( String lvar, String rvalue )
	{
		return String.format("%s = %s;", lvar, rvalue);
	}

	public String genCast( String newClass, String target )
	{
		return String.format("((%s)%s)", newClass, target);
	}

	public String genSwitch( String selectionCriterion )
	{
		return "switch( " + selectionCriterion + " )";
	}

	public String genEndSwitch()
	{
		return genEndBlock();
	}

	public String genCase( String criterionValue )
	{
		return genBeginLine() + "case " + criterionValue + ":" + genBeginBlock();
	}

	public String genEndCase()
	{
		return genLine("break;") + genEndBlock();
	}

	public String genElse()
	{
		return genBeginLine() + "else";
	}

	public String genLocalVar ( String type, String name, String initializer )
	{
		CodeFragment result = new CodeFragment(
                "declareInstanceField",
                "name", name,
                "type", type,
                "initializer", initializer
        );
		return result.toString();
	}

	/**
	 *  Declare a method.
	 *  @param modifiers - java.lang.reflect.Modifier flags for public/private visibility.
	 *  @param returnClass - the method's return type.  null if the method is a constructor.
	 *  @param name - the method's name.
	 *  @param plist - an array of type/name parameter declarations.
	 *  @param exceptions - exceptions the method may throw.  
	 *  @return a snippet with the method's declaration.
	 */
	public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
	{       
		return genLine(methodDeclaration(modifiers,returnClass,name,plist,exceptions));
	}

	private CodeFragment methodDeclaration( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
    {
		CodeFragment result = new CodeFragment(
            "declareMethod",
            "name", name,
            "returnType", returnClass
        );

		decodeModifiers(modifiers, result);

		for ( int i = 0; i < plist.length; i++ )
		{
			if ( plist[i].length != 2 )
				throw new IllegalStateException( "Parameter list elements must be parameter pairs" );

			result.setAttribute("parameters", new CodeFragment("declareFormalParameter", "elements", plist[i]));
		}

        // TODO: Use a renderer so these can go straight in.
		if ( exceptions != null )
        {
			for ( int j = 0; j < exceptions.length; j++ )
				result.setAttribute( "exceptions", exceptions[j].getName() );
		}

        return result;
    }


	public String genThrow( String diagnostic )
	{
		return new CodeFragment("throwDiagnostic", "diagnostic", diagnostic).toString();
	}

	public String genDefaultCase()
	{
		return "default:";
	}

	public String genReturnValue( String value )
	{
		return new CodeFragment( "returnValue", "value", value).toString();
	}

	public String genEndClass()
	{
		return genLine(genEndBlock());
	}

	public String genCountingLoop( String controlVar, String startValue, String endValue, boolean inclusive )
	{
        return new CodeFragment(
            "forLoop",
            "controlVar", controlVar,
            "startValue", startValue,
            "endValue", endValue,
            "comparison", (inclusive? "<=":"<")
        ).toString();
	}

	public String genInstanceField ( int modifiers, String type, String name, String initializer )
	{
		CodeFragment result = new CodeFragment(
                "declareInstanceField",
                "name", name,
                "type", type,
                "initializer", initializer
        );

		decodeModifiers(modifiers, result);
		return genLine(result.toString());
	}

	private void decodeModifiers( int modifiers, CodeFragment result )
	{
		if ( Modifier.isPublic( modifiers ) )
			result.setAttribute("modifiers", "public" );
		else if ( Modifier.isProtected( modifiers ) )
			result.setAttribute("modifiers", "protected" );
		else if ( Modifier.isPrivate( modifiers ) )
			result.setAttribute("modifiers", "private" );

		if ( Modifier.isStatic( modifiers ) )
			result.setAttribute("modifiers", "static" );

		if ( Modifier.isFinal( modifiers ) )
			result.setAttribute("modifiers", "final" );
	}

	public String genMaxIntValue()
	{
		return new CodeFragment("maxIntValue").toString();
	}

    @Override
	public String genNewObject( String type, String ... parameters )
	{
        return new CodeFragment(
            "newObject",
            "type", type,
            "parameters", parameters
        ).toString();
	}

    @Override
	public String genNullPointer()
	{
		return "null";
	}

    @Override
	public String genWhileLoop( String test_condition )
	{
		return new CodeFragment(
            "whileHeader",
            "test", test_condition
        ).toString();
	}

    @Override
	public String genNaryContainerType(String base_type)
	{
		return "java.util.Vector<" + base_type + ">";
	}
	
    @Override
	public void setINodeType(String inode_type)
	{
	    //  No effect in the Java emitter.
	}

    @Override
    public String genOverflowSafeAdd(Object expr1, Object expr2)
    {
        return new CodeFragment("normalizeCost", "expr1", expr1, "expr2", expr2).toString();
    }

    @Override
    public TemplateGroup getTemplates()
    {
        return this.templates;
    }

    /**
     * Convenience wrapper around templates.
     */
    public class CodeFragment
    {
        public CodeFragment(String name, Object... attributePairs)
        {
            this.templ = EmitJava.this.templates.getTemplate(name, attributePairs);
        }

        private StringTemplate templ;

        /**
         * Delegate to the template's setAttribute().
         */
        void setAttribute(String key, Object value)
        {
            this.templ.setAttribute(key, value);
        }

        public String toString()
        {
            return this.templ.toString();
        }
    }
}
