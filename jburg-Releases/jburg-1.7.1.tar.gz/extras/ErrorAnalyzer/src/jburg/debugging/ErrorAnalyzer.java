package jburg.debugging;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.UnsupportedEncodingException;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.Vector;

import javax.swing.*;
import javax.swing.border.EtchedBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 * The ErrorAnalyzer parses JBurg diagnostic
 * dumps and presents them in a simple UI.
 * 
 * @author tharwood@adobe.com
 */
@SuppressWarnings("unused")
public class ErrorAnalyzer
{
    JFrame mainFrame;
    ErrorTree  labelTree;
    JScrollPane scroller;
    JLabel statusBar;
    
    String backingFileName;
    
    public static void main(String[] args) 
    {
        if ( args.length == 0 )
        {
            usage(System.err);
            System.exit(1);
        }
        
        new ErrorAnalyzer(args);

    }

    public static void usage(java.io.PrintStream out)
    {
        out.println("Usage: jburg.debugging.ErrorAnalyzer <xml file>"); //$NON-NLS-1$
    }
    
    private ErrorAnalyzer(String[] args)
    {
        
        mainFrame = new JFrame(this.backingFileName);
        createUI();
        
        for ( int i = 0; i < args.length; i++ )
        {
            if ( "-tokenTypes".equalsIgnoreCase(args[i]))
            {
                i++;
                    this.loadOpcodes(args[i]);
            }
            else
            this.backingFileName = args[i];
        }
        
        parse();
        mainFrame.pack();
        mainFrame.setVisible(true);
    }
    
    void parse()
    {   
        try
        {
            new ErrorParser().parse(this.backingFileName);
            this.scroller = new JScrollPane(labelTree);
            mainFrame.add(scroller);
        } catch ( Exception ex )
        {
            ex.printStackTrace();
        }
    }
    
    @SuppressWarnings("nls")
    private void createUI()
    {
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JMenu file_menu = new JMenu("File");
        file_menu.setMnemonic(KeyEvent.VK_F);
        
        file_menu.add(addMenuItem("Refresh", KeyEvent.VK_R, ENABLE_MENU_ITEM, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),
            new ActionListener() {             
                public void actionPerformed(ActionEvent e) {
                    if ( scroller != null )
                        mainFrame.remove(scroller);
                    scroller = null;
                    labelTree = null;
                    parse();
                    mainFrame.setVisible(true);
                    setStatus("");
            }
        } 
        ));
        file_menu.add(addMenuItem(FILE_EXIT, KeyEvent.VK_X, ENABLE_MENU_ITEM, new ActionListener() { public void actionPerformed(ActionEvent e) {System.exit(0);}} ));
        
        JMenu edit_menu = new JMenu("Edit");
        edit_menu.add(addMenuItem(EDIT_FIND, KeyEvent.VK_F, ENABLE_MENU_ITEM, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask(),
                new ActionListener() {

                    public void actionPerformed(ActionEvent e)
                    {
                        labelTree.findNextUnlabeled();
                    }
                    
                })
            );
        
        JMenuBar menu_bar  = new JMenuBar();
        menu_bar.add(file_menu);
        menu_bar.add(edit_menu);
    
        mainFrame.setJMenuBar(menu_bar);
        
        //  Add the status bar.
        JPanel status_area = new JPanel(new BorderLayout());
        status_area.setBorder(new EtchedBorder());
        mainFrame.add(status_area, BorderLayout.SOUTH);
        
        this.statusBar = new JLabel(" ");
        status_area.add(this.statusBar, BorderLayout.WEST);
    }
    
    void setStatus(String status) {
        this.statusBar.setText(status);
    }
    
    
    /**
     * Parse a JBurg diagnostic dump into its ErrorTree representation.
     */
    class ErrorParser extends org.xml.sax.ext.DefaultHandler2
    {
        Stack<DiagnosticNode> nodeStack = new Stack<DiagnosticNode>();
        
        StringBuffer elementChars = null; 
        
        ErrorParser()
        {
        }
        void parse(String filename)
        throws Exception
        {
            SAXParserFactory factory = SAXParserFactory.newInstance();
            factory.setNamespaceAware(true);
    
            SAXParser parser = factory.newSAXParser();
            java.io.InputStream input = new ProgressMonitorInputStream(mainFrame, "Parsing " + filename, new java.io.FileInputStream(filename) ); //$NON-NLS-1$
            parser.parse(input, this);
        }
        
        @SuppressWarnings("nls")
        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes)
        {   
            DiagnosticNode next = new DiagnosticNode(localName, attributes);

            if ( "BurmDump".equals(localName))
            {
                labelTree = new ErrorTree(next);   
            }
            else if ( "goal".equals(localName))
            {
                assert (nodeStack.peek().getLabel().equals("node"));
                nodeStack.peek().addGoal(next);
            }
            else if ( "Exception".equals(localName) || "AST".equals(localName) )
            {
                this.elementChars = new StringBuffer();
            }
            
            if ( !nodeStack.isEmpty() )
                nodeStack.peek().add(next);
            
            this.nodeStack.push(next);
        }
        
        @Override
        public void endElement(String uri,  String localName,  String qName)
        {
            if ( this.elementChars != null )
            {
                this.nodeStack.peek().add(new DiagnosticNode(this.elementChars.toString(), new org.xml.sax.helpers.AttributesImpl()));
                this.elementChars  = null;
            }
            this.nodeStack.pop();
        }
        
        @Override
        public void characters(char[] ch,
                int start,
                int length)
         throws SAXException
         {
            if ( this.elementChars != null )
            {
                this.elementChars.append(ch, start, length);
            }
         }
    }
    
    
    @SuppressWarnings("serial")
    class ErrorTree extends JTree implements TreeSelectionListener
    {
        /** Selected subtree in preorder. */
        Enumeration<DiagnosticNode> treeInPreorder = null;
        
        DiagnosticNode rootNode;
        
        ErrorTree(DiagnosticNode root)
        {
            super(root);
            this.rootNode = root;
        }
        
        /**
         * Get the node under the mouse.
         * @param e - the mouse event that triggered this action.
         * @param set_selection - if true, also set the node as selected.
         * @return the CallStackLevel under the mouse, or null if the mouse
         *   is in some random location.
         */
        private DiagnosticNode getNode(MouseEvent e, boolean set_selection)
        {
            TreePath selPath = getPathForLocation(e.getX(), e.getY());
            
            if ( null == selPath )
            {
                // Random bogus mouse event.
                return null;
            }
            
            if ( set_selection )
                this.setSelectionPath(selPath);
            
            return (DiagnosticNode)selPath.getLastPathComponent();
        }
        
        private DiagnosticNode getCurrentNode()
        {
            Object current = this.getLastSelectedPathComponent();
            if ( current != null )
                return (DiagnosticNode)current;
            else
                return this.rootNode;
        }
        
        @SuppressWarnings({ "unchecked", "nls" })
        void findNextUnlabeled()
        {
            if ( null == this.treeInPreorder )
            {
                DiagnosticNode n = getCurrentNode();
                treeInPreorder = n.preorderEnumeration();
            }
            
            boolean found_unlabeled = false;
            while ( !found_unlabeled && treeInPreorder.hasMoreElements() )
            {
                DiagnosticNode n = treeInPreorder.nextElement();
                
                if ( "node".equals(n.getLabel()) && !n.hasGoal() )
                {
                    TreePath path = new TreePath(n.getPath());
                    this.setSelectionPath(path);
                    this.scrollPathToVisible(path);
                    this.expandPath(path);
                    
                    found_unlabeled = true;
                }
            }
            
            if ( found_unlabeled )
                setStatus("");
            else
                setStatus("No unlabeled node found.");
        }

        public void valueChanged(TreeSelectionEvent e)
        {
            treeInPreorder = null;
        }
    }
    /**
     * A tree node with knowledge of its goal states and some formatting.
     */
    @SuppressWarnings("serial")
    class DiagnosticNode extends DefaultMutableTreeNode
    {   
        String label;
        Attributes attributes;
        Vector<DiagnosticNode> goals;
        
        DiagnosticNode(String label, Attributes attributes)
        {   
            this.label = label;
            this.attributes = attributes;
            createUserObject();
        }
        
        @SuppressWarnings("nls")
        void createUserObject()
        {
            StringBuffer buffer = new StringBuffer();
            
            buffer.append(label);
            
            for ( int index = 0; index < attributes.getLength(); index++)
            {
                String attr_name = attributes.getLocalName(index);
                String attr_value = attributes.getValue(index);
                
                buffer.append(" ");
                buffer.append(attr_name);
                buffer.append("=");
                if ( "operator".equals(attr_name) )
                {
                    if ( !opcodeToOpcodeName.isEmpty() )
                        buffer.append(decodeTokenType(Integer.parseInt(attr_value)));
                    else
                        buffer.append(attr_value);
                }
                else
                {
                    try
                    {
                        buffer.append(java.net.URLDecoder.decode(attr_value,"UTF-8"));
                    }
                    catch (UnsupportedEncodingException e)
                    {
                        // Can't happen, compile appeasement
                        e.printStackTrace();
                    }
                }
            }
            
            this.setUserObject(buffer.toString());
        }
        
        void addGoal(DiagnosticNode goalState)
        {
            if ( null == this.goals)
                this.goals = new Vector<DiagnosticNode>();
            this.goals.add(goalState);
        }
        
        boolean hasGoal()
        {
            return this.goals != null && this.goals.size() > 0;
        }
        
        String getLabel() { 
            return this.label;
        }
    }
    
    /**
     * Add a menu item with no keyboard accelerator.
     * @param label - descriptive text.
     * @param keyboard_shortcut - the menu keyboard shortcut for this item.
     * @param enabled_state - initial state of the menu item.
     * @param listener - an action listener to perform the menu item's function.
     * @return the new menu item.
     */
    private JMenuItem addMenuItem(String label, int keyboard_shortcut, boolean enabled_state, ActionListener listener)
    {
        return addMenuItem(label, keyboard_shortcut, enabled_state, 0, listener);
    }
    
    /**
     * Add a menu item with a keyboard accelerator.
     * @param label - descriptive text.
     * @param keyboard_shortcut - the menu keyboard shortcut for this item.
     * @param enabled_state - initial state of the menu item.
     * @param accelerator_mask - Key or keys (e.g., ctrl key, Apple key, shift key)
     *   that activate this item outside its menu when pressed in conjunction with its shortcut key. 
     * @param listener - an action listener to perform the menu item's function.
     * @return the new menu item.
     */
    private JMenuItem addMenuItem(String label, int keyboard_shortcut, boolean enabled_state, int accelerator_mask, ActionListener listener) 
    {
        JMenuItem item = new JMenuItem(label, keyboard_shortcut);
        this.menuItems.put(label, item);
        item.setEnabled(enabled_state);
        item.addActionListener(listener);
        
        if ( accelerator_mask != 0 )
            item.setAccelerator(KeyStroke.getKeyStroke(keyboard_shortcut, accelerator_mask, false));
        
        return item;
    }
    
    /**
     * Get a menu item by name.
     * @param key - the menu item's label.
     * @return the corresponding menu item.
     */
    private JMenuItem getMenuItem(String key)
    {
        JMenuItem result = this.menuItems.get(key);
        assert(result != null);
        return result;
    }
    
    Map<String, JMenuItem> menuItems = new HashMap<String,JMenuItem>();
    
    /*
     * Menu choices 
     */
    
    /** File->Exit */
    static final String FILE_EXIT = "Exit";
    static final String EDIT_FIND = "Find next unlabeled";
    /** Select the node under the mouse. */
    private static final boolean SELECT_ON_MOUSE_EVENT = true;
    /** Don't select the node under the mouse. */
    private static final boolean DONT_SELECT_ON_MOUSE_EVENT = false;
    /** Strip line information from intermediate CallStackLevel nodes */
    private static final boolean STRIP_LINE_INFORMATION = true;
    /** Keep line information from intermediate CallStackLevel nodes */
    private static final boolean KEEP_LINE_INFORMATION = false;

    /** Initial state of a menu item: enabled. */
    private static final boolean ENABLE_MENU_ITEM = true;
    /** Initial state of a menu item: disabled. */
    private static final boolean DISABLE_MENU_ITEM = false;
    

    static public String decodeTokenType(int type) 
    {
        String result = opcodeToOpcodeName.get(type);

        if ( null == result )
            result = Integer.toString(type);
        return result.toString();
    }

    static Map<Integer, String> opcodeToOpcodeName = new HashMap<Integer,String>();
    
    private void loadOpcodes(String class_name)
    {
        try
        {
            Class<? extends Object> tokenTypes = Class.forName(class_name);
            //  Traverse the names of the OP_foo constants
            //  in AbcConstants and load their values.
            for ( java.lang.reflect.Field f: tokenTypes.getFields())
            {
                String field_name = f.getName();
               try
               {
                   int field_value = f.getInt(null);
                   opcodeToOpcodeName.put(field_value, field_name);
               }
               catch ( Exception noFieldValue)
               {
                   //  Ignore, continue...
               }
            }
        }
        catch ( Throwable no_class)
        {
            setStatus("Unable to load " + class_name + ": " + no_class.getLocalizedMessage());
            no_class.printStackTrace();
        }
    }

    
}
