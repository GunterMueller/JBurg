package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import antlr.collections.AST;

import jburg.burg.JBurgGenerator;
import jburg.burg.JBurgGenerator.JBurgINode;

/**
 * @author Nick Brereton
 *
 * Module to change the emitted language to be C++
 * TODO: Should output into a .h &amp; a .cpp file (perhaps file output should be handled in this class?)
 * TODO: Perhaps handle all data in the Emit**** interface &amp; derive methods ??
 * ????: Is the use of smart pointers the best way to deal with pointers in the action_nnn routines ?
 * TODO: How should "jburgsupp.h" be handled ? place in resources ?
 *
 */

public class EmitCpp implements EmitLang {
	JBurgGenerator	parent;

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitHeader(java.lang.String, java.lang.String, java.lang.String, java.util.Vector, boolean, java.io.PrintStream)
	 */
	public void emitHeader(String strClassName, String packageName, String headerBlock, Vector InterfaceNames, boolean debugMode, PrintStream output) {
		int i;

		// add c++ imports: note: STL is required (also required for ANTLR...so shouldn't be a problem
		output.print("#include <iostream>\n");
		output.print("#include <string>\n");
		output.print("#include <stack>\n");
		output.print("#include <exception>\n");
		output.print("#include <memory>\n");
		output.print("#include <sstream>\n");
		if(debugMode)
			output.print("#include <fstream>\n");
		output.print("#include \"jburgsupp.h\"\n");
		output.print("#include <antlr/AST.hpp>\n\n");

		// java package is regarded as being equivalent to a c++ namespace
		if (packageName != null)
			output.print("// nested namespace (JBurg package property)" +
									"\nnamespace " + packageName + "\n{\n\n");

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n\n");
		}

		output.print("class " + strClassName);

		if (InterfaceNames.size() > 0) {
			output.print(": ");

			for (i = 0; i < InterfaceNames.size(); i++) {
				if (i > 0) {
					output.print(", ");
				}

				output.print("public "+InterfaceNames.elementAt(i).toString());
			}
		}

		output.print(
			"\n{\nprivate:\n\n\tstd::stack<void*> reducedValues;\n\n");

		output.print("\tint\t*antecedentRules;\n\n");

		// output a constructor
		output.print("public:\n\n");
		output.print("\t" + strClassName + "() {\n");
		output.print("\t\tantecedentRules = new int[nStates];\n");
		output.print("\t}\n\n");

		// d'tor
		output.print("\t~" + strClassName + "() {\n");
		output.print("\t\tif( antecedentRules ) delete[] antecedentRules;\n");
		output.print("\t}\n\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitNTConstants(java.util.Hashtable, java.io.PrintStream)
	 */
	public void emitNTConstants(Hashtable subgoals, PrintStream output) {
		Enumeration keys = subgoals.keys();

		int i = 0;

		// constants are stored as an enum
		output.print("public:\n\n");

		//  Make this an enum for older compilers
		//  (e.g., Visual C++ 6.0) that don't
		//  support static const int.
		output.print("\tenum { nStates = " +
			String.valueOf(subgoals.size()) + " };\n\n");

		output.print("\tenum {\n");

		while (keys.hasMoreElements()) {
			String strNTName = keys.nextElement().toString();

			output.print("\t\t" + strNTName + "_NT = " +
				String.valueOf(++i) + (keys.hasMoreElements() ? ",\n" : "\n"));
		}

		output.print("\t};\n\n");

	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitLabelFunction(java.lang.String, java.io.PrintStream)
	 */
	public void emitLabelFunction(String iNodeClass, PrintStream output) {
		output.print("public:\n\n");
		output.print("\tJBurgAnnotation<"+iNodeClass+" >* label("+iNodeClass+" *n)\n\t{\n");
		output.print("\t\tJBurgAnnotation<"+iNodeClass+" >* result=0;\n\n");
		output.print("\t\tif( n ) {\n");

		output.print("\t\t\tresult = ::new JBurgAnnotation<"+iNodeClass+" >( n, nStates+1 );\n");
		output.print("\t\t\tif(!result)\n");
		output.print("\t\t\t\tthrow std::runtime_error(\"failed to allocate JBurgAnnotation structure!\");\n\n");

		output.print("\t\t\t"+iNodeClass+" *cnode = n->getFirstChild();\n");
		output.print("\t\t\tresult->left = label(cnode);\n");
		output.print("\t\t\tresult->right = label(cnode ? cnode->getNextSibling() : 0);\n\n");

		output.print("\t\t\tcomputeCostMatrix(result);\n");

		output.print("\t\t}\n\n");
		output.print("\t\treturn result;\n\t}\n\n");

	}

	public void emitCostFns(Vector cost_functions, String iNodeClass, PrintStream output) {
		output.print("\n\nprivate:\n\t// start of cost functions (if any)");
		for (int i = 0; i < cost_functions.size(); i++) {
			AST currentNode = (AST) cost_functions.elementAt(i);

			String functionName = currentNode.getFirstChild().getText();
			String functionBody[] = currentNode.getFirstChild().getNextSibling().getText().split("\n");

			output.print("\n\n\tint " + functionName + "(" + iNodeClass + "* p)\n");

			for(int x=0; x<functionBody.length; ++x)
				output.print("\t"+functionBody[x]);
		}
		output.print("\n\n\t// end of cost functions (if any)");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitAnnotation(java.lang.String, java.io.PrintStream)
	 */
	public void emitAnnotation(String iNodeClass, PrintStream output) {
		/* this is implemented in the "jburgsupp.h" file via a
		 * template, which in many ways is probably a better solution
		 * (well easier to maintain anyhow, although the file must be
		 * made avalible to all compiles...should it be included in
		 * the resources for JBurg & copied to destination directories?
		 */
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitActions(java.util.Vector, java.lang.String, java.util.Hashtable, java.lang.Object, java.io.PrintStream)
	 */
	public void emitActions(Vector reduceActions, String iNodeClass, PrintStream output) {
		Iterator it = reduceActions.iterator();
		int i;

		//  Print out the individual action routines.
		for (i = 2, it.next(); it.hasNext(); i++) {
			JBurgGenerator.JBurgReduceAction nextAction = (JBurgGenerator.JBurgReduceAction) it.next();

			output.print("\n\n\t" + parent.getReturnType( nextAction.getState() ) +
				"* action_" + String.valueOf(i) + "( " + iNodeClass +
				"* p )\n\t{\n");
			output.print(nextAction.toString());
			output.print("\n\t}");
		}

		//  Print out their common dispatch routine.
		output.print("\n\n\tvoid dispatchAction ( " + iNodeClass +
			"* p, int iRule )\n\t{\n\t\tswitch ( iRule )\n\t\t{");
		output.print("\n\t\t\tcase 1: break; // Don't reduce or touch the stack.");

		for (i = 2; i <= reduceActions.size(); i++) {
			output.print("\n\t\t\tcase " + String.valueOf(i) + ": ");
			output.print("reducedValues.push(action_" + String.valueOf(i) +
				"(p)); break;");
		}
		
		output.print("\n\t\t\tdefault: {" +
				"\n\t\t\t\tstd::stringstream s;\n\t\t\t\ts << \"Unmatched reduce action \" << iRule;\n" +
				"\n\t\t\t\tthrow std::runtime_error ( s.str() );\n" +
				"\n\t\t\t}\n\t\t}\n\t}\n\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitTrailer(java.lang.String, java.lang.String, java.util.Hashtable, java.util.Hashtable, boolean, java.io.PrintStream)
	 */
	public void emitTrailer(String strClassName, String iNodeClass, Hashtable subgoals, Hashtable burm_properties, boolean debugMode, PrintStream output) {
		output.print("\n\n\tvoid reduce ( JBurgAnnotation<"+iNodeClass+" >* p, int goalState");

		if (debugMode)
			output.print(", std::ostream &debugOutput ");

		output.print(" )\n\t{");
		output.print("\n\t\tint iRule = -1;");

		output.print(
			"\n\n\t\tif ( goalState > 0 ) {\n\t\t\tiRule = p->getRule(goalState);\n\t\t} else {" +
			"\n\t\t\t//  Find the minimum-cost path.\n\t\t\tint minCost = MAX_INT_VALUE;\n\t\t\t" +
			"for (int i = 0; i <= nStates ; ++i ) {\n\t\t\t\tif ( p->getCost(i) < minCost ) {\n\t\t\t\t\tiRule = p->getRule(i);" +
			"\n\t\t\t\t\tminCost = p->getCost(i);\n\t\t\t\t\tgoalState = i;\n\t\t\t\t}\n\t\t\t}\n\t\t}\n\n\t\tif ( iRule > 0 )\n\t\t{\n\t\t\t");

		if (debugMode) {
			output.print("\n\t\t\tdebugOutput << \"<reduction>\"; ");
			output.print(
				"\n\t\t\tdebugOutput << \"<node>\" << p->getNode()->toString() << \"</node>\";");
			output.print(
				"\n\t\t\tdebugOutput << \"<goal>\" << stateName[goalState] << \"</goal>\";");
			output.print(
				"\n\t\t\tdebugOutput << \"<rule>\" << iRule << \"</rule>\";\n\n\t\t\t");
		}

		output.print(
			"int firstGoalState = visitAntecedentStates(p, goalState");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");");

		if (debugMode)
			output.print("\n\t\t\tdebugOutput << \"</reduction>\"; ");

		output.print("\n\n\t\t\tif ( p->right )\n\t\t\t{");
		output.print(
			"\n\t\t\t\treduce ( p->right, p->rightSubgoals[firstGoalState]");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");\n\t\t\t}");

		output.print("\n\n\t\t\tif ( p->left )\n\t\t\t{");
		output.print("\n\t\t\t\treduce ( p->left, p->leftSubgoals[firstGoalState]");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");\n\t\t\t}");

		output.print("\n\t\t\treduceAntecedentStates(p, goalState);");

		output.print("\n\t\t\tdispatchAction ( p->getNode(), iRule );\n\t\t}\n\t\telse\n\t\t{");
		output.print(  "\n\t\t\tstd::stringstream s;"
					 + "\n\t\t\ts << \"Unable to find a rule to process \";"
					 + "\n\t\t\ts << p->getNode()->toString();"
					 + "\n\t\t\ts << \" (\" << p->getOperator() << \") {\" << goalState << \"}\";"
					 + "\n\t\t\tthrow new std::runtime_error ( s.str() );"
					 + "\n\t\t}\n\t}\n" );

		output.print(
			"\n\n\tint visitAntecedentStates( JBurgAnnotation<"+iNodeClass+" >* p, int goalState");

		if (debugMode)
			output.print(", std::ostream &debugOutput ");

		output.print(" )\n\t{");

		output.print(
			"\n\t\tint   currentState = goalState;\n\t\tint antecedentIndex = 0;");
		output.print("\n\t\twhile ( p->hasAntecedent(currentState) ) {");

		if (debugMode) {
			output.print("debugOutput << \"<antecedentState>\";");
			output.print("debugOutput << stateName[currentState];");
			output.print("debugOutput << \"</antecedentState>\" << std::endl;");
		}

		output.print("\n\t\t\tcurrentState = p->getAntecedent(currentState);");
		output.print(
			"\n\t\t\tif ( currentState == goalState )\n\t\t\t\tthrow new std::runtime_error ( \"cyclical antecedents\" );");
		output.print("\n\t\t}");
		output.print("\n\t\treturn currentState;\n\t}\n\n");

		//  Marshalling area for a reduction's antecedent states.
		//  Re-using this single int array saves considerable amounts of CPU and memory.
		//  On any given pass, we'll count up from 0 to (antecedentIndex-1) sequential int values
		//  to marshall the antecedent states, then back down to zero as we execute them.
		//  If there were ever more antecedent states than marshalling slots available,
		//  then we have more pigeons than pigeonholes, which means that a state has
		//  itself as an [eventual] antecedent.
		//  This should have been caught by the check in visitAntecedentStates(), above.
		// output.print("\n\tint[] antecedentRules = new int[nStates];");

		output.print(
			"\tvoid reduceAntecedentStates( JBurgAnnotation<"+iNodeClass+" >* p, int goalState)\n\t{");
		output.print(
			"\n\t\tint   currentState = goalState;\n\t\tint antecedentIndex = 0;");
		output.print("\n\t\twhile ( p->hasAntecedent(currentState)  )\n\t\t{");
		output.print("\n\t\t\tcurrentState = p->getAntecedent(currentState);");
		output.print("\n\t\t\tantecedentRules[antecedentIndex++] = p->getRule(currentState);");
		output.print("\n\t\t}");
		output.print("\n\t\tfor ( --antecedentIndex; antecedentIndex >= 0; antecedentIndex-- )\n\t\t{");
		output.print("\n\t\t\tdispatchAction( p->getNode(), antecedentRules[antecedentIndex] );");
		output.print("\n\t\t}\n\t}\n\n");

		//  Print the emitter function.
		output.print("public:\n\n");
		output.print("\tvoid burm ( " + iNodeClass + "* root )\n\t{");
		output.print("\n\t\tJBurgAnnotation<" + iNodeClass + " >* annotatedTree = label(root);");

		if (debugMode) {
			output.print(
				"\n\n\t\tstatic const char *stateName[] = { \"\" ");
			Enumeration keys = subgoals.keys();

			while (keys.hasMoreElements()) {
				output.print(", \"" + keys.nextElement().toString() + "\"");
			}

			output.println("};");
			
			output.println("\t\tthis->stateName = (char**)stateName;");

			output.print(
				"\n\t\tstd::ofstream debugOutput(\"" +
				strClassName + "_jburg.xml\");");
			// re-include when the 'finally' statement issue has been resolved
			// output.print("\n\ttry\n\t{");
			output.print("\n\t\t{");
			output.print(
				"\n\t\t\tdebugOutput << \"<?xml version=\\\"1.0\\\"?><jburg><label>\" << std::endl; ");
			output.print("\n\t\t\tdescribeNode(annotatedTree, debugOutput);");
			output.print(
				"\n\t\t\tdebugOutput << \"</label><reductions>\" << std::endl;");
		}

		output.print("\n\t\treduce ( annotatedTree, 0");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");");

		if (debugMode) {
			output.print(
				"\n\t\tdebugOutput << \"</reductions></jburg>\" << std::endl;");
			// TODO: what happens with this 'finally' statement...not exactly C++...
			//output.print("\n\t}\n\tfinally\n\t\t{ debugOutput.flush(); }");
			output.print("\n\t\t}\n\t\tdebugOutput.close();");
		}

		output.print("\n\t\tdelete annotatedTree;");
		output.print("\n\t}");

		if (debugMode) {
			//  Print out tree-dumping logic.
			output.print(
				"\n\n\tvoid describeNode ( JBurgAnnotation<"+iNodeClass+" >* node, std::ostream &debugOutput ) ");

			//  Print a table of human-readable state names.

			output.print("\n\t{\n\t\tif ( !node ) return;");
			output.print(
				"\n\t\tdebugOutput << \"<node operator=\\\"\" << node->getOperator() << \"\\\">\" << std::endl;");
			output.print(
				"\n\t\tdebugOutput << \"<selfDescription>\" << node->getNode()->toString() << \"</selfDescription>\";");

			output.print(
				"\n\n\t\tfor (int i = 0; i <= nStates ; i++ )\n\t\t{\n\t\t\tif ( node->getRule(i) != 0 )\n\t\t\t{");
			output.print("\n\t\t\t\tdebugOutput << \"<goal\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" name=\\\"\" << stateName[i] << \"\\\"\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" rule=\\\"\" << node->getRule(i) << \"\\\"\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" cost=\\\"\" << node->getCost(i) << \"\\\"\";");
			output.print("\n\t\t\t\tdebugOutput << \"/>\" << std::endl;");
			output.print("\n\t\t\t}");
			output.print("\n\t\t}");
			output.print("\n\t\tdescribeNode ( node->left, debugOutput );");
			output.print("\n\t\tdescribeNode ( node->right, debugOutput );");
			output.print("\n\t\tdebugOutput << \"</node>\" << std::endl;");
			output.print("\n\t}");
			
			output.print("\tchar **stateName;");

		}

		//  Emit BURM properties and their get/set methods.
		Enumeration keys = burm_properties.keys();

		if(keys.hasMoreElements())
			output.print("\n\npublic:");

		while (keys.hasMoreElements()) {
			String sName = keys.nextElement().toString();
			String sType = burm_properties.get(sName).toString();

			StringBuffer canonicalName = new StringBuffer(sName.toLowerCase());
			canonicalName.setCharAt(0,
				Character.toUpperCase(canonicalName.charAt(0)));

			output.print("\n\n\t//  BURM property, from the specification\n\t");
			output.print(sType + " " + sName + ";");
			output.print("\n\tvoid set" + canonicalName + "(" + sType +
				" setting)\n\t{");
			output.print("\n\t\tthis->" + sName + " = setting;\n\t}");
			output.print("\n\tpublic " + sType + " get" + canonicalName +
				"()\n\t{");
			output.print("\n\t\treturn this->" + sName + ";\n\t}");
		}

		//  Emit the JBurgAnnotation inner class.
		emitAnnotation(iNodeClass, output);

		//  Close the class definition.
		output.print("\n\n};\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitClosures(java.util.Hashtable, java.io.PrintStream)
	 */
	public void emitClosures(Hashtable closureSets, String iNodeClass, PrintStream output) {
		Enumeration eClosures = closureSets.keys();

		while (eClosures.hasMoreElements()) {
			String strClosureNT = eClosures.nextElement().toString();

			output.print("\tvoid closure_" + strClosureNT + "( JBurgAnnotation<"+iNodeClass+" >* p, int c )\n\t{\n");
			output.print("\t\tint iCost;");

			Enumeration eTargetClosures = ((Vector) closureSets.get(strClosureNT)).elements();

			while (eTargetClosures.hasMoreElements()) {
				JBurgGenerator.ClosureRecord newClosure = (JBurgGenerator.ClosureRecord) eTargetClosures.nextElement();

				String strRule;

				if (newClosure.getReduceAction() != null)
					strRule = String.valueOf(newClosure.getReduceAction().getIndex());
				else
					strRule = "0";

				String closureCost = newClosure.getCost("p->m_node");

				if (closureCost.equals("0"))
					output.print("\n\t\tiCost = c;");
				else
					output.print("\n\t\tiCost = c + " + closureCost + ";");

				output.print("\n\t\tif ( p->getCost(" + newClosure.getTargetNT()+"_NT) > iCost )\n\t\t{");
				output.print("\n\t\t\tp->reset(" + newClosure.getTargetNT() + "_NT, iCost, " + strRule + ");");
				output.print("\n\t\t\tp->recordAntecedent(" +
					newClosure.getTargetNT() + "_NT, " + strClosureNT +
					"_NT);");

				if (parent.hasClosure(newClosure)) {
					output.print("\n\t\t\tclosure_" + newClosure.getTargetNT() +
						"(p, iCost);");
				}

				output.print("\n\t\t}");
			}

			output.print("\n\t}\n\n");
		}
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitComputeCostMatrixFunction(java.util.Hashtable, jburg.burg.JBurgGenerator, java.lang.String, java.io.PrintStream)
	 */
	public void emitComputeCostMatrixFunction(Hashtable patternRules, String iNodeClass, PrintStream output) throws Exception {
		output.print("private:\n\n");
		output.print("\tvoid computeCostMatrix ( JBurgAnnotation<"+iNodeClass+" >* node )\n\t{\n");
		output.print("\t\tint iCost;\n\n");
		output.print("\t\tswitch(node->getOperator())\n");
		output.print("\t\t{\n");

		//  All cost matrix calculations start by recognizing a pattern.
		Enumeration eNonTerminals = patternRules.elements();

		while (eNonTerminals.hasMoreElements()) {
			Vector vPatternRules;
			Enumeration ePatternRules;
			JBurgGenerator.JBurgINode nPatternRule;
			String strCost;

			vPatternRules = (Vector) eNonTerminals.nextElement();
			ePatternRules = vPatternRules.elements();

			output.print("\n\t\t\tcase " +
				((JBurgGenerator.JBurgINode) vPatternRules.firstElement()).getOperator() +
				":\n\t\t\t{");

			while (ePatternRules.hasMoreElements()) {
				nPatternRule = (JBurgGenerator.JBurgINode) ePatternRules.nextElement();
				emitPatternRule(nPatternRule, iNodeClass, output);
			}

			output.print("\n\t\t\t\tbreak;\n\t\t\t}");
		}

		output.print("\n\t\t}\n\t}\n\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitPatternRule(jburg.burg.JBurgGenerator.JBurgINode, jburg.burg.JBurgGenerator, java.lang.String, java.io.PrintStream)
	 */
	public void emitPatternRule(JBurgINode p, String iNodeClass, PrintStream output) throws Exception {
		int i;

		AST operand1 = p.getPattern().getFirstChild();

		AST operand2 = (operand1 != null) ? operand1.getNextSibling() : null;

		//  Encode the subtree recognizers.
		//  As we traverse the subtree, we may find additional non-terminal elements;
		//  these non-terminal elements play several parts in the overall computation
		//  of the locally-optimal reduction:
		//  -  They contribute to the rule's computed cost.
		//  -  The reduction's action code may refer to these elements by name.
		//  -  "elide" pattern elements -- e.g., B in A(B(subgoal c)) -- that aren't reduced.
		//  -  If the rule is of the form OP(nttype1 a [, nttype2 b]), then the rule
		//     must enforce this reduce-time goal state on its subtrees' reductions.
		Vector vSubgoals = new Vector();
		Vector vElided = new Vector();

		String strLeftSubtree = parent.encodePattern(operand1, "node->left", vSubgoals, vElided);
		String strRightSubtree = parent.encodePattern(operand2, "node->right", vSubgoals, vElided);

		output.print("\n\t\t\t\tif (" + strLeftSubtree + " && " +
			strRightSubtree + ")\n\t\t\t\t{");

		//  Compute this rule's cost, which is the cost of the rule itself and all the non-terminals
		//  associated with it.
		output.print("\n\t\t\t\t\tiCost = " +
			p.getCost("(" + iNodeClass + ")node->m_node"));

		for (i = 0; i < vSubgoals.size(); i++) {
			JBurgGenerator.JBurgSubgoalRecord ntCost;

			ntCost = (JBurgGenerator.JBurgSubgoalRecord) vSubgoals.elementAt(i);
			output.print(" + " + ntCost.m_path + "->getCost(" + ntCost.m_goal +
				"_NT)");
		}

		String strRule = String.valueOf(p.getReduceAction().getIndex());
		output.print(";\n\n\t\t\t\t\tif ( node->getCost(" + p.getTargetNT() +
			"_NT) > iCost )\n\t\t\t\t\t{");
		output.print("\n\t\t\t\t\t\t//  Matched " + p.getOperator() + " ==> " +
			p.getTargetNT());
		output.print("\n\t\t\t\t\t\tnode->reset( " + p.getTargetNT() +
			"_NT, iCost, " + strRule + " );");

		//  Do we have reduce-time goals to enforce?
		if (parent.isNonTerminalParameter(operand1)) {
			output.print("\n\t\t\t\t\t\tnode->setLeftSubgoal ( " +
				p.getTargetNT() + "_NT, " + operand1.getText() + "_NT );");
		}

		if (parent.isNonTerminalParameter(operand2)) {
			output.print("\n\t\t\t\t\t\tnode->setRightSubgoal ( " +
				p.getTargetNT() + "_NT, " + operand2.getText() + "_NT );");
		}

		//  An elided node is one that appears in the middle of a pattern and does not have to
		//  be reduced, e.g., B in the pattern A( subgoal1 x, B(subgoal2 y, subgoal3 z)).
		for (i = 0; i < vElided.size(); i++) {
			String strElided = vElided.elementAt(i).toString();
			output.print("\n\t\t\t\t\t\t" + strElided + "->setElided(" +
				p.getTargetNT() + "_NT);");
		}

		if (parent.hasClosure(p)) {
			output.print("\n\t\t\t\t\t\tclosure_" + p.getTargetNT() +
				"(node, iCost);");
		}

		output.print("\n\t\t\t\t\t}\n\t\t\t\t}");

		//  Add the non-terminal subgoal result nodes to the action routine's "parameters."
		JBurgGenerator.JBurgReduceAction action = p.getReduceAction();

		for (i = 0; i < vSubgoals.size(); i++) {
			JBurgGenerator.JBurgSubgoalRecord ntParameter;
			ntParameter = (JBurgGenerator.JBurgSubgoalRecord) vSubgoals.elementAt(i);
			action.addParameter(ntParameter.m_name, ntParameter.m_goal);
		}
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitMLComment(java.lang.String, int, java.io.PrintStream)
	 */
	public void emitMLComment(String comment, int ndepth, PrintStream output) {
		int nl = comment.indexOf('\n');
		int ol = 0;
		String tabs = new String();
		for(int x=0; x<ndepth; x++) tabs+="\t";

		while(nl>0) {
			output.print(tabs+(ol==0? "/*":" *")+comment.substring(ol, nl+1-ol));
			ol = nl+1;
			nl = comment.indexOf('\n', nl+1);
		}

		if(ol<comment.length())
			output.print(tabs+(ol==0? "/*":" *")+comment.substring(ol));
		output.print(" */\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genPopFromStact(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public String genPopFromStack(String stackName, String paramType, String paramName, String tabs) {
		String s = new String(tabs + "std::auto_ptr< " + paramType + " > " + paramName + " ( (" + paramType + "*)" + stackName + ".top() );\n");
		s += tabs + stackName + ".pop();\n";
		return s;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCheckPtr(java.lang.String, boolean)
	 */
	public String genCheckPtr(String paramName, boolean checkForNull) {
		if(checkForNull)
			return new String("!" + paramName);
		return paramName;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genAccessMember(java.lang.String, java.lang.String)
	 */
	public String genAccessMember(String parentName, String memberName) {
		return new String(parentName + "->" + memberName);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCallMethod(java.lang.String, java.lang.String, java.lang.String[])
	 */
	public String genCallMethod(String parentName, String methodName, String[] params) {
		String s = new String(parentName + "->" + methodName + "(");
		if(params != null) {
			for(int x=0; x<params.length; ++x) {
				if(x!=0) s += ", ";
				s += params[x];
			}
		}
		s+=")";
		return s;
	}

	/**
	 * @param parent
	 */
	public EmitCpp(JBurgGenerator parent) {
		super();
		this.parent = parent;
	}
	
	public EmitCpp() {
		super();
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitInclass(java.lang.String, java.util.Vector)
	 */
	public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output) {
		for(Enumeration enum = inclassBlocks.elements(); enum.hasMoreElements(); ) {
			String icb = (String)enum.nextElement();

			output.print("\n"+icb+"\n");
		}
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCmpEquality(java.lang.String, java.lang.String, boolean)
	 */
	public String genCmpEquality(String lhs, String rhs, boolean bEquality) {
		return new String(lhs + ( bEquality==true ? "==" : "!=" ) + rhs);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genLogicalAnd(java.lang.String, java.lang.String)
	 */
	public String genLogicalAnd(String lhs, String rhs) {
		return new String(lhs + " && " + rhs);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#accept(java.lang.String)
	 */
	public boolean accept(String name) {
		return name!=null && name.equalsIgnoreCase("cpp");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#setRtInfo(jburg.burg.JBurgGenerator, java.lang.String)
	 */
	public void setRtInfo(JBurgGenerator parent, String opfname) {
		this.parent = parent;
		// does nothing with the output file name at the moment
		// should open 2 seperate streams, a .cpp & a .h file
	}
}
