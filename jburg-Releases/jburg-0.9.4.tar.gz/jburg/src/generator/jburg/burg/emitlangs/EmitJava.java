package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import antlr.collections.AST;

import jburg.burg.JBurgGenerator;
import jburg.burg.emitlangs.EmitLang;

public class EmitJava implements EmitLang {

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitHeader(java.lang.String, java.io.PrintStream)
	 */
	public void emitHeader(String strClassName, String packageName, String headerBlock, Vector InterfaceNames, boolean debugMode, PrintStream output) {
		int i;

		if (packageName != null)
			output.print("\npackage " + packageName + ";\n\n");

		output.print("import jburg.compiler.tl2.ir.TL2INode;");

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n");
		}

		output.print("public class " + strClassName);

		if (InterfaceNames.size() > 0) {
			output.print(" implements ");

			for (i = 0; i < InterfaceNames.size(); i++) {
				if (i > 0) {
					output.print(", ");
				}

				output.print(InterfaceNames.elementAt(i).toString());
			}
		}

		output.print(
			"\n{\n\n\tjava.util.Stack reducedValues = new java.util.Stack();\n\n");

		if (debugMode) {
			output.print("java.io.PrintWriter debugOutput;");
		}
	}

	/**
	 * write a multiple line comment out onto the output stream
	 * @param comment Comment to be output, lines seperated by \n chars
	 * @param ndepth Number of tabs to insert prior to the comment block
	 */
	public void emitMLComment(String comment, int ndepth, PrintStream output) {
		int nl = comment.indexOf('\n');
		int ol = 0;
		String tabs = new String();
		for(int x=0; x<ndepth; x++) tabs+="\t";
		
		while(nl>0) {
			output.print(tabs+(ol==0? "/*":" *")+comment.substring(ol, nl+1-ol));
			ol = nl+1;
			nl = comment.indexOf('\n', nl+1);
		}
		
		if(ol<comment.length())
			output.print(tabs+(ol==0? "/*":" *")+comment.substring(ol));
		output.print(" */\n");		
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitNTConstants(java.util.Hashtable, java.io.PrintStream)
	 */
	public void emitNTConstants(Hashtable subgoals, PrintStream output) {
		Enumeration keys = subgoals.keys();

		int i = 0;

		while (keys.hasMoreElements()) {
			i++;

			String strNTName = keys.nextElement().toString();

			output.print("\tpublic static final int " + strNTName + "_NT = " +
				String.valueOf(i) + ";\n");
		}

		output.print("\tpublic static final int nStates = " +
			String.valueOf(i) + ";\n\n");
	}

	public void emitLabelFunction(String iNodeClass, PrintStream output) {
		output.print("public JBurgAnnotation label ( " + iNodeClass +
			" n )\n{\n\tJBurgAnnotation result = null;\n\n\tif (n != null)\n\t{\n\t\tresult = new JBurgAnnotation ( n, nStates + 1 );" +
			"\n\n\t\tresult.left  = label((" + iNodeClass +
			")n.leftChild());\n\t\tresult.right = label((" + iNodeClass +
			")n.rightChild());\n\n\t\tcomputeCostMatrix(result);\n\t}" +
			"\n\n\treturn result;\n}\n");
	}

	public void emitCostFns(Vector cost_functions, String iNodeClass, PrintStream output) {
		for (int i = 0; i < cost_functions.size(); i++) {
			AST currentNode = (AST) cost_functions.elementAt(i);

			String functionName = currentNode.getFirstChild().getText();
			String functionBody = currentNode.getFirstChild().getNextSibling()
											 .getText();

			output.print("\n\n\tprivate int " + functionName + "(" +
						 iNodeClass + " p)\n\t");
			output.print(functionBody);
		}
	}

	public void emitAnnotation(String iNodeClass, PrintStream output) {
		output.print("\n\n/**\n *  JBurgAnnotation is a data structure internal to the\n *  JBurg-generated BURM that annotates a JBurgNode with");
		output.print("\n *  information used for dynamic programming and reduction.\n  */\nclass JBurgAnnotation\n{");
		output.print("\n\t/**\n\t *  The cost/rule matrices are used during dynamic programming");
		output.print("\n\t *  to compute the most economical rules that can reduce\n\t *  the input node.\n\t*/");
		output.print("\n\tprivate int cost[];");
		output.print("\n\tprivate int rule[];");
		output.print("\n\n\t/**  Transformation rules may have antecedents: other states whose");
		output.print("\n\t *  output the transformation rule is intended to transform.");
		output.print("\n\t *  All such antecedent states must be executed in sequence when the rule is reduced.\n\t */");
		output.print("\n\tprivate int[] antecedentState = null;");
		output.print("\n\n\t /**\n\t *  A node may have a specific goal state, set by its ancestor's");
		output.print("\n\t *  requirements for a certain type of input; or it may be at ");
		output.print("\n\t *  liberty to use the most locally-economical reduction.\n\t */");
		output.print("\n\tpublic int[] leftSubgoals;");
		output.print("\n\tpublic int[] rightSubgoals;");
		output.print("\n\n\t/** *  This node's children (may be null).  */");
		output.print("\n\tpublic JBurgAnnotation left;");
		output.print("\n\tpublic JBurgAnnotation right;");
		output.print("\n\t/**  The INode we're annotating.  */\n\t");
		output.print(iNodeClass);
		output.print(" m_node; ");
		output.print("\n\tJBurgAnnotation ( ");
		output.print(iNodeClass);
		output.print(" newNode, int nRules) ");
		output.print("\n\t{\n\t\tm_node = newNode;\n\t\trule   = new int[nRules];\n\t\tcost   = new int[nRules];");
		output.print("\n\t\t//  Initial cost of all rules is \"infinite\"\n\t\tjava.util.Arrays.fill ( cost, Integer.MAX_VALUE);");
		output.print("\n\t\t//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array.");
		output.print("\n\t\tleftSubgoals = new int[nRules];\n\t\trightSubgoals = new int[nRules];");
		output.print("\n\t}");
		output.print("\n\n\t /** @return this node's operator. */");
		output.print("\n\tpublic int getOperator() { return m_node.getOperator(); }");
		output.print("\n\n\t /** @return this node's wrapped");
		output.print(iNodeClass);
		output.print(". */ ");
		output.print("\n\tpublic " + iNodeClass + " getNode()  { return m_node; }");
		output.print("\n\n\t/** @return the wrapped node's toString().  */");
		output.print("\n\tpublic String toString() { return m_node.toString(); } ");
		output.print("\n\t/** @return the current best cost to reach a goal state.  */");
		output.print("\n\tpublic int getCost( int goalState ) { return cost[goalState]; }");
		output.print("\n\n\t /** Set the cost/rule configuration of a goal state.");
		output.print("\n\t * @throws IllegalArgumentException if this node has a fixed cost/rule.\n\t*/");
		output.print("\n\t public void reset ( int goalState, int cost, int rule )\n\t{");
		output.print("\n\t\tthis.cost[goalState] = cost;");
		output.print("\n\t\tthis.rule[goalState] = rule;");
		output.print("\n\t\t//  We have a brand new rule, therefore it has no antecedents.");
		output.print("\n\t\tif ( this.antecedentState != null )\n\t\tthis.antecedentState[goalState] = 0;");
		output.print("\n\t}");
		output.print("\n\n\t /** *  This node is is \"elided,\" i.e., it doesn't have a reduction. */");
		output.print("\n\t public void setElided ( int goalState )");
		output.print("\n\t{\n\t\trule[goalState] =1;\n\t\tcost[goalState] = Integer.MAX_VALUE - 1;\n\t}");
		output.print("\n\n\t/** * @return the rule to fire for a specific goal state. */");
		output.print("\n\tpublic int getRule ( int goalState ) { return rule[goalState]; }");
		output.print("\n\n\t /**");
		output.print("\n\t *  A closure's transformation rule succeeded.");
		output.print("\n\t *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;");
		output.print("\n\t *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never ");
		output.print("\n\t *  transition back to a goal state that has already been reduced).\n\t*/");
		output.print("\n\tpublic void recordAntecedent ( int iGoalState, int newAntecedentState )\n\t{");
		output.print("\n\t\tint antecedentRule = rule[newAntecedentState];");
		output.print("\n\t\t//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled.");
		output.print("\n\t\tif ( antecedentRule == 0 )");
		output.print("\n\t\t\tthrow new IllegalStateException ( \"Attempting to record an unlabelled antecedent state.\" );");
		output.print("\n\t\tif ( antecedentRule == 1 )\n\t\t{");
		output.print( "\n\t\t\t//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run.");
		output.print("\n\t\t\tif ( antecedentState != null )");
		output.print("\n\t\t\t\tantecedentState[iGoalState] = antecedentState[newAntecedentState];");
		output.print("\n\t\t\t}");
		output.print("\n\t\telse\n\t\t");
		output.print("\n\t\t\t{");
		output.print("\n\t\t\t\tif ( antecedentState == null )");
		output.print("\n\t\t\t\t\tantecedentState = new int[rule.length];");
		output.print("\n\t\t\t}");
		output.print("\n\t\tantecedentState[iGoalState] = newAntecedentState;\n\t}");
		output.print("\n\n\t /** @return the antecedent to the given goal state. */");
		output.print("\n\tpublic int getAntecedent(int iGoalState)\n\t{");
		output.print("\n\t\tif ( antecedentState != null )");
		output.print("\n\t\t\treturn antecedentState[iGoalState];");
		output.print("\n\t\telse");
		output.print("\n\t\t\treturn 0;\n\t}");
		output.print("\n\t /** @return true if the given goal state has an antecdent. */");
		output.print("\n\tpublic boolean hasAntecedent ( int iGoalState )");
		output.print("\n\t\t { return ( antecedentState != null && getAntecedent(iGoalState) != 0 ); }");
		output.print("\n\tpublic void setLeftSubgoal ( int goalState, int subGoal )");
		output.print("\n\t{\n\t\tleftSubgoals[goalState] = subGoal;\n\t}");
		output.print("\n\tpublic void setRightSubgoal ( int goalState, int subGoal )");
		output.print("\n\t{\n\t\trightSubgoals[goalState] = subGoal;\n\t}");
		output.print("\n}");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitActions(java.util.Vector, java.lang.String, java.io.PrintStream)
	 */
	public void emitActions(Vector reduceActions, String iNodeClass, PrintStream output) {
		Iterator it = reduceActions.iterator();
		int i;

		//  Print out the individual action routines.
		for (i = 2, it.next(); it.hasNext(); i++) {
			JBurgGenerator.JBurgReduceAction nextAction = (JBurgGenerator.JBurgReduceAction) it.next();

			output.print("\n\n" + parent.getReturnType(nextAction.getState()) +
				" action_" + String.valueOf(i) + "( " + iNodeClass +
				" p )\n{\n");
			output.print(nextAction.toString());
			output.print("\n}");
		}

		//  Print out their common dispatch routine.
		output.print("\n\nvoid dispatchAction ( " + iNodeClass +
			" p, int iRule ) throws Exception\n{\n\tswitch ( iRule )\n\t{");
		output.print("\n\t\tcase 1: break; // Don't reduce or touch the stack.");

		for (i = 2; i <= reduceActions.size(); i++) {
			output.print("\n\t\tcase " + String.valueOf(i) + ": ");
			output.print("reducedValues.push(action_" + String.valueOf(i) +
				"(p));\n\t\tbreak;");
		}

		output.print(
			"\n\tdefault: throw new IllegalStateException ( \"Unmatched reduce action \" + String.valueOf(iRule) );\n\t}\n}");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitTrailer(java.lang.String, java.lang.String, java.util.Hashtable, boolean, java.io.PrintStream)
	 */
	public void emitTrailer(String strClassName, String iNodeClass, Hashtable subgoals, Hashtable burm_properties, boolean debugMode, PrintStream output) {
		output.print("\n\nvoid reduce ( JBurgAnnotation p, int goalState");

		if (debugMode)
			output.print(", java.io.PrintWriter debugOutput ");

		output.print(" ) throws Exception\n{");
		output.print("\n\n\tint iRule = -1;");

		output.print(
			"\n\n\tif ( goalState > 0 )\n\t{\n\t\tiRule = p.getRule(goalState);\n\t}\n\telse\n\t{" +
			"\n\t\t//  Find the minimum-cost path.\n\t\tint minCost = Integer.MAX_VALUE;\n\t\tint i;\n\n\t\t" +
			"for (i = 0; i <= nStates ; i++ )\n\t\t{\n\t\t\tif ( p.getCost(i) < minCost )\n\t\t\t{\n\t\t\t\tiRule = p.getRule(i);" +
			"\n\t\t\t\tminCost = p.getCost(i);\n\t\t\t\tgoalState = i;\n\t\t\t}\n\t\t}\n\t}\n\n\tif ( iRule > 0 )\n\t{\n\t\t");

		if (debugMode) {
			output.print("\n\t\tdebugOutput.print ( \"<reduction>\" ); ");
			output.print(
				"\n\tdebugOutput.print ( \"<node>\" + p.getNode().toString() + \"</node>\");");
			output.print(
				"\n\t\tdebugOutput.print ( \"<goal>\" + stateName[goalState] + \"</goal>\" );");
			output.print(
				"\n\t\tdebugOutput.print ( \"<rule>\" + iRule + \"</rule>\" );");
		}

		output.print(
			"\n\n\t\tint firstGoalState = visitAntecedentStates(p, goalState");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");");

		if (debugMode)
			output.print("\n\t\tdebugOutput.println ( \"</reduction>\" ); ");

		output.print("\n\n\t\tif ( p.right != null )\n\t\t{");
		output.print(
			"\n\t\t\treduce ( p.right, p.rightSubgoals[firstGoalState]");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");\n\t\t}");

		output.print("\n\n\t\tif ( p.left != null )\n\t\t{");
		output.print("\n\t\t\treduce ( p.left, p.leftSubgoals[firstGoalState]");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");\n\t\t}");

		output.print("\n\t\treduceAntecedentStates(p, goalState);");

		output.print("\n\t\tdispatchAction ( (" + iNodeClass +
			")p.getNode(), iRule );\n\t}" +
			"\n\telse\n\t{\n\t\tthrow new IllegalStateException ( \"Unable to find a rule to process \" + p.toString() + \"(\"" +
			"+ String.valueOf(p.getOperator()) + \")\" + \"{\" + String.valueOf(goalState) +\"}\" );\n\t}\n}");

		output.print(
			"\n\nint visitAntecedentStates( JBurgAnnotation p, int goalState ");

		if (debugMode)
			output.print(", java.io.PrintWriter debugOutput ");

		output.print(" ) throws Exception\n{");

		output.print(
			"\n\tint   currentState = goalState;\n\tint antecedentIndex = 0;");
		output.print("\n\twhile ( p.hasAntecedent(currentState)  )\n\t{");

		if (debugMode) {
			output.print("debugOutput.print   ( \"<antecedentState>\" );");
			output.print("debugOutput.print   ( stateName[currentState] );");
			output.print("debugOutput.println ( \"</antecedentState>\" );");
		}

		output.print("\n\t\tcurrentState = p.getAntecedent(currentState);");
		output.print(
			"\n\t\tif ( currentState == goalState )\n\t\t\tthrow new IllegalStateException ( \"cyclical antecedents\" );");
		output.print("\n\t}");
		output.print("\n\treturn currentState;\n}");

		//  Marshalling area for a reduction's antecedent states.
		//  Re-using this single int array saves considerable amounts of CPU and memory.
		//  On any given pass, we'll count up from 0 to (antecedentIndex-1) sequential int values
		//  to marshall the antecedent states, then back down to zero as we execute them.
		//  If there were ever more antecedent states than marshalling slots available,
		//  then we have more pigeons than pigeonholes, which means that a state has
		//  itself as an [eventual] antecedent.
		//  This should have been caught by the check in visitAntecedentStates(), above.
		output.print("\n\tint[] antecedentRules = new int[nStates];");

		output.print(
			"void reduceAntecedentStates( JBurgAnnotation p, int goalState) throws Exception\n{");
		output.print(
			"\n\tint   currentState = goalState;\n\tint antecedentIndex = 0;");
		output.print("\n\twhile ( p.hasAntecedent(currentState)  )\n\t{");
		output.print("\n\t\tcurrentState = p.getAntecedent(currentState);");
		output.print(
			"\n\t\tantecedentRules[antecedentIndex++] = p.getRule(currentState);");
		output.print("\n\t}");
		output.print(
			"\n\tfor ( --antecedentIndex; antecedentIndex >= 0; antecedentIndex-- )\n\t{");
		output.print(
			"\n\t\tdispatchAction( p.getNode(), antecedentRules[antecedentIndex] );");
		output.print("\n\t}\n}");

		//  Print the emitter function.
		output.print("\n\npublic void burm ( " + iNodeClass +
			" root ) throws Exception\n{");
		output.print("\n\n\tJBurgAnnotation annotatedTree = label(root);");

		if (debugMode) {
			output.print(
				"\n\tdebugOutput = new java.io.PrintWriter(new java.io.FileWriter(\"" +
				strClassName + "_jburg.xml\"));");
			output.print("\n\ttry\n\t{");
			output.print(
				"\n\t\tdebugOutput.println ( \"<?xml version=\\\"1.0\\\"?><jburg><label>\" ); ");
			output.print("\n\t\tdescribeNode(annotatedTree, debugOutput);");
			output.print(
				"\n\t\tdebugOutput.println ( \"</label><reductions>\" );");
		}

		output.print("\n\treduce ( annotatedTree, 0");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");");

		if (debugMode) {
			output.print(
				"\n\tdebugOutput.println ( \"</reductions></jburg>\" );");
			output.print("\n\t}\n\tfinally\n\t\t{ debugOutput.flush(); }");
		}

		output.print("\n}");

		if (debugMode) {
			//  Print out tree-dumping logic.
			output.print(
				"\n\nvoid describeNode ( JBurgAnnotation node, java.io.PrintWriter debugOutput ) ");
			output.print("\n{\n\tif ( node == null ) return;");
			output.print(
				"\n\tdebugOutput.println ( \"<node operator=\\\"\" + node.getNode().getOperator() + \"\\\">\");");
			output.print(
				"\n\tdebugOutput.print ( \"<selfDescription>\" + node.getNode().toString() + \"</selfDescription>\");");

			output.print(
				"\n\n\tfor (int i = 0; i <= nStates ; i++ )\n\t{\n\t\tif ( node.getRule(i) != 0 )\n\t\t{");
			output.print("\n\t\t\tdebugOutput.print ( \"<goal\");");
			output.print(
				"\n\t\t\tdebugOutput.print ( \" name=\\\"\" + stateName[i] + \"\\\"\");");
			output.print(
				"\n\t\t\tdebugOutput.print ( \" rule=\\\"\" + node.getRule(i) + \"\\\"\");");
			output.print(
				"\n\t\t\tdebugOutput.print ( \" cost=\\\"\" + node.getCost(i) + \"\\\"\");");
			output.print("\n\t\t\tdebugOutput.println ( \"/>\" );");
			output.print("\n\t\t}");
			output.print("\n\t}");
			output.print("\n\tdescribeNode ( node.left, debugOutput );");
			output.print("\n\tdescribeNode ( node.right, debugOutput );");
			output.print("\n\tdebugOutput.println ( \"</node>\" );");
			output.print("\n}");

			//  Print a table of human-readable state names.
			output.print(
				"\n\n\tstatic final String[] stateName = new String[] { \"\" ");

			Enumeration keys = subgoals.keys();

			while (keys.hasMoreElements()) {
				output.print(", \"" + keys.nextElement().toString() + "\"");
			}

			output.println("};");
		}

		//  Emit BURM properties and their get/set methods.
		Enumeration keys = burm_properties.keys();

		while (keys.hasMoreElements()) {
			String sName = keys.nextElement().toString();
			String sType = burm_properties.get(sName).toString();

			StringBuffer canonicalName = new StringBuffer(sName.toLowerCase());
			canonicalName.setCharAt(0,
				Character.toUpperCase(canonicalName.charAt(0)));

			output.print("\n\n\t//  BURM property, from the specification\n\t");
			output.print(sType + " " + sName + ";");
			output.print("\n\tpublic void set" + canonicalName + "(" + sType +
				" setting)\n\t{");
			output.print("\n\t\tthis." + sName + " = setting;\n\t}");
			output.print("\n\tpublic " + sType + " get" + canonicalName +
				"()\n\t{");
			output.print("\n\t\treturn this." + sName + ";\n\t}");
		}

		//  Emit the JBurgAnnotation inner class.
		emitAnnotation(iNodeClass, output);

		//  Close the class definition.
		output.print("\n\n}\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitClosures(java.util.Hashtable, java.io.PrintStream)
	 */
	public void emitClosures(Hashtable closureSets, String iNodeClass, PrintStream output) {
		Enumeration eClosures = closureSets.keys();

		while (eClosures.hasMoreElements()) {
			String strClosureNT = eClosures.nextElement().toString();

			output.print("\n\nvoid closure_" + strClosureNT +
				"( JBurgAnnotation p, int c )\n{");
			output.print("\n\tint iCost;");

			Enumeration eTargetClosures = ((Vector) closureSets.get(strClosureNT)).elements();

			while (eTargetClosures.hasMoreElements()) {
				JBurgGenerator.ClosureRecord newClosure = (JBurgGenerator.ClosureRecord) eTargetClosures.nextElement();

				String strRule;

				if (newClosure.getReduceAction() != null)
					strRule = String.valueOf(newClosure.getReduceAction()
													   .getIndex());
				else
					strRule = "0";

				String closureCost = newClosure.getCost("p.m_node");

				if (closureCost.equals("0"))
					output.print("\n\tiCost = c;");
				else
					output.print("\n\tiCost = c + " + closureCost + ";");

				output.print("\n\tif ( p.getCost(" + newClosure.getTargetNT() +
					"_NT) > iCost )\n\t{");
				output.print("\n\t\tp.reset(" + newClosure.getTargetNT() +
					"_NT, iCost, " + strRule + ");");
				output.print("\n\t\tp.recordAntecedent(" +
					newClosure.getTargetNT() + "_NT, " + strClosureNT +
					"_NT);");

				if (parent.hasClosure(newClosure)) {
					output.print("\n\t\tclosure_" + newClosure.getTargetNT() +
						"(p, iCost);");
				}

				output.print("\n\t}");
			}

			output.print("\n}");
		}
	}
	
	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitComputeCostMatrixFunction(java.io.PrintStream)
	 */
	public void emitComputeCostMatrixFunction(Hashtable patternRules, String iNodeClass, PrintStream output) throws Exception {
		output.print("\n\nprivate void computeCostMatrix ( JBurgAnnotation node )\n{\n\n\tint iCost;\n\n\tswitch(node.getOperator())\n\t{\n");

		//  All cost matrix calculations start by recognizing a pattern.
		Enumeration eNonTerminals = patternRules.elements();

		while (eNonTerminals.hasMoreElements()) {
			Vector vPatternRules;
			Enumeration ePatternRules;
			JBurgGenerator.JBurgINode nPatternRule;
			String strCost;

			vPatternRules = (Vector) eNonTerminals.nextElement();
			ePatternRules = vPatternRules.elements();

			output.print("\n\t\tcase " +
				((JBurgGenerator.JBurgINode) vPatternRules.firstElement()).getOperator() +
				":\n\t\t{");

			while (ePatternRules.hasMoreElements()) {
				nPatternRule = (JBurgGenerator.JBurgINode) ePatternRules.nextElement();
				emitPatternRule(nPatternRule, iNodeClass, output);
			}

			output.print("\n\t\t\tbreak;\n\t\t}");
		}

		output.print("\n\t}\n}\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitPatternRule(jburg.burg.JBurgGenerator.JBurgINode, java.io.PrintStream)
	 */
	public void emitPatternRule(JBurgGenerator.JBurgINode p, String iNodeClass, PrintStream output) throws Exception
	{
        int i;

        AST operand1 = p.getPattern().getFirstChild();

        AST operand2 = (operand1 != null) ? operand1.getNextSibling() : null;

        //  Encode the subtree recognizers.
        //  As we traverse the subtree, we may find additional non-terminal elements;
        //  these non-terminal elements play several parts in the overall computation
        //  of the locally-optimal reduction:
        //  -  They contribute to the rule's computed cost.
        //  -  The reduction's action code may refer to these elements by name.
        //  -  "elide" pattern elements -- e.g., B in A(B(subgoal c)) -- that aren't reduced.
        //  -  If the rule is of the form OP(nttype1 a [, nttype2 b]), then the rule
        //     must enforce this reduce-time goal state on its subtrees' reductions.
        Vector vSubgoals = new Vector();
        Vector vElided = new Vector();

        String strLeftSubtree = parent.encodePattern(operand1, "node.left", vSubgoals,
                vElided);
        String strRightSubtree = parent.encodePattern(operand2, "node.right",
                vSubgoals, vElided);

        output.print("\n\t\t\tif (" + strLeftSubtree + " && " +
            strRightSubtree + ")\n\t\t\t{");

        //  Compute this rule's cost, which is the cost of the rule itself and all the non-terminals
        //  associated with it.
        output.print("\n\t\t\t\tiCost = " +
            p.getCost("(" + iNodeClass + ")node.m_node"));

        for (i = 0; i < vSubgoals.size(); i++) {
            JBurgGenerator.JBurgSubgoalRecord ntCost;

            ntCost = (JBurgGenerator.JBurgSubgoalRecord) vSubgoals.elementAt(i);
            output.print(" + " + ntCost.m_path + ".getCost(" + ntCost.m_goal +
                "_NT)");
        }

        String strRule = String.valueOf(p.getReduceAction().getIndex());
        output.print(";\n\n\t\t\t\tif ( node.getCost(" + p.getTargetNT() +
            "_NT) > iCost )\n\t\t\t\t{");
        output.print("\n\t\t\t\t\t//  Matched " + p.getOperator() + " ==> " +
            p.getTargetNT());
        output.print("\n\t\t\t\t\tnode.reset(" + p.getTargetNT() +
            "_NT,  iCost," + strRule + ");");

        //  Do we have reduce-time goals to enforce?
        if (parent.isNonTerminalParameter(operand1)) {
            output.print("\n\t\t\t\t\tnode.setLeftSubgoal ( " +
                p.getTargetNT() + "_NT, " + operand1.getText() + "_NT );");
        }

        if (parent.isNonTerminalParameter(operand2)) {
            output.print("\n\t\t\t\t\tnode.setRightSubgoal ( " +
                p.getTargetNT() + "_NT, " + operand2.getText() + "_NT );");
        }

        //  An elided node is one that appears in the middle of a pattern and does not have to
        //  be reduced, e.g., B in the pattern A( subgoal1 x, B(subgoal2 y, subgoal3 z)).
        for (i = 0; i < vElided.size(); i++) {
            String strElided = vElided.elementAt(i).toString();
            output.print("\n\t\t\t\t\t" + strElided + ".setElided(" +
                p.getTargetNT() + "_NT);");
        }

        if (parent.hasClosure(p)) {
            output.print("\n\t\t\t\t\tclosure_" + p.getTargetNT() +
                "(node, iCost);");
        }

        output.print("\n\t\t\t\t}\n\t\t\t}");

        //  Add the non-terminal subgoal result nodes to the action routine's "parameters."
        JBurgGenerator.JBurgReduceAction action = p.getReduceAction();

        for (i = 0; i < vSubgoals.size(); i++) {
            JBurgGenerator.JBurgSubgoalRecord ntParameter;
            ntParameter = (JBurgGenerator.JBurgSubgoalRecord) vSubgoals.elementAt(i);
            action.addParameter(ntParameter.m_name, ntParameter.m_goal);
        }
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genPopFromStact(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public String genPopFromStack(String stackName, String paramType, String paramName, String tabs) {
		String s = new String("\n\t" + paramType + " " + paramName + " = (" +
													paramType + ")reducedValues.pop();\n");
		return s;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCheckPtr(java.lang.String, boolean)
	 */
	public String genCheckPtr(String paramName, boolean checkForNull) {
		if(checkForNull)
			return new String(paramName + " == null");
		return new String(paramName + " != null");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genAccessMember(java.lang.String, java.lang.String)
	 */
	public String genAccessMember(String parentName, String memberName) {
		return new String(parentName + "." + memberName);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCallMethod(java.lang.String, java.lang.String, java.lang.String[])
	 */
	public String genCallMethod(String parentName, String methodName, String[] params) {
		String s = new String(parentName + "." + methodName + "(");
		if(params != null) {
			for(int x=0; x<params.length; ++x) {
				if(x!=0) s += ", ";
				s += params[x];
			}
		}
		s+=")";
		return s;
	}
	
	JBurgGenerator parent;
	
	String filename;
	
	/**
	 * @param parent
	 */
	public EmitJava(JBurgGenerator parent) {
		super();
		this.parent = parent;
	}
	
	public EmitJava() {
		super();
	}

	public void setRtInfo(JBurgGenerator parent, String opfname) {
		this.parent = parent;
		this.filename = opfname;
	}
	
	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitInclass(java.lang.String, java.util.Vector, java.io.PrintStream)
	 */
	public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output) {
		for(Enumeration enum = inclassBlocks.elements(); enum.hasMoreElements(); ) {
			String icb = (String)enum.nextElement();
		
			output.print("\n"+icb+"\n");
		}
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCmpEquality(java.lang.String, java.lang.String, boolean)
	 */
	public String genCmpEquality(String lhs, String rhs, boolean bEquality) {
		return new String(lhs + ( bEquality==true ? " == " : " != " ) + rhs);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genLogicalAnd(java.lang.String, java.lang.String)
	 */
	public String genLogicalAnd(String lhs, String rhs) {
		return new String(lhs + " && " + rhs);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#accept(java.lang.String)
	 */
	public boolean accept(String name) {
		if(name==null || name.length()==0) {
			System.out.println("Warning: No Language specified, assuming Language Java");
			return true;
		}
		return name.equalsIgnoreCase("java");
	}
}