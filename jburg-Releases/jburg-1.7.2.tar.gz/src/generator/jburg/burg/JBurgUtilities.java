package jburg.burg;
import java.lang.reflect.Method;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

import java.util.jar.JarFile;

public class JBurgUtilities
{
    /**
     *   Traverse the given collection (and any subcollections) 
     *   and apply the specified method to all elements.
     *   This applyToAll variant assumes that the method takes an Object parameter.
     */
    public static void applyToAll(
		Object actor,
	    java.util.AbstractCollection collection,
        String strMethodName) throws Exception
    {
        //  Assume the method has an Object parameter.
        applyToAll(actor, collection, strMethodName, Object.class);
    }

    /**
     *   Traverse the given collection (and any subcollections) 
	 *   and apply the specified method to all elements.
     *   @param strMethodName the method to apply.
     *   @param cParamType the class of the method's one parameter.
     */
    public static void applyToAll( Object actor, java.util.AbstractCollection collection,
        String strMethodName, Class cParmType) throws Exception
    {
        Method m = actor.getClass().getDeclaredMethod(strMethodName, new Class[] {cParmType });
        applyToAll(actor, collection, m);
    }

    /**
     *  Traverse the given collection (and any subcollections)
	 *  and apply the specified method to all elements.
     */
    private static void applyToAll( Object actor, java.util.AbstractCollection collection, Method m)
        throws Exception
    {
        Iterator it = collection.iterator();

        while (it.hasNext()) {
            Object o = it.next();

            if (o instanceof java.util.AbstractCollection) {
                applyToAll( actor, (java.util.AbstractCollection) o, m);
            } else {
                Object[] arglist = new Object[1];
                arglist[0] = o;
                m.invoke(actor, arglist);
            }
        }
    }

	/**
	 *   @return all implementations of the given interface class that
	 *     are in the same URI.
	 */
	public static Vector<Class> getInterfaceImpls( Class interfaceClass )
	{
		Vector<Class> candidates = null;

		//  Starting point for the search is the EmitLang class' location.
		URL location = interfaceClass.getProtectionDomain().getCodeSource().getLocation();

		try
		{
			if(location.toString().endsWith(".jar"))
			{
				candidates = searchJar(new URI(location.toString()), interfaceClass);
			}
			else
			{
				//  A filesystem-based build, search the directory.
				URI iLoc = new URI(
					location.toString() +
					interfaceClass.getPackage().getName().replace('.','/') + '/'
				);
				candidates = searchPath(iLoc, interfaceClass);
			}
		}
	   	catch(URISyntaxException e)
		{
			System.err.println("Unable to load interface implementations of " + interfaceClass.getName() );
			System.err.println(e);
		}

		return candidates;
	}
	
	/**
	 *  Search a URI for candidate classes that implement an interface.
	 *  @param location -- the URI to search, usually a directory.
	 *  @param iface -- the interface class that successful candidates implement.
	 *  @return a Vector of Class objects that implement the interface.
	 */
	private static Vector<Class> searchPath(URI location, Class iface) {
		File floc;
		Vector<Class> retv = new Vector<Class>();
		
		floc = new File( location );
		
		if(!floc.isDirectory())
			return retv;
		
		String[] fls = floc.list();
		for(int i=0; i<fls.length; ++i) {
			if(fls[i].endsWith(".class") && fls[i].indexOf('$') < 0) {
				try {
					Class cl = Class.forName(iface.getPackage().getName()+"."
											 +fls[i].substring(0, fls[i].length()-6));
					Class[] ifs = cl.getInterfaces();
					boolean bIfOk = false;
					for(int j=0; j<ifs.length; ++j)
						if(ifs[j].equals(iface))
							bIfOk = true;
					if(bIfOk && !cl.isInterface())
						retv.add(cl);
				} catch(ClassNotFoundException e) {};
			}
		}
		return retv;
	}
	
	/**
	 *  Search a jarfile for candidate classes that implement an interface.
	 *  @param location -- the jarfile to search.
	 *  @param iface -- the interface class that successful candidates implement.
	 */
	private static Vector<Class> searchJar(URI location, Class iface)
	{
		File floc;
		JarFile jf;
		Vector<Class> retv = new Vector<Class>();
		
		try {
			jf = new JarFile( new File( location ) );
		} catch(IOException e) { System.out.println(e); return retv; }
		
		String pkg = iface.getPackage().getName().replace('.','/');
		
		for(Enumeration walker=jf.entries(); walker.hasMoreElements(); ) {
			// check each name for being a ".class", no "$" & starting with the iface's package name
			String cname = walker.nextElement().toString();
			if(cname.startsWith(pkg) && cname.endsWith(".class") && cname.indexOf('$')<0) {
				try {
					Class cl = Class.forName(cname.substring(0,cname.length()-6).replace('/','.'));
					Class[] ifs = cl.getInterfaces();
					boolean bIfOk = false;
					for(int j=0; j<ifs.length; ++j)
						if(ifs[j].equals(iface))
							bIfOk = true;
					if(bIfOk && !cl.isInterface())
						retv.add(cl);
				} catch(ClassNotFoundException e) {
					System.err.println("Couldn't resolve class : "+cname.substring(0,cname.length()-6).replace('/','.'));
					System.err.println(e);
				}
			}
		}
		return retv;		
	}
}
