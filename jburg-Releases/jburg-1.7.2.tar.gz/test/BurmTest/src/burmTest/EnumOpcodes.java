package burmTest;

public enum EnumOpcodes
{
    ADD,
    INT,
    PAREN,
    REGION,
}

