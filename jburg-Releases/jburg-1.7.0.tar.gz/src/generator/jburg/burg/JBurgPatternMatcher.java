package jburg.burg;

import java.util.Vector;

import jburg.burg.emitlangs.EmitLang;
import jburg.burg.inode.InodeAdapter2;

/**
 *  JBurgPatternMatcher encodes a pattern match
 *  recognizer for a subtree.  
 */

@SuppressWarnings("nls")
class JBurgPatternMatcher
{
	/**
	 *  The pattern's arity.
	 *  @warning only present for n-ary patterns;
     *  Fixed-arity patterns get arity from the number
     *  of sub-patterns.
	 */ 
	private Arity m_arity = null;

	/**
	 *  A pattern that matches an operator,
	 *  i.e. a specific node type in the
	 *  matching subtree.
	 */
	private String m_operator = null;


	/**
	 *  Subpatterns of this node.
	 */
	private Vector<JBurgPatternMatcher> m_sub_patterns = new Vector<JBurgPatternMatcher>();

	/**
     *  A pattern node that matches any finite cost
	 *  for a particular goal state.  This pattern
	 *  generates a subgoal.
     */
    private String m_match_finite_cost_state = null;
    
    /**
     * Parent of this node; used to traverse the tree
     * from a leaf back to the root.
     */
    private JBurgPatternMatcher m_parent = null;
    
    /**
     * This node's position in the parent's subpatterns vector.
     */
    Integer m_positionInParent = null;
    
    /**
     *  The goal state of a non-terminal parameter to a parent pattern.
     *  @see setParameterData(), which sets this when
     *    the pattern-matching BURM sees a parameter declaration.
     */
    String paramState = null;
    
    /**
     *  The name of a non-terminal parameter to a parent pattern.
     *  @see setParameterData(), which sets this when
     *    the pattern-matching BURM sees a parameter declaration.
     */
    String paramName = null;
    
    /**
     *  A top-level patter matcher may have parameterized subtrees,
     *  for example, in ADD(expr lhs, expr rhs) lhs and rhs are paramterized
     *  subtrees.  These subtrees play several parts in the computation of the
     *  locally-optimal reduction:
     *  -  They contribute to the rule's computed cost.
     *  -  The reduction's action code may refer to these elements by name.
     *  -  If the rule is of the form OP(nttype1 a [, nttype2 b]), then the rule
     *     must enforce this reduce-time goal state on its subtrees' reductions.
     */
    private Vector<JBurgPatternMatcher> parameterizedSubtrees;
    
    /**
     *  Named subtrees that are not parameterized non-terminals;
     *  record their names as a convenience so the reduction action
     *  can refer to them by name.
     */
    private Vector<JBurgPatternMatcher> namedSubtrees;

    /**
     *  Construct a pattern matching node.
     *  @see factory methods that generate matcher nodes.
     */
	private JBurgPatternMatcher()
	{
	}


	/**
	 * Construct a matcher that matches a specific operator.
	 * @param pattern_op - the operator to match.
	 * @return a pattern matcher that matches this operator.
	 */
	public static JBurgPatternMatcher matchOperator(String pattern_op)
    {
        JBurgPatternMatcher result = new JBurgPatternMatcher();
		result.m_operator = pattern_op;
		return result;
    }

	/**
	 * Construct a matcher that matches a subgoal that's present
	 * at least a minimum number of times.
	 * @param minimum - the minimum number of instances to accept.
	 *   almost always 1, may be zero.
	 * @return a pattern matcher that matches the n-ary aggregation.
	 */
	public static JBurgPatternMatcher matchOperandAtLeastNTimes(int minimum)
	{
        JBurgPatternMatcher result = new JBurgPatternMatcher();
		result.m_arity = new Arity(minimum);
		return result;
	}

	/**
	 * Construct a matcher that matches when a subgoal has a finite
	 * cost (i.e., when the labeler found a solution).
	 * @param state - the subgoal's goal state.
	 * @return a pattern matcher that matches when the reducer
	 *   can reduce the subgoal.
	 */
	public static JBurgPatternMatcher matchFiniteCost( String state)
    {
        JBurgPatternMatcher result = new JBurgPatternMatcher();
        result.m_match_finite_cost_state = state;
		return result;
    }


	/**
	 * @return true if the pattern matches against an operator.
	 */
	public boolean matchesOperator()
	{
	    return null != m_operator;
	}
	
	/**
	 * @return an operator-matching node's operator.
	 */
    public String getOperator()
    {
        checkPrecondition ( matchesOperator(), "Node has no operator" );
        return m_operator;
    }

    /**
     * @return the number of subpatterns present.  This is the node's arity
     * unless the final subpattern is n-ary.
     */
    private int getFixedArity()
    {
        if ( hasNaryTail() )
        {
            int arity_of_fixed_operands = m_sub_patterns.size() - 1;
            return arity_of_fixed_operands + this.m_sub_patterns.lastElement().m_arity.m_minimum;
        }
        else
        {
            return m_sub_patterns.size();
        }
    }

	/**
	 *  Add a child node.
	 */
	void addChild( JBurgPatternMatcher child )
	{
        checkPrecondition ( ! this.hasNaryTail(), "Cannot add a subpattern after an n-ary subpattern.");
        checkPrecondition ( null == child.m_parent, "Child " + child.toString() + " already has a parent.");
        
        child.m_positionInParent = new Integer(m_sub_patterns.size());
        child.m_parent = this;
        m_sub_patterns.add(child);
	}

    /**
     *  Assume ownership of a Vector of subpatterns.
     *  @param patterns - this node's Vector of subpatterns.
     */
    public void addAll(Vector<JBurgPatternMatcher> patterns)
    {
        for ( JBurgPatternMatcher child: patterns)
            addChild(child);
    }

	/**
	 *  @return the pattern recognizer for this node and its children.
	 *  @param emitter - the code emitter to use to generate the path.
	 *  @param stem - the path generated by the parent (or external caller).
	 *  @param node_info - the active InodeAdapter2 interface or null.  When present
     *     it's used to omit tautological comparisons.
	 */
	public String generatePatternRecognizer( EmitLang emitter, String stem, InodeAdapter2 node_info )
	{
        if ( m_match_finite_cost_state != null )
        {
            return generateFiniteCostCheck(emitter, stem);
        }
		else if ( isNary() )
		{
			return generateNaryPattern(emitter, stem);
		}
        else
		{
			return generatePatternWithArityChecks(emitter, stem, node_info);
		}
	}
	
	/**
     * @param emitter - the active code emitter.
     * @param stem - the a priori expression at the root of this node's path from root.
     * @return a snippet that gets the matched node's cost.
     */
	public String generateCost( EmitLang emitter, String stem )
    {
        if ( m_match_finite_cost_state != null )
        {
            return generateGetFiniteCost(emitter, stem);
        }
        else if ( this.isNary() )
        {
            return getNaryCost( emitter, stem );
        }
        
        //  Else the node doesn't cost anything.
        return null;
        
    }
	
	/**
	 * @return true if the last sub-pattern is n-ary.
	 */
	private boolean hasNaryTail()
	{
	    return this.m_sub_patterns.size() > 0 && this.m_sub_patterns.lastElement().isNary();
	}

	/**
     * @param emitter - the active code emitter.
	 * @param stem - the a priori expression at the root of this node's path from root.
	 * @param node_info - the active InodeAdapter2 interface or null.  When present
	 *     it's used to omit tautological comparisons.
     * @return a snippet that compares the candidate node to this matcher's constraints.
     */
	private String generatePatternWithArityChecks( EmitLang emitter, String stem, InodeAdapter2 node_info )
	{
	    
        checkPrecondition(m_operator != null, "Pattern node must have an operator");

        String result_pattern = null;
        
        if ( hasNaryTail() )
        {
            result_pattern = emitter.genCmpGtEq(
                    emitter.genCallMethod( generatePathToRoot(emitter, stem), "getArity", null ),
                    Integer.toString(getFixedArity())
                );
        }
        else
        {
            result_pattern = generateFixedArityCheck(emitter, stem, node_info);
        }
        
        //  The check against opcode is redundant at the root;
        //  that's just been tested as the switch expression.
        if ( null != this.m_parent )
        {
            result_pattern =
                emitter.genLogicalAnd(
                    result_pattern, 
                    generateOpCheck(emitter, stem)
            );
        }
        
		//  AND in each pattern-matching child's recognizer.
		//  Note: this could result in an arbitrarily deep
        //  parenthetical structure, but in practice patterns
        //  aren't nested very deeply.
		for ( JBurgPatternMatcher currentChild: m_sub_patterns )
		{
            result_pattern = emitter.genLogicalAnd( result_pattern, currentChild.generatePatternRecognizer(emitter, stem, node_info) );
		}

		return result_pattern;
	}

	/**
     * @param emitter - the active code emitter.
     * @param stem - the a priori expression at the root of this node's path from root.
     * @return a snippet that compares the candidate node's n-ary cost to MAX_VALUE.
     */
	private String generateNaryPattern( EmitLang emitter, String stem )
	{
		return emitter.genCmpEquality(
			getNaryCost( emitter, stem ),
			emitter.genMaxIntValue(),
			EmitLang.TEST_INEQUALITY
		);
	}

	/**
     * @param emitter - the active code emitter.
     * @param stem - the a priori expression at the root of this node's path from root.
     * @return a snippet that calls the candidate node's getNaryCost() routine.
     */
	private String getNaryCost( EmitLang emitter, String stem)
	{
		checkPrecondition(isNary(), "getNaryCost called on fixed-arity pattern");

		return emitter.genCallMethod( 
			"this",
			"getNaryCost", 
			new String[] 
                {
			        generatePathToRoot(emitter, stem), 
			        emitter.genGetGoalState(getSubgoal()), 
			        this.m_positionInParent.toString()
			    }
		);
	}


	/**
	 * 
	 * @param emitter - the active code emitter.
	 * @param stem - the a priori name of the root node.
	 * @return the path from the root node to this node.
	 */
	public String generatePathToRoot(EmitLang emitter, String stem)
	{
	    if ( null == m_parent )
	    {
	        return stem;
	    }
	    else if ( this.isNary() )
	    {
	        checkPrecondition(m_parent != null, "N-ary node with no parent");
	        return m_parent.generatePathToRoot(emitter, stem);
	    }
	    else
	    {
	        return emitter.genAccessMember(
	           m_parent.generatePathToRoot(emitter, stem),
	           emitter.genCallMethod(
	                   null, 
	                   "getNthChild", 
	                   new String[] { this.m_positionInParent.toString() }) );
	    }
	}

	/**
	 * Get the subgoal (non-terminal) state this pattern produces.
	 * @return the subgoal state.
	 */
	public String getSubgoal()
	{
	    if ( this.isNary() )
	    {
    		checkPrecondition(this.paramState != null, "n-ary goal has no parameter state");
    		return this.paramState;
	    }
	    else
	    {
	        checkPrecondition(m_match_finite_cost_state != null, "pattern has no subgoal");
	        return this.m_match_finite_cost_state;
	    }
	}

	/**
	 * Is this an n-ary pattern?
	 * @return true if this is an n-ary pattern.
	 */
	public boolean isNary()
	{
		return m_arity != null;
	}

	/**
     * @param emitter - the active code emitter.
     * @param stem - the a priori expression at the root of this node's path from root.
     * @param node_info - the active InodeAdapter2 interface or null.  When present
     *     it's used to omit tautological comparisons.
     * @return a snippet that compares the candidate node's arity to this matcher's fixed arity,
     *   or null if the arity has been checked here as a compiler-compile time constant.
     */
    private String generateFixedArityCheck( EmitLang emitter, String stem, InodeAdapter2 node_info )
    {
        Integer constant_arity = ( node_info != null )? node_info.getConstantArity(this.m_operator):null;
        if ( null == constant_arity || this.getFixedArity() != constant_arity.intValue() )
        {
    		//  This calls the JBurgAnnotation's getArity() method,
    		//  indirectly calling the i-node's getArity implementation
    		//  Thus it's hardcoded.
            
    		return emitter.genCmpEquality(
    			emitter.genCallMethod( generatePathToRoot(emitter, stem), "getArity", null ),
    			Integer.toString(getFixedArity()),
    			EmitLang.TEST_EQUALITY
    		);
        }
        else
        {
            //  Omit the arity check.
            return null;
        }
    }

    /**
     * @param emitter - the active code emitter.
     * @param stem - the a priori expression at the root of this node's path from root.
     * @return a snippet that compares the candidate node's operator to this matcher's specified operator.
     */
    private String generateOpCheck( EmitLang codeEmitter, String stem )
    {
        return codeEmitter.genCmpEquality(
            codeEmitter.genCallMethod( generatePathToRoot(codeEmitter, stem), "getOperator", null ),
			m_operator,
			EmitLang.TEST_EQUALITY
		);
    }

    /**
     * @param emitter - the active code emitter.
     * @param stem - the a priori expression at the root of this node's path from root.
     * @return a call to the matched node's getCost() method.
     */
    private String generateGetFiniteCost(EmitLang emitter, String stem)
    {
        return emitter.genCallMethod( 
            generatePathToRoot(emitter, stem), 
            "getCost", 
            new String[] { emitter.genGetGoalState(m_match_finite_cost_state) }
        );
    }
    
    /**
     * @param emitter - the active code emitter.
     * @param stem - the a priori expression at the root of this node's path from root.
     * @return a snippet that compares the matched node's cost to MAX_VALUE.
     */
    private String generateFiniteCostCheck( EmitLang codeEmitter, String stem )
    {
        return codeEmitter.genCmpLess(
			codeEmitter.genMaxIntValue(),
			generateGetFiniteCost( codeEmitter, stem )
		);
    }
    
    /**
     *  The BURM sees a parameterized subtree to a parent pattern, e.g.,
     *  <xmp>operand = NON_TERMINAL_PARAMETER( simple_identifier state, simple_identifier paramName )</xmp> 
     *  @param param_state - the non-terminal state the subtree must derive.
     *  @param param_name - the name to give to the reduced subtree result.
     */
    void setParameterData(String param_state, String param_name)
    {
        this.paramState = param_state;
        this.paramName  = param_name;
    }
    
    /**
     *  Get the name this parameterized subtree is to be given 
     *  in the parent pattern matcher's reduction action. 
     *  @return the name of this parameter.
     */
    public String getParameterName()
    {
        checkPrecondition(hasParameterName(), "no parameter name");
        return this.paramName;
    }
    
    /**
     *  Does this pattern matcher have a parameter name?
     *  @return true => the pattern is a parameter type matcher with a name.
     */
    public boolean hasParameterName()
    {
        return this.paramName != null;
    }
    
    /**
     *  Get a pattern matcher's parameterized subtrees, e.g. 
     *  lhs and rhs in the pattern ADD(expr lhs, expr rhs).
     *  @return this matcher's vector of subtrees.
     *  @warn only top-level pattern matchers have these.
     */
    public Vector<JBurgPatternMatcher> getParameterizedSubtrees()
    {
        checkPrecondition (this.parameterizedSubtrees != null, "no parameterized subtrees");
        return this.parameterizedSubtrees;
    }
    
    /**
     *  Set this pattern matcher's parameterized subtrees; the BURM harvests
     *  these subtrees from the pattern matcher's AST and the BURM's caller
     *  transfers them to the top-level pattern matcher.
     *  @param subtrees - the subtrees identified by the BURM.
     */
    public void setParameterizedSubtrees(Vector<JBurgPatternMatcher> subtrees)
    {
        this.parameterizedSubtrees = subtrees;
    }
    
    /**
     * @return non-parameterized subtrees that were given names,
     *   mostly embedded terminal nodes.
     */
    public Vector<JBurgPatternMatcher> getNamedSubtrees()
    {
        return this.namedSubtrees;
    }
    
    /**
     * Set a top-level pattern matcher's list of named subtrees.
     * @param named_subtrees - named subtrees identified by the BURM.
     */
    public void setNamedSubtrees(Vector<JBurgPatternMatcher> named_subtrees)
    {
        this.namedSubtrees = named_subtrees;
    }

    /**
     * Panic if the precondition isn't satisfied.
     * @param pre_condition - the condition that must be true.
     * @param diagnostic - detail message for the panic exception
     * @throws IllegalStateException if panic ensues.
     */
    private void checkPrecondition(boolean pre_condition, String diagnostic)
    {
        if ( !pre_condition )
        {
            System.err.println("!checkPrecondition(" + toString() + "): " + diagnostic );
            throw new IllegalStateException(diagnostic);
        }
    }
    
    
    @Override
    public String toString()
    {
        StringBuffer buffer = new StringBuffer();
        toStringHelper(buffer,0);
        return buffer.toString();
    }

    /**
     * Traverse a tree of pattern matchers and build
     * a string representation.
     * @param buffer - the StringBuffer used to build the result
     * @param level - recursion level, used to indent lines.
     */
	private void toStringHelper(StringBuffer buffer, int level)
    {
	    for ( int i = 0; i < level; i++ )
	        buffer.append("  ");
	    
	    if ( m_operator != null )
            buffer.append("opcode:" + m_operator + " ");
	    
	    if ( m_arity != null )
	       buffer.append("Arity: " + m_arity.m_minimum + ":" + m_arity.m_maximum + " ");
    
	    if ( m_match_finite_cost_state != null )
	        buffer.append("cost:" + m_match_finite_cost_state + " ");
	    
        for ( JBurgPatternMatcher matcher: m_sub_patterns )
        {
            buffer.append("\n");
            matcher.toStringHelper(buffer, level+1);
        }
        
        buffer.append("\n");

    }

	/**
	 *  The minimum and maximum number of subtrees an n-ary pattern may match.
	 */
    private static class Arity
	{
		int m_minimum;
		int m_maximum;

		Arity(int minimum)
		{
			m_minimum = minimum;
			m_maximum = Integer.MAX_VALUE;
		}
	}
    
    public boolean isSamePattern(JBurgPatternMatcher other)
    {
        boolean result;
        
        if ( this.m_arity != null && other.m_arity != null )
            result = this.m_arity.m_maximum == other.m_arity.m_maximum && this.m_arity.m_minimum == other.m_arity.m_minimum;
        else
            result = this.m_arity == other.m_arity;
        
        if ( this.matchesOperator() && other.matchesOperator() )
            result &= this.m_operator.equals(other.m_operator);
        else
            result &= this.matchesOperator() == other.matchesOperator();
        
        if ( m_match_finite_cost_state != null && other.m_match_finite_cost_state != null )
            result &= this.m_match_finite_cost_state.equals(other.m_match_finite_cost_state);
        else
            result &= this.m_match_finite_cost_state == other.m_match_finite_cost_state;
        
        result &= this.m_sub_patterns.size() == other.m_sub_patterns.size();
        
        for ( int i = 0; i < this.m_sub_patterns.size() && result; i++ )
            result &= this.m_sub_patterns.elementAt(i).isSamePattern(other.m_sub_patterns.elementAt(i));
        
        return result;
            
    }
}
