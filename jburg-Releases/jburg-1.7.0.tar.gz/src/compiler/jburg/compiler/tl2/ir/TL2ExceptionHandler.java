package jburg.compiler.tl2.ir;

import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.ObjectType;


import jburg.compiler.tl2.reducer.TL2InstructionList;

/**
 *  TL2ExceptionHander objects hold information about a catch clause.
 */
public class TL2ExceptionHandler
  implements TL2CompilerConstants
{
   public  TL2InstructionList  il;
   public  InstructionHandle   start, end, target;

   private Symbol              catchVar;

   /**
    *  Semantic analysis constructs TL2ExceptionHandler objects, and stores them
    *    for the emitter in the CATCH_STMT node's EXCEPTION_HANDER attribute.
    *
    *  @param catchNode - the syntax node that defines the
    *    catch class, variable, etc.
    *  @param catchVar - the Symbol that represents the catch clause's local variable.
    */
   public TL2ExceptionHandler ( Symbol catchVar )
   {
    this.catchVar   = catchVar;
   }

   /** @return the BCEL Type of the Throwable to be caught. */
   public ObjectType getType()
   {
    return (ObjectType)this.catchVar.getType();
   }

   /** @return this handler's exception variable's slot number. */
   public int getSlotnumber()
   {
    return this.catchVar.getSlotnumber();
   }
}
