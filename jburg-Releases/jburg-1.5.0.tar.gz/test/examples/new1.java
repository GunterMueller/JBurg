public class new1
{
	static Integer i1;

	public static void main ( String[] argv )
	{
		i1 = new Integer("1");
		System.out.println ( "i1 is " + i1.toString() );
	}
}
