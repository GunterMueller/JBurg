public interface IntegerINodeTypes
{
	public static int ADD = 1;
	public static int INDIR = 2;
	public static int INTEGER_LITERAL = 3;
}
