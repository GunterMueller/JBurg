
		package jburg.generator.version;
		public interface JBurgVersion {
		    public static final String version="1.5.0";
		}
		