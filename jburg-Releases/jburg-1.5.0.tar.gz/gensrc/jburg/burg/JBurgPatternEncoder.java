/*  Generated Wed Oct 20 16:48:59 EDT 2010 by JBurg version 1.3.0 */

package jburg.burg;


    import java.util.Set;
    import java.util.Vector;
    import jburg.parser.JBurgTokenTypes;
public class JBurgPatternEncoder implements JBurgTokenTypes
	
{
	java.util.Stack __reducedValues = new java.util.Stack();
	java.io.PrintWriter debugOutput;
	
	public static final int __operator_specification_NT = 1;
	
	public static final int __PatternMatcher_NT = 2;
	
	public static final int __simple_identifier_NT = 3;
	
	public static final int __operand_list_NT = 4;
	
	public static final int __operand_NT = 5;
	
	public static final int nStates = 5;
	
	private int getArity(antlr.collections.AST n)
	{
		int result = 0;
		antlr.collections.AST cursor = n.getFirstChild();
		while (cursor != null) {
			result++;
			cursor = cursor.getNextSibling();
		}
	return result;
	}

	private antlr.collections.AST getNthChild(antlr.collections.AST n, int idx)
	{
		antlr.collections.AST result = n.getFirstChild();
		while (result != null && idx != 0 ) {
			idx--;
			result = result.getNextSibling();
		}
	return result;
	}
	
	public JBurgAnnotation label( antlr.collections.AST to_be_labelled)
	{
		JBurgAnnotation result = null;
		
		int i;
		
		int arity;
		if ( to_be_labelled != null )
		{
			result = new JBurgAnnotation(to_be_labelled,nStates + 1);
			
			arity = getArity(to_be_labelled);
			
			i = 0;
			while ( ( arity > i ) )
			{
				result.addChild(label(((antlr.collections.AST)getNthChild(to_be_labelled, i))));
				
				i =  (i + 1) ;
				
			}this.computeCostMatrix(result);
			
		}return( result);
		
	}
	
	private void computeCostMatrix( JBurgAnnotation node)
	{
		int iCost;
		
		switch( node.getOperator() )
		{
			case OPERAND_AT_LEAST_ONE_ARITY:
			{
				if ( node.getArity() == 1 && node.getNthChild(0).getArity() == 2 && node.getNthChild(0).getOperator() == NON_TERMINAL_PARAMETER && ( Integer.MAX_VALUE > node.getNthChild(0).getNthChild(0).getCost(__simple_identifier_NT) )  && ( Integer.MAX_VALUE > node.getNthChild(0).getNthChild(1).getCost(__simple_identifier_NT) )  )
				{
					
					iCost =  (1 +  (node.getNthChild(0).getNthChild(1).getCost(__simple_identifier_NT) + node.getNthChild(0).getNthChild(0).getCost(__simple_identifier_NT)) ) ;
					if ( ( node.getCost(__operand_NT) > iCost )  )
					{
						/* Matched OPERAND_AT_LEAST_ONE_ARITY ==> operand */
						node.reset(__operand_NT, iCost, 7);
						node.addSubgoal(__operand_NT, node.getNthChild(0).getNthChild(1), __simple_identifier_NT);
						node.addSubgoal(__operand_NT, node.getNthChild(0).getNthChild(0), __simple_identifier_NT);
						
					}
				}
				break;
			}
			case OPERATOR_SPECIFICATION:
			{
				if ( node.getArity() == 2 && ( Integer.MAX_VALUE > node.getNthChild(0).getCost(__simple_identifier_NT) )  && ( Integer.MAX_VALUE > node.getNthChild(1).getCost(__operand_list_NT) )  )
				{
					
					iCost =  (1 +  (node.getNthChild(1).getCost(__operand_list_NT) + node.getNthChild(0).getCost(__simple_identifier_NT)) ) ;
					if ( ( node.getCost(__operator_specification_NT) > iCost )  )
					{
						/* Matched OPERATOR_SPECIFICATION ==> operator_specification */
						node.reset(__operator_specification_NT, iCost, 4);
						node.addSubgoal(__operator_specification_NT, node.getNthChild(1), __operand_list_NT);
						node.addSubgoal(__operator_specification_NT, node.getNthChild(0), __simple_identifier_NT);
						closure_operator_specification(node, iCost);
						
					}
				}
				break;
			}
			case PATTERN_SPECIFICATION:
			{
				if ( node.getArity() == 1 && ( Integer.MAX_VALUE > node.getNthChild(0).getCost(__operator_specification_NT) )  )
				{
					
					iCost =  (1 + node.getNthChild(0).getCost(__operator_specification_NT)) ;
					if ( ( node.getCost(__PatternMatcher_NT) > iCost )  )
					{
						/* Matched PATTERN_SPECIFICATION ==> PatternMatcher */
						node.reset(__PatternMatcher_NT, iCost, 2);
						node.addSubgoal(__PatternMatcher_NT, node.getNthChild(0), __operator_specification_NT);
						
					}
				}
				break;
			}
			case NON_TERMINAL_PARAMETER:
			{
				if ( node.getArity() == 2 && ( Integer.MAX_VALUE > node.getNthChild(0).getCost(__simple_identifier_NT) )  && ( Integer.MAX_VALUE > node.getNthChild(1).getCost(__simple_identifier_NT) )  )
				{
					
					iCost =  (1 +  (node.getNthChild(1).getCost(__simple_identifier_NT) + node.getNthChild(0).getCost(__simple_identifier_NT)) ) ;
					if ( ( node.getCost(__operand_NT) > iCost )  )
					{
						/* Matched NON_TERMINAL_PARAMETER ==> operand */
						node.reset(__operand_NT, iCost, 5);
						node.addSubgoal(__operand_NT, node.getNthChild(1), __simple_identifier_NT);
						node.addSubgoal(__operand_NT, node.getNthChild(0), __simple_identifier_NT);
						
					}
				}
				break;
			}
			case IDENTIFIER:
			{
				if ( node.getArity() == 0 )
				{
					
					iCost = 1;
					if ( ( node.getCost(__simple_identifier_NT) > iCost )  )
					{
						/* Matched IDENTIFIER ==> simple_identifier */
						node.reset(__simple_identifier_NT, iCost, 9);
						
					}
				}
				break;
			}
			case TERMINAL_RULE:
			{
				if ( node.getArity() == 1 && ( Integer.MAX_VALUE > node.getNthChild(0).getCost(__simple_identifier_NT) )  )
				{
					
					iCost =  (1 + node.getNthChild(0).getCost(__simple_identifier_NT)) ;
					if ( ( node.getCost(__PatternMatcher_NT) > iCost )  )
					{
						/* Matched TERMINAL_RULE ==> PatternMatcher */
						node.reset(__PatternMatcher_NT, iCost, 3);
						node.addSubgoal(__PatternMatcher_NT, node.getNthChild(0), __simple_identifier_NT);
						
					}
				}
				break;
			}
			case OPERAND_ARBITRARY_ARITY:
			{
				if ( node.getArity() == 1 && node.getNthChild(0).getArity() == 2 && node.getNthChild(0).getOperator() == NON_TERMINAL_PARAMETER && ( Integer.MAX_VALUE > node.getNthChild(0).getNthChild(0).getCost(__simple_identifier_NT) )  && ( Integer.MAX_VALUE > node.getNthChild(0).getNthChild(1).getCost(__simple_identifier_NT) )  )
				{
					
					iCost =  (1 +  (node.getNthChild(0).getNthChild(1).getCost(__simple_identifier_NT) + node.getNthChild(0).getNthChild(0).getCost(__simple_identifier_NT)) ) ;
					if ( ( node.getCost(__operand_NT) > iCost )  )
					{
						/* Matched OPERAND_ARBITRARY_ARITY ==> operand */
						node.reset(__operand_NT, iCost, 8);
						node.addSubgoal(__operand_NT, node.getNthChild(0).getNthChild(1), __simple_identifier_NT);
						node.addSubgoal(__operand_NT, node.getNthChild(0).getNthChild(0), __simple_identifier_NT);
						
					}
				}
				break;
			}
			case OPERAND_LIST:
			{
				if ( !(( 1 > node.getArity() ) ) && this.getNaryCost(node, __operand_NT, 0) != Integer.MAX_VALUE )
				{
					
					iCost =  (1 + this.getNaryCost(node, __operand_NT, 0)) ;
					if ( ( node.getCost(__operand_list_NT) > iCost )  )
					{
						/* Matched OPERAND_LIST ==> operand_list */
						node.reset(__operand_list_NT, iCost, 6);
						node.addNarySubgoal(__operand_list_NT, node, __operand_NT, 0);
						
					}
				}
				break;
			}
		}
	}
	
	private void closure_operator_specification( JBurgAnnotation __p, int c)
	{
		int iCost;
		
		iCost = c;
		if ( ( __p.getCost(__operand_NT) > iCost )  )
		{__p.reset(__operand_NT, iCost, 1);
			__p.recordAntecedent(__operand_NT, __operator_specification_NT);
			
		}
	}
	/* PatternMatcher */
	
	private JBurgPatternMatcher action_2( antlr.collections.AST __p)
	{

	JBurgPatternMatcher pattern = (JBurgPatternMatcher)__reducedValues.pop();

		{
			return pattern;
		}
	}
	/* PatternMatcher */
	
	private JBurgPatternMatcher action_3( antlr.collections.AST __p)
	{

	String terminalID = (String)__reducedValues.pop();

		{
		    if ( operators != null )
		        operators.add(terminalID);
		
		    return JBurgPatternMatcher.matchOperator(terminalID);
		}
	}
	/* operator_specification */
	
	private JBurgPatternMatcher action_4( antlr.collections.AST __p)
	{

	Vector operands = (Vector)__reducedValues.pop();


	String operator = (String)__reducedValues.pop();

		{
		    //  The presence of the operands node is checked by the cost computation
			//  (if the second node cannot be used as operands, its cost is infinite),
			//  so this recognizer need only check the operator.
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperator(operator);
			result.addAll( operands );
		
		    if ( operators != null )
		        operators.add(operator);
		
			return result;
		}
	}
	/* operand */
	
	private JBurgPatternMatcher action_5( antlr.collections.AST __p)
	{

	String paramName = (String)__reducedValues.pop();


	String state = (String)__reducedValues.pop();

		{
		    JBurgPatternMatcher result = JBurgPatternMatcher.matchFiniteCost(state);
		    result.setParameterData(state, paramName);
		
			//  This subgoal's cost will be added to the overall cost of the pattern match.
			subgoals.add(0, result);
		
		    return result;
		}
	}
	/* operand_list */
	
	private Vector action_6( antlr.collections.AST __p)
	{

	java.util.Vector fixed_arity_operands = (java.util.Vector)__reducedValues.pop();

		{
		    return fixed_arity_operands;
		}
	}
	/* operand */
	
	private JBurgPatternMatcher action_7( antlr.collections.AST __p)
	{

	String paramName = (String)__reducedValues.pop();


	String state = (String)__reducedValues.pop();

		{
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperandAtLeastNTimes(1);
		    result.setParameterData(state, paramName);
		    subgoals.add(0, result);
		
		    return result;
		}
	}
	/* operand */
	
	private JBurgPatternMatcher action_8( antlr.collections.AST __p)
	{

	String paramName = (String)__reducedValues.pop();


	String state = (String)__reducedValues.pop();

		{
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperandAtLeastNTimes(0);
		    result.setParameterData(state, paramName);
		    subgoals.add(0, result);
		
		    return result;
		}
	}
	/* simple_identifier */
	
	private String action_9( antlr.collections.AST __p)
	{
		{
		    return __p.getText();
		}
	}
	
	private void dispatchAction( antlr.collections.AST __p, int iRule) throws java.lang.Exception
	{
		switch( iRule )
		{
			case 1:
			{/* Don't reduce or touch the stack. */
				
				break;
			}
			case 2:
			{__reducedValues.push(this.action_2(__p));
				
				break;
			}
			case 3:
			{__reducedValues.push(this.action_3(__p));
				
				break;
			}
			case 4:
			{__reducedValues.push(this.action_4(__p));
				
				break;
			}
			case 5:
			{__reducedValues.push(this.action_5(__p));
				
				break;
			}
			case 6:
			{__reducedValues.push(this.action_6(__p));
				
				break;
			}
			case 7:
			{__reducedValues.push(this.action_7(__p));
				
				break;
			}
			case 8:
			{__reducedValues.push(this.action_8(__p));
				
				break;
			}
			case 9:
			{__reducedValues.push(this.action_9(__p));
				
				break;
			}default:throw new IllegalStateException("Unmatched reduce action " + iRule);
			
		}
	}
	
	public void reduce( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		int iRule = -1;
		if ( ( goalState > 0 )  )
		{
			iRule = p.getRule(goalState);
			
		}
		else
		{
			/* Find the minimum-cost path. */
			int minCost = Integer.MAX_VALUE;
			
			int i;
			for( 
			i = 0;
			i <= nStates;i++ )
			{
				if ( ( minCost > p.getCost(i) )  )
				{
					iRule = p.getRule(i);
					
					minCost = p.getCost(i);
					
					goalState = i;
					
				}
			}
		}if ( ( iRule > 0 )  )
		{
			reduceAntecedentStates(p, goalState);
			reduceSubgoals(p, goalState);
			dispatchAction ( (antlr.collections.AST)p.getNode(), iRule );
		}
		else
		{
			throw new IllegalStateException ( "Unable to find a rule to process \"" + p.toString() + "\", operator="+ String.valueOf(p.getOperator()) + ", goal=" + String.valueOf(goalState) );
		}
	}
	
	private void reduceSubgoals( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		/* Reduce subgoals in reverse order so they get pushed onto the stack */
		/* in the order expected by the action routines. */
		for ( int i = p.getSubgoalsSize(goalState) - 1; i >= 0; i-- )
		{
			JBurgSubgoal sg = (JBurgSubgoal) p.getSubgoals(goalState).elementAt(i);
			if ( null == sg.m_startIndex )
				reduce ( sg.getNode(), sg.getGoalState());else
			{
				/* Aggregate the operands of an n-ary operator into a single container. */
				JBurgAnnotation sub_parent = sg.getNode();
				java.util.Vector variadic_result = new java.util.Vector(sub_parent.getArity() - sg.m_startIndex);
				for ( int j = sg.m_startIndex; j < sub_parent.getArity(); j++ )
				{
					reduce(sub_parent.getNthChild(j), sg.getGoalState());
					variadic_result.add(__reducedValues.pop());
				}
				__reducedValues.push(variadic_result);
			}
		}
	}
	
	private int getNaryCost( JBurgAnnotation node, int goalState, int start_index)
	{
		int accumCost = 0;
		for ( int i = start_index; i < node.getArity() && accumCost != Integer.MAX_VALUE; i++ )
		{
			int subCost = node.getNthChild(i).cost[goalState];
			if ( subCost != Integer.MAX_VALUE )
				accumCost += subCost;
			else
				accumCost = Integer.MAX_VALUE;
		}
		return accumCost;
	}
	
	private void reduceAntecedentStates( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		int[] antecedentRules = new int[nStates];
		
		int[] antecedentStates = new int[nStates];
		
		int currentState = goalState;
		
		int antecedentIndex = 0;
		
		while ( p.hasAntecedent(currentState) )
		{
			currentState = p.getAntecedent(currentState);
			antecedentStates[antecedentIndex] = currentState;
			antecedentRules[antecedentIndex] = p.getRule(currentState);
			antecedentIndex++;
		}
		for ( --antecedentIndex; antecedentIndex >= 0; antecedentIndex-- )
		{
			reduceSubgoals( p, antecedentStates[antecedentIndex]);
			dispatchAction( p.getNode(), antecedentRules[antecedentIndex] );
		}
	}
	
	public void burm( antlr.collections.AST root) throws java.lang.Exception
	{
		/* Use the least-cost goal state available. */
		burm(root, 0);
	}
	
	public void burm( antlr.collections.AST root, int goal_state) throws java.lang.Exception
	{
		JBurgAnnotation annotatedTree = label(root);
		try
		{
			reduce ( annotatedTree, goal_state);
		}
		catch ( Exception cant_reduce )
		{
			this.__problemTree = annotatedTree;
			throw cant_reduce;
		}
	}
	private JBurgAnnotation __problemTree;
	
	
	public void dump( java.io.PrintWriter debug_output)
	{if ( null == __problemTree )
		{debug_output.println("<bailed reason=\"no problem tree\"/>");
			
			return;
			
		}debug_output.println("<jburg><label>");
		
		describeNode(__problemTree, debug_output);
		debug_output.println("</label></jburg>");
		
	}

void describeNode ( JBurgAnnotation node, java.io.PrintWriter debugOutput ) 
{
	if ( node == null ) return;
	String self_description;
	try {
		self_description = java.net.URLEncoder.encode(node.getNode().toString(),"UTF-8");
	} catch ( Exception cant_encode ) {self_description = node.getNode().toString();
	}
	debugOutput.print ( "<node operator=\"" + node.getNode().getType() + "\" selfDescription=\"" + self_description + "\">");

	for (int i = 0; i <= nStates ; i++ )
	{
		if ( node.getRule(i) != 0 )
		{
			debugOutput.print ( "<goal");
			debugOutput.print ( " name=\"" + stateName[i] + "\"");
			debugOutput.print ( " rule=\"" + node.getRule(i) + "\"");
			debugOutput.print ( " cost=\"" + node.getCost(i) + "\"");
			debugOutput.println ( "/>" );
		}
	}
	for (int i = 0; i < node.getArity(); i++ )
		describeNode ( node.getNthChild(i), debugOutput );
	debugOutput.println ( "</node>" );
}

	static final String[] stateName = new String[] { "" , "operator_specification", "PatternMatcher", "simple_identifier", "operand_list", "operand"};

	/* BURM property, from the specification */
	
	private Set operators;
	
	
	public void setOperators( Set setting)
	{
		this.operators = setting;
		
	}
	
	public Set getOperators( )
	{return( this.operators);
		
	}
	/* BURM property, from the specification */
	
	private Vector subgoals;
	
	
	public void setSubgoals( Vector setting)
	{
		this.subgoals = setting;
		
	}
	
	public Vector getSubgoals( )
	{return( this.subgoals);
		
	}
	
	public Object getResult( )
	{
		return __reducedValues.pop();
		
	}
	/**
 *  JBurgAnnotation is a data structure internal to the
	  JBurg-generated BURM that annotates a JBurgNode with
	  information used for dynamic programming and reduction.
	 */
	class JBurgAnnotation
	{
	/**
	 *  The cost/rule matrices are used during dynamic programming
	 *  to compute the most economical rules that can reduce
	 *  the input node.
	*/
	private int cost[];
	private int rule[];

	/**  Transformation rules may have antecedents: other states whose
	 *  output the transformation rule is intended to transform.
	 *  All such antecedent states must be executed in sequence when the rule is reduced.
	 */
	private int[] antecedentState = null;

	 /**
	 *  A node may have a specific goal state, set by its ancestor's
	 *  requirements for a certain type of input; or it may be at 
	 *  liberty to use the most locally-economical reduction.
	 */
	public java.util.Vector[] m_subgoals;

	/** *  This node's children (may be empty).  */
	private java.util.Vector m_children = new java.util.Vector();
	/**  The INode we're annotating.  */
	
		antlr.collections.AST m_node; 
	JBurgAnnotation ( antlr.collections.AST newNode, int nRules) 
	{
		m_node = newNode;
		rule   = new int[nRules];
		cost   = new int[nRules];
		//  Initial cost of all rules is "infinite"
		java.util.Arrays.fill ( cost, Integer.MAX_VALUE);
		//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array.
	}

	 /** @return this node's operator. */
	public int getOperator() { return m_node.getType(); }

	 /** @return this node's wrappedantlr.collections.AST. */ 
	public antlr.collections.AST getNode()  { return m_node; }

	/** @return the nth child of this node.  */

	public JBurgAnnotation getNthChild(int idx)
	{
		if ( m_children.size() > idx) {
			return (JBurgAnnotation) m_children.elementAt(idx);
		} else {
			throw new IllegalArgumentException( "Index out of range:" + Integer.toString(idx) );
		}
	}

	/** @return this node's child count.  */

	public int getArity()
	{
		return m_children.size();
	}

	/** Add a new child to this node.  */

	public void addChild(JBurgAnnotation new_child)
	{
			if (new_child != null)
				m_children.add(new_child);
	}

	/** @return the wrapped node's toString().  */
	public String toString() { return m_node.toString(); } 
	/** @return the current best cost to reach a goal state.  */
	public int getCost( int goalState ) { return cost[goalState]; }

	 /** Set the cost/rule configuration of a goal state.
	 * @throws IllegalArgumentException if this node has a fixed cost/rule.
	*/
	 public void reset ( int goalState, int cost, int rule )
	{
		this.cost[goalState] = cost;
		this.rule[goalState] = rule;
		//  We have a brand new rule, therefore it has no antecedents.
		if ( this.antecedentState != null )
			this.antecedentState[goalState] = 0;
		if ( m_subgoals != null && m_subgoals[goalState] != null )
		{
			m_subgoals[goalState].clear();
		}
	}

	/** * @return the rule to fire for a specific goal state. */
	public int getRule ( int goalState ) { return rule[goalState]; }

	 /**
	 *  A closure's transformation rule succeeded.
	 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
	 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
	 *  transition back to a goal state that has already been reduced).
	*/
	public void recordAntecedent ( int iGoalState, int newAntecedentState )
	{
		int antecedentRule = rule[newAntecedentState];
		//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled.
		if ( antecedentRule == 0 )
			throw new IllegalStateException ( "Attempting to record an unlabelled antecedent state." );
		if ( antecedentRule == 1 )
		{
			//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run.
			if ( antecedentState != null )
				antecedentState[iGoalState] = antecedentState[newAntecedentState];
			}
		else
		
			{
				if ( antecedentState == null )
					antecedentState = new int[rule.length];
			}
		antecedentState[iGoalState] = newAntecedentState;
	}

	 /** @return the antecedent to the given goal state. */
	public int getAntecedent(int iGoalState)
	{
		if ( antecedentState != null )
			return antecedentState[iGoalState];
		else
			return 0;
	}
		/* @return true if the given goal state has an antecdent. */
		
		public boolean hasAntecedent( int iGoalState)
		{
			return ( antecedentState != null && getAntecedent(iGoalState) != 0 );
		}
		
		public void addSubgoal( int goalState, JBurgAnnotation node, int subGoal)
		{
			if ( m_subgoals == null )
			{
				m_subgoals = new java.util.Vector[rule.length];
			}
			if ( m_subgoals[goalState] == null )
			{
				m_subgoals[goalState] = new java.util.Vector();
			}
			m_subgoals[goalState].add(new JBurgSubgoal(node, subGoal));
		}
		
		public void addNarySubgoal( int goalState, JBurgAnnotation node, int subGoal, int start_index)
		{
			if ( m_subgoals == null )
			{
				m_subgoals = new java.util.Vector[rule.length];
			}
			if ( m_subgoals[goalState] == null )
			{
				m_subgoals[goalState] = new java.util.Vector();
			}
			m_subgoals[goalState].add(new JBurgSubgoal(node, subGoal, start_index));
		}
		
		public int getSubgoalsSize( int goalState)
		{
			if ( m_subgoals != null && m_subgoals[goalState] != null )
			{
				return m_subgoals[goalState].size();
			}
			else
			{
				return 0;
			}
		}
		
		public java.util.Vector getSubgoals( int goalState)
		{
			if ( m_subgoals == null )
			{
				throw new IllegalStateException("No subgoal records.");
			}
			return m_subgoals[goalState];
		}
	
	}
	
	public class JBurgSubgoal
	{
		private JBurgAnnotation m_node;
		
		private int m_goal_state;
		
		private Integer m_startIndex = null;
		
		
		public JBurgSubgoal( JBurgAnnotation node, int goalState)
		{
			m_node = node;
			m_goal_state = goalState;
		}
		
		public JBurgSubgoal( JBurgAnnotation node, int goalState, int start_index)
		{
			m_node = node;
			m_goal_state = goalState;
			m_startIndex = start_index;
		}
		public JBurgAnnotation getNode() { return m_node; }
		public int getGoalState() { return m_goal_state; }
	
	}

}