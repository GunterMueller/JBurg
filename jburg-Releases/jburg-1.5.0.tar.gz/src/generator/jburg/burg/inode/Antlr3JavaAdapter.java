package jburg.burg.inode;

public class Antlr3JavaAdapter
	implements InodeAdapter
{
	/**  The fully qualified name of the AST. */
	public static final String s_iNodeType = "org.antlr.runtime.tree.Tree";

	public Antlr3JavaAdapter()
	{
	}

	public boolean accept(String iNodeClass)
	{
		return iNodeClass.equals(s_iNodeType);
	}

	public String genGetArity(String node, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(node, "getChildCount", null);
	}

	public String genGetNthChild( String node, String index, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod( node, "getChild", new String[] { index } );
	}

	public String genGetOperator( String node, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(node, "getType", null);
	}
}
