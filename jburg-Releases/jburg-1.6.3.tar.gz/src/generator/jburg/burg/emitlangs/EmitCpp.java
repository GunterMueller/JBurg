package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.lang.reflect.Modifier;

import java.util.Map;
import java.util.Set;
import java.util.Vector;

import jburg.burg.JBurgGenerator;
import jburg.parser.JBurgTokenTypes;

/**
 * @author Nick Brereton
 *
 * Module to change the emitted language to be C++
 * TODO: Should output into a .h &amp; a .cpp file (perhaps file output should be handled in this class?)
 * TODO: Perhaps handle all data in the Emit**** interface &amp; derive methods ??
 * ????: Is the use of smart pointers the best way to deal with pointers in the action_nnn routines ?
 * TODO: How should "jburgsupp.h" be handled ? place in resources ?
 *
 */

@SuppressWarnings("nls")
public class EmitCpp implements EmitLang, JBurgTokenTypes
{
	private int blockCount = 0;

	@SuppressWarnings("unused")
    private String m_strClassName;
	
	public String iNodeType;
	
	/** Operator type, defaults to int */
    String operatorType = "int";
    
    public void setOpcodeType(String operator_type)
    {
        this.operatorType = operator_type;
    }

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitHeader(java.lang.String, java.lang.String, java.lang.String, java.util.Vector, boolean, java.io.PrintStream)
	 */
	public void emitHeader(String strClassName, String packageName, String headerBlock, Vector InterfaceNames, boolean debugMode, PrintStream output)
	{
		int i;

		m_strClassName = strClassName;

		// add c++ imports: note: STL is required (also required for ANTLR...so shouldn't be a problem
		output.print("#include <iostream>\n");
		output.print("#include <string>\n");
		output.print("#include <stack>\n");
		output.print("#include <exception>\n");
		output.print("#include <memory>\n");
		output.print("#include <sstream>\n");
		if(debugMode)
			output.print("#include <fstream>\n");
		output.print("#include \"jburgsupp.h\"\n");

		// java package is regarded as being equivalent to a c++ namespace
		if (packageName != null)
			output.print("// nested namespace (JBurg package property)" +
									"\nnamespace " + packageName + "\n{\n\n");

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n\n");
		}

		output.print("class " + strClassName);

		if (InterfaceNames.size() > 0) {
			output.print(": ");

			for (i = 0; i < InterfaceNames.size(); i++) {
				if (i > 0) {
					output.print(", ");
				}

				output.print("public "+InterfaceNames.elementAt(i).toString());
			}
		}

		output.print(
			"\n{\nprivate:\n\n\tstd::stack<void*> __reducedValues;\n\n");

		output.print("\tint\t*antecedentRules;\n\n");

		// output a constructor
		output.print("public:\n\n");
		output.print("\t" + strClassName + "() {\n");
		output.print("\t\tantecedentRules = new int[nStates];\n");
		output.print("\t}\n\n");

		// d'tor
		output.print("\t~" + strClassName + "() {\n");
		output.print("\t\tif( antecedentRules ) delete[] antecedentRules;\n");
		output.print("\t}\n\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitTrailer(java.lang.String, java.lang.String, java.util.Hashtable, java.util.Hashtable, boolean, java.io.PrintStream)
	 */
	public void emitTrailer(
        String strClassName, 
        String iNodeClass, 
        Set<String> subgoals, 
        Map<String, String> burm_properties, 
        boolean debugMode, 
        String default_error_handler, 
        Map<Integer,String> prologue_blocks,
        PrintStream output
        ) 
    {
		output.print("\n\n\tvoid reduce ( JBurgAnnotation<"+iNodeClass+" >* p, int goalState");

		if (debugMode)
			output.print(", std::ostream &debugOutput ");

		output.print(" )\n\t{");
		output.print("\n\t\tint iRule = -1;");

		output.print(
			"\n\n\t\tif ( goalState > 0 ) {\n\t\t\tiRule = p->getRule(goalState);\n\t\t} else {" +
			"\n\t\t\t//  Find the minimum-cost path.\n\t\t\tint minCost = MAX_INT_VALUE;\n\t\t\t" +
			"for (int i = 0; i <= nStates ; ++i ) {\n\t\t\t\tif ( p->getCost(i) < minCost ) {\n\t\t\t\t\tiRule = p->getRule(i);" +
			"\n\t\t\t\t\tminCost = p->getCost(i);\n\t\t\t\t\tgoalState = i;\n\t\t\t\t}\n\t\t\t}\n\t\t}");

		output.print("\n\n\t\tif ( iRule > 0 )\n\t\t{\n\t\t\t");

		if (debugMode) {
			output.print("\n\t\t\tdebugOutput << \"<reduction>\"; ");
			output.print(
				"\n\t\t\tdebugOutput << \"<node>\" << p->getNode()->toString() << \"</node>\";");
			output.print(
				"\n\t\t\tdebugOutput << \"<goal>\" << stateName[goalState] << \"</goal>\";");
			output.print(
				"\n\t\t\tdebugOutput << \"<rule>\" << iRule << \"</rule>\";\n\n\t\t\t");
			output.print("\n\t\t\tdebugOutput << \"</reduction>\"; ");
		}

		output.print("\n\t\t\treduceAntecedentStates(p, goalState);");

		output.print(
			"\n\t\t\tif ( p->isNary(goalState) )" +
			"\n\t\t\t{" +
				"\n\t\t\t/* Aggregate the operands of an n-ary operator into a single container. */" +
				genNaryContainerType("void*") + "* variadic_result = new " + genNaryContainerType("void*") + ";" +
				"\n\t\t\tfor ( int i = 0; i < p->getArity(); i++ )" +
				"\n\t\t\t{" +
				"\n\t\t\t	reduce(p->getNthChild(i), p->getNarySubgoal(goalState));" +
				"\n\t\t\t	variadic_result->push_back(__reducedValues.top());" +
				"\n\t\t\t	__reducedValues.pop();" +
				"\n\t\t\t}" +
				"\n\t\t\t__reducedValues.push(variadic_result);" +
			"\n\t\t\t}" 
		);

		output.print("\n\t\t\treduceSubgoals(p, goalState);");
		output.print("\n\n\t\t\tdispatchAction ( p->getNode(), iRule );");
		output.print("\n\t\t}\n\t\telse\n\t\t{");
        if ( default_error_handler != null )
        {
            output.print(default_error_handler);
        }
        else
        {
            output.print(  "\n\t\t\tstd::stringstream s;"
                     + "\n\t\t\ts << \"Unable to find a rule to process \";"
					 + "\n\t\t\ts << p->getNode()->toString();"
					 + "\n\t\t\ts << \" (\" << p->getOperator() << \") {\" << goalState << \"}\";"
					 + "\n\t\t\tthrow new std::runtime_error ( s.str() );"
					 + "\n\t\t}\n\t}\n" );
         }

		output.print("\n\tvoid reduceAntecedentStates( JBurgAnnotation<antlr::AST >* p, int goalState)");
		output.print("\n\t{");
		output.print("\n\t\tint   currentState = goalState;");

		output.print("\n\t\tstd::vector<int> antecedent_states;");
		output.print("\n\t\tstd::vector<int> antecedent_rules;");
		output.print("\n");

		output.print("\n\t\t//  If X is antecedent of Y, then the reduce action");
		output.print("\n\t\t//  for X must occur before the reduce action of Y.");
		output.print("\n\t\t//  The antecdents must therefore be processed ");
		output.print("\n\t\t//  from \"back\" to \"front.\"");
		output.print("\n\t\twhile ( p->hasAntecedent(currentState)  )");
		output.print("\n\t\t{");
		output.print("\n\t\t\tcurrentState = p->getAntecedent(currentState);");
		output.print("\n\t\t\tantecedent_states.push_back(currentState);");
		output.print("\n\t\t\tantecedent_rules.push_back(p->getRule(currentState));");
		output.print("\n\t\t}");
		output.print("\n\t\twhile ( ! antecedent_states.empty() )");
		output.print("\n\t\t{");
		output.print("\n\t\t\treduceSubgoals(p, antecedent_states.back());");
		output.print("\n\t\t\tdispatchAction( p->getNode(), antecedent_rules.back());");
		output.print("\n\t\t\tantecedent_states.pop_back();");
		output.print("\n\t\t\tantecedent_rules.pop_back();");
		output.print("\n\t\t}");
		output.print("\n\t}");

		output.print("\n\tvoid reduceSubgoals( JBurgAnnotation<antlr::AST >* p, int goalState)");
		output.print("\n\t{");
		output.print("\n\t/* Reduce subgoals in reverse order so they get pushed onto the stack */");
		output.print("\n\t/* in the order expected by the action routines. */");
		output.print("\n\t\tfor ( int i = p->getSubgoalsSize(goalState) - 1; i >= 0; i-- )");
		output.print("\n\t\t{");
		output.print("\n\t\t\tJBurgAnnotation<antlr::AST >::JBurgSubgoal sg = p->getSubgoals(goalState)[i];");
		output.print("\n\t\t\treduce ( sg.getNode(), sg.getGoalState());");
		output.print("\n\t\t}");
		output.print("\n\t}");

		//  Print the emitter functions.
		output.print("\n\npublic:\n\n");
		output.print("\tvoid burm ( " + iNodeClass + "*" + " root )\n\t{");
        output.print("\t\tburm(root,0);");
        output.print("\t}");
		output.print("\tvoid burm ( " + iNodeClass + "*" + " root, int goal_state )\n\t{");
		output.print("\n\t\tJBurgAnnotation<" + iNodeClass + " >* annotatedTree = label(root);");

		if (debugMode) {
			output.print(
				"\n\n\t\tstatic const char *stateName[] = { \"\" ");

			for (String s : subgoals )
            {
				output.print("\"" + s + "\",");
			}

			output.println("};");
			
			output.println("\t\tthis->stateName = (char**)stateName;");

			output.print(
				"\n\t\tstd::ofstream debugOutput(\"" +
				strClassName + "_jburg.xml\");");
			// re-include when the 'finally' statement issue has been resolved
			// output.print("\n\ttry\n\t{");
			output.print("\n\t\t{");
			output.print(
				"\n\t\t\tdebugOutput << \"<?xml version=\\\"1.0\\\"?><jburg><label>\" << std::endl; ");
			output.print("\n\t\t\tdescribeNode(annotatedTree, debugOutput);");
			output.print(
				"\n\t\t\tdebugOutput << \"</label><reductions>\" << std::endl;");
		}

		output.print("\n\t\treduce ( annotatedTree, goal_state");

		if (debugMode)
			output.print(", debugOutput");

		output.print(");");

		if (debugMode) {
			output.print(
				"\n\t\tdebugOutput << \"</reductions></jburg>\" << std::endl;");
			// TODO: what happens with this 'finally' statement...not exactly C++...
			//output.print("\n\t}\n\tfinally\n\t\t{ debugOutput.flush(); }");
			output.print("\n\t\t}\n\t\tdebugOutput.close();");
		}

		output.print("\n\t\tdelete annotatedTree;");
		output.print("\n\t}");

		if (debugMode)
		{
			//  Print out tree-dumping logic.
			output.print(
				"\n\n\tvoid describeNode ( JBurgAnnotation<"+iNodeClass+" >* node, std::ostream &debugOutput ) ");

			//  Print a table of human-readable state names.

			output.print("\n\t{\n\t\tif ( !node ) return;");
			output.print(
				"\n\t\tdebugOutput << \"<node operator=\\\"\" << node->getOperator() << \"\\\">\" << std::endl;");
			output.print(
				"\n\t\tdebugOutput << \"<selfDescription>\" << node->getNode()->toString() << \"</selfDescription>\";");

			output.print(
				"\n\n\t\tfor (int i = 0; i <= nStates ; i++ )\n\t\t{\n\t\t\tif ( node->getRule(i) != 0 )\n\t\t\t{");
			output.print("\n\t\t\t\tdebugOutput << \"<goal\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" name=\\\"\" << stateName[i] << \"\\\"\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" rule=\\\"\" << node->getRule(i) << \"\\\"\";");
			output.print(
				"\n\t\t\t\tdebugOutput << \" cost=\\\"\" << node->getCost(i) << \"\\\"\";");
			output.print("\n\t\t\t\tdebugOutput << \"/>\" << std::endl;");
			output.print("\n\t\t\t}");
			output.print("\n\t\t}");
			output.print("\n\t\tfor(size_t idx = 0; idx < node->getArity(); i++ ) {");
			output.print("\n\t\t\tdescribeNode ( node->getNthChild(idx), debugOutput );");
			output.print("\n\t\t}");
			output.print("\n\t\tdebugOutput << \"</node>\" << std::endl;");
			output.print("\n\t}");
			
			output.print("\tchar **stateName;");

		}

		//  Emit BURM properties and their get/set methods.
		if(burm_properties.size() > 0)
			output.print("\n\npublic:");

		for (String sName : burm_properties.keySet() )
        {
			String sType = burm_properties.get(sName);

			StringBuffer canonicalName = new StringBuffer(sName.toLowerCase());
			canonicalName.setCharAt(0,
				Character.toUpperCase(canonicalName.charAt(0)));

			output.print("\n\n\t//  BURM property, from the specification\n\t");
			output.print(sType + " " + sName + ";");
			output.print("\n\tvoid set" + canonicalName + "(" + sType +
				" setting)\n\t{");
			output.print("\n\t\tthis->" + sName + " = setting;\n\t}");
			output.print("\n\tpublic " + sType + " get" + canonicalName +
				"()\n\t{");
			output.print("\n\t\treturn this->" + sName + ";\n\t}");
		}

		//  Emit methods to simulate array-based node addressing.
		output.print(
			declareMethod(
				Modifier.PRIVATE,
				"int",
				"getArityOf",
				new String[][]{
					new String[] { iNodeClass, "node" }
				},
				null
			)
		);

		output.print( genBeginBlock() );

		output.print( genLocalVar ( iNodeClass, "cnode", "NULL" ));
		output.print( genLocalVar ( "int", "result", "0" ));

		//  FIXME: Need a generator for this.
		output.print( "for ( cnode = node->getFirstChild(); cnode != NULL; cnode = cnode->getNextSibling() ) { result++; }" );

		output.print( genBeginLine() );
		output.print( genReturnValue( "result" ) );
		output.print( genEndStmt() );
		output.print( genEndBlock() );
		

		/*
		 *  getNthChild( inode, idx)
		 */
		output.print(
			declareMethod(
				Modifier.PRIVATE,
				iNodeClass,
				"getNthChild",
				new String[][]{
					new String[] { iNodeClass, "node" },
					new String[] { "int", "idx" }
				},
				null
			)
		);

		output.print( genBeginBlock() );

		output.print( genLocalVar ( iNodeClass, "result", "NULL" ));
		output.print( genLocalVar ( "int", "i", "0" ));

		//  FIXME: Need a generator for this.
		output.print( "for ( i = 0, result = node->getFirstChild(); result != NULL && i < idx; result = result->getNextSibling() ) { i++; }" );

		output.print( genBeginLine() );
		output.print( genReturnValue( "result" ) );
		output.print( genEndStmt() );
		output.print( genEndBlock() );

		/*
		 *  getNaryCost
		 */
		output.print( genBeginLine() );
		output.print("int getNaryCost( JBurgAnnotation<"+iNodeClass+">* node, int goalState)");
		output.print( genBeginBlock() );
		output.print( genLocalVar ( "int", "i", "0" ));
		output.print( genLocalVar ( "int", "accum", "0" ));

		output.print( genBeginLine() );
		output.print( "for ( i = 0; i < node->getArity(); i++ )");
		output.print( genBeginBlock() );

		output.print( genBeginLine() );
		output.print( "accum += node->getCost(goalState)");
		output.print( genEndStmt() );

		output.print( genEndBlock() );

		output.print( genBeginLine() );
		output.print( genReturnValue( "accum" ) );
		output.print( genEndStmt() );

		output.print( genEndBlock() );

		//  Close the class definition.
		output.print("\n\n};\n");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genPopFromStact(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public String genPopFromStack(String stackName, String paramType, String paramName, String tabs)
	{
		StringBuffer result = new StringBuffer();

		result.append( genBeginLine() );

		if ( hasTrailingStar( paramType ) )
		{
			result.append( "std::auto_ptr<" );
			convertType ( paramType, false, result );
			result.append( "> " );
		}
		else
		{
			convertType( paramType, false, result );
			result.append( " " );
		}

		result.append( paramName );
		result.append( genCast(paramType, stackName + ".top()") );
		result.append( genEndStmt() );

		result.append( stackName + ".pop()" );
		result.append( genEndStmt() );

		return result.toString();
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCheckPtr(java.lang.String, boolean)
	 */
	public String genCheckPtr(String paramName, boolean checkForNull) {
		if(checkForNull)
			return new String("!" + paramName);
		return paramName;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genAccessMember(java.lang.String, java.lang.String)
	 */
	public String genAccessMember(String parentName, String memberName) {
		return new String(parentName + "->" + memberName);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCallMethod(java.lang.String, java.lang.String, java.lang.String[])
	 */
	public String genCallMethod(String parentName, String methodName, String[] params)
	{
		String s;
		
		if ( parentName != null )
		{
			s = new String(parentName + "->" + methodName + "(");
		}
		else
		{
			s = new String( methodName + "(");
		}

		if(params != null) {
			for(int x=0; x<params.length; ++x) {
				if(x!=0) s += ", ";
				s += params[x];
			}
		}
		s+=")";
		return s;
	}
	
	public EmitCpp() {
		super();
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitInclass(java.lang.String, java.util.Vector)
	 */
	public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output) {
		for( Object icb: inclassBlocks ) {
			output.print("\n"+icb.toString()+"\n");
		}
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCmpEquality(java.lang.String, java.lang.String, boolean)
	 */
	public String genCmpEquality(String lhs, String rhs, boolean bEquality) {
		return new String(lhs + ( bEquality==true ? "==" : "!=" ) + rhs);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genLogicalAnd(java.lang.String, java.lang.String)
	 */
	public String genLogicalAnd(String lhs, String rhs)
	{
	    if ( lhs != null && rhs != null)
	           return new String(lhs + " && " + rhs);
	       else if ( null == lhs )
	           return rhs;
	       else
	           return lhs;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#accept(java.lang.String)
	 */
	public boolean accept(String langName)
	{
		boolean accepted = ( langName !=null && langName .equalsIgnoreCase("cpp") );

		return accepted;
	}

	public void setInodeAdapter(jburg.burg.inode.InodeAdapter adapter)
	{
		//  FIXME: This should be so that code gen
		//  adapts to the input i-node type.
	}

	public String genIf( String condition )
	{
		return "if ( " + condition + " )";
	}

	public String genElse()
	{
		return "else";
	}

	public String genBeginBlock()
	{
		//  Replace with " " to get something like 1TBS
		String leadingSpace = genBeginLine();

		blockCount++;
		return leadingSpace + "{" + genBeginLine();
	}

	public String genEndBlock()
	{
		blockCount--;

		if ( blockCount < 0 )
		{
			throw new IllegalStateException("Invalid block count " + String.valueOf(blockCount) );
		}

		return genBeginLine() + "}" + genBeginLine();
	}

	public String genBeginLine()
	{
		StringBuffer result = new StringBuffer("\n");

		for ( int i = 0; i < blockCount; i++ )
		{
			result.append("\t");
		}

		return result.toString();
	}

	public String genCmpLess( String lhs, String rhs )
	{
		return "( " + lhs + " > " + rhs + " ) ";
	}
	
	public String genCmpGtEq(String lhs, String rhs)
    {
        return "(" + lhs + " >= " + rhs + ")";
    }

	public String genNot( String operand )
	{
		return "!(" + operand + ")";
	}

	public String genGetGoalState ( Object p )
    {
       if ( p instanceof JBurgGenerator.JBurgRule )
           return "__" + ((JBurgGenerator.JBurgRule)p).getGoalState() + "_NT";
       else
           return "__" + p.toString() + "_NT";
    }

	public String genComment( String text )
	{
		return "/* " + text + " */\n";
	}

	public String genEndStmt()
	{
		return ";" + genBeginLine();
	}

	public String genAddition( String a1, String a2 )
	{
		if ( a1.equals("0") )
			return a2;
		if ( a2.equals("0") )
			return a1;
		else
			return " (" + a1 + " + " + a2 + ") ";
	}

	public String genAssignment( String lvar, String rvalue )
	{
		return lvar + " = " + rvalue + genEndStmt();
	}

	public String genCast( String newClass, String target )
	{
		StringBuffer result = new StringBuffer("((");

		convertType( newClass, true, result );
		result.append(")");
		result.append(target);
		result.append(")");

		return result.toString();
	}

	public String genBeginEnumeratedChoiceSet( String selectionCriterion )
	{
		return "switch( " + selectionCriterion + " )" + genBeginBlock();
	}

	public String genEndEnumeratedChoiceSet()
	{
		return genEndBlock();
	}

	public String genBeginChoiceCase( String criterionValue )
	{
		return "case " + criterionValue + ":" + genBeginBlock();
	}

	public String genEndChoiceCase()
	{
		return "break;" + genEndBlock();
	}

	public String genLocalVar ( String type, String name, String initializer )
	{
		StringBuffer result = new StringBuffer();

		convertType(type, true, result);

		result.append( " " );
		result.append( name );

		if ( initializer != null )
		{
			result.append(" = ");
			result.append(initializer);
		}

		result.append( genEndStmt() );
		return result.toString();
	}

	public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
	{
		StringBuffer result = new StringBuffer();

		decodeModifiers(modifiers, result);
		convertType( returnClass, true, result );
		result.append( " " );
		result.append( name );
		result.append( "( " );

		for ( int i = 0; i < plist.length; i++ )
		{
			if ( i > 0 )
			{
				result.append(", " );
			}

			convertType( plist[i][0], true, result );
			result.append( " " );
			result.append( plist[i][1] );
		}

		result.append(" )" );

		//  Igoring exception decls in C++.

		return result.toString();
	}

	public String genSignalError( String diagnostic )
	{
		return "throw std::string(" + diagnostic + ")";

	}

	public String genDefaultChoiceCase()
	{
		return "default:";
	}

	public String genReturnValue( String value )
	{
		return "return (" + value + ")";
	}

	public String genInstanceField ( int modifiers, String type, String name, String initializer )
	{
		StringBuffer result = new StringBuffer();

		decodeModifiers( modifiers, result );
		convertType( type, true, result );

		result.append( " " );
		result.append( name );

		if ( initializer != null )
		{
			result.append( " = " );
			result.append( initializer );
		}

		result.append( genEndStmt() );

		return result.toString();
	}

	private void decodeModifiers( int modifiers, StringBuffer result )
	{
		if ( Modifier.isPublic(modifiers) )
		{
			result.append("public:");
			result.append( genBeginLine() );
		}
		else if ( Modifier.isPrivate(modifiers) )
		{
			result.append("private:");
			result.append( genBeginLine() );
		}

		if ( Modifier.isStatic(modifiers) )
		{
			result.append("static ");
		}

		if ( Modifier.isFinal(modifiers) )
		{
			result.append("const ");
		}
	}

	private boolean hasTrailingStar ( String inType )
	{
		return ( '*' == inType.charAt( inType.length() - 1 ) );
	}

	private void convertType( String inType, boolean isReference, StringBuffer result )
	{
		if ( inType.equals("JBurgAnnotation") )
		{
			//  This is a parameterized type in C++ BURMs.
			result.append("JBurgAnnotation<" + iNodeType + ">");

			if ( isReference && ! hasTrailingStar( inType ) )
			{
				result.append("*");
			}
		}
		else if ( inType.startsWith("int") || inType.equals("void") || inType.startsWith("std::string") )
		{
			result.append( inType );

			if ( !isReference && hasTrailingStar( inType ) )
			{
				result.deleteCharAt(  result.length() - 1 );
			}
		}
		else if ( inType.equals(genNaryContainerType("void*")) )
		{
			result.append( inType );
			result.append("*");
		}
		else
		{
		    if ( isReference && ! hasTrailingStar( inType ) )
            {
                result.append("*");
            }
		}
	}

	public String genMaxIntValue()
	{
		return "MAX_INT_VALUE";
	}

	public String genPushToStack(String stackName, String value )
	{
		return stackName + ".push( (void*)(" + value + "))";
	}

	public String genNewObject( String type, String[] parameters )
	{
		StringBuffer result = new StringBuffer("new ");

		convertType( type, false, result );

		result.append("(");

		if (parameters != null )
		{
			for ( int i = 0; i < parameters.length; i++ )
			{
				if ( i > 0 )
				{
					result.append(",");
				}
				result.append(parameters[i]);
			}
		}

		result.append(")");

		return result.toString();
	}

	public String genNullPointer()
	{
		return "NULL";
	}

	public String genPreTestLoop( String test_condition )
	{
		return "while ( " + test_condition + ")";
	}

	public String genNaryContainerType(String base_type)
	{
		return "std::vector<" + base_type + ">";
	}
}
