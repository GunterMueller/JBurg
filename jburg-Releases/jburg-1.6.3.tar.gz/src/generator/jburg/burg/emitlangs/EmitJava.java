package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.lang.reflect.Modifier;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import jburg.burg.JBurgGenerator;

import jburg.burg.inode.InodeAdapter;
import jburg.burg.emitlangs.EmitLang;

import jburg.parser.JBurgTokenTypes;

@SuppressWarnings({"nls","rawtypes"})
public class EmitJava implements EmitLang, JBurgTokenTypes  
{
	/**  The current block nesting depth. */
	private int blockCount = 0;

	/** Manifest constant signature snippet for a method that throws Exception.  */
	final static Class[] throwsException = new Class[] { Exception.class };
	/** Manifest constant signature snippet for a method that doens't throw.  */
	final static Class[] throwsNothing   = null;

	/** I-node adapter in use. */
	jburg.burg.inode.InodeAdapter inodeAdapter;
	
	/** Prefix to internal BURM names. */
	String internalPrefix = "__";

    /** Operator type, defaults to int */
    String operatorType = "int";
    
    public void setOpcodeType(String operator_type)
    {
        this.operatorType = operator_type;
    }
	
	private String reducerStack()
	{
	    return internalPrefix + "reducedValues";
	}
	
	/** 
	 *  Debugging aid, used while converting boilerplate code from
	 *  raw output of cut/pasted hand-built reducer logic to the
	 *  more language-independent format JBurg uses.
	 */
	public boolean noisyBlockCounts = false;

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitHeader(java.lang.String, java.io.PrintStream)
	 */

    public void emitHeader(String strClassName, String packageName, String headerBlock, Vector InterfaceNames, boolean debugMode, PrintStream output) 
	{
		int i;

		if (packageName != null)
			output.print("\npackage " + packageName + ";\n\n");

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n");
		}

		output.print("public class " + strClassName);

		if (InterfaceNames.size() > 0) {
			output.print(" implements ");

			for (i = 0; i < InterfaceNames.size(); i++) {
				if (i > 0) {
					output.print(", ");
				}

				output.print(InterfaceNames.elementAt(i).toString());
			}
		}

		output.print( genStatement(genBeginBlock()));
		output.print(genStatement("java.util.Stack " + reducerStack() + " = new java.util.Stack();"));

		if (debugMode) {
			output.print(genStatement("java.io.PrintWriter debugOutput;"));
		}
	}


	public void emitAnnotation(String iNodeClass, PrintStream output) 
	{
		output.print(genStatement("/**\n *  JBurgAnnotation is a data structure internal to the"));
		output.print(genStatement("  JBurg-generated BURM that annotates a JBurgNode with"));
		output.print(genStatement("  information used for dynamic programming and reduction."));
		output.print(genStatement(" */"));
		output.print(genStatement("class JBurgAnnotation"));
		output.print(genBeginBlock());
		output.print("\n\t/**\n\t *  The cost/rule matrices are used during dynamic programming");
		output.print("\n\t *  to compute the most economical rules that can reduce\n\t *  the input node.\n\t*/");
		output.print("\n\tprivate int cost[];");
		output.print("\n\tprivate int rule[];");

		output.print("\n\n\t/**  Transformation rules may have antecedents: other states whose");
		output.print("\n\t *  output the transformation rule is intended to transform.");
		output.print("\n\t *  All such antecedent states must be executed in sequence when the rule is reduced.\n\t */");
		output.print("\n\tprivate int[] antecedentState = null;");
		
		output.print("\n\n\t /**\n\t *  A node may have a specific goal state, set by its ancestor's");
		output.print("\n\t *  requirements for a certain type of input; or it may be at ");
		output.print("\n\t *  liberty to use the most locally-economical reduction.\n\t */");
		output.print("\n\tpublic Vector[] m_subgoals;");
		
		output.print("\n\n\t/** *  This node's children (may be empty).  */");
		output.print("\n\tprivate " + genNaryContainerType("JBurgAnnotation") + " m_children = null;");
		
		output.print("\n\t/**  The INode we're annotating.  */\n\t");
		output.print(genStatement(iNodeClass));
		output.print(" m_node; ");
		
		output.print("\n\tJBurgAnnotation ( ");
		output.print(iNodeClass);
		output.print(" newNode, int nRules) ");
		output.print("\n\t{\n\t\tm_node = newNode;\n\t\trule   = new int[nRules];\n\t\tcost   = new int[nRules];");
		output.print("\n\t\t//  Initial cost of all rules is \"infinite\"\n\t\tjava.util.Arrays.fill ( cost, Integer.MAX_VALUE);");
		output.print("\n\t\t//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array.");
		output.print("\n\t}");

		output.print("\n\n\t /** @return this node's operator. */");
		output.print("\n\tpublic " + this.operatorType + " getOperator() { return " + inodeAdapter.genGetOperator("m_node", this) + "; }");

		output.print("\n\n\t /** @return this node's wrapped");
		output.print(iNodeClass);
		output.print(". */ ");
		output.print("\n\tpublic " + iNodeClass + " getNode()  { return m_node; }");

		output.print("\n\n\t/** @return the nth child of this node.  */");
		output.print("\n\n\tpublic JBurgAnnotation getNthChild(int idx)");
		output.print("\n\t{");
	    output.print("\n\t\tif ( m_children != null && m_children.size() > idx) {");
	    output.print("\n\t\t\treturn (JBurgAnnotation) m_children.elementAt(idx);");
	    output.print("\n\t\t} else {");
	    output.print("\n\t\t\tthrow new IllegalArgumentException( \"Index out of range:\" + Integer.toString(idx) );");
	    output.print("\n\t\t}");
	    output.print("\n\t}");

		output.print("\n\n\t/** @return this node's child count.  */");
		output.print("\n\n\tpublic int getArity()\n\t{");
		output.print("\n\t\treturn m_children != null? m_children.size():0;" );
	    output.print("\n\t}");

		output.print("\n\n\t/** Add a new child to this node.  */");
		output.print("\n\n\tpublic void addChild(JBurgAnnotation new_child)");
	    output.print("\n\t{");
	    output.print("\n\t\tif (m_children == null)");
	    output.print("\n\t\t\tm_children = new " + genNaryContainerType("JBurgAnnotation") +"();");
		output.print("\n\t\tif (new_child != null)");
		output.print("\n\t\t\tm_children.add(new_child);");
	    output.print("\n\t}");

		output.print("\n\n\t/** @return the wrapped node's toString().  */");
		output.print("\n\tpublic String toString() { return m_node.toString(); } ");
		output.print("\n\t/** @return the current best cost to reach a goal state.  */");
		output.print("\n\tpublic int getCost( int goalState ) { return cost[goalState]; }");
		output.print("\n\n\t /** Set the cost/rule configuration of a goal state.");
		output.print("\n\t * @throws IllegalArgumentException if this node has a fixed cost/rule.\n\t*/");
		output.print("\n\t public void reset ( int goalState, int cost, int rule )\n\t{");
		output.print("\n\t\tthis.cost[goalState] = cost;");
		output.print("\n\t\tthis.rule[goalState] = rule;");
		output.print("\n\t\t//  We have a brand new rule, therefore it has no antecedents.");
		output.print("\n\t\tif ( this.antecedentState != null )\n\t\t\tthis.antecedentState[goalState] = 0;");
		output.print("\n\t\tif ( m_subgoals != null && m_subgoals[goalState] != null )");
		output.print("\n\t\t{");
		output.print("\n\t\t\tm_subgoals[goalState].clear();");
		output.print("\n\t\t}");
		output.print("\n\t}");
		output.print("\n\n\t/** * @return the rule to fire for a specific goal state. */");
		output.print("\n\tpublic int getRule ( int goalState ) { return rule[goalState]; }");
		output.print("\n\n\t /**");
		output.print("\n\t *  A closure's transformation rule succeeded.");
		output.print("\n\t *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;");
		output.print("\n\t *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never ");
		output.print("\n\t *  transition back to a goal state that has already been reduced).\n\t*/");
		output.print("\n\tpublic void recordAntecedent ( int iGoalState, int newAntecedentState )\n\t{");
		output.print("\n\t\tint antecedentRule = rule[newAntecedentState];");
		output.print("\n\t\t//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled.");
		output.print("\n\t\tif ( antecedentRule == 0 )");
		output.print("\n\t\t\tthrow new IllegalStateException ( \"Attempting to record an unlabelled antecedent state.\" );");
		output.print("\n\t\tif ( antecedentRule == 1 )\n\t\t{");
		output.print( "\n\t\t\t//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run.");
		output.print("\n\t\t\tif ( antecedentState != null )");
		output.print("\n\t\t\t\tantecedentState[iGoalState] = antecedentState[newAntecedentState];");
		output.print("\n\t\t\t}");
		output.print("\n\t\telse\n\t\t");
		output.print("\n\t\t\t{");
		output.print("\n\t\t\t\tif ( antecedentState == null )");
		output.print("\n\t\t\t\t\tantecedentState = new int[rule.length];");
		output.print("\n\t\t\t}");
		output.print("\n\t\tantecedentState[iGoalState] = newAntecedentState;\n\t}");
		output.print("\n\n\t /** @return the antecedent to the given goal state. */");
		output.print("\n\tpublic int getAntecedent(int iGoalState)\n\t{");
		output.print("\n\t\tif ( antecedentState != null )");
		output.print("\n\t\t\treturn antecedentState[iGoalState];");
		output.print("\n\t\telse");
		output.print("\n\t\t\treturn 0;\n\t}");
		
		output.print(genStatement(genComment("@return true if the given goal state has an antecdent.")));
		output.print(declareMethod(Modifier.PUBLIC, "boolean","hasAntecedent", new String[][]{{"int", "iGoalState"}}, throwsNothing));
		output.print(genBeginBlock());
		output.print(genStatement("return ( antecedentState != null && getAntecedent(iGoalState) != 0 );"));
		output.print(genEndBlock());
		
		//  addSubgoal
		String[][] addSubgoalFormals = { {"int", "goalState"}, {"JBurgAnnotation", "node"}, {"int", "subGoal"} };
		output.print( declareMethod( Modifier.PUBLIC, "void", "addSubgoal", addSubgoalFormals, throwsNothing ));
		output.print(genBeginBlock());
		output.print(genStatement("if ( m_subgoals == null )"));
		output.print(genBeginBlock());
		output.print(genStatement("m_subgoals = new Vector[rule.length];"));
		output.print(genEndBlock());
		output.print(genStatement("if ( m_subgoals[goalState] == null )"));
		output.print(genBeginBlock());
		output.print(genStatement("m_subgoals[goalState] = new " + genNaryContainerType("JBurgSubgoal") + "();"));
		output.print(genEndBlock());
		output.print(genStatement("m_subgoals[goalState].add(new JBurgSubgoal(node, subGoal));"));
		output.print(genEndBlock());
		
		// addNarySubgoal
		String[][] addNarySubgoalFormals = { {"int", "goalState"}, {"JBurgAnnotation", "node"}, {"int", "subGoal"}, {"int", "start_index"} };
        output.print( declareMethod( Modifier.PUBLIC, "void", "addNarySubgoal", addNarySubgoalFormals, throwsNothing ));
        output.print(genBeginBlock());
        output.print(genStatement("if ( m_subgoals == null )"));
        output.print(genBeginBlock());
        output.print(genStatement("m_subgoals = new Vector[rule.length];"));
        output.print(genEndBlock());
        output.print(genStatement("if ( m_subgoals[goalState] == null )"));
        output.print(genBeginBlock());
        output.print(genStatement("m_subgoals[goalState] = new " + genNaryContainerType("JBurgSubgoal") + "();"));
        output.print(genEndBlock());
        output.print(genStatement("m_subgoals[goalState].add(new JBurgSubgoal(node, subGoal, start_index));"));
        output.print(genEndBlock());
		
		//  getSubgoalsSize
		output.print(declareMethod(Modifier.PUBLIC, "int", "getSubgoalsSize", new String[][] {{"int", "goalState"}}, throwsNothing));
		output.print(genBeginBlock());
		output.print(genStatement("if ( m_subgoals != null && m_subgoals[goalState] != null )"));
		output.print(genBeginBlock());
		output.print(genStatement("return m_subgoals[goalState].size();"));
		output.print(genEndBlock());
		output.print(genStatement("else"));
		output.print(genBeginBlock());
		output.print(genStatement("return 0;"));
		output.print(genEndBlock());
		output.print(genEndBlock());
		
		//  getSubgoals
		String[][] getSubgoalsFormals = {{"int", "goalState"}};
		output.print(declareMethod(Modifier.PUBLIC, genNaryContainerType("JBurgSubgoal"), "getSubgoals", getSubgoalsFormals, throwsNothing));
		output.print(genBeginBlock());
		output.print(genStatement("if ( m_subgoals == null )"));
		output.print(genBeginBlock());
		output.print(genStatement("throw new IllegalStateException(\"No subgoal records.\");"));
		output.print(genEndBlock());
		output.print(genStatement("return " + genCast(genNaryContainerType("JBurgSubgoal"), "m_subgoals[goalState]")) + ";");
		output.print(genEndBlock());
		
		//  End of JBurgAnnotation
		output.print(genEndClass());

		//  class JBurgSubgoal
		output.print(genBeginLine());
		output.print(genStatement("public class JBurgSubgoal"));
		output.print(genBeginBlock());
		output.print(genInstanceField(Modifier.PRIVATE, "JBurgAnnotation", "m_node", null));
		output.print(genInstanceField(Modifier.PRIVATE, "int", "m_goal_state", null));
		output.print(genInstanceField(Modifier.PRIVATE, "Integer", "m_startIndex", genNullPointer()));
		
		final String[][] subgoalFixedArityCtorFormals = {{"JBurgAnnotation", "node"}, {"int", "goalState"}};
		output.print(declareMethod(Modifier.PUBLIC, null, "JBurgSubgoal", subgoalFixedArityCtorFormals, throwsNothing));
		output.print(genBeginBlock());
		output.print(genStatement("m_node = node;"));
		output.print(genStatement("m_goal_state = goalState;"));
		output.print(genEndBlock());
		
		final String[][] subgoalNaryCtorFormals = {{"JBurgAnnotation", "node"}, {"int", "goalState"}, {"int", "start_index"}};
        output.print(declareMethod(Modifier.PUBLIC, null, "JBurgSubgoal", subgoalNaryCtorFormals, throwsNothing));
        output.print(genBeginBlock());
        output.print(genStatement("m_node = node;"));
        output.print(genStatement("m_goal_state = goalState;"));
        output.print(genStatement("m_startIndex = start_index;"));
        output.print(genEndBlock());
		
		output.print("\n\t\tpublic JBurgAnnotation getNode() { return m_node; }");
		output.print("\n\t\tpublic int getGoalState() { return m_goal_state; }");
		output.print(genEndClass());
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitTrailer(java.lang.String, java.lang.String, java.util.Hashtable, boolean, java.io.PrintStream)
	 */
	public void emitTrailer(
			String strClassName, 
			String iNodeClass, 
			Set<String> goalStateNames, 
			Map<String, String> burm_properties, 
			boolean debugMode, 
            String default_error_handler,
            Map<Integer,String> prologue_blocks,
			PrintStream output
		)
	{
		//  "i" is frequently used as a parameter to method calls in the reducer.
		final String[] iAsParameter =  { "i" };

		genBeginLine();
		genBeginLine();

		//  Common parameter list for reduction routines
		final String[][] reduction_plist = {
				{ "JBurgAnnotation", "p" },
				{ "int", "goalState" }
		};
		

		//  Emit reduce()
		output.print( declareMethod( Modifier.PUBLIC, "void", "reduce", reduction_plist, throwsException ));

		output.print( genBeginBlock() );
		output.print( genLocalVar( "int", "iRule", "-1"));

		output.print( genIf ( genCmpLess( "goalState", "0" )));
		output.print( genBeginBlock() );
		output.print(
			genAssignment(
				"iRule",
				genCallMethod( "p", "getRule", new String[] { "goalState" } )
				)
		);
		output.print( genEndBlock() );
		output.print( genElse() );
		output.print( genBeginBlock() );
		output.print( genStatement(genComment ( "Find the minimum-cost path." )));
		output.print( genLocalVar ( "int", "minCost", genMaxIntValue() ) );
		output.print( genLocalVar ( "int", "i", null ) );

		output.print( genCountingLoop( "i", "0", "nStates", true ) );
		output.print( genBeginBlock() ); 
		output.print( 
			genStatement(
				genIf(
					genCmpLess(
						"minCost",
						genCallMethod("p", "getCost", iAsParameter )
					)
				)
			)
		);
		output.print( genBeginBlock() );
		output.print( genAssignment( "iRule", genCallMethod( "p", "getRule", iAsParameter ) ));
		output.print( genAssignment( "minCost", genCallMethod( "p", "getCost", iAsParameter ) ));
		output.print( genAssignment( "goalState", "i" ) );
		output.print( genEndBlock() );
		output.print( genEndBlock() );
		output.print( genEndBlock() );

		//  Emit test for matched rule, and then emit a call to dispatch the reduction.
		output.print( genStatement(genIf( genCmpLess( "iRule", "0" ))));
		output.print( genBeginBlock() );

		/*
		 * TODO: Buffer these reductions.
		if (debugMode) 
		{
			output.print(genStatement("try"));
			output.print( genBeginBlock() );
			output.print("\t\tdebugOutput.print(\"<reduction");

			output.print(genDebugAttr("node", "p.getNode().toString()"));
			// output.print(" node=\\\"\" + p.getNode().toString() + \"\\\"");
			output.print(genDebugAttr("goal", "stateName[goalState]"));
			output.print(" rule=\\\"\" + iRule + \"\\\"");
			output.print(">\\n\")");
			output.print( genEndStmt() );
		}
		*/

		//  Emit call to reduceAntecedentStates()
        output.print(genStatement("if ( p.hasAntecedent(goalState) )"));
        output.print(genBeginBlock());
		output.print(genStatement("reduceAntecedentStates(p, goalState);" ));
        output.print(genEndBlock());

        //  Any prologue code to emit?
        if ( prologue_blocks.size() > 0 )
        {
            output.print(genStatement("dispatchPrologue ( (" + iNodeClass + ")p.getNode(), iRule );" ));
        }
		
		output.print(genStatement("reduceSubgoals(p, goalState);" ) );
		
		//  Dispatch the action routine.
		output.print(genStatement("dispatchAction ( (" + iNodeClass + ")p.getNode(), iRule );" ));

		//  Emit the else clause -- no rule found with finite cost, throw an exception.
		output.print( genEndBlock() );
		output.print(genStatement("else"));
		output.print( genBeginBlock() );

		/*
		 * TODO: Save this as a breadcrumb
		if ( debugMode )
		{
			output.print(genStatement("debugOutput.print(\"<noRule"));
			output.print(genDebugAttr("operator", "String.valueOf(p.getOperator())"));
			output.print(genDebugAttr("goal", "stateName[goalState]"));
			output.print( "/>\\n\");");
		}
		*/

        if ( default_error_handler != null )
        {
            output.print(genStatement(default_error_handler));
        }
        else
        {
            output.print(genStatement("throw"));
            output.print(
                " new IllegalStateException ( \"Unable to find a rule to process \\\"\" + p.toString() + \"\\\", operator=\"" +
                "+ String.valueOf(p.getOperator()) + \", goal=\" + String.valueOf(goalState) );"
            );
        }
		output.print( genEndBlock() );

		output.print( genEndBlock() );

		//  Emit reduceSubgoals() code.
		//  Note: signature is the same as reduce()'s signature,
		//  if this changes then a different reduction_plist is required 
		//  to match the signature.
		output.print(
			declareMethod ( 
				Modifier.PRIVATE, 
				"void", 
				"reduceSubgoals", 
				reduction_plist, 
				throwsException
			)
		);

		output.print(genBeginBlock());
		
		output.print(genStatement(genComment("Reduce subgoals in reverse order so they get pushed onto the stack")));
		output.print(genStatement(genComment("in the order expected by the action routines.")));

		output.print(genStatement("for ( int i = p.getSubgoalsSize(goalState) - 1; i >= 0; i-- )"));
		output.print(genBeginBlock());

		output.print(genStatement("JBurgSubgoal sg = (JBurgSubgoal) p.getSubgoals(goalState).elementAt(i);"));

		/*
		if ( debugMode )
		{
			output.print(genStatement("try"));
			output.print(genBeginBlock());
			output.print(genStatement("debugOutput.print(\"<Subgoal"));
			output.print(genDebugAttr("goal", "stateName[sg.getGoalState()]"));
			output.print(">\\n\");");
		}
		*/
		
		output.print(genStatement("if ( null == sg.m_startIndex )"));
		output.print( genBeginBlock() );
		output.print(genSingleLineBlock("reduce ( sg.getNode(), sg.getGoalState());"));
		output.print( genEndBlock() );
	    //  For n-ary nodes, emit code that collects all the n-ary elements
        //  into a single aggregate data structure.
		output.print(genStatement("else"));
        output.print( genBeginBlock() );
        output.print( genStatement( genComment( "Aggregate the operands of an n-ary operator into a single container." ) ) );
        output.print( genStatement("JBurgAnnotation sub_parent = sg.getNode();"));
        output.print( genStatement( genNaryContainerType("Object") + " variadic_result = new " + genNaryContainerType("Object") + "(sub_parent.getArity() - sg.m_startIndex);"));
        output.print( genStatement("for ( int j = sg.m_startIndex; j < sub_parent.getArity(); j++ )") );
        output.print( genBeginBlock() );
        output.print( genStatement("reduce(sub_parent.getNthChild(j), sg.getGoalState());"));
        output.print( genStatement("variadic_result.add(" + reducerStack() + ".pop());"));
        output.print( genEndBlock() );
        output.print( genStatement( reducerStack() + ".push(variadic_result);"));
        output.print( genEndBlock() );

		output.print(genEndBlock());  //  end for
		output.print(genEndBlock()); // end reduceSubgoals

        /*
         *  dispatchPrologue
         */
        final String[][] prologue_plist = {
				{ iNodeClass, "p" },
				{ "int", "iRule" }
		};

        if ( prologue_blocks.size() > 0 )
        {
            output.print(
                declareMethod ( 
                    Modifier.PRIVATE, 
                    "void", 
                    "dispatchPrologue", 
                    prologue_plist, 
                    throwsException
                )
            );

            output.print(genBeginBlock());
            
            output.print(genStatement(genBeginEnumeratedChoiceSet("iRule")));

            for ( Integer rule: prologue_blocks.keySet() )
            {
                output.print(genStatement(genBeginChoiceCase( rule.toString() )));

                output.print(prologue_blocks.get(rule));

                output.print(genEndChoiceCase());
            }

            output.print(genEndEnumeratedChoiceSet());

            output.print(genEndBlock()); // end dispatchPrologue
        }

		/*
		 *  getNaryCost
		 */
        final String[][] getNaryCostFormals = {{"JBurgAnnotation", "node"}, {"int", "goalState" }, {"int", "start_index"}};
		output.print(declareMethod(Modifier.PRIVATE, "int", "getNaryCost", getNaryCostFormals, throwsNothing));
		output.print(genBeginBlock());
		output.print(genStatement("int accumCost = 0;"));
		output.print(genStatement("for ( int i = start_index; i < node.getArity() && accumCost != Integer.MAX_VALUE; i++ )"));
		output.print(genBeginBlock());
		output.print(genStatement("int subCost = node.getNthChild(i).cost[goalState];"));
		output.print(genStatement("if ( subCost != Integer.MAX_VALUE )"));
		output.print(genSingleLineBlock("accumCost += subCost;"));
		output.print(genStatement("else"));
		output.print(genSingleLineBlock("accumCost = Integer.MAX_VALUE;"));
		output.print(genEndBlock());
		output.print(genStatement("return accumCost;"));
		output.print(genEndBlock());


		//  Marshaling area for a reduction's antecedent states.
		//  Re-using this single int array saves considerable amounts of CPU and memory.
		//  On any given pass, we'll count up from 0 to (antecedentIndex-1) sequential int values
		//  to marshal the antecedent states, then back down to zero as we execute them.
		//  If there were ever more antecedent states than marshaling slots available,
		//  then we have more pigeons than pigeonholes, which means that a state has
		//  itself as an [eventual] antecedent.
		//  This should have been caught by the check in visitAntecedentStates(), above.

		//  Emit reduceAntecedentStates() code.
		output.print(
			declareMethod( 
				Modifier.PRIVATE, 
				"void", 
				"reduceAntecedentStates", 
				reduction_plist, 
				throwsException 
			)
		);

		output.print(genBeginBlock());


		output.print(genStatement("assert ( p.hasAntecedent(goalState) );"));

		output.print(genStatement("int antecedent_state = p.getAntecedent(goalState);"));
		output.print(genStatement("if ( p.hasAntecedent(antecedent_state) )"));
		output.print(genBeginBlock());
		output.print(genStatement("reduceAntecedentStates(p, antecedent_state);"));
		output.print(genEndBlock());

		output.print( genStatement("int antecedent_rule = p.getRule(antecedent_state);"));
		output.print( genStatement( "reduceSubgoals( p, antecedent_state);") );
        //  Any prologue code to emit?
        if ( prologue_blocks.size() > 0 )
        {
            output.print(genStatement("dispatchPrologue ( p.getNode(), antecedent_rule);" ));
        }

		output.print(genStatement("dispatchAction( p.getNode(), antecedent_rule);"));

		output.print(genEndBlock());  // End reduceAntecedentStates()

		
		// burm(root)
		final String[][] simpleBurmFormals = {{iNodeClass,"root"}};
		output.print(declareMethod(Modifier.PUBLIC, "void", "burm", simpleBurmFormals, throwsException));
        output.print(genBeginBlock());
        output.print(genStatement(genComment("Use the least-cost goal state available.")));
        output.print(genStatement(genCallMethod(null, "burm", new String[] { "root", "0" } ) + ";"));
        output.print(genEndBlock());

        // burm(root, goal_state)
        final String[][] burmWithStateFormals = {{iNodeClass, "root"}, {"int","goal_state"}};
		output.print(declareMethod(Modifier.PUBLIC, "void", "burm", burmWithStateFormals, throwsException));
        output.print(genBeginBlock());
		output.print(genStatement("JBurgAnnotation annotatedTree = label(root);"));

		if (debugMode)
		{
			output.print(genStatement("try"));
            output.print(genBeginBlock());
		}

		output.print(genStatement("reduce ( annotatedTree, goal_state);"));

		String problem_tree =  this.internalPrefix + "problemTree";
		
		if (debugMode)
        {
		    output.print(genEndBlock());
		    output.print(genStatement("catch ( Exception cant_reduce )"));
            output.print(genBeginBlock());
		    output.print(genStatement("this." + problem_tree + " = annotatedTree;"));
		    output.print(genStatement("throw cant_reduce;"));
		    output.print(genEndBlock());
		}

        output.print(genEndBlock());

		if (debugMode) {
            output.print(this.genInstanceField(Modifier.PRIVATE, "JBurgAnnotation", problem_tree, null));
        }
		
		// dump(debug_output)
		if (debugMode) 
		{
		    String debug_output = "debug_output";
		    String[][] dump_plist = new String[][] { {"java.io.PrintWriter", debug_output} };

		    output.print(this.declareMethod(Modifier.PUBLIC, "void", "dump", dump_plist, null));
		    output.print(this.genBeginBlock());
		    
		    output.print(this.genIf(this.genCmpEquality(this.genNullPointer(), problem_tree, true)));
		    output.print(this.genBeginBlock());
		    output.print(this.genCallMethod(debug_output, "println", new String[] { "\"<bailed reason=\\\"no problem tree\\\"/>\"" }));
		    output.print(this.genEndStmt());
		    output.print(this.genStatement("return"));
		    output.print(this.genEndStmt());
		    output.print(this.genEndBlock());
		    
		    output.print(this.genCallMethod(debug_output, "println", new String[] { "\"<jburg><label>\"" } ));
		    output.print(this.genEndStmt());
		    output.print(this.genStatement(genCallMethod(null, "describeNode", new String[] {problem_tree, debug_output})));
		    output.print(this.genEndStmt());
		    output.print(this.genCallMethod(debug_output, "println", new String[] { "\"</label></jburg>\"" } ));
		    output.print(this.genEndStmt());

		    output.print(this.genEndBlock());
		    
			//  Print out tree-dumping logic.
			output.print(
				"\n\nvoid describeNode ( JBurgAnnotation node, java.io.PrintWriter debugOutput ) ");
			output.print("\n{\n\tif ( node == null ) return;");
			output.print(
				"\n\tString self_description;" +
                "\n\ttry {" +
                "\n\t\tself_description = java.net.URLEncoder.encode(node.getNode().toString(),\"UTF-8\");" +
                "\n\t} catch ( Exception cant_encode ) {" +
                "self_description = node.getNode().toString();\n\t}"
            );
    
            output.print("\n\tdebugOutput.print ( \"<node operator=\\\"\" + " + inodeAdapter.genGetOperator("node.getNode()", this) + " + " +
            "\"\\\" selfDescription=\\\"\" + self_description + \"\\\">\");");

			output.print(
				"\n\n\tfor (int i = 0; i <= nStates ; i++ )\n\t{\n\t\tif ( node.getRule(i) != 0 )\n\t\t{");
			output.print("\n\t\t\tdebugOutput.print ( \"<goal\");");
			output.print(
				"\n\t\t\tdebugOutput.print ( \" name=\\\"\" + stateName[i] + \"\\\"\");");
			output.print(
				"\n\t\t\tdebugOutput.print ( \" rule=\\\"\" + node.getRule(i) + \"\\\"\");");
			output.print(
				"\n\t\t\tdebugOutput.print ( \" cost=\\\"\" + node.getCost(i) + \"\\\"\");");
			output.print("\n\t\t\tdebugOutput.println ( \"/>\" );");
			output.print("\n\t\t}");
			output.print("\n\t}");
			output.print("\n\tfor (int i = 0; i < node.getArity(); i++ )");
			output.print("\n\t\tdescribeNode ( node.getNthChild(i), debugOutput );");
			output.print("\n\tdebugOutput.println ( \"</node>\" );");
			output.print("\n}");

			//  Print a table of human-readable state names.
			output.print(
				"\n\n\tstatic final String[] stateName = new String[] { \"\" ");

			for ( String s: goalStateNames )
            {
				output.print(", \"" + s + "\"");
			}

			output.println("};");
		}

		//  Emit BURM properties and their get/set methods.
		for (String sName: burm_properties.keySet() )
		{
			String sType = burm_properties.get(sName).toString();

			//  Convert the property's name to canonical form, for inclusion
			//  in the get/set method names.
			StringBuffer canonicalName = new StringBuffer(sName.toLowerCase());
			canonicalName.setCharAt( 0, Character.toUpperCase( canonicalName.charAt( 0 )));

			output.print( genStatement(genComment( "BURM property, from the specification")));
			output.print( genBeginLine() );
			output.print( genInstanceField( Modifier.PRIVATE, sType, sName, null ));

			String setDecl = declareMethod(
				Modifier.PUBLIC,
				"void",
				"set" + canonicalName,
				new String[][] {
					new String[] { sType, "setting" }
				},
				null
			);

			output.print( setDecl );
			output.print( genBeginBlock() );
			output.print( genAssignment( genAccessMember( "this", sName), "setting"));
			output.print( genEndBlock() );

			String getDecl = declareMethod( 
				Modifier.PUBLIC, 
				sType, 
				"get" + canonicalName, 
				new String[][]{}, 
				null 
			);

			output.print( getDecl );
			output.print( genBeginBlock() );
			output.print( genReturnValue( genAccessMember("this", sName ) ) );
			output.print( genEndStmt() );
			output.print( genEndBlock() );
		}

		//  Emit the getResult() method to get the final value off the stack.
		String getResultDecl = declareMethod(
				Modifier.PUBLIC,
				"Object",
				"getResult",
				new String[][] {
				},
				null
			);

		output.print( getResultDecl );
		output.print( genBeginBlock() );
		output.print( genStatement("return "));
		output.print( genCallMethod( reducerStack(), "pop", null ) );
		output.print( genEndStmt() );
		output.print( genEndBlock() );

		//  Emit the JBurgAnnotation inner class.
		emitAnnotation(iNodeClass, output);

		//  Close the class definition.
		output.print( genEndClass() );
	}


	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genPopFromStack(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public String genPopFromStack(String stackName, String paramType, String paramName, String tabs)
	{
		String s = new String("\n\t" + paramType + " " + paramName + " = (" +
													paramType + ")" + stackName + ".pop();\n");
		return s;
	}

	public String genPushToStack(String stackName, String value )
	{
		return "" + stackName + ".push(" + value + ")";
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCheckPtr(java.lang.String, boolean)
	 */
	public String genCheckPtr(String paramName, boolean checkForNull)
	{
		if(checkForNull)
			return new String(paramName + " == null");
		return new String(paramName + " != null");
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genAccessMember(java.lang.String, java.lang.String)
	 */
	public String genAccessMember(String parentName, String memberName)
	{
		return new String(parentName + "." + memberName);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCallMethod(java.lang.String, java.lang.String, java.lang.String[])
	 */
	public String genCallMethod(String parentName, String methodName, String[] params)
	{
		StringBuffer result = new StringBuffer();

		if ( parentName != null )
		{
			result.append( parentName );
			result.append( "." );
		}

		result.append( methodName );
		result.append( "(" );

		if ( params != null )
		{
			for ( int x = 0; x < params.length; ++x )
			{
				if ( x != 0)
				{
					result.append( ", " );
				}

				result.append( params[x] );
			}
		}

		result.append( ")" );

		return result.toString();
	}
	
	public EmitJava() {
		super();
	}

	public void setInodeAdapter(jburg.burg.inode.InodeAdapter adapter)
	{
		this.inodeAdapter = adapter;
	}
	
	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitInclass(java.lang.String, java.util.Vector, java.io.PrintStream)
	 */
	public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output) 
	{
		for(Object icb: inclassBlocks )
        {
			output.print("\n"+icb.toString()+"\n");
		}
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCmpEquality(java.lang.String, java.lang.String, boolean)
	 */
	public String genCmpEquality(String lhs, String rhs, boolean bEquality)
	{
		return new String(lhs + ( bEquality==true ? " == " : " != " ) + rhs);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genLogicalAnd(java.lang.String, java.lang.String)
	 */
	public String genLogicalAnd(String lhs, String rhs)
	{
	   if ( lhs != null && rhs != null)
	       return new String(lhs + " && " + rhs);
	   else if ( null == lhs )
	       return rhs;
	   else
	       return lhs;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#accept(java.lang.String)
	 */
	public boolean accept(String langName)
	{
        return "java".equalsIgnoreCase(langName);
	}

	public String genIf( String condition )
	{
		return "if ( " + condition + " )";
	}


	public String genBeginBlock()
	{
		//  Note: change to " " to get something like 1TBS.
		String leadingSpace = genBeginLine();

		blockCount++;
		if ( this.noisyBlockCounts )
		    trace ("<+ " + blockCount);
		return leadingSpace + "{";
	}

	public String genEndBlock()
	{
		blockCount--;
		
		if ( this.noisyBlockCounts )
		    trace("-> " + blockCount);

		if ( blockCount < 0 )
		{
			throw new IllegalStateException("Invalid block count " + String.valueOf(blockCount) );
		}
		

		return genBeginLine() + "}";
	}
	
	void trace(String msg)
	{
	    System.out.println(msg);
	    StackTraceElement[] stack = new Exception().getStackTrace();
	    for ( int i = 2; i < 5 && i < stack.length; i++)
	       System.out.println(stack[i]);
	}

	public String genBeginLine()
	{
		StringBuffer result = new StringBuffer("\n");

		for ( int i = 0; i < blockCount; i++ )
		{
			result.append("\t");
		}

		return result.toString();
	}

	/** Generate a statement on a new line with proper indentation. */
	public String genStatement(String stmt)
	{
		return genBeginLine() + stmt;
	}
	
	private String genSingleLineBlock(String stmt)
	{
	    this.blockCount++;
	    try
	    {
	        return genStatement(stmt);
	    }
	    finally
	    {
	        this.blockCount--;
	    }
	}

	public String genCmpLess( String lhs, String rhs )
	{
		return "( " + lhs + " > " + rhs + " ) ";
	}

	public String genCmpGtEq(String lhs, String rhs)
	{
	    return "(" + lhs + " >= " + rhs + ")";
	}
	public String genNot( String operand )
	{
		return "!(" + operand + ")";
	}

	public String genGetGoalState ( Object p )
	{
	   if ( p instanceof JBurgGenerator.JBurgRule )
           return "__" + ((JBurgGenerator.JBurgRule)p).getGoalState() + "_NT";
	   else
	       return "__" + p.toString() + "_NT";
	}

	public String genComment( String text )
	{
		return "/* " + text + " */";
	}

	public String genEndStmt()
	{
		return ";" + genBeginLine();
	}

	public String genAddition( String a1, String a2 )
	{
		if ( a1.equals("0") )
			return a2;
		if ( a2.equals("0") )
			return a1;
		else
			return " (" + a1 + " + " + a2 + ") ";
	}

	public String genAssignment( String lvar, String rvalue )
	{
		return genStatement(lvar + " = " + rvalue) + genEndStmt();
	}

	public String genCast( String newClass, String target )
	{
		return "((" + newClass + ")" + target + ")";
	}

	public String genBeginEnumeratedChoiceSet( String selectionCriterion )
	{
		return genBeginLine() + "switch( " + selectionCriterion + " )" + genBeginBlock();
	}

	public String genEndEnumeratedChoiceSet()
	{
		return genEndBlock();
	}

	public String genBeginChoiceCase( String criterionValue )
	{
		return genBeginLine() + "case " + criterionValue + ":" + genBeginBlock();
	}

	public String genEndChoiceCase()
	{
		return genBeginLine() + "break;" + genEndBlock();
	}

	public String genElse()
	{
		return genBeginLine() + "else";
	}

	public String genLocalVar ( String type, String name, String initializer )
	{
		if ( initializer == null )
		{
			return genBeginLine() + type + " " + name + genEndStmt();
		}
		else
		{
			return genBeginLine() + type + " " + name + " = " + initializer + genEndStmt();
		}
	}

	
	/**
	 *  Declare a method.
	 *  @param modifiers - java.lang.reflect.Modifier flags for public/private visibility.
	 *  @param returnClass - the method's return type.  null if the method is a constructor.
	 *  @param name - the method's name.
	 *  @param plist - an array of type/name parameter declarations.
	 *  @param exceptions - exceptions the method may throw.  
	 *  @return a snippet with the method's declaration.
	 */
	public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
	{       
		//  Java has no separate declaration stream.
		StringBuffer result = new StringBuffer();

		result.append( genBeginLine() );
		result.append( genBeginLine() );

		decodeModifiers(modifiers, result );

		if ( returnClass != null )
		{
            result.append( returnClass );
            result.append( " " );
		}
		
		result.append( name );
		result.append( "( " );

		for ( int i = 0; i < plist.length; i++ )
		{
			if ( plist[i].length != 2 )
			{
				throw new IllegalStateException( "Parameter list elements must be parameter pairs" );
			}

			if ( i > 0 )
			{
				result.append(", " );
			}

			result.append( plist[i][0] );
			result.append( " " );
			result.append( plist[i][1] );
		}

		result.append( ")" );

		if ( exceptions != null )
		{
			result.append( " throws " );

			for ( int j = 0; j < exceptions.length; j++ )
			{
				if ( j > 0 )
				{
					result.append( ", " );
				}

				result.append( exceptions[j].getName() );
			}
		}

		return result.toString();
	}

	public String genSignalError( String diagnostic )
	{
		return "throw new IllegalStateException(" + diagnostic + ")";
	}

	public String genDefaultChoiceCase()
	{
		return genBeginLine() + "default:";
	}

	public String genReturnValue( String value )
	{
		return "return( " + value + ")";
	}

	public String genEndClass()
	{
		return genStatement(genEndBlock());
	}
	public String genCountingLoop( String controlVar, String startValue, String endValue, boolean inclusive )
	{
		StringBuffer result = new StringBuffer();

		result.append( "for( " );
		result.append( genAssignment( controlVar, startValue ) );

		result.append( controlVar );
		result.append( (inclusive)? " <= ": " < " );
		result.append( endValue );
		result.append( ";" );

		result.append( controlVar );
		result.append( "++" );

		result.append( " )" );
				
		return result.toString();
	}

	public String genInstanceField ( int modifiers, String type, String name, String initializer )
	{
		StringBuffer result = new StringBuffer();

		decodeModifiers( modifiers, result );
		result.append( type );
		result.append( " " );
		result.append( name );

		if ( initializer != null )
		{
			result.append( " = " );
			result.append( initializer );
		}

		result.append( genEndStmt() );

		return genStatement(result.toString());
	}

	private void decodeModifiers( int modifiers, StringBuffer result )
	{
		if ( Modifier.isPublic( modifiers ) )
		{
			result.append( "public " );
		}
		else if ( Modifier.isProtected( modifiers ) )
		{
			result.append( "protected " );
		}
		else if ( Modifier.isPrivate( modifiers ) )
		{
			result.append( "private " );
		}

		if ( Modifier.isStatic( modifiers ) )
		{
			result.append( "static " );
		}

		if ( Modifier.isFinal( modifiers ) )
		{
			result.append( "final " );
		}
	}

	public String genMaxIntValue()
	{
		return "Integer.MAX_VALUE";
	}

	public String genNewObject( String type, String[] parameters )
	{
		StringBuffer result = new StringBuffer("new ");

		result.append(type);

		result.append("(");

		if (parameters != null )
		{
			for ( int i = 0; i < parameters.length; i++ )
			{
				if ( i > 0 )
				{
					result.append(",");
				}
				result.append(parameters[i]);
			}
		}

		result.append(")");

		return result.toString();
	}

	public String genNullPointer()
	{
		return "null";
	}

	public String genPreTestLoop( String test_condition )
	{
		return "while ( " + test_condition + ")";
	}

	public String genNaryContainerType(String base_type)
	{
		return "java.util.Vector<" + base_type + ">";
	}
}
