package jburg.burg.inode;

public class DefaultAdapter
    implements InodeAdapter
{
	public boolean accept(String inodeClassName)
	{
		//  This adapter is directly instantiated
		//  by the generator if all other adapters fail.
		return false;
	}

	public String genGetArity(String stem, jburg.emitter.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getArity");
	}

	public String genGetNthChild(String stem, String index, jburg.emitter.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getNthChild", index );
	}

	public String genGetOperator(String stem, jburg.emitter.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getOperator");
	}
}
