package jburg.burg.inode;

public class Antlr3JavaAdapter
	implements InodeAdapter
{
	/**  The fully qualified name of the AST. */
	public static final String s_iNodeType = "org.antlr.runtime.tree.Tree";

	public Antlr3JavaAdapter()
	{
	}

	public boolean accept(String iNodeClass)
	{
		return iNodeClass.equals(s_iNodeType);
	}

	public String genGetArity(String node, jburg.emitter.EmitLang emitter)
	{
		return emitter.genCallMethod(node, "getChildCount");
	}

	public String genGetNthChild( String node, String index, jburg.emitter.EmitLang emitter)
	{
		return emitter.genCallMethod( node, "getChild", index );
	}

	public String genGetOperator( String node, jburg.emitter.EmitLang emitter)
	{
		return emitter.genCallMethod(node, "getType");
	}
}
