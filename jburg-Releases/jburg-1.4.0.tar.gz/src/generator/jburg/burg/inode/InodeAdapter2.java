package jburg.burg.inode;


public interface InodeAdapter2
{
    /**
     *  Retrieve a node's arity, if it can be determined at compiler-compile time.
     *  @param operator - the opcode of the node whose arity is to be checked. 
     *  @return the node's compiler-compile-time constant arity, or null if the arity 
     *    must be computed at compile time.
     */
    public Integer getConstantArity(String operator);
    
    public Integer getMaxNthChildChoice(String operator);

    /**
     *  @param opcode - the opcode of the node at the root of this production's pattern.
     *  @param node_path - the path to the node whose child is to be returned.
     *  @param emitter - the language-specific code emitter in use. 
     *  @return an expression that fetches a child node at the specified index.
     */
    public String genGetNthChild(String operator, String node_path, int index, jburg.burg.emitlangs.EmitLang emitter);
    
    public String genGetDefaultChild(String operator, String node_path, String index, jburg.burg.emitlangs.EmitLang emitter);
    
    /**
     * @return a snippet that fetches the node's semantic content, e.g. the value of a literal
     * or the name of an identifier.
     * @param operator - the opcode of the node at the root of this production's pattern.
     * @param goal_state - the state this node is being reduced to.
     * @param subgoal_states - the nonterminal states satisfied by the production's subgoals.
     * @param emitter - the language-specific code emitter in use. 
     */
    public String genGetContent(String operator, String node_path, String goal_state, jburg.burg.emitlangs.EmitLang emitter);
}