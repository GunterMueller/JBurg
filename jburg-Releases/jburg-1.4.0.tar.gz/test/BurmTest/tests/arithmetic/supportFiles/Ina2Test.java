/**
 *  Ina2Test tests both i-node adapter interfaces.
 */
public class Ina2Test 
    implements 
        jburg.burg.inode.InodeAdapter, 
        jburg.burg.inode.InodeAdapter2,
        ArithmeticOpcodes
{
    public boolean accept(String inode_class)
    {
        //  Instantiated directly.
        return false;
    }

    public String genGetArity(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getArity", null);
	}

	public String genGetNthChild(String stem, String index, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getNthChild", new String[] { index } );
	}

	public String genGetOperator(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getOperator", null);
	}

    public Integer getConstantArity(String opcode)
    {
        if ( "INT".equals(opcode) )
            return new Integer(0);
        else
            return null;
    }

    public String genGetNthChild(String operator, String stem, int index, jburg.burg.emitlangs.EmitLang emitter)
    {
        if ( "INT".equals(operator) )
            return "null";
        else
            return genGetNthChild(stem, Integer.toString(index), emitter);
    }

    public String genGetDefaultChild(String operator, String node_path, String index, jburg.burg.emitlangs.EmitLang emitter)
    {
        return genGetNthChild(node_path, index, emitter);
    }
    
    public String genGetContent(String operator, String node_path, String goal_state, jburg.burg.emitlangs.EmitLang emitter)
    {
        if ( "INT".equals(operator) )
        {
            return "Integer.parseInt(" + node_path + ".getUserObject().toString())";
        }
        else
        {
            return null;
        }
    }

    public Integer getMaxNthChildChoice(String operator)
    {
        if ( "ADD".equals(operator) )
            return new Integer(2);
        else
            return null;
    }
}
