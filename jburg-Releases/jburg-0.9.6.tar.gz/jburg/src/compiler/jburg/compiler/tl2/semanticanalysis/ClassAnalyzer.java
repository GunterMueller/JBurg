package jburg.compiler.tl2.semanticanalysis;

import java.io.DataOutputStream;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import jburg.compiler.tl2.ir.MultipartIdentifier;
import jburg.compiler.tl2.ir.TL2INode;
import jburg.compiler.tl2.ir.TL2CompilerConstants;
import jburg.compiler.tl2.ir.Symbol;
import jburg.compiler.tl2.ir.TL2ExceptionHandler;

import jburg.compiler.tl2.parser.TL2ParserConstants;
import jburg.compiler.tl2.parser.Token;

import jburg.compiler.tl2.emitter.TL2Emitter;

import jburg.compiler.tl2.reducer.FunctionParamInstructionList;
import jburg.compiler.tl2.reducer.TL2InstructionList;

import org.apache.bcel.classfile.JavaClass;

import org.apache.bcel.generic.ALOAD;
import org.apache.bcel.generic.ArrayType;
import org.apache.bcel.generic.ClassGen;
import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.FieldGen;
import org.apache.bcel.generic.InstructionFactory;
import org.apache.bcel.generic.InstructionList;
import org.apache.bcel.generic.INVOKESPECIAL;
import org.apache.bcel.generic.MethodGen;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.RETURN;
import org.apache.bcel.generic.Type;

/**
 *  ClassInformation objects hold class-level tables
 *  of imports, field definitions, etc., and provide
 *  methods to extract that information.
 */
public class ClassAnalyzer
implements  org.apache.bcel.Constants, TL2ParserConstants, TL2CompilerConstants, SemanticVisitor
{
   /**
    *  Quick reference pointer to the class that is being compiled.
    */
   private AbstractClass classUnderCompilation;

   /**
    *  Superclass of the class that is being compiled.
    */
   private AbstractClass  superclass;

   /**
    *  The Symbol that holds the class' name and modifiers.
    */
   private Symbol classSymbol = new Symbol();

   /**  Methods and constructors. */
   private Vector methods = new Vector();

   /**  Declared fields. */
   private SymbolTable fields = new SymbolTable();

   /**  Current method's local variables, volatile on a per-traversal basis. */
   private SymbolTable localVarSymbolTable = null;

   /**
    *  Compilation proceeds on a per-thread basis,
    *  so we can get the correct analyzer context
    *  using a ThreadLocal.
    */
   static private ThreadLocal contextMap = new ThreadLocal();

   /**  The code emitter that's generating code for this class. */
   private TL2Emitter emitter;

   /**  The BCEL ClassGen object that's receiving the generated BCEL code. */
   ClassGen classGen;

   /**  The list of all field initialization code, to be injected into &lt;init&gt; methods. */
   private InstructionList initList;



   public ClassAnalyzer()
   {
    contextMap.set(this);

    AbstractClass.initializeClassMap();

    this.superclass = AbstractClass.ObjectClass;
   }

   public String getClassname()
   {
    return this.classSymbol.getName();
   }

   /**
    *  Set the given name into this' class symbol,
    *  and set up a local class definition in the
    *  AbstractClass map.
    */
   public void setClassname ( String className )
   {
    this.classSymbol.setName(className);

    this.classUnderCompilation = AbstractClass.declareLocalClass ( this );
    this.classSymbol.setSymbolClass(classUnderCompilation);
   }

   /**
    *  Initialize this class' superclass.
    */
   public void setSuperclass ( String superclassName )
   {
    this.superclass = AbstractClass.getAbstractClass ( superclassName );
   }

   /**
    *  @return the AbstractClass that represents this class' superclass.
    */
   public AbstractClass getSuperclass ()
   {
    return this.superclass;
   }

   /**
    *  @return the BCEL flags for this class' access modifiers (public/private, final).
    */
   public int getAccesslevel()
   {
    return this.classSymbol.getAccesslevel();
   }

   /**
    *  Append a parsed modifier (public, static, etc.) to this class' symbol.
    */
   public void appendModifier ( int pKind )
   {
    this.classSymbol.appendModifier(pKind);
   }

   /**
    *  Add a METHOD_DEFINITION node to this class' list of methods.
    */
   public void addMethod ( TL2INode md )
   {
    methods.add(md);
   }

   /** @return the number of methods that have been defined in this class. */
   public int numMethods()
   {
    return methods.size();
   }

   /**
    *  Perform visitor actions before the given node's children have been processed.
    *  Only special cases that can't be processed in the normal post-order go here,
    *  usually to initialize some type information.
    */
   public void preOrderVisit  (TL2INode p)
   {
    switch ( p.getOperator() )
    {
        case NEW_OPERATOR:
            //  The new operator must be built before we visit the
            //  children, so that "bar" nodes in expressions like
            //  new Foo().bar() can get foo's AbstractClass.
            buildNew(p);
            break;
        case CATCH_STMT:
            //  Add the catch statement's local variable to the
            //  symbol table before its code block is analyzed,
            //  'cuz it's a good bet the code will refer to the
            //  variable.

            AbstractClass exClass  = AbstractClass.getAbstractClass ( p.getAttribute ( CATCH_CLASS ).toString() );
            Token         varName  = (Token) p.getAttribute ( CATCH_VARIABLE );

            Symbol catchVar = new Symbol();
            catchVar.setName ( varName.image );
            catchVar.setSymbolClass ( exClass );
            catchVar.setSlotnumber ( this.localVarSymbolTable.size() );

            this.localVarSymbolTable.addSymbol ( catchVar );

            p.putAttribute ( EXCEPTION_HANDLER, new TL2ExceptionHandler ( catchVar ));
            break;
        default:
            //  nothing special
    }
   }

   /**
    *  Perform visitor actions after the children have been processed.
    */
   public void postOrderVisit ( TL2INode p )
   {
    switch ( p.getOperator() )
    {
        case QUALIFIED_NAME:
            buildObjectReference( p );
            break;

        case METHOD_CALL:
            buildMethodCall( p );
            break;

        case IDENTIFIER:
            Symbol s = getSymbol ( p.getStartToken().image );

            if ( s != null )
            {
                p.putAttribute ( IDENTIFIER_SYMBOL, s );
            }
            else
            {
                throw new IllegalArgumentException ( "Unknown identifier " + p.getStartToken().image );
            }
            break;

        default:
            //  nothing special
    }
   }

   /**
    * @param identifierName - the name of an identifier that may be a local variable or field reference.
    * @return the Symbol (search local var, then field) that corresponds to this name, or null if not found.
    */
   private Symbol getSymbol(Object identifierName)
   {
    Object result = (localVarSymbolTable == null)? null : this.localVarSymbolTable.getSymbol(identifierName);

    if ( result == null )
        result = this.fields.getSymbol( identifierName );

    return (Symbol)result;
   }

   /** @return the SymbolTable that holds this class' declared fields. */
   public SymbolTable getFieldSymbolTable()
   {
    return this.fields;
   }

   /**
    *  Traverse the class' code and perform semantic analysis.
    */
   public void analyze ()
   throws Exception
   {
    /*
     * Finish the AbstractClass that represents the class being compiled.
     */
    AbstractClass.initializeLocalClass ( this );

    //  Create a BCEL ClassGen object to generate bytecode.
    this.classGen = new ClassGen
        (
            this.classSymbol.getName(),
            this.superclass.getName(),
            "TL/2 in memory compilation",
            this.classSymbol.getAccesslevel(),
            this.getInterfaces()
        );

    //  Create and initialize a TL/2 BURM code emitter.
    this.emitter = new TL2Emitter();

    emitter.setClassgen  ( this.classGen );
    emitter.setCp        ( this.classGen.getConstantPool() );
    emitter.setFactory   ( new InstructionFactory(this.classGen) );
    emitter.setAnalyzer  ( this );

    emitter.setException_handlers ( new java.util.Vector() );
    emitter.setUnlabelled_gotos   ( new java.util.Vector() );

    /*
     * Walk each method's code.
     */
    Iterator itAnalyzer = getMethods();
    TL2INode methodDefinition;

    while ( itAnalyzer.hasNext() )
    {
        methodDefinition = (TL2INode) itAnalyzer.next();
        this.localVarSymbolTable = (SymbolTable) methodDefinition.getAttribute ( METHOD_SYMBOL_TABLE );
        TraverseAST.traverse(methodDefinition, this);
        this.localVarSymbolTable = null;
    }

    /*
     * Record the class' fields in the BCEL ClassGen.
     */
    ConstantPoolGen cp = this.classGen.getConstantPool();

    Iterator it = fields.iterator();
    Symbol   s;

    while ( it.hasNext() )
    {
        s = (Symbol)it.next();
        s.makeField ( cp );

        this.classGen.addField ( s.getFieldGen().getField() );
    }

    /*
     *  Add any initializers; we do the initializers separately because
     *  they may need to refer to fields other than theirselves.
     */
    InstructionList initializerList = new InstructionList();

    it = fields.iterator();

    while ( it.hasNext() )
    {
        s = (Symbol)it.next();

        TL2INode initializer = fields.getInitializer(s);

        if ( initializer != null )
        {
            //  Generate code; constant initializers are done in the parser.
            initializerList.append ( getInitializer( s, initializer) );
        }
    }

    /*
     * Inject this initializer logic into the class' constructors.
     */

    //  FIXME:  ctor processing, this injects a default ctor into the generated code.
    Symbol initSymbol = new Symbol();
    initSymbol.setName("<init>");
    initSymbol.setSymbolClass(this.classUnderCompilation );

    InstructionList ctorInstructions = new InstructionList( new ALOAD(0) );

    //  Call the no-args superclass constructor.
    ctorInstructions.append
        ( new INVOKESPECIAL
          ( cp.addMethodref
            ( superclass.getName(), "<init>", analyzeConstructor( this.classUnderCompilation, new Vector() ) ) ) );

    ctorInstructions.append ( initializerList );
    ctorInstructions.append ( new RETURN() );

    MethodGen mGen = new MethodGen
        (
            ACC_PUBLIC,
            Type.VOID,
            new Type[]{},
            null,
            "<init>",
            this.classUnderCompilation.getName(),
            ctorInstructions,
            cp
        );

    mGen.setMaxStack();
    mGen.setMaxLocals();

    this.classGen.addMethod ( mGen.getMethod() );
   }

   /**
    *  Generate Java bytecode.
    *  @return a JavaClass BCEL object with the generated code.
    */
   public void generateJavaClass( DataOutputStream output )
   throws Exception
   {
    for ( int i = 0; i < methods.size(); i++ )
    {
        emitter.burm( (TL2INode)methods.elementAt(i) );
    }

    this.classGen.getJavaClass().dump ( output );
   }

   /**
    *  Add a field to the class' field list.
    *  @param fieldSymbol - the field's symbol.
    *  @param initializer - the field's initializer.  May be null.
    */
   public void addField ( Symbol fieldSymbol, TL2INode initializer )
   {
    if ( getFieldSymbolTable().addSymbol ( fieldSymbol, initializer ) != null )
        throw new IllegalArgumentException ( "Field " + fieldSymbol.getName() + " has already been defined." );
   }

   /**
    *  Deconstruct a multipart identifier node into a reference chain,
    *  starting with a known variable or field.
    */
   private void buildObjectReference ( TL2INode root )
   {
    MultipartIdentifier id = (MultipartIdentifier) root.getAttribute ( QUALIFIED_SYMBOL );

    buildQualifiedReference( root, id, id.size() );

    if ( root.getOperator() == REFERENCE_STATIC_METHOD )
    {
        //  "Never-happen"
        throw new IllegalStateException ( "Static reference " + toString() + " not OK in this context." );
    }
   }

   /**
    *  Deconstruct a METHOD_CALL node into a reference chain,
    *  starting with a known variable or field, and ending
    *  with the method invocation.
    */
   private void buildMethodCall ( TL2INode root )
   {
    MultipartIdentifier id = (MultipartIdentifier) root.getAttribute ( QUALIFIED_SYMBOL );

    Token  methodName = id.elementAt( id.size() - 1 );

    if ( root.getAttribute(PARENT_REFERENCE) != null )
    {
        //  A method call that is already part of a reference chain.
        TL2INode parent = (TL2INode) root.getAttribute ( PARENT_REFERENCE );

        root.setOperator ( INVOKE_METHOD );
        root.putAttribute ( NODE_CLASS, parent.getNodeClass() );
        root.setStartToken ( methodName );
    }
    else if ( id.size() == 1 )
    {
        //  This must be a reference to a static or virtual
        //  method of the current class.
        root.setOperator ( INVOKE_METHOD );
        root.putAttribute ( NODE_CLASS, this.classUnderCompilation );
        root.setStartToken ( methodName );
    }
    else
    {
        //  This is a reference chain with mixed parts; deconstruct it.
        //  Don't let the reference chain use the method name.
        TL2INode lastReference = buildQualifiedReference( root, id, id.size() - 1);

        //  The final method reference may be static or virtual.
        if ( root.getOperator() == REFERENCE_STATIC_METHOD )
        {
            root.setOperator   ( INVOKE_STATIC_METHOD );
            root.setStartToken ( methodName );
        }
        else
        {
            TL2INode fParams = root.leftChild();

            TL2INode methodCall = new TL2INode ( INVOKE_METHOD );
            methodCall.setStartToken ( methodName );
            methodCall.setLeftChild ( fParams );

            lastReference.setLeftChild(methodCall);

            //  Propagate class information.
            methodCall.putAttribute ( NODE_CLASS, lastReference.getAttribute(NODE_CLASS) );
        }
    }
   }

   /**
    *  Deconstruct a root node and a multipart identifier into a reference chain.
    *
    *  @param p - the root node.  <b>NOTE:</b> p will be mutated.
    *  @param id - the MultipartIdentifier.
    *  @param limit - the number of elements of the MultipartIdentifier we can use.  May be
    *    less than the number of elements present in the MultipartIdentifier if the final
    *    element is reserved for use as a method name, etc.
    *  @return the <i>last</i> node in the reference chain, for further work.
    */
   public TL2INode buildQualifiedReference ( TL2INode p, MultipartIdentifier id, int limit )
   {
    //  Until we've built more references into the chain,  the last node is the input.
    TL2INode  result = p;

    // The class of the last node, updated in parallel with the result.
    AbstractClass  resultClass = null;

    // Current position in the multipart identifier.
    int ixId;

    /*
     * Check for a local variable or a field reference.
     */
    Symbol s = getSymbol ( id.elementAt(0).image );

    if ( s != null )
    {
        /*
         *  We found a valid match, begin the reference chain.
         */
        resultClass = s.getSymbolClass();

        result.putAttribute  ( IDENTIFIER_SYMBOL, s );
        result.putAttribute  ( NODE_CLASS, resultClass );
        result.setStartToken ( id.elementAt(0) );

        if ( s.getSlotnumber() == -1 )
        {
            //  This is a field reference; is it static?
            if ( s.isStatic() )
            {
                //  This is a reference to a static field.
                result.setOperator   ( REFERENCE_STATIC );

                result.putAttribute  ( NODE_STATIC_CLASS, this.classUnderCompilation );
            }
            else
            {
                //  This is a reference to instance data.
                result.setOperator ( REFERENCE_THIS );
            }
        }
        else
        {
            //  This is a reference to a local variable.
            result.setOperator ( REFERENCE_LOCAL );
        }

        //  Begin checking for further references immediately following
        //  this first identifier.
        ixId = 1;
    }
    else
    {
        /*
         *  No local variable by this name; the first element
         *  in the chain must be a static reference.
         */

        StringBuffer candidateClassName = new StringBuffer( id.elementAt(0).toString() );

        //  Static references need a class prefix, find that first.
        AbstractClass resolvedClass = null;

        //  Once we have a class, we need a field to continue.
        String candidateFieldName = null;

        for ( ixId = 0;  resolvedClass == null && ixId < limit; ixId++ )
        {
            if ( ixId > 1 )
            {
                //  Previous class/field pair didn't work, try it as part of the class name.
                candidateClassName.append(".");
                candidateClassName.append(candidateFieldName);
            }

            //  Try the next field.
            candidateFieldName = id.elementAt(ixId + 1).toString();

            try
            {
                //  Get a candidate class and check it for a static field by this name.
                AbstractClass clazz = AbstractClass.getAbstractClass ( candidateClassName.toString() );

                if ( clazz != null )
                {
                    resolvedClass = clazz;

                    //  Check for a match on the field name.
                    Symbol staticField = clazz.getField ( candidateFieldName, AbstractClass.STATIC_FIELD );

                    if ( staticField != null )
                    {
                        resultClass = staticField.getSymbolClass();

                        ixId++;

                        result.setOperator   ( REFERENCE_STATIC );

                        result.setStartToken ( id.elementAt(ixId) );
                        result.putAttribute  ( NODE_CLASS, resultClass );
                        result.putAttribute  ( NODE_STATIC_CLASS, resolvedClass );
                    }
                    else if ( ixId + 1 == limit || limit < id.size() )
                    {
                        //  We can accept a bare class name as a static method qualifier only.
                        result.setOperator  ( REFERENCE_STATIC_METHOD );
                        result.putAttribute ( NODE_CLASS, resolvedClass );
                    }
                    else
                    {
                        //  Try again.
                        resolvedClass = null;
                    }
                }
            }
            catch ( Exception ex )
            {
                //  Try again.
            }
        }

        if ( resolvedClass == null )
        {
            throw new IllegalArgumentException ( id.toString() + " is not defined, daddy-o." );
        }
        else
        {
            resultClass = resolvedClass;
        }
    }

    /*
     *  We've found the first element of the chain, resolve the rest.
     */
    for ( ; ixId < limit; ixId++ )
    {
        Token fieldName = id.elementAt(ixId);

        TL2INode nextRef = new TL2INode ( REFERENCE_MEMBER );

        nextRef.setStartToken ( fieldName );

        //  Get class information about this field, save it in the i-node
        //  and set it into our local running "class of this field" variable
        //  for the next iteration.
        Symbol nextField = resultClass.getField ( fieldName.image, AbstractClass.INSTANCE_FIELD );

        if ( nextField != null )
        {
            resultClass = nextField.getSymbolClass();
            nextRef.putAttribute ( NODE_CLASS, resultClass );
        }
        else
        {
            throw new IllegalArgumentException
                (
                    "Unable to find a field named " +
                    fieldName.image +
                    " in class " +
                    resultClass.getName()
                );
        }

        //  Continue forming the chain of references.
        result.setLeftChild ( nextRef );
        result = nextRef;
    }

    return result;
   }


   /**
    *  Translate internal data structures into a JVM constructor signature.
    */
   public static String analyzeConstructor ( AbstractClass clazz, Vector ptypes )
   {
    StringBuffer result = new StringBuffer("(");

    for ( int j = 0; ptypes != null && j < ptypes.size(); j++ )
    {
        result.append ( ( ((AbstractClass)ptypes.elementAt(j)).getSignature() ) );
    }

    result.append ( ")V" );

    return result.toString();
   }

   /**
    *  Translate TL/2 compiler-centric method information into a BCEL MethodGen object.
    *  @param methodSymbol - a TL/2 compiler Symbol with the method's name and modifiers (public, static, final, etc.).
    *  @param methodParams - a Vector of Symbol objects that represent the method's parameters.
    *  @param il - the method body.
    *  @param cp - the class' constant pool.
    *  @return the MethodGen constructed.
    */
   public static MethodGen createMethod
    (
        Symbol methodSymbol, Vector methodParams, InstructionList il, ConstantPoolGen cp
    )
   {
    Type returnType = methodSymbol.getType();

    Type[] pTypes = null;

    if ( methodParams != null && methodParams.size() > 0 )
    {
        pTypes = new Type[methodParams.size()];

        for ( int i = 0; i < methodParams.size(); i++ )
        {
            Symbol s = (Symbol)methodParams.elementAt(i);

            pTypes[i] = s.getType();
        }
    }

    return  new MethodGen ( methodSymbol.getAccesslevel(), returnType, pTypes, null, methodSymbol.getName(), null, il, cp );
   }


   /**
    *  Deconstruct a TL2INode into a class name and parameters.
    */
   void buildNew(TL2INode p)
   {
    MultipartIdentifier id = (MultipartIdentifier) p.getAttribute ( QUALIFIED_SYMBOL );

    p.putAttribute ( NODE_CLASS, AbstractClass.getAbstractClass ( id.toString()));
   }

   /**
    *  @return the ClassAnalyzer specific to this thread of execution;
    *    compilation proceeds on a thread-per-compilation-unit basis,
    *    so this is a static way for any compiler code to get the
    *    ClassAnalyzer for its current compilation unit, assuming
    *    it's running in the same thread.
    */
   public static ClassAnalyzer getClassAnalyzer()
   {
    return (ClassAnalyzer)contextMap.get();
   }

   /**
    *  @return the instruction sequence or constant value
    *    that can initialize a field or local variable.
    */
   private InstructionList getInitializer ( Symbol s, TL2INode n )
   {
    TL2INode root = new TL2INode ( INITIALIZE_NON_FINAL );
    root.setLeftChild ( new TL2INode ( REFERENCE_THIS ) );
    root.leftChild().putAttribute ( IDENTIFIER_SYMBOL, s );
    root.setRightChild(n);

    try
    {
        this.emitter.burm (root);
    }
    catch ( Exception ex )
    {
        ex.printStackTrace();
        throw new IllegalArgumentException ( "Unable to initialize " + s.toString() + ": " + ex.getMessage() );
    }

    return (InstructionList)root.getAttribute ( AD_HOC_COMPILATION_RESULT );
   }

   /**
    *  @return true if the given class is the class under compilation.
    */
   public boolean isThisClass ( AbstractClass c )
   {
    return classUnderCompilation.equals(c);
   }

   /**
    *  @return the interfaces this class implements.
    */
   private String[] getInterfaces()
   {
    return null;
   }

   /**
    *  @return an Iterator over the class' METHOD_DEFINITION nodes.
    */
   public Iterator getMethods()
   {
    return this.methods.iterator();
   }
}
