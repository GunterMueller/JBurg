package jburg.burg.emitlangs;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

import java.util.Enumeration;
import java.util.Vector;

import java.util.jar.JarFile;

import jburg.burg.JBurgGenerator;

/**
 *  The JBurgEmitterFactory searches for an emitter that can
 *  emit the specified language using i-nodes of the given class.
 *  @author Nick Brereton -- original implementation.
 *  @author Tom Harwood -- maintenance, split out of JBurgGenerator into a factory.
 *  
 */
public class JBurgEmitterFactory
{
	/**
	 * Find a suitable EmitLang interface class to deal with the language we want to emit
	 * @param location location of the code base
	 * @param iface interface class that must be derived from
	 * @return vector of classes
	 */
	public static EmitLang getEmitter( JBurgGenerator generator, String langname, String iNodeClass)
	{
		Vector candidates = null;

		//  Starting point for the search is the EmitLang class' location.
		URL location = EmitLang.class.getProtectionDomain().getCodeSource().getLocation();

		try {
		
			if(location.toString().endsWith(".jar")) {
				candidates = searchJar(new URI(location.toString()), EmitLang.class);
			} else {

				//  A filesystem-based build, search the directory.
				URI iLoc = new URI(
					location.toString() +
					EmitLang.class.getPackage().getName().replace('.','/') + '/'
				);
				candidates = searchPath(iLoc, EmitLang.class);
			}
		} catch(URISyntaxException e) { System.out.println(e); return null; }

		if(candidates==null) return null;
		
		for(Enumeration enum=candidates.elements(); enum.hasMoreElements();) {
			try {
				Class cl = (Class)enum.nextElement();

				//  Skip emitters that cannot be instantiated; these include
				//  abstract superclasses and the BURG's own emitter for 
				//  its pattern-matching rules, which needs special setup
				//  and would malfunction if it were ever selected this way.
				if ( isEmitterSuperclass(cl) )
				{
					continue;
				}
				
				try
				{
					EmitLang el = (EmitLang)ClassLoader.getSystemClassLoader().loadClass(cl.getName()).newInstance();

					if(el.accept(langname, iNodeClass )) {
						System.out.println("Using Language Adaptor : "+el.getClass().getName());

						//  Set the emitter's parent generator (this) and its output filename.
						//  Note that output filename is not presently used.
						el.setRtInfo(generator, null );

						return el;
					}
				} catch(InstantiationException e) {
					System.err.println("Unable to instantiate possible language class!");
					System.err.println(e);
				} catch(IllegalAccessException e) {
					System.err.println("IllegalAccessException: see info:");
					System.err.println(e);
				}
			}  catch(ClassNotFoundException e) {
				System.err.println("Class does not appear to exist in CLASSPATH");
				System.err.println(e);
			}
		}
		
		return null;
	}
	
	/**
	 *  Search a URI for candidate classes that implement an interface.
	 *  @param location -- the URI to search, usually a directory.
	 *  @param iface -- the interface class that successful candidates implement.
	 */
	private static Vector searchPath(URI location, Class iface) {
		File floc;
		Vector retv = new Vector();
		
		floc = new File( location );
		
		if(!floc.isDirectory())
			return retv;
		
		String[] fls = floc.list();
		for(int i=0; i<fls.length; ++i) {
			if(fls[i].endsWith(".class") && fls[i].indexOf('$') < 0) {
				try {
					Class cl = Class.forName(iface.getPackage().getName()+"."
											 +fls[i].substring(0, fls[i].length()-6));
					Class[] ifs = cl.getInterfaces();
					boolean bIfOk = false;
					for(int j=0; j<ifs.length; ++j)
						if(ifs[j].equals(iface))
							bIfOk = true;
					if(bIfOk && !cl.isInterface())
						retv.add(cl);
				} catch(ClassNotFoundException e) {};
			}
		}
		return retv;
	}
	
	/**
	 *  Search a jarfile for candidate classes that implement an interface.
	 *  @param location -- the jarfile to search.
	 *  @param iface -- the interface class that successful candidates implement.
	 */
	private static Vector searchJar(URI location, Class iface)
	{
		File floc;
		JarFile jf;
		Vector retv = new Vector();
		
		try {
			jf = new JarFile( new File( location ) );
		} catch(IOException e) { System.out.println(e); return retv; }
		
		String pkg = iface.getPackage().getName().replace('.','/');
		
		for(Enumeration enum=jf.entries(); enum.hasMoreElements(); ) {
			// check each name for being a ".class", no "$" & starting with the iface's package name
			String cname = enum.nextElement().toString();
			if(cname.startsWith(pkg) && cname.endsWith(".class") && cname.indexOf('$')<0) {
				try {
					Class cl = Class.forName(cname.substring(0,cname.length()-6).replace('/','.'));
					Class[] ifs = cl.getInterfaces();
					boolean bIfOk = false;
					for(int j=0; j<ifs.length; ++j)
						if(ifs[j].equals(iface))
							bIfOk = true;
					if(bIfOk && !cl.isInterface())
						retv.add(cl);
				} catch(ClassNotFoundException e) {
					System.err.println("Couldn't resolve class : "+cname.substring(0,cname.length()-6).replace('/','.'));
					System.err.println(e);
				}
			}
		}
		return retv;		
	}

	private static boolean isEmitterSuperclass(Class cl)
	{
		return 
			cl.getName().equals("jburg.burg.emitlangs.DelegatingEmitter")
			||
			cl.getName().equals("jburg.burg.emitlangs.EmitINodeASTTargetJava")
			;
	}
}
