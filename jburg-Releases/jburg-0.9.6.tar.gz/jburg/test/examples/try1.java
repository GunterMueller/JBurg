public class try1
{
	public static void main ( String[] argv )
	{
		try
		{
			Class.forName("zuul");
		}
		catch ( Exception ex )
		{
			System.out.println ( "Caught Exception" );
		}
		catch ( Throwable t )
		{
			System.out.println ( "Caught Throwable" );
		}
	}
}
