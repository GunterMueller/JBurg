/**
 *  A simple type of I-node that carries integer values.
 */
public class IntegerINode
	implements IntegerINodeTypes
{
	Integer m_int_value;

	int m_opcode;

	IntegerINode m_left, m_right;

	public IntegerINode(int opcode, IntegerINode left, IntegerINode right )
	{
		m_opcode    = opcode;
		m_int_value = null;

		m_left  = left;
		m_right = right;
	}

	public IntegerINode(int iValue)
	{
		m_opcode    = INTEGER_LITERAL;
		m_int_value = new Integer(iValue);
	}

	public Integer integerLiteral()
	{
		if ( null == m_int_value )
		{
			throw new IllegalStateException("not integer literal");
		}

		return m_int_value;
	}

	public IntegerINode leftChild() { return m_left; }
	public IntegerINode rightChild() { return m_right; }

	public int getOperator() { return m_opcode; }

	public String toString()
	{
		StringBuffer result = new StringBuffer();

		result.append("op=");
		result.append(Integer.toString(getOperator()));
		if ( m_int_value != null )
		{
			result.append (", value=");
			result.append ( m_int_value.toString());
		}

		if ( m_left != null )
		{
			result.append("(");
			result.append(m_left.toString());
			result.append(")");

			if ( m_right != null )
			{
				result.append("(");
				result.append(m_right.toString());
				result.append(")");
			}
		}

		return result.toString();
	}
}
