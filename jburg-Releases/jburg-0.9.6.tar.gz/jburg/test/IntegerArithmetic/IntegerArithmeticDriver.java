public class IntegerArithmeticDriver
	implements IntegerINodeTypes
{
	public static void main(String[] argv)
		throws Exception
	{
		Integer iResult;
		IntegerArithmeticMatcher matcher = new IntegerArithmeticMatcher();

		IntegerINode one = new IntegerINode(1);
		IntegerINode two = new IntegerINode(2);

		IntegerINode add = new IntegerINode(ADD, one, two);
		matcher.burm(add);
		iResult = (Integer)matcher.getResult();

		if ( iResult.intValue() == 3 )
		{
			System.out.println("Simple ADD tree succeeded.");
		}
		else
		{
			System.err.println(
				"Simple ADD tree FAILED: BURM result is " + 
				iResult.toString()
			);
		}

		IntegerINode indir = new IntegerINode(INDIR, one, null);
		IntegerINode indir_add = new IntegerINode(ADD, indir, two);
		matcher.burm(indir_add);
		iResult = (Integer)matcher.getResult();

		if ( iResult.intValue() == 3 )
		{
			System.out.println("ADD(INDIR) tree succeeded.");
		}
		else
		{
			System.err.println(
				"ADD(INDIR) tree FAILED: BURM result is " + 
				iResult.toString()
			);
		}
	}
}
