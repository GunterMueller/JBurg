/*  Generated Sat Oct 18 10:23:05 EDT 2014 by JBurg version 2.0  */

#include <iostream>
#include <string>
#include <stack>
#include <exception>
#include <memory>
#include <sstream>
#include <limits>
#include <stdexcept>
#include <vector>
#include <algorithm>

#define MAX_INT_VALUE std::numeric_limits<int>::max()

static int _jburg_getOperator(TestINode* );
static TestINode* _jburg_getNthChild(TestINode* , int );
static int _jburg_getChildCount (TestINode* );
namespace jburg {
	int getOperator( TestINode* m_node )
	{
        return m_node->getOperator();
	}

    int normalizedAdd(int c1, int c2)
    {
        int result = MAX_INT_VALUE;

        if ( c1 < MAX_INT_VALUE && c2 < MAX_INT_VALUE )
            {
                long long accum = (long long)c1 + (long long)c2;
                result = accum < MAX_INT_VALUE?
                    (int)accum:
                    MAX_INT_VALUE;
            }

            return result;
    }

    struct ReducerIntermediateResult
    {
        union {
            long        longResult;
            intptr_t    intptrResult;
        } scalars;
        std::vector<ReducerIntermediateResult> variadicResult;
    };
}


class JBurgAnnotation_INT_0;
JBurgAnnotation_INT_0* getJBurgAnnotation_INT_0_instance();

template<typename T> class JBurgAnnotation
{
public:
    JBurgAnnotation( T node ):
        m_node(node)
    {
    }

    virtual ~JBurgAnnotation()
    {
    }

	virtual int getOperator() { return m_node->getOperator();}
	virtual std::string 	toString() = 0;
	virtual int				getCost(int goalState) = 0;
	virtual int				getRule(int goalState) = 0;
	
	virtual const bool hasAntecedent( int goalState ) = 0;

	virtual const int getAntecedent( int goalState ) = 0;

	/**
	 *  @return the number of children of this node.
	 */
	virtual int getArity() = 0;

	/**
	 *  @return the child at the specified index.
	 *  @throw std::runtime_error if the child index is out of bounds.
	 */
	virtual JBurgAnnotation<T>* getNthChild(int idx) = 0;

	/**
	 *  Add a new child node.
	 *  @post this node assumes ownership of the child node.
	 */
	virtual void addChild(JBurgAnnotation<T>* new_child) = 0;

protected:
    int getNaryCost( JBurgAnnotation<T>* node, int goalState, int startIndex)
    {
        int accum = 0;
	
        for ( int i = startIndex; i < node->getArity(); i++ )
            accum = jburg::normalizedAdd(accum, node->getNthChild(i)->getCost(goalState));

        return (accum);
    }

private:
        T   m_node;
public:
	class JBurgSubgoal
	{
	public:
		JBurgSubgoal(const int subgoal_state, const bool is_nary, const int start_index, const std::vector<int> access_path):
            subgoalState(subgoal_state)
            , m_isNary(is_nary)
            , startIndex(start_index)
            , accessPath(access_path)
		{
		}

	public:

		/// @return the state to which the node must be reduced.
		const int getGoalState() const { return this->subgoalState; }
        ///  @return true if the node is n-ary.
        const bool isNary() const { return this->m_isNary; }
        ///  @return the node's start index.
        const int getStartIndex() const { return this->startIndex; }

        ///  @return the root node's child specified by the access path.
        TestINode* getNode(TestINode* ancestor) const
        {
            TestINode* result = ancestor;
            for ( int idx = 0; idx < accessPath.size(); idx++ )
				result = result->getNthChild(accessPath[idx]);
            return result;
        }

	private:
		int subgoalState;
        bool m_isNary;
        int startIndex;
        std::vector<int> accessPath;

	};
};

    JBurgAnnotation<TestINode*>* getAnnotation(TestINode* p)
    {
        return (JBurgAnnotation<TestINode*>*) p->getAnnotation();
    }
    void setAnnotation(TestINode* p, JBurgAnnotation<TestINode*>* anno)
    {
        p->setAnnotation((intptr_t)anno);
    }

class JBurgSpecializedAnnotation: public JBurgAnnotation<TestINode*>
{
    public:
    JBurgSpecializedAnnotation(TestINode* node)
        :JBurgAnnotation<TestINode*>(node)
        {
        }
    virtual int				getCost(int goalState) { return MAX_INT_VALUE; }
    virtual int				getRule(int goalState) { return -1; }
    virtual const bool hasAntecedent( int goalState )   { return false; }
    virtual const int getAntecedent( int goalState )    { throw std::logic_error("placeholder"); }
    virtual int getArity() { return 0; }
    virtual JBurgAnnotation<TestINode*>* getNthChild(int idx) { throw std::logic_error("placeholder"); }
    virtual void addChild(JBurgAnnotation<TestINode*>* new_child) { }
    virtual std::string toString() { throw std::logic_error("placeholder"); }
};

class PlaceholderAnnotation: public JBurgSpecializedAnnotation
{
    public:
    PlaceholderAnnotation(TestINode* node, int arity)
        :JBurgSpecializedAnnotation(node)
        {
        }
    virtual std::string toString() { return "PlaceholderAnnotation"; }
};

class AccessorTest: public ArithmeticTokenHolder
{
private:

	std::stack<jburg::ReducerIntermediateResult> __reducedValues;

	int	*antecedentRules;

public:

	AccessorTest() {
		antecedentRules = new int[nStates];
	}

	~AccessorTest() {
        delete[] antecedentRules;
	}

public: static const int __expression_NT = 1;
public: static const int nStates = 1;

    public:
    JBurgAnnotation<TestINode*>* label(TestINode* to_be_labelled) {
         JBurgAnnotation<TestINode*>* result  = NULL;
         int i  = 0;
         int arity  = to_be_labelled->getArity();
        result = this->getJBurgAnnotation(to_be_labelled);
        while((arity > i)) {
            result->addChild(this->label(((TestINode*)to_be_labelled->getNthChild(i))));
            i = i + 1;
        }
        to_be_labelled->setAnnotation(((intptr_t)result));
        return (result);
    }

/* expression */

    private:
    long action_1(TestINode* __p) {

        long r(__reducedValues.top().scalars.longResult);
        __reducedValues.pop();
        long l(__reducedValues.top().scalars.longResult);
        __reducedValues.pop();
        		{
        		    return l + r;
        		}
    }

/* expression */

    private:
    long action_2(TestINode* __p) {

        		{
        		    return atoi(__p->getText().c_str());
        		}
    }

    private:
    void dispatchAction(TestINode* __p,int iRule) {
        jburg::ReducerIntermediateResult result;
        switch(iRule) {
            case 1: {
                    result.scalars.longResult = (this->action_1(__p));
                    __reducedValues.push(result);
                }
                break;
            case 2: {
                    result.scalars.longResult = (this->action_2(__p));
                    __reducedValues.push(result);
                }
                break;
            default: {
                throw std::logic_error("Unmatched reduce action " + iRule);
            }
        }
    }


class JBurgAnnotation_ADD_2  :public JBurgSpecializedAnnotation 
{
    private:
     JBurgAnnotation<TestINode*>* subtree0 ;private:
     JBurgAnnotation<TestINode*>* subtree1 ;private:
     int cachedCostFor_expression ;
    public:
     JBurgAnnotation_ADD_2(TestINode* node)
            :JBurgSpecializedAnnotation(node)
                ,cachedCostFor_expression(-1),subtree0(NULL),subtree1(NULL)

    {
    }
        private:
        int getPatternMatchCost(int goalState) {
             int result  = MAX_INT_VALUE;
            switch(goalState) {
                case __expression_NT: {
                        result = getCostForRule_7df17e77(goalState);
                    }
                    break;
            }
            return (result);
        }
        public:
        int getCost(int goalState) {
             int result  = MAX_INT_VALUE;
            switch(goalState) {
                case __expression_NT: {
                        if ((cachedCostFor_expression == -1)) {
                            cachedCostFor_expression = getPatternMatchCost(__expression_NT);
                        } 
                        result = cachedCostFor_expression;
                    }
                    break;
            }
            return (result);
        }
        public:
        int getRule(int goalState) {
             int rule  = -1;
            switch(goalState) {
                case __expression_NT: {
                        if ((MAX_INT_VALUE > getCostForRule_7df17e77(goalState))) {
                            rule = 1;
                        } 
                    }
                    break;
            }
            return (rule);
        }
        public:
        int getArity() {
            return (2);
        }
        public:
        JBurgAnnotation<TestINode*>* getNthChild(int index) {
             JBurgAnnotation<TestINode*>* result  = NULL;
            switch(index) {
                case 0: {
                        result = subtree0;
                    }
                    break;
                case 1: {
                        result = subtree1;
                    }
                    break;
                default: {
                    throw std::logic_error("Invalid index " + index);
                }
            }
            return (result);
        }
        public:
        void addChild(JBurgAnnotation<TestINode*>* child) {
            if ( (!(subtree0)) ) {
                subtree0 = child;
            } else if (  (!(subtree1))  ) {
                subtree1 = child;
            } else  {
                throw std::logic_error("too many children");
            } 
        }
        private:
        int getCostForRule_7df17e77(int goalState) {
            return (jburg::normalizedAdd(1, jburg::normalizedAdd(this->getNthChild(1)->getCost(__expression_NT), this->getNthChild(0)->getCost(__expression_NT))));
        }
};



class JBurgAnnotation_INT_0  :public JBurgSpecializedAnnotation 
{

    public:
     JBurgAnnotation_INT_0(TestINode* node)
            :JBurgSpecializedAnnotation(node)

    {
    }
        private:
        int getPatternMatchCost(int goalState) {
             int result  = MAX_INT_VALUE;
            switch(goalState) {
                case __expression_NT: {
                        result = 1;
                    }
                    break;
            }
            return (result);
        }
        public:
        int getCost(int goalState) {
             int result  = MAX_INT_VALUE;
            switch(goalState) {
                case __expression_NT: {
                        result = 1;
                    }
                    break;
            }
            return (result);
        }
        public:
        int getRule(int goalState) {
             int rule  = -1;
            switch(goalState) {
                case __expression_NT: {
                        rule = 2;
                    }
                    break;
            }
            return (rule);
        }
        public:
        int getArity() {
            return (0);
        }
};


    public:
    JBurgAnnotation<TestINode*>* getJBurgAnnotation(TestINode* node) {
        switch(node->getOperator()) {
            case ADD: {
                    if ((node->getArity() == 2)) {
                        return (new  JBurgAnnotation_ADD_2(node));
                    } 
                }
                break;
            case INT: {
                    if ((node->getArity() == 0)) {
                        return (getJBurgAnnotation_INT_0_instance());
                    } 
                }
                break;
        }
        return (new  PlaceholderAnnotation(node,node->getArity()));
    }
    public: static std::vector<std::vector<JBurgAnnotation<TestINode*>::JBurgSubgoal> > subgoals_by_rule343112216;

    /* Static initializer code for the subgoals lookup table. */
    public: class SubgoalsByRuleInitializerHack {

        public: SubgoalsByRuleInitializerHack() {

            AccessorTest::subgoals_by_rule343112216.resize(3);

            std::vector<int> rule_1_pattern_1;
            rule_1_pattern_1.push_back(0);
            AccessorTest::subgoals_by_rule343112216[1].push_back(JBurgAnnotation<TestINode*>::JBurgSubgoal(__expression_NT,false,0,rule_1_pattern_1));

            std::vector<int> rule_1_pattern_0;
            rule_1_pattern_0.push_back(1);
            AccessorTest::subgoals_by_rule343112216[1].push_back(JBurgAnnotation<TestINode*>::JBurgSubgoal(__expression_NT,false,1,rule_1_pattern_0));
        }

        static SubgoalsByRuleInitializerHack init_hack343112216;
    };


    void reduce (TestINode* node , int goalState )
	{
		int iRule = -1;

        JBurgAnnotation<TestINode*>* p = (JBurgAnnotation<TestINode*>*) getAnnotation(node);
		if ( goalState > 0 ) {
			iRule = p->getRule(goalState);
		} else {
			//  Find the minimum-cost path.
			int minCost = MAX_INT_VALUE;
			for (int i = 0; i <= nStates ; ++i ) {
				if ( p->getCost(i) < minCost ) {
					iRule = p->getRule(i);
					minCost = p->getCost(i);
					goalState = i;
				}
			}
		}

		if ( iRule > 0 ) {
			
			reduceAntecedent(node, goalState);
			reduceSubgoals(node, iRule);
			dispatchAction (node, iRule );
		} else {
			std::stringstream s;
			s << "Unable to find a rule to process ";
			s << node;
			s << " (" << p->getOperator() << ") {" << goalState << "}";
			throw new  std::runtime_error(s.str());
		}
	}

	void reduceAntecedent(TestINode* node , int goalState)
	{
		int   currentState = goalState;
		std::vector<int> antecedent_states;
		std::vector<int> antecedent_rules;

        JBurgAnnotation<TestINode*>* p = (JBurgAnnotation<TestINode*>*) getAnnotation(node);
		//  If X is antecedent of Y, then the reduce action
		//  for X must occur before the reduce action of Y.
		//  The antecdents must therefore be processed 
		//  from "back" to "front."
		while ( p->hasAntecedent(currentState)  )
		{
			currentState = p->getAntecedent(currentState);
			antecedent_states.push_back(currentState);
			antecedent_rules.push_back(p->getRule(currentState));
		}
		while ( ! antecedent_states.empty() )
		{
			reduceSubgoals(node, antecedent_rules.back());
			dispatchAction(node, antecedent_rules.back());
			antecedent_states.pop_back();
			antecedent_rules.pop_back();
		}
	}

    void reduceSubgoals( TestINode* node , int rule_num)
    {
        JBurgAnnotation<TestINode*>* p = (JBurgAnnotation<TestINode*>*) getAnnotation(node);

        for ( int i = 0; i < subgoals_by_rule343112216[rule_num].size(); i++)
        {
            JBurgAnnotation<TestINode*>::JBurgSubgoal sg = subgoals_by_rule343112216[rule_num][i];

            if (!sg.isNary()) {
                reduce ( sg.getNode(node), sg.getGoalState());
            } else {

                // Aggregate the operands of an n-ary operator into a single container.
                TestINode* sub_parent = sg.getNode(node);
                int arity = sub_parent->getArity();
                jburg::ReducerIntermediateResult result;
                for ( int j = sg.getStartIndex(); j < arity; j++ )
                {
                    reduce(node->getNthChild(i), sg.getGoalState());
                    result.variadicResult.push_back(__reducedValues.top());
                    __reducedValues.pop();
                }
                __reducedValues.push(result);
            }
        }
    }

public:

	void burm ( TestINode* root )
	{		burm(root,0);	}

	void burm ( TestINode* root, int goal_state )
	{
		JBurgAnnotation<TestINode* >* annotatedTree = label(root);
		reduce (root, goal_state);
		delete annotatedTree;
	}

	intptr_t getResult()
    {
		return __reducedValues.top().scalars.intptrResult;
	}

    void* popValueStack(std::stack<void*>& stack)
    {
        void* result = stack.top();
        stack.pop();
        return result;
    }



private:

    JBurgAnnotation_INT_0* getJBurgAnnotation_INT_0_instance()
    {
        static JBurgAnnotation_INT_0 instance(NULL);
        return &instance;
    }    };
std::vector<std::vector<JBurgAnnotation<TestINode*>::JBurgSubgoal> > AccessorTest::subgoals_by_rule343112216;
AccessorTest::SubgoalsByRuleInitializerHack AccessorTest::SubgoalsByRuleInitializerHack::init_hack343112216;

static int _jburg_getOperator(TestINode* )
{
}

static TestINode* _jburg_getNthChild(TestINode* , int )
{
}

static int _jburg_getChildCount (TestINode* )
{
}

