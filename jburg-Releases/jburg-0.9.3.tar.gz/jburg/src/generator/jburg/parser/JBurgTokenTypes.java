// $ANTLR 2.7.2: "jburg.g" -> "JBurgANTLRLexer.java"$

package jburg.parser;


public interface JBurgTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int COST_FUNCTION = 4;
	int FUNCTION_CALL = 5;
	int HEADER_DECLARATION = 6;
	int IMPLEMENTS_INTERFACE_SPECIFICATION = 7;
	int INCLASS_DECLARATION = 8;
	int INODE_DECLARATION = 9;
	int LANGUAGE_DECLARATION = 10;
	int PACKAGE_SPECIFICATION = 11;
	int PATTERN_RULE = 12;
	int PROPERTY_SPECIFICATION = 13;
	int RETURN_DECLARATION = 14;
	int SIMPLE_COST_SPEC = 15;
	int SIMPLE_TRANSFORMATION_RULE = 16;
	int TRANSFORMATION_RULE = 17;
	int TERMINAL_RULE = 18;
	int TYPED_RETURN_DECLARATION = 19;
	int IDENTIFIER = 20;
	int LPAREN = 21;
	int RPAREN = 22;
	int BLOCK = 23;
	int COLON = 24;
	int LITERAL_header = 25;
	int LITERAL_INodeType = 26;
	int SEMI = 27;
	int LITERAL_Language = 28;
	int LITERAL_implements = 29;
	int PERIOD = 30;
	int COMMA = 31;
	int LITERAL_package = 32;
	int LITERAL_BURMProperty = 33;
	int LITERAL_ReturnType = 34;
	int EQUALS = 35;
	int INT = 36;
	int LITERAL_void = 37;
	int STRING_LITERAL = 38;
	int WS = 39;
	int COMMENT = 40;
	int ML_COMMENT = 41;
	int DIGIT = 42;
}
