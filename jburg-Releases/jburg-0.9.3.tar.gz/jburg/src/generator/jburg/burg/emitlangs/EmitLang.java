package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Vector;

import jburg.burg.JBurgGenerator;

/*
 * Interface for code emmision
 */

public interface EmitLang {
	/**
	 * Emit the file/class header information.
	 * @param strClassName  the name of the class to be generated.
	 * @param packageName  the name of the package or namespace, or null if no package/namespace is to be generated.
	 * @param headerBlock  Code to be copied as-is into the header section of a Java file.
	 * @param InterfaceNames  names of interfaces a Java class implements.
	 * @param debugMode  true ==&lt; generate code that emits debugging information about the label and reduction passes.
	 * @param output
	 */
	abstract public void emitHeader(String strClassName, String packageName, String headerBlock, Vector InterfaceNames, boolean debugMode, PrintStream output);
	
	/**
	 * Emit verbatim code blocks that are intended to be part of the class definition.
	 * @param strClassName  the name of the class to be generated.
	 * @param inclassBlocks  A Vector of strings to be copied in verbatim.
	 * @param output  the stream that's writing the generated code.
	 */
	abstract public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output);

	/**
	 * Emit symbolic constants for the goal/subgoal non-terminal states.
	 * @param subgoals  The states that this BURM uses as non-terminal states are the keys of this table.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitNTConstants(Hashtable subgoals, PrintStream output);

	/**
	 * Emit the labelling function.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitLabelFunction(String iNodeClass, PrintStream output);

	/**
	 * Emit the cost functions.
	 * @param cost_functions  a Vector of function definitions.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitCostFns(Vector cost_functions, String iNodeClass, PrintStream output);

	/**
	 * Emit the inner class JBurg uses to annotate the tree.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitAnnotation(String iNodeClass, PrintStream output);
	
	/**
	 * Emit the action routines
	 * @param reduceActions  a Vector of code fragments that contain the logic for each reduction.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitActions(Vector reduceActions, String iNodeClass, PrintStream output);

	/**
	 * Emit the reducer and finish the class definition.
	 * @param strClassName  the name of the class being generated.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param subgoals  the states that this BURM may transition through.
	 * @param burm_properties  any properties (private fields and public get/set methods)
	 * @param debugMode  true ==&lt; generate debugging code that writes information about the generated class.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitTrailer(String strClassName, String iNodeClass, Hashtable subgoals, Hashtable burm_properties, boolean debugMode, PrintStream output);

	/**
	 * Emit the transitive closure computations.
	 * @param closureSets  a map of non-terminal states to other non-terminal states that can be satisfied when the key state is satisfied.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitClosures(Hashtable closureSets, String iNodeClass, PrintStream output);

	/**
	 * Emit the cost matrix computation.
	 * @param patternRules  a map of non-terminal states to tree patterns that can produce the key state.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param output   the stream that's writing the generated code.
	 * @throws Exception
	 */
	abstract public void emitComputeCostMatrixFunction(Hashtable patternRules, String iNodeClass, PrintStream output) throws Exception;

	/**
	 * Analyze a pattern rule, and emit logic to recognize it.
	 * @param p pattern rule to analyse
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param output   the stream that's writing the generated code.
	 * @throws Exception
	 */
	abstract public void emitPatternRule(JBurgGenerator.JBurgINode p, String iNodeClass, PrintStream output) throws Exception;
	
	/**
	 * emit a comment that might cover multiple lines
	 * @param Comment comment text, use '\n' for comments that cover multiple lines
	 * @param ndepth number of tabs to insert before each line of the commment
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitMLComment (String Comment, int ndepth, PrintStream output);
	
	/**
	 * @return a string that represents the code in the taget language that will 
	 * get the top value of a stack & decrement the size of the stack 
	 * @param stackName variable name of the stack
	 * @param paramType type of the parameter to be retrieved
	 * @param paramName name of the parameter into which the stack is poped
	 * @param tabs string containing the sequence of white space to insert at the start of every line
	 * @return String containing the formated lines
	 */
	abstract public String genPopFromStack(String stackName, String paramType, String paramName, String tabs);
	
	/**
	 * @return a String that gives the code to check if a reference is null
	 * @param paramName parameter to be checked
	 * @param checkForNull if true, check for a null pointer, if false check is true if not null
	 * @return String object containing relevent code fragment
	 */
	abstract public String genCheckPtr(String paramName, boolean checkForNull);
	
	/**
	 * Generate code for direct access to an object's member
	 * @param parentName name of the parent object
	 * @param memberName name of the parameter to access
	 * @return String object containing the code fragment to use
	 */
	abstract public String genAccessMember(String parentName, String memberName);
	
	/**
	 * Call a method contained within an object
	 * @param parentName name of the parent object
	 * @param methodName name of the method to call
	 * @param params list of the paramters for the call
	 * @return String containing the relevent code fragment
	 */
	abstract public String genCallMethod(String parentName, String methodName, String[] params);
	
	/**
	 * Generate a clip that compares two expressions. 
	 * @param lhs Expression to be placed on the left-hand side of the compare
	 * @param rhs Expression to be placed on the right-hand side of the compare
	 * @param bEquality set to true to compare for equality, false for non-equality
	 * @return String
	 */
	abstract public String genCmpEquality(String lhs, String rhs, boolean bEquality);
	
	/**
	 * Generate a clip that combines 2 expressions with a logical and
	 * @param lhs Expression to be placed on the left-hand side of the and
	 * @param rhs Expression to be placed on the right-hand side of the and
	 * @return String
	 */
	abstract public String genLogicalAnd(String lhs, String rhs);
}
