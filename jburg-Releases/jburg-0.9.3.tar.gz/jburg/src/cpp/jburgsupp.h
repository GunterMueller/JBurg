/**
  * Header file to support JBurg whilst emitting C++
  */
#include <string>
#include <stdexcept>

// strange as it looks, this does work (at least on my platform, VS.NET 2003)
// and I think it should work on any platform
#define MAX_INT_VALUE (-1^(1<<((sizeof(int)*8)-1)))
// and the inverse (might be useful!)
#define MIN_INT_VALUE (MAX_INT_VALUE+1)

template<class T>
class JBurgAnnotation
{
/* data members */
protected:
	int					*cost;
	int					*rule;
	int					nRules;
	int					*antecedentState;

	// surely this should be private ? esp. if we're using methods to access it!
	T*					m_node;

public:
	int					*leftSubgoals;
	int					*rightSubgoals;

	JBurgAnnotation<T>	*left;
	JBurgAnnotation<T>	*right;

/* c'tors & d'tor */
public:
	JBurgAnnotation(T* newNode, int nRules)
	{
		m_node = newNode;
		
		// initialise rules array
		rule = new int[nRules];
		memset(rule, 0, sizeof(int)*nRules);
		
		// init cost array
		cost = new int[nRules];
		for(int x=0; x<nRules; ++x) cost[x] = MAX_INT_VALUE;
		
		// initial rule for all sub-goals should be zero
		leftSubgoals = new int[nRules];
		memset(leftSubgoals, 0, sizeof(int)*nRules);
		rightSubgoals = new int[nRules];
		memset(rightSubgoals, 0, sizeof(int)*nRules);
		
		// initialise the left & right children
		left = 0;
		right = 0;
		antecedentState = 0;

		// keep a copy of the array sizes, we don't know them otherwise! (unlike java we can't do array.length)
		this->nRules = nRules;
	}

	~JBurgAnnotation()
	{
		// assume that m_node is a reference & is deleted elsewhere
		if(rule) delete[] rule;
		if(cost) delete[] cost;
		if(leftSubgoals) delete[] leftSubgoals;
		if(rightSubgoals) delete[] rightSubgoals;
		if(antecedentState) delete[] antecedentState;
		if(left) delete left;
		if(right) delete right;
	}


protected:
	// lock-out the default constructor
	JBurgAnnotation() {}


/* methods */
public:
	int				getOperator()					{ return m_node->getType(); }
	T*				getNode()						{ return m_node; }
	std::string&	toString()						{ return m_node->getText(); }
	int				getCost(int goalState)			{ return cost[goalState]; }
	int				getRule(int goalState)			{ return rule[goalState]; }
	bool			hasAntecedent(int goalState)	{ return (antecedentState && antecedentState[goalState] != 0); }
	
	void reset(int goalState, int cost, int rule) {
		this->cost[goalState] = cost;
		this->rule[goalState] = rule;
		if(antecedentState)
			antecedentState[goalState] = 0;
	}

	void setElided(int goalState) {
		rule[goalState] = 1;
		cost[goalState] = MAX_INT_VALUE - 1;
	}

	void recordAntecedent(int iGoalState, int newAntecedentState)
	{
		int antecedentRule = rule[newAntecedentState];
		// sanity-check; we shouldn't be asked to record an antecedent state that hasn't been labelled
		// TODO: find a relevent exception
		if( !antecedentRule )
			throw new std::runtime_error("Attempting to recoed an unlabelled antecedent state" );
		if(antecedentRule == 1) {
			// rule 1 is the simple transformation rule: it doesn't run, but if it has antecedednts then they must run
			if(antecedentState)
				antecedentState[iGoalState] = antecedentState[newAntecedentState];
		} else {
			if(!antecedentState) {
				antecedentState = new int[nRules];
				memset(antecedentState, 0, sizeof(int)*nRules);
			}
		}
		antecedentState[iGoalState] = newAntecedentState;
	}

	int getAntecedent(int goalState) {
		return antecedentState ? antecedentState[goalState] : 0;
	}

	inline void setLeftSubgoal(int goalState, int subGoal) {
		leftSubgoals[goalState] = subGoal;
	}

	inline void setRightSubgoal(int goalState, int subGoal) {
		rightSubgoals[goalState] = subGoal;
	}
};