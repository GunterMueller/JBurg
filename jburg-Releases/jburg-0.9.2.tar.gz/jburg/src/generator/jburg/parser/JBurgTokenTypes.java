// $ANTLR 2.7.2: "jburg.g" -> "JBurgANTLRLexer.java"$

package jburg.parser;


public interface JBurgTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int COST_FUNCTION = 4;
	int FUNCTION_CALL = 5;
	int HEADER_DECLARATION = 6;
	int IMPLEMENTS_INTERFACE_SPECIFICATION = 7;
	int INODE_DECLARATION = 8;
	int PACKAGE_SPECIFICATION = 9;
	int PATTERN_RULE = 10;
	int PROPERTY_SPECIFICATION = 11;
	int RETURN_DECLARATION = 12;
	int SIMPLE_COST_SPEC = 13;
	int SIMPLE_TRANSFORMATION_RULE = 14;
	int TRANSFORMATION_RULE = 15;
	int TERMINAL_RULE = 16;
	int TYPED_RETURN_DECLARATION = 17;
	int IDENTIFIER = 18;
	int LPAREN = 19;
	int RPAREN = 20;
	int BLOCK = 21;
	int COLON = 22;
	int LITERAL_header = 23;
	int LITERAL_INodeType = 24;
	int SEMI = 25;
	int LITERAL_implements = 26;
	int PERIOD = 27;
	int COMMA = 28;
	int LITERAL_package = 29;
	int LITERAL_BURMProperty = 30;
	int LITERAL_ReturnType = 31;
	int EQUALS = 32;
	int INT = 33;
	int LITERAL_void = 34;
	int STRING_LITERAL = 35;
	int WS = 36;
	int COMMENT = 37;
	int ML_COMMENT = 38;
	int DIGIT = 39;
}
