public class switch1
{
	public static void main ( String[] argv )
	{
		int i;
		i = 2;
		switch ( i )
		{
			case 1:
				System.out.println ( "GIGO" );
			case 2:
				System.out.println ( "i is " + i );
			case 3:
				System.out.println ( "fell into case 3." );
		}
	}
}
