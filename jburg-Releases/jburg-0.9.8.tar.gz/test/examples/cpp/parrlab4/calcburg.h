/*  Generated Thu Jul 10 17:20:59 EDT 2008 by JBurg version 0.9.8 */
#include <iostream>
#include <string>
#include <stack>
#include <exception>
#include <memory>
#include <sstream>
#include "jburgsupp.h"
#include <antlr/AST.hpp>


#include <iostream>
#include "CalcParserTokenTypes.hpp"

class calcburg: public CalcParserTokenTypes
{
private:

	std::stack<void*> reducedValues;

	int	*antecedentRules;

public:

	calcburg() {
		antecedentRules = new int[nStates];
	}

	~calcburg() {
		if( antecedentRules ) delete[] antecedentRules;
	}



public:
	int regnum;
public:
static const int identifier_NT = 1;
public:
static const int stmt_NT = 2;
public:
static const int constant_NT = 3;
public:
static const int reg_NT = 4;
public:
static const int addr_NT = 5;
public:
static const int nStates = 5;
public:
JBurgAnnotation<antlr::AST>* label( antlr::AST* to_be_labelled )
{
	JBurgAnnotation<antlr::AST>* result = NULL;
	int i;
	int arity;
	if ( to_be_labelled )
	{
		result = new JBurgAnnotation<antlr::AST>(to_be_labelled,nStates + 1);
		arity = getArityOf(to_be_labelled);
		i = 0;
		while ( ( arity > i ) )
		{
			
			result->addChild(label(((antlr::AST*)getNthChild(to_be_labelled, i))));
			i =  (i + 1) ;
			
		}
		this->computeCostMatrix(result);
		
	}
	return (result);
	
}
private:
void computeCostMatrix( JBurgAnnotation<antlr::AST>* node )
{
	int iCost;
	switch( node->getOperator() )
	{
		case MINUS:
		{
			
			if ( node->getArity()==2 && node->getOperator()==MINUS && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(reg_NT) )  && ( MAX_INT_VALUE > node->getNthChild(1)->getCost(reg_NT) )  )
			{
				
				iCost =  ( (1 + node->getNthChild(1)->getCost(reg_NT))  + node->getNthChild(0)->getCost(reg_NT)) ;
				if ( ( node->getCost(reg_NT) > iCost )  )
				{
					
					/* Matched MINUS ==> reg */

					node->reset(reg_NT, iCost, 6);
					node->addSubgoal(reg_NT, node->getNthChild(1), reg_NT);
					node->addSubgoal(reg_NT, node->getNthChild(0), reg_NT);
					
				}
				
			}
			break;
		}
		case INT:
		{
			
			if ( node->getArity()==0 && node->getOperator()==INT )
			{
				
				iCost = 0;
				if ( ( node->getCost(constant_NT) > iCost )  )
				{
					
					/* Matched INT ==> constant */

					node->reset(constant_NT, iCost, 11);
					closure_constant(node, iCost);
					
				}
				
			}
			break;
		}
		case PLUS:
		{
			
			if ( node->getArity()==2 && node->getOperator()==PLUS && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(reg_NT) )  && ( MAX_INT_VALUE > node->getNthChild(1)->getCost(reg_NT) )  )
			{
				
				iCost =  ( (1 + node->getNthChild(1)->getCost(reg_NT))  + node->getNthChild(0)->getCost(reg_NT)) ;
				if ( ( node->getCost(reg_NT) > iCost )  )
				{
					
					/* Matched PLUS ==> reg */

					node->reset(reg_NT, iCost, 4);
					node->addSubgoal(reg_NT, node->getNthChild(1), reg_NT);
					node->addSubgoal(reg_NT, node->getNthChild(0), reg_NT);
					
				}
				
			}
			
			if ( this->getNaryCost(node, reg_NT)!=MAX_INT_VALUE )
			{
				
				iCost =  (this->getNaryCost(node, reg_NT) + 2) ;
				if ( ( node->getCost(reg_NT) > iCost )  )
				{
					
					/* Matched PLUS ==> reg */

					node->reset(reg_NT, iCost, 5);
					node->setNarySubgoal(reg_NT, reg_NT);
					
				}
				
			}
			break;
		}
		case ZERO:
		{
			
			if ( node->getArity()==0 && node->getOperator()==ZERO )
			{
				
				iCost = 0;
				if ( ( node->getCost(reg_NT) > iCost )  )
				{
					
					/* Matched ZERO ==> reg */

					node->reset(reg_NT, iCost, 8);
					
				}
				
			}
			break;
		}
		case ADDR:
		{
			
			if ( node->getArity()==1 && node->getOperator()==ADDR && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(identifier_NT) )  )
			{
				
				iCost =  (1 + node->getNthChild(0)->getCost(identifier_NT)) ;
				if ( ( node->getCost(addr_NT) > iCost )  )
				{
					
					/* Matched ADDR ==> addr */

					node->reset(addr_NT, iCost, 13);
					node->addSubgoal(addr_NT, node->getNthChild(0), identifier_NT);
					
				}
				
			}
			break;
		}
		case ID:
		{
			
			if ( node->getArity()==0 && node->getOperator()==ID )
			{
				
				iCost = 0;
				if ( ( node->getCost(identifier_NT) > iCost )  )
				{
					
					/* Matched ID ==> identifier */

					node->reset(identifier_NT, iCost, 12);
					
				}
				
			}
			break;
		}
		case DECL:
		{
			
			if ( node->getArity()==1 && node->getOperator()==DECL && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(identifier_NT) )  )
			{
				
				iCost = node->getNthChild(0)->getCost(identifier_NT);
				if ( ( node->getCost(stmt_NT) > iCost )  )
				{
					
					/* Matched DECL ==> stmt */

					node->reset(stmt_NT, iCost, 3);
					node->addSubgoal(stmt_NT, node->getNthChild(0), identifier_NT);
					
				}
				
			}
			break;
		}
		case IND:
		{
			
			if ( node->getArity()==1 && node->getOperator()==IND && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(addr_NT) )  )
			{
				
				iCost =  (1 + node->getNthChild(0)->getCost(addr_NT)) ;
				if ( ( node->getCost(reg_NT) > iCost )  )
				{
					
					/* Matched IND ==> reg */

					node->reset(reg_NT, iCost, 9);
					node->addSubgoal(reg_NT, node->getNthChild(0), addr_NT);
					
				}
				
			}
			break;
		}
		case EQUALS:
		{
			
			if ( node->getArity()==2 && node->getOperator()==EQUALS && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(addr_NT) )  && ( MAX_INT_VALUE > node->getNthChild(1)->getCost(reg_NT) )  )
			{
				
				iCost =  ( (1 + node->getNthChild(1)->getCost(reg_NT))  + node->getNthChild(0)->getCost(addr_NT)) ;
				if ( ( node->getCost(stmt_NT) > iCost )  )
				{
					
					/* Matched EQUALS ==> stmt */

					node->reset(stmt_NT, iCost, 2);
					node->addSubgoal(stmt_NT, node->getNthChild(1), reg_NT);
					node->addSubgoal(stmt_NT, node->getNthChild(0), addr_NT);
					
				}
				
			}
			break;
		}
		case NARGLE:
		{
			
			if ( this->getNaryCost(node, constant_NT)!=MAX_INT_VALUE )
			{
				
				iCost =  (this->getNaryCost(node, constant_NT) + 4) ;
				if ( ( node->getCost(reg_NT) > iCost )  )
				{
					
					/* Matched NARGLE ==> reg */

					node->reset(reg_NT, iCost, 10);
					node->setNarySubgoal(reg_NT, constant_NT);
					
				}
				
			}
			break;
		}
		
	}
	
}
private:
void closure_constant( JBurgAnnotation<antlr::AST>* p, int c )
{
	int iCost;
	iCost =  (c + 1) ;
	;
	if ( ( p->getCost(reg_NT) > iCost )  )
	{
		p->reset(reg_NT, iCost, 7);
		p->recordAntecedent(reg_NT, constant_NT);
		
	}
	
}
private:
int action_2( antlr::AST* p )
{
	

	int r((int)reducedValues.top());
	reducedValues.pop();
	

	int a((int)reducedValues.top());
	reducedValues.pop();
	
		{
			std::cout << "\tsw\tr" << r << ", (r" << a << ")" << std::endl;
			return 0;
		}
}
private:
int action_3( antlr::AST* p )
{
	

	std::auto_ptr<std::string> id((std::string*)reducedValues.top());
	reducedValues.pop();
	
		{
			std::cout << "\t.comm\t" << *id << ", 4" << std::endl;
			return 0;
		}
}
private:
int action_4( antlr::AST* p )
{
	

	int r2((int)reducedValues.top());
	reducedValues.pop();
	

	int r1((int)reducedValues.top());
	reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tadd\tr" << r << ", r" << r1 << ", r" << r2 << std::endl;
			return r;
		}
}
private:
int action_5( antlr::AST* p )
{
	

	std::vector<void*>* addends((std::vector<void*>*)reducedValues.top());
	reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tn-ary add" << std::endl;
		
			return r;
		}
}
private:
int action_6( antlr::AST* p )
{
	

	int r2((int)reducedValues.top());
	reducedValues.pop();
	

	int r1((int)reducedValues.top());
	reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tsub\tr" << r << ", r" << r1 << ", r" << r2 << std::endl;
			return r;
		}
}
private:
int action_7( antlr::AST* p )
{
	

	int constant((int)reducedValues.top());
	reducedValues.pop();
	
		{
			int r = regnum++;
			// hmmm, I don't seem to have any use for 'constant' directly...
			std::cout << "\tla\tr" << r << ", " << constant << std::endl;
			return r;
		}
}
private:
int action_8( antlr::AST* p )
{
	
		{
			return 0;
		}
}
private:
int action_9( antlr::AST* p )
{
	

	int a((int)reducedValues.top());
	reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tlw\tr" << r << ", (r" << a << ")" << std::endl;
			return r;
		}
}
private:
int action_10( antlr::AST* p )
{
	

	std::vector<void*>* c1((std::vector<void*>*)reducedValues.top());
	reducedValues.pop();
	
		{
		    std::cout << "-- Recognized NARGLE..." << std::endl;
		    return 2917;
		}
}
private:
int action_11( antlr::AST* p )
{
	
		{
			return atoi(p->getText().c_str());
		}
}
private:
std::string* action_12( antlr::AST* p )
{
	
		{ return new std::string ( p->getText().c_str() ); }
}
private:
int action_13( antlr::AST* p )
{
	

	std::auto_ptr<std::string> id((std::string*)reducedValues.top());
	reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tla\tr" << r << ", " << *id << std::endl;
			return r;
		}
}
private:
void dispatchAction( antlr::AST* p, int iRule )
{
	switch( iRule )
	{
		case 1:
		{
			/* Don't reduce or touch the stack. */

			break;
		}
		case 2:
		{
			reducedValues.push( (void*)(this->action_2(p)));
			break;
		}
		case 3:
		{
			reducedValues.push( (void*)(this->action_3(p)));
			break;
		}
		case 4:
		{
			reducedValues.push( (void*)(this->action_4(p)));
			break;
		}
		case 5:
		{
			reducedValues.push( (void*)(this->action_5(p)));
			break;
		}
		case 6:
		{
			reducedValues.push( (void*)(this->action_6(p)));
			break;
		}
		case 7:
		{
			reducedValues.push( (void*)(this->action_7(p)));
			break;
		}
		case 8:
		{
			reducedValues.push( (void*)(this->action_8(p)));
			break;
		}
		case 9:
		{
			reducedValues.push( (void*)(this->action_9(p)));
			break;
		}
		case 10:
		{
			reducedValues.push( (void*)(this->action_10(p)));
			break;
		}
		case 11:
		{
			reducedValues.push( (void*)(this->action_11(p)));
			break;
		}
		case 12:
		{
			reducedValues.push( (void*)(this->action_12(p)));
			break;
		}
		case 13:
		{
			reducedValues.push( (void*)(this->action_13(p)));
			break;
		}
		default:throw std::string("Unmatched reduce action " + iRule);
		
	}
	
}


	void reduce ( JBurgAnnotation<antlr::AST >* p, int goalState )
	{
		int iRule = -1;

		if ( goalState > 0 ) {
			iRule = p->getRule(goalState);
		} else {
			//  Find the minimum-cost path.
			int minCost = MAX_INT_VALUE;
			for (int i = 0; i <= nStates ; ++i ) {
				if ( p->getCost(i) < minCost ) {
					iRule = p->getRule(i);
					minCost = p->getCost(i);
					goalState = i;
				}
			}
		}

		if ( iRule > 0 )
		{
			
			reduceAntecedentStates(p, goalState);
			if ( p->isNary(goalState) )
			{
			/* Aggregate the operands of an n-ary operator into a single container. */std::vector<void*>* variadic_result = new std::vector<void*>;
			for ( int i = 0; i < p->getArity(); i++ )
			{
				reduce(p->getNthChild(i), p->getNarySubgoal(goalState));
				variadic_result->push_back(reducedValues.top());
				reducedValues.pop();
			}
			reducedValues.push(variadic_result);
			}
			reduceSubgoals(p, goalState);

			dispatchAction ( p->getNode(), iRule );
		}
		else
		{
			std::stringstream s;
			s << "Unable to find a rule to process ";
			s << p->getNode()->toString();
			s << " (" << p->getOperator() << ") {" << goalState << "}";
			throw new std::runtime_error ( s.str() );
		}
	}

	void reduceAntecedentStates( JBurgAnnotation<antlr::AST >* p, int goalState)
	{
		int   currentState = goalState;
		std::vector<int> antecedent_states;
		std::vector<int> antecedent_rules;

		//  If X is antecedent of Y, then the reduce action
		//  for X must occur before the reduce action of Y.
		//  The antecdents must therefore be processed 
		//  from "back" to "front."
		while ( p->hasAntecedent(currentState)  )
		{
			currentState = p->getAntecedent(currentState);
			antecedent_states.push_back(currentState);
			antecedent_rules.push_back(p->getRule(currentState));
		}
		while ( ! antecedent_states.empty() )
		{
			reduceSubgoals(p, antecedent_states.back());
			dispatchAction( p->getNode(), antecedent_rules.back());
			antecedent_states.pop_back();
			antecedent_rules.pop_back();
		}
	}
	void reduceSubgoals( JBurgAnnotation<antlr::AST >* p, int goalState)
	{
	/* Reduce subgoals in reverse order so they get pushed onto the stack */
	/* in the order expected by the action routines. */
		for ( int i = p->getSubgoalsSize(goalState) - 1; i >= 0; i-- )
		{
			JBurgAnnotation<antlr::AST >::JBurgSubgoal sg = p->getSubgoals(goalState)[i];
			reduce ( sg.getNode(), sg.getGoalState());
		}
	}

public:

	void burm ( antlr::AST* root )
	{
		JBurgAnnotation<antlr::AST >* annotatedTree = label(root);
		reduce ( annotatedTree, 0);
		delete annotatedTree;
	}private:
int getArityOf( antlr::AST* node )
{
	antlr::AST* cnode = NULL;
	int result = 0;
	for ( cnode = node->getFirstChild(); cnode != NULL; cnode = cnode->getNextSibling() ) { result++; }
	return (result);
	
}
private:
antlr::AST* getNthChild( antlr::AST* node, int idx )
{
	antlr::AST* result = NULL;
	int i = 0;
	for ( i = 0, result = node->getFirstChild(); result != NULL && i < idx; result = result->getNextSibling() ) { i++; }
	return (result);
	
}

int getNaryCost( JBurgAnnotation<antlr::AST>* node, int goalState)
{
	int i = 0;
	int accum = 0;
	
	for ( i = 0; i < node->getArity(); i++ )
	{
		
		accum += node->getCost(goalState);
		
	}
	
	return (accum);
	
}


};
