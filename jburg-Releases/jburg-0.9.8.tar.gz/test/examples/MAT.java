/**
 *  TL/2 "Minimal Acceptance Test" as a one-shot program.
 */
public class MAT
{
    java.lang.String h1;
	String h2;
	String h3;

	public static final int TWO = 2;
	
	/**
	 *  Tests string concatenation after conversion of int to string,
	 *  variable scoping by setting member field which is declared
	 *  after this routine.
	 */
	void poot( int x)
	{
		System.out.println ( "x is " + x );
		i = 12;
	}

	/**
	 *   Tests string concat on result of toString() call.
	 */
	void poot(Object y)
	{
		System.out.println( "Object y is " + y.toString());
	}

	/**
	 *  Tests switch control-flow and static final int
	 *  as a manifest constant.
	 */
	static private void switchIt( int i )
	{
		switch ( i )
		{
			case 1:
				System.out.println ( "case 1" );
			case TWO:
				System.out.println ( "i is " + i );
				break;
			case 3:
				System.out.println ( "case 3." );
				break;
			default:
				System.out.println ( "default" );
		}

		switch ( i + 1 )
		{
			case 1:
				System.out.println ( "case 1" );
			case TWO:
				System.out.println ( "i is " + i );
				break;
			case 3:
				System.out.println ( "case 3." );
				break;
			default:
				System.out.println ( "default" );
		}
	}

	public void hello()
	{
	    h1 = "hello, ";
		h2 = "world";
		h3 = h1 + h2;
		
		System.out.println ( h3 );
		System.out.println ( h1 + " concatenated " + h2 );
		// System.out.println ( new java.util.Date().toString() );

		if ( h3.equalsIgnoreCase(h1 + h2) )
			System.out.println ("strings match, succeeded." );
		else
			System.out.println ("strings DO NOT match, GIGO." );

		System.out.println ( "i is " + String.valueOf(i) );

		j = 1;
		i = 14 + j;


		if ( i > 14 )
			System.out.println ( "i is " + String.valueOf(i) );
		else
			System.out.println ( "GIGO" );

		poot(1);
		System.out.println ( "i is " + String.valueOf(i) );

		if ( j > 12 )
		{
		    System.out.println ( "GIGO, j > 12?" );
		}
		else
		{
		    System.out.println ( "Succeeded, j is " + String.valueOf(j) );
		}

		while ( i > 1 )
		{
		    System.out.println ( "i = " + String.valueOf(i) );
			i = dec(i);
		}

		intParam(new Integer(7), new Integer(4));


		i = 2;
		switch ( i )
		{
			case 1:
				System.out.println ( "GIGO" );
			case 2:
				System.out.println ( "i is " + i );
			case 3:
				System.out.println ( "fell into case 3." );
		}

		System.out.println ( "switch tests" );
		switchIt(1);
		switchIt(2);
		switchIt(3);
		switchIt(12);

		try
		{
			Class.forName("zuul");
		}
		catch ( Exception ex )
		{
			System.out.println ( "Caught " + ex.getMessage() );
		}

	}

	private int dec(int i)
	{
		return i - 1;
	}

	private void intParam ( Integer i, Integer j )
	{
		System.out.println ( "int param i as an integer is " + i.toString() );
		System.out.println ( "int param j as an integer is " + j.toString() );
	}

	//  These fields are below their initial references to ensure
	//  that field lookup is not position-sensitive.
	int i = 7;
	int j;

	public static void main ( String[] args )
	{
		new MAT().hello();
	}
}
