package jburg.burg.inode;

import jburg.burg.JBurgGenerator;

class TL2INodeAdapter
    implements InodeAdapter
{
	public boolean accept(String inodeClassName)
	{
		return inodeClassName != null &&
			inodeClassName.equals("jburg.compiler.tl2.ir.TL2INode");
	}

	public String genGetArity(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		verifyStem(stem);
		return emitter.genCallMethod(stem, "getArity", null);
	}

	public String genGetNthChild(String stem, String index, jburg.burg.emitlangs.EmitLang emitter)
	{
		verifyStem(stem);
		return emitter.genCallMethod(stem, "getNthChild", new String[] { index } );
	}

	public String genGetOperator(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		verifyStem(stem);
		return emitter.genCallMethod(stem, "getOperator", null);
	}

	private void verifyStem(String stem)
	{
		if ( !JBurgGenerator.isInitialParamName(stem) ) 
		{
			// FIXME: Can't verify this way.
			// throw new IllegalStateException("i-node adapter called on JBurg annotation: " + stem);
		}
	}
}
