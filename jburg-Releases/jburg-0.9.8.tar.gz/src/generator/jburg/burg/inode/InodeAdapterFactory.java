package jburg.burg.inode;

import jburg.burg.JBurgUtilities;

import java.util.Enumeration;
import java.util.Vector;

public class InodeAdapterFactory
{
	public static InodeAdapter getAdapter(String inodeTypeName)
	{

		Vector candidates = JBurgUtilities.getInterfaceImpls(InodeAdapter.class);

		if(candidates==null) return null;
		
		for(Enumeration walker=candidates.elements(); walker.hasMoreElements();) {
			try {
				Class cl = (Class)walker.nextElement();

				try
				{
					InodeAdapter el = (InodeAdapter)ClassLoader.getSystemClassLoader().loadClass(cl.getName()).newInstance();

					if(el.accept(inodeTypeName )) {
						System.out.println("Using I-Node Adaptor : "+el.getClass().getName());

						return el;
					}
				} catch(InstantiationException e) {
					System.err.println("Unable to instantiate possible language class!");
					System.err.println(e);
				} catch(IllegalAccessException e) {
					System.err.println("IllegalAccessException: see info:");
					System.err.println(e);
				}
			}  catch(ClassNotFoundException e) {
				System.err.println("Class does not appear to exist in CLASSPATH");
				System.err.println(e);
			}
		}
		return null;
	}
}
