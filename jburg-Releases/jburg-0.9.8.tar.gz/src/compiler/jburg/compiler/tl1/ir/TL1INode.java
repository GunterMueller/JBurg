package jburg.compiler.tl1.ir;


import jburg.compiler.tl1.TL1Compiler;

import jburg.compiler.tl1.parser.Token;
import jburg.compiler.tl1.parser.TL1ParserConstants;


import org.apache.bcel.generic.ClassGen;
import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.InstructionList;

/**
 *  TL1INode is the TL/1 compiler's abstract syntax tree node,
 *  suitable for use as input to a JBurg-generated BURM.
 */
public class TL1INode
implements TL1ParserConstants, TL1NodeTypes
{
   /**  Left child and/or "car" */
   private TL1INode left;

   /**  Right child and/or "cdr" */
   private TL1INode right;

   /**
    *  The Token (if any) that represents the syntactic
    *  construct that generated this node.
    */
   Token startToken;

   /**
    *  An explicitly set opcode, used by nodes without a
    *  specific start token.
    */
   int opcode = NO_OPCODE;

   /**
    *  Construct a TL1INode with a particular opcode.
    *  @param opcode - the opcode for this node.
    */
   public TL1INode ( int opcode )
   {
    this.opcode = opcode;
   }

   /**
    *  Construct a TL1INode with a particular opcode and known children
    *  @param opcode - the opcode for this node.
    *  @param left - the left child/car
    *  @param right - the right child/cdr
    */
   public TL1INode ( int opcode, TL1INode left, TL1INode right )
   {
    this(opcode);

    setLeftChild  (left);
    setRightChild (right);
   }

   /**
    *  Construct a node that represents a syntactic construct.
    *  @param startToken - the token that represents the construct.
    */
   public TL1INode ( Token startToken )
   {
    setStartToken ( startToken );
   }

   /**
    *  Construct a node that represents a syntactic construct with known children.
    *  @param startToken - the token that represents the construct.
    *  @param left - the left child/car
    *  @param right - the right child/cdr
    */
   public TL1INode ( Token startToken, TL1INode left, TL1INode right )
   {
    this ( startToken );

    setLeftChild  (left);
    setRightChild (right);
   }

   /**
    *  Set this node's startToken.
    */
   public void setStartToken ( Token t )
   {
    this.startToken = t;
   }

   /**
    *  @return this node's start token, or null if it's not set.
    */
   public Token getStartToken()
   {
    return this.startToken;
   }

   /**
    *  Set this node's left child/"car".
    */
   public void setLeftChild ( TL1INode left )
   {
    this.left = left;
   }

   /**
    *  Set this node's right child/"cdr".
    */
   public void setRightChild ( TL1INode right )
   {
    this.right = right;
   }

   /**
    *  @return this node's right child/"cdr".
    */
   public TL1INode rightChild()
   {
    return this.right;
   }


   /**
    *  @return this node's left child/"car".
    */
   public TL1INode leftChild()
   {
    return this.left;
   }

   /**
    *  Set this node's operator.  The newly set operator
    *  will override the start token's operator, if any.
    */
   public void setOperator(int opcode)
   {
    this.opcode = opcode;
   }

   /**
    *  @return this node's operator, looking first for
    *    an explicitly set operator, then looking at the
    *    start token.
    */
   public int getOperator()
   {
    if ( this.opcode != NO_OPCODE )
        return this.opcode;
    else
        return this.startToken.kind;
   }

   /**
    *  @return a String representation of this node, suitable for use in debugging.
    */
   public String toString()
   {
    return
    (
         (this.startToken != null)?
            this.startToken.image :
            "[" + getOperator() + "]"
    );
   }

   /**
    *  @return the int value of an INTEGER_LITERAL.
    */
   public int intValue()
   {
    if ( getOperator() != INTEGER_LITERAL )
        throw new IllegalStateException( "Operator " + getOperator() + " is not INTEGER_LITERAL");

    return Integer.parseInt(getStartToken().image);
   }
}
