package burmTest;

public enum NonterminalTypes
{
    expression,
}
