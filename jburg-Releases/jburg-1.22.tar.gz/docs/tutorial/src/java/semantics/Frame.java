package jburg.tutorial.semantics;

import java.util.*;

import org.antlr.runtime.tree.Tree;

/**
 * The Frame is an abstract
 * description of a stack frame.
 */
public interface Frame
{
    /**
     * Add a formal parameter to a function's frame.
     * @param formalDescriptor the formal's descriptor,
     * which holds its type and name.
     */
    void addFormal(Tree formalDescriptor);

    /**
     * Add a local variable to a frame.
     * @param localDescriptor the local's descriptor, 
     * which holds its type and name.
     */
    void addLocal(Tree localDescriptor);

    /**
     * @return the stack frame's size.
     */
    Integer getSize();

    /**
     * @return true if the function needs to save its $ra.
     */
    boolean getNeedsRaSaved();

    /**
     * Set the function's $ra-save status.
     * @param setting the state of the $ra register;
     * may be set from false to true, and from true
     * to true, but may not be set from true to false.
     */
    void setNeedsRaSaved(boolean setting);

    /**
     * Does the given lvalue have a backing register?
     * @param name the name of the lvalue of interest.
     * @return true if the lvalue is register-based.
     */
    boolean hasRegister(String name);

    /**
     * Get an lvalue's backing register; hasRegister must be true.
     * @param name the name of the lvalue of interest.
     * @return the register backing the lvalue.
     */
    String getRegister(String name);

    /**
     * Get an lvalue's backing stack offset; hasRegister must be false.
     * @param name the name of the lvalue of interest.
     * @return the stack offset backing the lvalue.
     */
    Integer getOffset(String name);
}
