package jburg.tutorial.semantics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.antlr.runtime.tree.Tree;

public class SimplifiedCallFrame implements Frame
{
    Map<String,DataDescriptor> formals = new HashMap<String,DataDescriptor>();
    Map<String,DataDescriptor> locals  = new HashMap<String,DataDescriptor>();

    boolean shouldSaveRa = false;

    public void addFormal(Tree formalDescriptor)
    {
        String name = formalDescriptor.getChild(1).getText();
        if ( findDescriptorUnchecked(name) != null )
            throw new IllegalStateException(String.format("Cannot redeclare %s."));
        DataDescriptor desc = new DataDescriptor(formalDescriptor, formals.size());
        if ( formals.size() < 4 )
            desc.register = String.format("a%d", formals.size());

        formals.put(name,desc);
    }

    public void addLocal(Tree localDescriptor)
    {
        String name = localDescriptor.getChild(1).getText();
        if ( findDescriptorUnchecked(name) != null )
            throw new IllegalStateException(String.format("Cannot redeclare %s."));
        DataDescriptor desc = new DataDescriptor(localDescriptor, locals.size());
        locals.put(name, desc);
    }

    public boolean hasRegister(String name)
    {
        return findDescriptor(name).register != null;
    }

    public String getRegister(String name)
    {
        String register = findDescriptor(name).register;
        if ( register != null )
            return register;
        else
            throw new IllegalStateException(String.format("Variable %s has no backing register."));
    }
    public Integer getSize()
    {
        // TODO: Needs stack alignment, register save area, and other calling conventions.
        return locals.size() * 4 + (shouldSaveRa? 4:0);
    }

    public boolean getNeedsRaSaved()
    {
        return shouldSaveRa;
    }

    public void setNeedsRaSaved(boolean setting)
    {
        if ( !setting && shouldSaveRa )
            throw new IllegalStateException("Cannot reset save $ra flag to false.");
        shouldSaveRa = setting;
    }

    public Integer getOffset(String name)
    {
        // TODO: Needs stack alignment and other MIPS calling conventions.
        int entryPosition = findDescriptor(name).entryPosition;

        if ( formals.containsKey(name) )
            return entryPosition * 4 + getSize();
        else if ( locals.containsKey(name) )
            return entryPosition * 4;
        else
            throw new IllegalStateException(String.format("Unknown DataDescriptor : %s",name));
    }

    private DataDescriptor findDescriptor(String name)
    {
        DataDescriptor desc = findDescriptorUnchecked(name);
        if ( desc != null )
            return desc;
        else
            throw new IllegalStateException(String.format("Reference to undeclared variable %s.", name));
    }

    private DataDescriptor findDescriptorUnchecked(String name)
    {
        DataDescriptor result = this.formals.get(name);
        if ( result == null )
            result = this.locals.get(name);
        return result;
    }

    private static class DataDescriptor
    {
        DataDescriptor(Tree declaration, int entryPosition)
        {
            this.declaration   = declaration;
            this.entryPosition = entryPosition;
        }

        final Tree declaration;
        final int entryPosition;
        String register = null;
    }
}
