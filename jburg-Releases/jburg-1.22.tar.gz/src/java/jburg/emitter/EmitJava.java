package jburg.emitter;

@SuppressWarnings({"nls"})
public class EmitJava extends TemplateBasedEmitter implements EmitLang
{
    /**
     * Construct an emitter and load its templates.
     */
	public EmitJava()
    {
        super("Java");
	}

    @Override
	public boolean accept(String langName)
	{
        return "java".equalsIgnoreCase(langName);
	}

    @Override
    public Object getAnnotationType()
    {
        return "JBurgAnnotation";
    }
}
