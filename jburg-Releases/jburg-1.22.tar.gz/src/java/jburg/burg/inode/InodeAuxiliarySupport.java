package jburg.burg.inode;

public interface InodeAuxiliarySupport
{
	public void emitAuxiliarySupport(jburg.emitter.EmitLang emitter, java.io.PrintStream output);
}
