package jburg.burg.inode;

public class Antlr2CppAdapter 
	implements InodeAdapter, InodeAuxiliarySupport
{
	public boolean accept(String inodeClassName)
	{
		return inodeClassName.equals("antlr::AST");
	}

	public String genGetArity(String stem, jburg.emitter.EmitLang emitter)
	{
		return emitter.genCallMethod(null, "getArityOf", new String[] { stem } );
	}

	/**
	 *  @return an expression that fetches a child node at the specified index.
	 */
	public String genGetNthChild(String stem, String index, jburg.emitter.EmitLang emitter)
	{
		//  Uses auxillary method in jburgsupp.h
		return emitter.genCallMethod(null, "getNthChild", new String[] { stem, index } );
	}

	public String genGetOperator( String node, jburg.emitter.EmitLang emitter)
	{
		return node + "->getType";
	}

	public void emitAuxiliarySupport(jburg.emitter.EmitLang emitter, java.io.PrintStream output)
	{
		/*
		//  FIXME: Use structured statements!
		output.print("\n\tprivate:");
		output.print("\n\tint getArity(antlr::AST* n)");
		output.print("\n\t{");

		output.print("\n\t\tint result = 0;");
		output.print("\n\t\tantlr::AST* cursor = n->getFirstChild();");
		output.print("\n\t\twhile (cursor != NULL) {");
		output.print("\n\t\t\tresult++;");
		output.print("\n\t\t\tcursor = cursor->getNextSibling();");
		output.print("\n\t\t}");
		output.print("\n\treturn result;");

		output.print("\n\t}");

		output.print("\n\nantlr::AST* getNthChild(antlr::AST* n, int idx)");

		output.print("\n\t{");

		output.print("\n\t\tantlr::AST* result = n->getFirstChild();");
		output.print("\n\t\twhile (result != NULL && idx != 0 ) {");
		output.print("\n\t\t\tidx--;");
		output.print("\n\t\t\tresult = result->getNextSibling();");
		output.print("\n\t\t}");
		output.print("\n\treturn result;");

		output.print("\n\t}");
		output.print("\n\n");
		*/
	}
}

