package jburg.burg.patternmatcher;

/**
 * A PATRICIA trie implementation.
 */
public class Trie<T extends Comparable>
{

}
