package jburg.burg;

/**
 *  A JBurgSubgoalRecord is a record of a goal that
 *  a pattern's child nodes must satisfy.
 *  For example, in the pattern ADD(int x, int y),
 *  x and y are the names of subgoals.  Both these
 *  subgoals require the children to satisfy the
 *  "int" goal state.
 */
public class JBurgSubgoalRecord
{
	public String m_name;
	public String m_goal;

	/**
	 *  The pattern matcher that 
	 */
	public JBurgPatternMatcher m_path;

	public int m_type;

	/**
	 *  A BURM-constructed subgoal record (the only type presently used).
	 *  @param name -- the programmer-supplied name, e.g., "x" in foo(int x).
	 *  @param state -- the state that the child node must satisfy.
	 *  @param path -- the path from the pattern's root node to the subgoal node.
	 */
	public JBurgSubgoalRecord(
			String name, 
			String state,
			JBurgPatternMatcher path
		)
	{
		m_name = name;
		m_goal = state;
		m_path = path;
	}

	public String getAccesspath()
	{
		return m_path.getAccesspath();
	}
}
