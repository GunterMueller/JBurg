import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 *  BurmTest reads a simple tree description language,
 *  builds a test tree, and invokes the specified BURM
 *  to rewrite the tree.
 */
public class BurmTest extends org.xml.sax.helpers.DefaultHandler
{
    Stack<TestINode>  nodeStack = new Stack<TestINode>();

    Map<String,Integer> opcodes = new HashMap<String,Integer>();

    TestINode rootNode;

    Object burm;

    String expectedResult = null;

    public static void main(String[] args)
    throws Exception
    {
        if ( args.length < 1 )
        {
            usage();
            System.exit(1);
        }

        BurmTest testobj = new BurmTest();
        testobj.parse(args[0]);

        String burm_result = testobj.burm().toString();

        if ( null == testobj.expectedResult )
            System.out.println(burm_result);
        else if ( testobj.expectedResult.equals(burm_result ) )
            System.out.println("Succeeded.");
        else
            System.err.println(String.format("FAILED: expected %s, actual %s", testobj.expectedResult, burm_result));

    }

    static void usage()
    {
        System.out.println("usage: BurmTest <test spec file>");
    }

    /**
     *  Parse the test specification.
     */
    void parse(String spec_file)
    throws Exception
    {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
    
        SAXParser parser = factory.newSAXParser();
        java.io.InputStream input = new java.io.FileInputStream(spec_file);
        
        parser.parse(input, this);
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes)
    {
        if ( "BurmTest".equalsIgnoreCase(qName) )
        {
            this.expectedResult = attributes.getValue("expectedResult");
            String burm_class_name = attributes.getValue("burm");
            try
            {
                Class burm_class = Class.forName(burm_class_name);
                this.burm = burm_class.newInstance();
            }
            catch ( Exception no_burm )
            {
                System.err.println("Unable to instantiate " + burm_class_name + " due to " + no_burm);
            }
        }
        else if ( "Opcodes".equalsIgnoreCase(qName) )
        {
            loadOpcodes(attributes.getValue("class"));
        }
        else if ( "Node".equalsIgnoreCase(qName) )
        {
            int opcode = opcodes.get(attributes.getValue("opcode"));

            TestINode node = new TestINode(opcode, attributes.getValue("userObject"));

            if ( !nodeStack.isEmpty() )
                nodeStack.peek().addChild(node);

            nodeStack.push(node);
        }
        else
            throw new IllegalArgumentException("Unknown node type " + qName);
    }

    @Override
    public void endElement(String uri,  String localName,  String qName)
    {
        if ( "Node".equalsIgnoreCase(qName) )
            this.rootNode = nodeStack.pop();
    }

    /**
     *  Rewrite the test tree and get the result.
     *  @return the result of the tree rewrite.
     */
    private Object burm()
    {
        Class burm_class = this.burm.getClass();
        try
        {
            //  The burm doesn't implement a known class,
            //  but it has known methods to rewrite the
            //  input tree and return a result.
            Method burm_method = burm_class.getDeclaredMethod( "burm", TestINode.class);

            burm_method.invoke(burm, this.rootNode);

            try
            {
                Method result_method = burm_class.getDeclaredMethod( "getResult");
                return result_method.invoke(burm);
            }
            catch ( Exception ex )
            {
                System.err.println("Error getting burm result:");
                ex.printStackTrace();
                System.exit(2);
            }
         }
         catch ( Exception ex )
         {
             System.err.println("Error invoking burm:");
             ex.printStackTrace();
             System.exit(3);
         }
         return null;
    }

    /**
     *  Load the symbolic name to opcode encodings.
     */
    private void loadOpcodes(String class_name)
    {
        try
        {
            Class<? extends Object> tokenTypes = Class.forName(class_name);
            //  Traverse the names of the OP_foo constants
            //  in AbcConstants and load their values.
            for ( Field f: tokenTypes.getFields())
            {
                String field_name = f.getName();
               try
               {
                   int field_value = f.getInt(null);
                   opcodes.put(field_name, field_value);
               }
               catch ( Exception noFieldValue)
               {
                   //  Ignore, continue...
               }
            }
        }
        catch ( Throwable no_class)
        {
            System.err.println("Unable to load " + class_name + ": " + no_class.getLocalizedMessage());
            no_class.printStackTrace();
        }
        
    }
}
