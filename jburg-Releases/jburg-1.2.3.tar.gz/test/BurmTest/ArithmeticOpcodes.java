public interface ArithmeticOpcodes
{
    public static int ADD = 1;
    public static int INT = ADD + 1;
}
