public class IntegerArithmeticDriver
	implements IntegerINodeTypes
{
	public static void main(String[] argv)
		throws Exception
	{
		Integer iResult;
		IntegerArithmeticMatcher matcher = new IntegerArithmeticMatcher();

		IntegerINode one = new IntegerINode( new Integer(1));
		IntegerINode two = new IntegerINode( new Integer(2));
		IntegerINode three = new IntegerINode( new Integer(3));
		IntegerINode four = new IntegerINode( new Integer(4));

		IntegerINode add = new IntegerINode(ADD, one, two);
		matcher.burm(add);
		iResult = (Integer)matcher.getResult();
		verifyResult("Simple ADD", 3, iResult);

		IntegerINode indir = new IntegerINode(INDIR, one, null);
		IntegerINode indir_add = new IntegerINode(ADD, indir, two);
		matcher.burm(indir_add);
		iResult = (Integer)matcher.getResult();

		verifyResult("ADD(INDIR)", 3, iResult);

		IntegerINode ternary = new IntegerINode(ADD);
		ternary.addChild(one);
		ternary.addChild(two);
		ternary.addChild(three);
		matcher.burm(ternary);
		iResult = (Integer)matcher.getResult();

		verifyResult("ADD(<ternary>)", 6, iResult);

		IntegerINode addMany = new IntegerINode(ADD);
		addMany.addChild(one);
		addMany.addChild(two);
		addMany.addChild(three);
		addMany.addChild(four);
		matcher.burm(addMany);
		iResult = (Integer)matcher.getResult();

		verifyResult("ADD(...)", 10, iResult);

	}

	private static void verifyResult(String testName, int expected, Integer actual)
	{
		if ( actual.intValue() == expected )
		{
			System.out.println( testName + " succeeded.");
		}
		else
		{
			throw new IllegalStateException(
					testName +
					" FAILED: expected result is " + 
					Integer.toString(expected) +
					", BURM result is " + 
					actual.toString()
			);
		}
	}
}
