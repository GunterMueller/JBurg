import java.util.Vector;

class TestINode
{
    Vector<TestINode> children;

    int opcode;

    Object userObject;

    TestINode(int opcode, Object user_object)
    {
        this.opcode = opcode;
        this.userObject = user_object;
    }

    public int getArity()
    {
        if ( null == children )
            return 0;
        else
            return children.size();
    }

    public TestINode getNthChild(int idx)
    {
        return children.elementAt(idx);
    }

    public int getOperator()
    {
        return this.opcode;
    }

    Object getUserObject()
    {
        return this.userObject;
    }

    void setUserObject(Object user_object)
    {
       this.userObject = user_object;
    }

    void addChild(TestINode child)
    {
        if ( null == this.children )
            this.children = new Vector<TestINode>();

        this.children.add(child);
    }

    public String toString()
    {
        StringBuffer result = new StringBuffer("<Node");
        addAttribute(result, "operator", this.opcode);
        if ( this.userObject != null )
            addAttribute(result, "userObject", this.userObject);

        if ( this.children != null )
        {
            result.append("> ");
            for ( TestINode kid: this.children)
            {
                result.append(kid.toString());
            }
            result.append(" </Node>");
        }
        else
            result.append("/>");

        return result.toString();
    }

    void addAttribute(StringBuffer buffer, String attr_name, Object attr_value)
    {
        buffer.append(" ");
        buffer.append(attr_name);
        buffer.append("=\"");
        buffer.append(attr_value.toString());
        buffer.append("\"");
    }
}
