/*  Generated Thu Apr 07 14:11:06 EDT 2011 by JBurg version 1.7.3 */

    import java.util.Vector;
    @SuppressWarnings("unchecked")
public class Test2999397 implements burmTest.ArithmeticOpcodes
	
{
	java.util.Stack __reducedValues = new java.util.Stack();
	
	public static final int __expression_NT = 1;
	
	public static final int __block_NT = 2;
	
	public static final int nStates = 2;
	

	private static final JBurgSubgoal[][] ___subgoals_by_rule = 
	{
		null,
		null,
		{
			new JBurgSubgoal(__expression_NT,false,0,0),
			new JBurgSubgoal(__expression_NT,false,0,1),
		},
		{
			new JBurgSubgoal(__expression_NT,true,0),
		},
		null,
	};
	


	
	public JBurgAnnotation label( burmTest.TestINode to_be_labelled)
	{
		JBurgAnnotation result = null;
		
		int i;
		
		int arity;
		if ( to_be_labelled != null )
		{
			result = new JBurgAnnotation(to_be_labelled,nStates + 1);
			
			arity = to_be_labelled.getArity();
			
			i = 0;
			while ( ( arity > i ) )
			{
				result.addChild(this.label(((burmTest.TestINode)to_be_labelled.getNthChild(i))));
				
				i =  (i + 1) ;
				
			}
			this.computeCostMatrix(result);
			
		}
		return( result);
		
	}
	
	private void computeCostMatrix( JBurgAnnotation node)
	{
		long iCost;
		
		switch( node.getOperator() )
		{
			case INT:
			{
				if ( node.getArity() == 0 )
				{
					
					/* Try matching INT ==> expression */if ( ( node.getCost(__expression_NT) > 1 )  && ( Integer.MAX_VALUE > 1 )  )
					{
						node.reset(__expression_NT, 1, 4);
						
					}
				}
				break;
			}
			case PAREN:
			{
				if ( (node.getArity() >= 1) && this.getNaryCost(node, __expression_NT, 0) != Integer.MAX_VALUE )
				{
					
					/* Try matching PAREN ==> block */
					iCost =  (((long)0) + ((long)this.getNaryCost(node, __expression_NT, 0))) ;
					if ( ( node.getCost(__block_NT) > iCost )  && ( Integer.MAX_VALUE > iCost )  )
					{
						node.reset(__block_NT, ((int)iCost), 3);
						closure_block(node, ((int)iCost));
						
					}
				}
				break;
			}
			case ADD:
			{
				if ( node.getArity() == 2 )
				{
					
					/* Try matching ADD ==> expression */
					iCost =  ( (((long)1) + ((long)node.getNthChild(1).getCost(__expression_NT)))  + ((long)node.getNthChild(0).getCost(__expression_NT))) ;
					if ( ( node.getCost(__expression_NT) > iCost )  && ( Integer.MAX_VALUE > iCost )  )
					{
						node.reset(__expression_NT, ((int)iCost), 2);
						
					}
				}
				break;
			}
		}
	}
	
	private void closure_block( JBurgAnnotation __p, int c)
	{
		int iCost;
		
		iCost = c;
		if ( ( __p.getCost(__expression_NT) > iCost )  )
		{__p.reset(__expression_NT, iCost, 1);
			__p.recordAntecedent(__expression_NT, __block_NT);
			
		}
	}
	/* expression */
	
	private Integer action_2( burmTest.TestINode __p)
	{

	Integer r = (Integer)__reducedValues.pop();


	Integer l = (Integer)__reducedValues.pop();

		{
		    return l.intValue() + r.intValue();
		}
	}
	/* block */
	
	private Integer action_3( burmTest.TestINode __p)
	{

	java.util.Vector<Integer> expr = (java.util.Vector<Integer>)__reducedValues.pop();

		{
		    int result = 0;
		    for ( Integer i: (Vector<Integer>)expr)
		        result += i;
		
		    return result;
		}
	}
	/* expression */
	
	private Integer action_4( burmTest.TestINode __p)
	{
		{
		    return Integer.parseInt(__p.getUserObject().toString());
		}
	}
	
	private void dispatchAction( burmTest.TestINode __p, int iRule) throws java.lang.Exception
	{
		switch( iRule )
		{
			case 1:
			{/* Don't reduce or touch the stack. */
				
				break;
			}
			case 2:
			{__reducedValues.push(this.action_2(__p));
				
				break;
			}
			case 3:
			{__reducedValues.push(this.action_3(__p));
				
				break;
			}
			case 4:
			{__reducedValues.push(this.action_4(__p));
				
				break;
			}
			default:throw new IllegalStateException("Unmatched reduce action " + iRule);
			
		}
	}
	
	public void reduce( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		int iRule = -1;
		if ( ( goalState > 0 )  )
		{
			iRule = p.getRule(goalState);
			
		}
		else
		{
			/* Find the minimum-cost path. */
			int minCost = Integer.MAX_VALUE;
			
			int i;
			for( 
			i = 0;
			i <= nStates;i++ )
			{
				if ( ( minCost > p.getCost(i) )  )
				{
					iRule = p.getRule(i);
					
					minCost = p.getCost(i);
					
					goalState = i;
					
				}
			}
		}
		if ( ( iRule > 0 )  )
		{
			if ( p.hasAntecedent(goalState) )
			{
				reduceAntecedentStates(p, goalState);
			}
			reduceSubgoals(p, iRule);
			dispatchAction ( (burmTest.TestINode)p.getNode(), iRule );
		}
		else
		{
			throw new IllegalStateException ( "Unable to find a rule to process \"" + p.toString() + "\", operator="+ String.valueOf(p.getOperator()) + ", goal=" + String.valueOf(goalState) );
		}
	}
	
	private void reduceSubgoals( JBurgAnnotation p, int rule_num) throws java.lang.Exception
	{
		if ( ___subgoals_by_rule[rule_num] != null )
		{
			for ( JBurgSubgoal sg : ___subgoals_by_rule[rule_num] )
			{
				if ( !sg.isNary() )
				{
					reduce ( sg.getNode(p), sg.getGoalState());
				}
				else
				{
					/* Aggregate the operands of an n-ary operator into a single container. */
					JBurgAnnotation sub_parent = sg.getNode(p);
					java.util.Vector<Object> variadic_result = new java.util.Vector<Object>(sub_parent.getArity() - sg.startIndex);
					for ( int j = sg.startIndex; j < sub_parent.getArity(); j++ )
					{
						reduce(sub_parent.getNthChild(j), sg.getGoalState());
						variadic_result.add(__reducedValues.pop());
					}
					__reducedValues.push(variadic_result);
				}
			}
		}
	}
	
	private int getNaryCost( JBurgAnnotation node, int goalState, int start_index)
	{
		int accumCost = 0;
		for ( int i = start_index; i < node.getArity() && accumCost != Integer.MAX_VALUE; i++ )
		{
			int subCost = node.getNthChild(i).cost[goalState];
			if ( subCost != Integer.MAX_VALUE )
				accumCost += subCost;
			else
				accumCost = Integer.MAX_VALUE;
		}
		return accumCost;
	}
	
	private int addAllCosts(int count, int ... costs)
	{
		long accum = 0;
		
		for ( int i: costs )
		{
			if ( accum + i >= Integer.MAX_VALUE )
			{
				return Integer.MAX_VALUE;
			}
			accum += i;
		}
		return (int)accum;
	}
	
	private void reduceAntecedentStates( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		int antecedent_state = p.getAntecedent(goalState);
		if ( p.hasAntecedent(antecedent_state) )
		{
			reduceAntecedentStates(p, antecedent_state);
		}
		int antecedent_rule = p.getRule(antecedent_state);
		reduceSubgoals(p, antecedent_rule);
		dispatchAction(p.getNode(), antecedent_rule);
	}
	
	public void burm( burmTest.TestINode root) throws java.lang.Exception
	{
		/* Use the least-cost goal state available. */
		burm(root, 0);
	}
	
	public void burm( burmTest.TestINode root, int goal_state) throws java.lang.Exception
	{
		JBurgAnnotation annotatedTree = label(root);
		reduce ( annotatedTree, goal_state);
	}
	
	public Object getResult( )
	{
		return __reducedValues.pop();
		
	}
	/**
 *  JBurgAnnotation is a data structure internal to the
	  JBurg-generated BURM that annotates a JBurgNode with
	  information used for dynamic programming and reduction.
	 */
	class JBurgAnnotation
	{
	/**
	 *  The cost/rule matrices are used during dynamic programming
	 *  to compute the most economical rules that can reduce
	 *  the input node.
	*/
	private int cost[];
	private int rule[];

	/**  Transformation rules may have antecedents: other states whose
	 *  output the transformation rule is intended to transform.
	 *  All such antecedent states must be executed in sequence when the rule is reduced.
	 */
	private int[] antecedentState = null;

	/** *  This node's children (may be empty).  */
	private java.util.Vector<JBurgAnnotation> m_children = null;
	/**  The INode we're annotating.  */
	
		burmTest.TestINode m_node; 
	JBurgAnnotation ( burmTest.TestINode newNode, int nRules) 
	{
		m_node = newNode;
		rule   = new int[nRules];
		cost   = new int[nRules];
		//  Initial cost of all rules is "infinite"
		java.util.Arrays.fill ( cost, Integer.MAX_VALUE);
		//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array.
	}

	 /** @return this node's operator. */
	public int getOperator() { return m_node.getOperator(); }

	 /** @return this node's wrappedburmTest.TestINode. */ 
	public burmTest.TestINode getNode()  { return m_node; }

	/** @return the nth child of this node.  */

	public JBurgAnnotation getNthChild(int idx)
	{
		if ( m_children != null && m_children.size() > idx) {
			return (JBurgAnnotation) m_children.elementAt(idx);
		} else {
			throw new IllegalArgumentException( "Index out of range:" + Integer.toString(idx) );
		}
	}

	/** @return this node's child count.  */

	public int getArity()
	{
		return m_children != null? m_children.size():0;
	}

	/** Add a new child to this node.  */

	public void addChild(JBurgAnnotation new_child)
	{
		if (m_children == null)
			m_children = new java.util.Vector<JBurgAnnotation>();
		if (new_child != null)
			m_children.add(new_child);
	}

	/** @return the wrapped node's toString().  */
	public String toString() { return m_node.toString(); } 
	/** @return the current best cost to reach a goal state.  */
	public int getCost( int goalState ) { return cost[goalState]; }

	 /** Set the cost/rule configuration of a goal state.
	 * @throws IllegalArgumentException if this node has a fixed cost/rule.
	*/
	 public void reset ( int goalState, int cost, int rule )
	{
		this.cost[goalState] = cost;
		this.rule[goalState] = rule;
		//  We have a brand new rule, therefore it has no antecedents.
		if ( this.antecedentState != null )
			this.antecedentState[goalState] = 0;
	}

	/** * @return the rule to fire for a specific goal state. */
	public int getRule ( int goalState ) { return rule[goalState]; }

	 /**
	 *  A closure's transformation rule succeeded.
	 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
	 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
	 *  transition back to a goal state that has already been reduced).
	*/
	public void recordAntecedent ( int iGoalState, int newAntecedentState )
	{
		int antecedentRule = rule[newAntecedentState];
		//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled.
		if ( antecedentRule == 0 )
			throw new IllegalStateException ( "Attempting to record an unlabelled antecedent state." );
		if ( antecedentRule == 1 )
		{
			//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run.
			if ( antecedentState != null )
				antecedentState[iGoalState] = antecedentState[newAntecedentState];
			}
		else
		
			{
				if ( antecedentState == null )
					antecedentState = new int[rule.length];
			}
		antecedentState[iGoalState] = newAntecedentState;
	}

	 /** @return the antecedent to the given goal state. */
	public int getAntecedent(int iGoalState)
	{
		if ( antecedentState != null )
			return antecedentState[iGoalState];
		else
			return 0;
	}
		/* @return true if the given goal state has an antecdent. */
		
		public boolean hasAntecedent( int iGoalState)
		{
			return ( antecedentState != null && getAntecedent(iGoalState) != 0 );
		}
	
	}
	
	static class JBurgSubgoal
	{
		private int goalState;
		
		private boolean isNary;
		
		private int startIndex;
		
		private int[] accessPath;
		
		
		public JBurgSubgoal( int goal_state, boolean is_nary, int start_index, int... access_path)
		{
			this.goalState = goal_state;
			this.isNary = is_nary;
			this.startIndex = start_index;
			this.accessPath = access_path;
		}
		public int getGoalState() { return this.goalState; }
		public boolean isNary() { return this.isNary; }
		public JBurgAnnotation getNode(JBurgAnnotation root)
		{
			JBurgAnnotation result = root;
			for ( int idx: this.accessPath )
				result = result.getNthChild(idx);
			return result;
		}
	
	}

}