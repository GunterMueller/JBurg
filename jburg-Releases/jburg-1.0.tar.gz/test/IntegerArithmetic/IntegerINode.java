import java.util.Vector;

/**
 *  A simple type of I-node that carries integer values.
 */
public class IntegerINode
	implements IntegerINodeTypes
{
	Integer m_int_value;

	int m_opcode;

	Vector m_children;

	public IntegerINode(int opcode)
	{
		m_opcode    = opcode;
		m_int_value = null;
		m_children  = new Vector();
	}

	public IntegerINode(int opcode, IntegerINode left, IntegerINode right )
	{
		this(opcode);

		addChild(left);
		addChild(right);
	}


	public IntegerINode(Integer iValue)
	{
		m_opcode    = INTEGER_LITERAL;
		m_int_value = iValue;
	}

	public void addChild(IntegerINode child)
	{
		m_children.add(child);
	}

	public Integer integerLiteral()
	{
		if ( null == m_int_value )
		{
			throw new IllegalStateException("not integer literal");
		}

		return m_int_value;
	}

	public IntegerINode getNthChild(int idx)
	{
		if ( idx >= 0 && idx < m_children.size() )
			return (IntegerINode)m_children.elementAt(idx);
		else
			throw new IllegalArgumentException("index out of range: " + Integer.toString(idx));
	}

	public int getOperator() { return m_opcode; }

	public int getArity()
	{
		if ( m_children != null )
		{
			return m_children.size();
		}
		else
			return 0;
	}

	public String toString()
	{
		StringBuffer result = new StringBuffer();

		result.append("op=");
		result.append(Integer.toString(getOperator()));

		if ( m_int_value != null )
		{
			result.append (", value=");
			result.append ( m_int_value.toString());
		}
		else if ( m_children.size() > 0 )
		{
			result.append("(");
			for ( int i = 0; i < m_children.size(); i++ )
			{
				if ( i > 0 )
					result.append(", ");
				result.append(m_children.elementAt(i).toString());
			}
			result.append(")");
		}

		return result.toString();
	}
}
