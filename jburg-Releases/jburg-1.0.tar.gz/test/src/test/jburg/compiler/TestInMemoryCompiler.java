package test.jburg.compiler;

import java.lang.reflect.*;
import jburg.compiler.InMemoryCompiler;

public class TestInMemoryCompiler
{
   public static void main ( String[] argv )
    throws Exception
   {
    InMemoryCompiler compiler = new InMemoryCompiler();

    Class clazz = compiler.compile
        (
            "public class Hello {" +
            "  public String toString()" +
            "  { return ( \"Hello from memory!\" ); }" +
            "}"
        );

    Object foo = clazz.newInstance();
    System.out.println(foo.toString());
   }
}
