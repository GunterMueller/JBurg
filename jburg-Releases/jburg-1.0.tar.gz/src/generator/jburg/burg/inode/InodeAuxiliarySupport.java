package jburg.burg.inode;

public interface InodeAuxiliarySupport
{
	public void emitAuxiliarySupport(jburg.burg.emitlangs.EmitLang emitter, java.io.PrintStream output);
}
