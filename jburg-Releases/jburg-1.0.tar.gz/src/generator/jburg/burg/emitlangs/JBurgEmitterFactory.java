package jburg.burg.emitlangs;

import java.util.Enumeration;
import java.util.Vector;

import jburg.burg.JBurgGenerator;
import jburg.burg.JBurgUtilities;

/**
 *  The JBurgEmitterFactory searches for an emitter that can
 *  emit the specified language using i-nodes of the given class.
 *  @author Nick Brereton -- original implementation.
 *  @author Tom Harwood -- maintenance, split out of JBurgGenerator into a factory.
 *  
 */
public class JBurgEmitterFactory
{
	/**
	 * Find a suitable EmitLang interface class to deal with the language we want to emit
	 * @param language the target language.
	 * @param iNodeClass the intput i-node class.
	 * @return vector of classes
	 */
	public static EmitLang getEmitter( String langname )
	{
		Vector candidates = JBurgUtilities.getInterfaceImpls(EmitLang.class);

		if(candidates==null) return null;
		
		for(Enumeration walker=candidates.elements(); walker.hasMoreElements();) {
			try {
				Class cl = (Class)walker.nextElement();

				//  Skip emitters that cannot be instantiated; these include
				//  abstract superclasses and the BURG's own emitter for 
				//  its pattern-matching rules, which needs special setup
				//  and would malfunction if it were ever selected this way.
				if ( isEmitterSuperclass(cl) )
				{
					continue;
				}
				
				try
				{
					EmitLang el = (EmitLang)ClassLoader.getSystemClassLoader().loadClass(cl.getName()).newInstance();

					if ( el.accept(langname) )
					{
						System.out.println("Using Language Adaptor : "+el.getClass().getName());
						return el;
					}
				} catch(InstantiationException e) {
					System.err.println("Unable to instantiate possible language class!");
					System.err.println(e);
				} catch(IllegalAccessException e) {
					System.err.println("IllegalAccessException: see info:");
					System.err.println(e);
				}
			}  catch(ClassNotFoundException e) {
				System.err.println("Class does not appear to exist in CLASSPATH");
				System.err.println(e);
			}
		}
		
		return null;
	}


	private static boolean isEmitterSuperclass(Class cl)
	{
		return 
			cl.getName().equals("jburg.burg.emitlangs.DelegatingEmitter")
			||
			cl.getName().equals("jburg.burg.emitlangs.EmitINodeASTTargetJava")
			;
	}
}
