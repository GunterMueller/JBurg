package jburg.compiler.tl1;

import java.io.File;

import jburg.compiler.tl1.ir.TL1INode;
import jburg.compiler.tl1.parser.TL1Parser;
import jburg.compiler.tl1.emitter.TL1Reducer;

import org.apache.bcel.generic.*;

/**
 *  TL1Compiler is a static class that manages plumbing for
 *  the parsing and code emitting phases of the TL/1 compiler.
 */
public class TL1Compiler
implements org.apache.bcel.Constants
{
   //  FIXME: TL/1 classes are always a subclass of the TL/1
   //  runtime support class, but that might not be the case
   //  in a more complex compiler.
   final public static String   TL1superclass = "jburg.test.tl1.runtime.Runtime";

   public static void main ( String[] args )
   {
    try
    {
        String inputName = args[0];
        compile(inputName);
    }
    catch ( Exception ex )
    {
        ex.printStackTrace();
        System.exit(1);
    }
   }

   /**
    *  Compile an input file to a .class file on disk.
    *  @param inputName - the name of the input .tl1 TL/1 source file.
    */
   private static void compile ( String inputName )
   throws Exception
   {
    String className;

    if ( inputName.length() > 4 && inputName.substring(inputName.length() - 4).equalsIgnoreCase(".tl1") )
    {
        className = inputName.substring(0, inputName.length() - 4);
    }
    else
    {
        className = inputName;
    }

    //  Call the JavaCC parser.
    TL1INode root = TL1Parser.parse(new File(inputName));

    //  Create a new BCEL ClassGen object to generate bytecode.
    ClassGen classGen =
        new ClassGen
        (
            className,
            TL1superclass,
            inputName,
            ACC_PUBLIC | ACC_FINAL | ACC_SUPER,
            null
        );

    TL1Reducer emitter = new TL1Reducer();

    //  The TL/1 emitter needs to know the classGen to be used,
    //  the class' name, and the superclass' name.
    //  The JBurg specification added these set methods through
    //  its BURMproperty directive.
    emitter.setClassgen       ( classGen );
    emitter.setCp             ( classGen.getConstantPool() );
    emitter.setClassname      ( className );
    emitter.setSuperclassname ( TL1superclass );

    //  Generate code.
    //  The emitter takes the tree as input, and works
    //  by side effect on the compiler's classGen object.
    emitter.burm(root);

    //  Graft on a main routine and a no-args <init> method.
    appendMain ( classGen, className, TL1superclass );

    //  Write the class out to disk.
    classGen.getJavaClass().dump ( className + ".class" );
   }

   /**
    * Append a main(String[]) method and a no-args constructor to the class.
    */
   static private void appendMain ( ClassGen cg, String className, String superclassName )
   {
    ConstantPoolGen cp = cg.getConstantPool();

    InstructionList il = new InstructionList();

    //  main() constructs a new object of this TL/1 class and calls its TL1Main method.

    il.append ( new NEW ( cp.addClass ( className ) ) );
    il.append ( new DUP() );
    il.append ( new INVOKESPECIAL ( cp.addMethodref ( className, "<init>", "()V" ) ) );

       il.append ( new INVOKEVIRTUAL ( cp.addMethodref ( className, "TL1main", "()V" ) ));
    il.append ( new RETURN() );

    MethodGen method = new MethodGen(
            ACC_STATIC | ACC_PUBLIC,
            Type.VOID,
            new Type[] { new ArrayType(Type.STRING, 1) },
            null,
            "main",
            className,
            il,
            cp );

    method.setMaxLocals();
    method.setMaxStack(2);

    cg.addMethod(method.getMethod());

    //  Add a default <init> constructor.
    //  BCEL provides a convenience method, addEmptyConstructor(),
    //  that does the same thing, but the code is spelled out here
    //  as an example //  and to show that a constructor is simply
    //  a method, at the bytecode level.
    il = new InstructionList();

    il.append ( new ALOAD(0) );
    il.append ( new INVOKESPECIAL ( cp.addMethodref ( superclassName, "<init>", "()V" ) ) );
    il.append ( new RETURN() );

    method = new MethodGen(
            ACC_PRIVATE,
            Type.VOID,
            new Type[0],
            null,
            "<init>",
            className,
            il,
            cp );

    method.setMaxLocals();
    method.setMaxStack(1);

    cg.addMethod(method.getMethod());

   }
}
