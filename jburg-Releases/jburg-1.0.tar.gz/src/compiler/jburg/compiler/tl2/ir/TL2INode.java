package jburg.compiler.tl2.ir;

import java.util.Hashtable;

import jburg.compiler.tl2.parser.TL2ParserConstants;
import jburg.compiler.tl2.parser.Token;

import jburg.compiler.tl2.semanticanalysis.AbstractClass;

/**
 *  TL2INode is the TL/2 compiler's abstract syntax tree node,
 *  suitable for use as input to a JBurg-generated BURM.
 */
public class TL2INode
implements TL2ParserConstants, TL2CompilerConstants
{
   /**  Left child and/or "car" */
   private TL2INode left;

   /**  Right child and/or "cdr" */
   private TL2INode right;

   /**
    *  The Token (if any) that represents the syntactic
    *  construct that generated this node.
    */
   Token startToken;

   /**
    *  An explicitly set opcode, used by nodes without a
    *  specific start token.
    */
   int opcode = NO_OPCODE;

   /**
    * The INode's table of attributes.
    * May be null if no attributes are present.
    */
   private Hashtable attributes;

   /**
    *  Construct a TL2INode with a particular opcode.
    *  @param opcode - the opcode for this node.
    */
   public TL2INode ( int opcode )
   {
    this.opcode = opcode;
   }

   /** Copy constructor. */
   public TL2INode ( TL2INode src )
   {
    this.left       = src.left;
    this.right      = src.right;
    this.startToken = src.startToken;
    this.opcode     = src.opcode;
    this.attributes = src.attributes;
   }

   /**
    *  Construct a TL2INode with a particular opcode and known children
    *  @param opcode - the opcode for this node.
    *  @param left - the left child/car
    *  @param right - the right child/cdr
    */
   public TL2INode ( int opcode, TL2INode left, TL2INode right )
   {
    this(opcode);

    setLeftChild  (left);
    setRightChild (right);
   }

   /**
    *  Construct a node that represents a syntactic construct.
    *  @param startToken - the token that represents the construct.
    */
   public TL2INode ( Token startToken )
   {
    setStartToken ( startToken );
   }

   /**
    *  Construct a node that represents a syntactic construct with known children.
    *  @param startToken - the token that represents the construct.
    *  @param left - the left child/car
    *  @param right - the right child/cdr
    */
   public TL2INode ( Token startToken, TL2INode left, TL2INode right )
   {
    this ( startToken );

    setLeftChild  (left);
    setRightChild (right);
   }

   /**
    *  Set this node's startToken.
    */
   public void setStartToken ( Token t )
   {
    this.startToken = t;
   }

   /**
    *  @return this node's start token, or null if it's not set.
    */
   public Token getStartToken()
   {
    return this.startToken;
   }

   /**
    *  Set this node's left child/"car".
    */
   public void setLeftChild ( TL2INode left )
   {
    this.left = left;
   }

   /**
    *  Set this node's right child/"cdr".
    */
   public void setRightChild ( TL2INode right )
   {
    this.right = right;
   }

   /**
    *  @return this node's right child/"cdr".
    */
   public TL2INode rightChild()
   {
    return this.right;
   }


   /**
    *  @return this node's left child/"car".
    */
   public TL2INode leftChild()
   {
    return this.left;
   }

   /**
    *  Set this node's operator.  The newly set operator
    *  will override the start token's operator, if any.
    */
   public void setOperator(int opcode)
   {
    this.opcode = opcode;
   }

   /**
    *  @return this node's operator, looking first for
    *    an explicitly set operator, then looking at the
    *    start token.
    */
   public int getOperator()
   {
    if ( this.opcode != NO_OPCODE )
        return this.opcode;
    else
        return this.startToken.kind;
   }

   public void insert ( int newNodeOpcode )
   {
    this.left = new TL2INode(this);
    this.right = null;

    setOperator ( newNodeOpcode );
   }

   /**
    *  @return a String representation of this node, suitable for use in debugging.
    */
   public String toString()
   {
    return
    (
         (this.startToken != null)?
            this.startToken.image :
            "[" + getOperator() + "]"
    );
   }

   /**
    *  @return the int value of an INTEGER_LITERAL.
    */
   public int intValue()
   {
    if ( getOperator() != INTEGER_LITERAL )
        throw new IllegalStateException( "Operator " + getOperator() + " is not INTEGER_LITERAL");

    return Integer.parseInt(getStartToken().image);
   }

   /**
    * @return true if the specified attribute exists.
    */
   public boolean containsKey ( Object key )
   {
    if ( this.attributes != null )
        return this.attributes.containsKey(key);
    else
        return false;
   }

   /**
    * @return the value of the specified attribute, or <code>null</code> if it doesn't exist.
    */
   public Object getAttribute ( Object key )
   {
    if ( this.attributes != null )
        return this.attributes.get(key);
    else
        return null;
   }

   public String getStringAttribute ( Object key )
   {
    Object value = getAttribute(key);

    if ( value != null )
    {
        if ( value instanceof Token )
            return ((Token)value).image;
        else
            return value.toString();
    }

    return null;
   }

   /**
    * Set the value of an attribute.
    */
   public Object putAttribute ( Object key, Object value )
   {
    if ( this.attributes == null )
        this.attributes = new Hashtable();

    return this.attributes.put ( key, value );
   }

   public void putUniqueAttribute ( Object key, Object value )
   {
    if ( putAttribute ( key, value ) != null )
    {
        throw new IllegalStateException ( "Attribute " + key + " may only be specified once." );
    }
   }

   public Symbol getSymbol()
   {
    return (Symbol) getAttribute(IDENTIFIER_SYMBOL);
   }

   public AbstractClass getNodeClass()
   {
    return (AbstractClass) getAttribute(NODE_CLASS);
   }

	/**
	 *  @return the child at the specified index.
	 */
	public TL2INode getNthChild(int idx)
	{
		switch(idx)
		{
			case 0:
				return leftChild();
			case 1:
				return rightChild();
			default:
				throw new IllegalArgumentException(
					"Index out of range: " + Integer.toString(idx)
				);
		}
	}

	public int getArity()
	{
		if ( null == left )
			return 0;
		else if ( null == right )
			return 1;
		else
			return 2;
	}
}
