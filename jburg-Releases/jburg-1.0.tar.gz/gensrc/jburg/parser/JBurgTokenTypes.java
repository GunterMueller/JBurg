// $ANTLR 2.7.5 (20050128): "jburg.g" -> "JBurgANTLRLexer.java"$

package jburg.parser;


public interface JBurgTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int COST_FUNCTION = 4;
	int FUNCTION_CALL = 5;
	int HEADER_DECLARATION = 6;
	int IMPLEMENTS_INTERFACE_SPECIFICATION = 7;
	int INCLASS_DECLARATION = 8;
	int INODE_ADAPTER_DECLARATION = 9;
	int INODE_TYPE_DECLARATION = 10;
	int LANGUAGE_DECLARATION = 11;
	int MULTIPART_IDENTIFIER = 12;
	int NON_TERMINAL_PARAMETER = 13;
	int OPERATOR_SPECIFICATION = 14;
	int OPERAND_LIST_KNOWN_ARITY = 15;
	int OPERAND_LIST_ARBITRARY_ARITY = 16;
	int PACKAGE_SPECIFICATION = 17;
	int PATTERN_SPECIFICATION = 18;
	int PATTERN_RULE = 19;
	int PROPERTY_SPECIFICATION = 20;
	int RETURN_DECLARATION = 21;
	int SIMPLE_COST_SPEC = 22;
	int SIMPLE_TRANSFORMATION_RULE = 23;
	int TRANSFORMATION_RULE = 24;
	int TERMINAL_RULE = 25;
	int TYPED_RETURN_DECLARATION = 26;
	int IDENTIFIER = 27;
	int LPAREN = 28;
	int RPAREN = 29;
	int BLOCK = 30;
	int COLON = 31;
	int LITERAL_header = 32;
	int LITERAL_INodeAdapter = 33;
	int SEMI = 34;
	int LITERAL_INodeType = 35;
	int LITERAL_Language = 36;
	int LITERAL_implements = 37;
	int PERIOD = 38;
	int STAR = 39;
	int COMMA = 40;
	int PLUS = 41;
	int LITERAL_package = 42;
	int LITERAL_BURMProperty = 43;
	int LITERAL_ReturnType = 44;
	int EQUALS = 45;
	int INT = 46;
	int LITERAL_void = 47;
	int STRING_LITERAL = 48;
	int WS = 49;
	int COMMENT = 50;
	int ML_COMMENT = 51;
	int DIGIT = 52;
}
