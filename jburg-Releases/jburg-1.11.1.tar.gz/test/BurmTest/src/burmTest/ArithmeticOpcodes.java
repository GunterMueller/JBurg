package burmTest;

public interface ArithmeticOpcodes
{
    public static int ADD = 1;
    public static int INT = ADD + 1;
    public static int PAREN = INT + 1;
    public static int REGION = PAREN + 1;
}
