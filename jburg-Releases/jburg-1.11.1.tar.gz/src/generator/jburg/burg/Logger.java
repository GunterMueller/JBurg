package jburg.burg;

/**
 *  A simple message logging facility.
 */
public class Logger
{

    protected boolean logInfo;
    protected boolean logWarning;
    protected boolean logError;

    protected int errorCount = 0;

    protected Logger(boolean log_info, boolean log_warning, boolean log_error)
    {
        this.logInfo = log_info;
        this.logWarning = log_warning;
        this.logError = log_error;
    }

    /** Log an informational message. */
    public void info(String msg )
    {
        if ( logInfo )
            System.out.println(msg);
    }

    /** Log a warning. */
    public void warning(String wmsg)
    {
        if ( this.logWarning )
            System.err.println("Warning: " + wmsg);
    }

    /** Log an error. */
    public void error(String emsg)
    {
        if ( this.logError )
            System.err.println("Error: " + emsg);
        this.errorCount++;
    }

    /** Log an exception. */
    public void exception(String context, Exception ex)
    {
        if ( this.logError )
        {
            System.err.println("Exception: " + context);
            ex.printStackTrace();
        }
        this.errorCount++;
    }
}
