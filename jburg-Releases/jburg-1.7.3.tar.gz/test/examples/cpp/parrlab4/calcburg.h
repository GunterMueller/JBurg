/*  Generated Mon Nov 01 17:13:38 EDT 2010 by JBurg version 1.6.0 */

#include <iostream>
#include <string>
#include <stack>
#include <exception>
#include <memory>
#include <sstream>
#include "jburgsupp.h"

#include <iostream>
#include <antlr/AST.hpp>
#include "CalcParserTokenTypes.hpp"

class calcburg: public CalcParserTokenTypes
{
private:

	std::stack<void*> __reducedValues;

	int	*antecedentRules;

public:

	calcburg() {
		antecedentRules = new int[nStates];
	}

	~calcburg() {
		if( antecedentRules ) delete[] antecedentRules;
	}



public:
	int regnum;

public:
static const int __stmt_NT = 1;
public:
static const int __addr_NT = 2;
public:
static const int __identifier_NT = 3;
public:
static const int __reg_NT = 4;
public:
static const int __constant_NT = 5;
public:
static const int nStates = 5;
public:
JBurgAnnotation<null>* label( * to_be_labelled )
{
	JBurgAnnotation<null>* result = NULL;
	int i;
	int arity;
	if ( to_be_labelled )
	{
		result = new JBurgAnnotation<null>(to_be_labelled,nStates + 1);
		arity = getArityOf(to_be_labelled);
		i = 0;
		while ( ( arity > i ) )
		{
			
			result->addChild(this->label(((*)getNthChild(to_be_labelled, i))));
			i =  (i + 1) ;
			
		}
		this->computeCostMatrix(result);
		
	}
	return (result);
	
}
private:
void computeCostMatrix( JBurgAnnotation<null>* node )
{
	int iCost;
	switch( node->getOperator() )
	{
		case EQUALS:
		{
			
			if ( node->getArity()==2 && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(__addr_NT) )  && ( MAX_INT_VALUE > node->getNthChild(1)->getCost(__reg_NT) )  )
			{
				
				iCost =  (1 +  (node->getNthChild(1)->getCost(__reg_NT) + node->getNthChild(0)->getCost(__addr_NT)) ) ;
				if ( ( node->getCost(__stmt_NT) > iCost )  )
				{
					
					/* Matched EQUALS ==> stmt */

					node->reset(__stmt_NT, iCost, 2);
					node->addSubgoal(__stmt_NT, node->getNthChild(1), __reg_NT);
					node->addSubgoal(__stmt_NT, node->getNthChild(0), __addr_NT);
					
				}
				
			}
			break;
		}
		case ADDR:
		{
			
			if ( node->getArity()==1 && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(__identifier_NT) )  )
			{
				
				iCost =  (1 + node->getNthChild(0)->getCost(__identifier_NT)) ;
				if ( ( node->getCost(__addr_NT) > iCost )  )
				{
					
					/* Matched ADDR ==> addr */

					node->reset(__addr_NT, iCost, 11);
					node->addSubgoal(__addr_NT, node->getNthChild(0), __identifier_NT);
					
				}
				
			}
			break;
		}
		case IND:
		{
			
			if ( node->getArity()==1 && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(__addr_NT) )  )
			{
				
				iCost =  (1 + node->getNthChild(0)->getCost(__addr_NT)) ;
				if ( ( node->getCost(__reg_NT) > iCost )  )
				{
					
					/* Matched IND ==> reg */

					node->reset(__reg_NT, iCost, 8);
					node->addSubgoal(__reg_NT, node->getNthChild(0), __addr_NT);
					
				}
				
			}
			break;
		}
		case MINUS:
		{
			
			if ( node->getArity()==2 && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(__reg_NT) )  && ( MAX_INT_VALUE > node->getNthChild(1)->getCost(__reg_NT) )  )
			{
				
				iCost =  (1 +  (node->getNthChild(1)->getCost(__reg_NT) + node->getNthChild(0)->getCost(__reg_NT)) ) ;
				if ( ( node->getCost(__reg_NT) > iCost )  )
				{
					
					/* Matched MINUS ==> reg */

					node->reset(__reg_NT, iCost, 5);
					node->addSubgoal(__reg_NT, node->getNthChild(1), __reg_NT);
					node->addSubgoal(__reg_NT, node->getNthChild(0), __reg_NT);
					
				}
				
			}
			break;
		}
		case ZERO:
		{
			
			if ( node->getArity()==0 )
			{
				
				iCost = 0;
				if ( ( node->getCost(__reg_NT) > iCost )  )
				{
					
					/* Matched ZERO ==> reg */

					node->reset(__reg_NT, iCost, 7);
					
				}
				
			}
			break;
		}
		case DECL:
		{
			
			if ( node->getArity()==1 && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(__identifier_NT) )  )
			{
				
				iCost = node->getNthChild(0)->getCost(__identifier_NT);
				if ( ( node->getCost(__stmt_NT) > iCost )  )
				{
					
					/* Matched DECL ==> stmt */

					node->reset(__stmt_NT, iCost, 3);
					node->addSubgoal(__stmt_NT, node->getNthChild(0), __identifier_NT);
					
				}
				
			}
			break;
		}
		case PLUS:
		{
			
			if ( node->getArity()==2 && ( MAX_INT_VALUE > node->getNthChild(0)->getCost(__reg_NT) )  && ( MAX_INT_VALUE > node->getNthChild(1)->getCost(__reg_NT) )  )
			{
				
				iCost =  (1 +  (node->getNthChild(1)->getCost(__reg_NT) + node->getNthChild(0)->getCost(__reg_NT)) ) ;
				if ( ( node->getCost(__reg_NT) > iCost )  )
				{
					
					/* Matched PLUS ==> reg */

					node->reset(__reg_NT, iCost, 4);
					node->addSubgoal(__reg_NT, node->getNthChild(1), __reg_NT);
					node->addSubgoal(__reg_NT, node->getNthChild(0), __reg_NT);
					
				}
				
			}
			break;
		}
		case INT:
		{
			
			if ( node->getArity()==0 )
			{
				
				iCost = 0;
				if ( ( node->getCost(__constant_NT) > iCost )  )
				{
					
					/* Matched INT ==> constant */

					node->reset(__constant_NT, iCost, 9);
					closure_constant(node, iCost);
					
				}
				
			}
			break;
		}
		case ID:
		{
			
			if ( node->getArity()==0 )
			{
				
				iCost = 0;
				if ( ( node->getCost(__identifier_NT) > iCost )  )
				{
					
					/* Matched ID ==> identifier */

					node->reset(__identifier_NT, iCost, 10);
					
				}
				
			}
			break;
		}
		
	}
	
}
private:
void closure_constant( JBurgAnnotation<null>* __p, int c )
{
	int iCost;
	iCost =  (c + 1) ;
	if ( ( __p->getCost(__reg_NT) > iCost )  )
	{
		__p->reset(__reg_NT, iCost, 6);
		__p->recordAntecedent(__reg_NT, __constant_NT);
		
	}
	
}

/* stmt */
private:
int action_2( * __p )
{
	

	int r((int)__reducedValues.top());
	__reducedValues.pop();
	

	int a((int)__reducedValues.top());
	__reducedValues.pop();
	
		{
			std::cout << "\tsw\tr" << r << ", (r" << a << ")" << std::endl;
			return 0;
		}
}

/* stmt */
private:
int action_3( * __p )
{
	

	std::auto_ptr<std::string> id((std::string*)__reducedValues.top());
	__reducedValues.pop();
	
		{
			std::cout << "\t.comm\t" << *id << ", 4" << std::endl;
			return 0;
		}
}

/* reg */
private:
int action_4( * __p )
{
	

	int r2((int)__reducedValues.top());
	__reducedValues.pop();
	

	int r1((int)__reducedValues.top());
	__reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tadd\tr" << r << ", r" << r1 << ", r" << r2 << std::endl;
			return r;
		}
}

/* reg */
private:
int action_5( * __p )
{
	

	int r2((int)__reducedValues.top());
	__reducedValues.pop();
	

	int r1((int)__reducedValues.top());
	__reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tsub\tr" << r << ", r" << r1 << ", r" << r2 << std::endl;
			return r;
		}
}

/* reg */
private:
int action_6( * __p )
{
	

	int constant((int)__reducedValues.top());
	__reducedValues.pop();
	
		{
			int r = regnum++;
			// hmmm, I don't seem to have any use for 'constant' directly...
			std::cout << "\tla\tr" << r << ", " << constant << std::endl;
			return r;
		}
}

/* reg */
private:
int action_7( * __p )
{
	
		{
			return 0;
		}
}

/* reg */
private:
int action_8( * __p )
{
	

	int a((int)__reducedValues.top());
	__reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tlw\tr" << r << ", (r" << a << ")" << std::endl;
			return r;
		}
}

/* constant */
private:
int action_9( * __p )
{
	
		{
			return atoi(__p->getText().c_str());
		}
}

/* identifier */
private:
std::string* action_10( * __p )
{
	
		{ return new std::string ( __p->getText().c_str() ); }
}

/* addr */
private:
int action_11( * __p )
{
	

	std::auto_ptr<std::string> id((std::string*)__reducedValues.top());
	__reducedValues.pop();
	
		{
			int r = regnum++;
			std::cout << "\tla\tr" << r << ", " << *id << std::endl;
			return r;
		}
}
private:
void dispatchAction( * __p, int iRule )
{
	switch( iRule )
	{
		case 1:
		{
			/* Don't reduce or touch the stack. */

			break;
		}
		case 2:
		{
			__reducedValues.push( (void*)(this->action_2(__p)));
			break;
		}
		case 3:
		{
			__reducedValues.push( (void*)(this->action_3(__p)));
			break;
		}
		case 4:
		{
			__reducedValues.push( (void*)(this->action_4(__p)));
			break;
		}
		case 5:
		{
			__reducedValues.push( (void*)(this->action_5(__p)));
			break;
		}
		case 6:
		{
			__reducedValues.push( (void*)(this->action_6(__p)));
			break;
		}
		case 7:
		{
			__reducedValues.push( (void*)(this->action_7(__p)));
			break;
		}
		case 8:
		{
			__reducedValues.push( (void*)(this->action_8(__p)));
			break;
		}
		case 9:
		{
			__reducedValues.push( (void*)(this->action_9(__p)));
			break;
		}
		case 10:
		{
			__reducedValues.push( (void*)(this->action_10(__p)));
			break;
		}
		case 11:
		{
			__reducedValues.push( (void*)(this->action_11(__p)));
			break;
		}
		default:throw std::string("Unmatched reduce action " + iRule);
		
	}
	
}


	void reduce ( JBurgAnnotation<antlr::AST >* p, int goalState )
	{
		int iRule = -1;

		if ( goalState > 0 ) {
			iRule = p->getRule(goalState);
		} else {
			//  Find the minimum-cost path.
			int minCost = MAX_INT_VALUE;
			for (int i = 0; i <= nStates ; ++i ) {
				if ( p->getCost(i) < minCost ) {
					iRule = p->getRule(i);
					minCost = p->getCost(i);
					goalState = i;
				}
			}
		}

		if ( iRule > 0 )
		{
			
			reduceAntecedentStates(p, goalState);
			if ( p->isNary(goalState) )
			{
			/* Aggregate the operands of an n-ary operator into a single container. */std::vector<void*>* variadic_result = new std::vector<void*>;
			for ( int i = 0; i < p->getArity(); i++ )
			{
				reduce(p->getNthChild(i), p->getNarySubgoal(goalState));
				variadic_result->push_back(__reducedValues.top());
				__reducedValues.pop();
			}
			__reducedValues.push(variadic_result);
			}
			reduceSubgoals(p, goalState);

			dispatchAction ( p->getNode(), iRule );
		}
		else
		{
			std::stringstream s;
			s << "Unable to find a rule to process ";
			s << p->getNode()->toString();
			s << " (" << p->getOperator() << ") {" << goalState << "}";
			throw new std::runtime_error ( s.str() );
		}
	}

	void reduceAntecedentStates( JBurgAnnotation<antlr::AST >* p, int goalState)
	{
		int   currentState = goalState;
		std::vector<int> antecedent_states;
		std::vector<int> antecedent_rules;

		//  If X is antecedent of Y, then the reduce action
		//  for X must occur before the reduce action of Y.
		//  The antecdents must therefore be processed 
		//  from "back" to "front."
		while ( p->hasAntecedent(currentState)  )
		{
			currentState = p->getAntecedent(currentState);
			antecedent_states.push_back(currentState);
			antecedent_rules.push_back(p->getRule(currentState));
		}
		while ( ! antecedent_states.empty() )
		{
			reduceSubgoals(p, antecedent_states.back());
			dispatchAction( p->getNode(), antecedent_rules.back());
			antecedent_states.pop_back();
			antecedent_rules.pop_back();
		}
	}
	void reduceSubgoals( JBurgAnnotation<antlr::AST >* p, int goalState)
	{
	/* Reduce subgoals in reverse order so they get pushed onto the stack */
	/* in the order expected by the action routines. */
		for ( int i = p->getSubgoalsSize(goalState) - 1; i >= 0; i-- )
		{
			JBurgAnnotation<antlr::AST >::JBurgSubgoal sg = p->getSubgoals(goalState)[i];
			reduce ( sg.getNode(), sg.getGoalState());
		}
	}

public:

	void burm ( antlr::AST* root )
	{		burm(root,0);	}	void burm ( antlr::AST* root, int goal_state )
	{
		JBurgAnnotation<antlr::AST >* annotatedTree = label(root);
		reduce ( annotatedTree, goal_state);
		delete annotatedTree;
	}private:
int getArityOf( * node )
{
	* cnode = NULL;
	int result = 0;
	for ( cnode = node->getFirstChild(); cnode != NULL; cnode = cnode->getNextSibling() ) { result++; }
	return (result);
	
}
private:
* getNthChild( * node, int idx )
{
	* result = NULL;
	int i = 0;
	for ( i = 0, result = node->getFirstChild(); result != NULL && i < idx; result = result->getNextSibling() ) { i++; }
	return (result);
	
}

int getNaryCost( JBurgAnnotation<antlr::AST>* node, int goalState)
{
	int i = 0;
	int accum = 0;
	
	for ( i = 0; i < node->getArity(); i++ )
	{
		
		accum += node->getCost(goalState);
		
	}
	
	return (accum);
	
}


};
