package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import jburg.burg.JBurgPatternMatcher;

/*
 * Interface for code emmision
 */

public interface EmitLang
{
	/**
	 * Return true if based on the language and iNode class, this emitter can process the specification.
	 * @param languageName Name specifed by the 'Language' qualifier in the spec
	 * @return true if emitter handles this language (nb: on null or zero length EmitJava will trigger true)
	 */
	abstract public boolean accept(String languageName );
	
	/**
	 *  Set the i-node adapter so the emitter can generate
	 *  code to access its relevant members.
	 */
	abstract public void setInodeAdapter(jburg.burg.inode.InodeAdapter adapter);
	
	/**
	 * Set the opcode type.
	 */
	abstract public void setOpcodeType(String opcode_type);
	
	/**
	 *  Set the i-node type.
	 */
	abstract public void setINodeType(String inode_type);

	/**
	 * Emit the file/class header information.
	 * @param strClassName  the name of the class to be generated.
	 * @param packageName  the name of the package or namespace, or null if no package/namespace is to be generated.
	 * @param headerBlock  Code to be copied as-is into the header section of a Java file.
	 * @param InterfaceNames  names of interfaces a Java class implements.
	 * @param debugMode  true ==> generate code that emits debugging information about the label and reduction passes.
	 * @param output
	 */
	abstract public void emitHeader(String strClassName, String packageName, String headerBlock, Vector InterfaceNames, boolean debugMode, PrintStream output);
	
	abstract public void emitStatics(int max_action, Map<Integer, Vector<JBurgPatternMatcher>> rules_by_action, PrintStream output);
	
	/**
	 * Emit verbatim code blocks that are intended to be part of the class definition.
	 * @param strClassName  the name of the class to be generated.
	 * @param inclassBlocks  A Vector of strings to be copied in verbatim.
	 * @param output  the stream that's writing the generated code.
	 */
	abstract public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output);

	/**
	 * Emit the reducer and finish the class definition.
	 * @param strClassName  the name of the class being generated.
	 * @param iNodeClass  the name of the class that represents the i-code DAG.
	 * @param subgoals  the states that this BURM may transition through.
	 * @param burm_properties  any properties (private fields and public get/set methods)
	 * @param debugMode  true ==&lt; generate debugging code that writes information about the generated class.
	 * @param output   the stream that's writing the generated code.
	 */
	abstract public void emitTrailer(String strClassName, String iNodeClass, Set<String> subgoals, Map<String, String> burm_properties, boolean debugMode, String default_error_handler, Map<Integer,String> prologue_blocks, PrintStream output);

	/**
	 * @return a string that represents the code in the taget language that will 
	 * get the top value of a stack and decrement the size of the stack 
	 * @param stackName variable name of the stack
	 * @param paramType type of the parameter to be retrieved
	 * @param paramName name of the parameter into which the stack is poped
	 * @param tabs string containing the sequence of white space to insert at the start of every line
	 * @return String containing the formated lines
	 */
	abstract public String genPopFromStack(String stackName, String paramType, String paramName, String tabs);

	/**
	 * @return a code snippet that pushes a value onto a stack of reduced values.
	 * @param stackName the name of the stack variable.  Type of the stack is assumed to be 
	 *    reasonably generic, e.g., java.util.Stack on Java implementations, std::stack&lt;void*&gt; in C++.
	 * @param value a code snippet that generates the value to be pushed.
	 */
	abstract public String genPushToStack(String stackName, String value );
	
	/**
	 * @return a String that gives the code to check if a reference is null
	 * @param paramName parameter to be checked
	 * @param checkForNull if true, check for a null pointer, if false check is true if not null
	 * @return String object containing relevent code fragment
	 */
	abstract public String genCheckPtr(String paramName, boolean checkForNull);
	
	/**
	 * Generate code for direct access to an object's member
	 * @param parentName name of the parent object
	 * @param memberName name of the parameter to access
	 * @return String object containing the code fragment to use
	 */
	abstract public String genAccessMember(String parentName, String memberName);
	
	/**
	 * Generate a clip that calls a method contained within an object.
	 * @param parentName name of the parent object
	 * @param methodName name of the method to call
	 * @param params list of the paramters for the call
	 * @return String containing the relevent code fragment
	 */
	abstract public String genCallMethod(String parentName, String methodName, String[] params);
	
	/**
	 * Generate a clip that compares two expressions. 
	 * @param lhs Expression to be placed on the left-hand side of the compare
	 * @param rhs Expression to be placed on the right-hand side of the compare
	 * @param bEquality set to true to compare for equality, false for non-equality
	 * @return String
	 */
	abstract public String genCmpEquality(String lhs, String rhs, boolean bEquality);

	/**  Manifest constant for genCmpEquality -- test for equality. */
	public static final boolean TEST_EQUALITY = true;

	/**  Manifest constant for genCmpEquality -- test for inequality. */
	public static final boolean TEST_INEQUALITY = false;
	
	/**
	 * Generate a clip that combines 2 expressions with a logical and
	 * @param lhs Expression to be placed on the left-hand side of the and
	 * @param rhs Expression to be placed on the right-hand side of the and
	 * @return String
	 */
	abstract public String genLogicalAnd(String lhs, String rhs);

	/**
	 * @return a code snippet that generates a logical if.
	 */
	abstract public String genIf( String condition );

	/**
	 * @return a code snippet that generates an "else" clause for a preceeding "if."
	 */
	abstract public String genElse();


	/**
	 * @return a code snippet that begins a block and resets indentation parameters.
	 */
	abstract public String genBeginBlock();

	/**
	 * @return a code snippet that ends a block and resets indentation parameters.
	 */
	abstract public String genEndBlock();

	/**
	 * @return a code snippet that ends a statement.
	 */
	abstract public String genEndStmt();

	/**
	 * @return a code snippet that starts a new line and indents.
	 */
	abstract public String genBeginLine();
	
	/**
	 * @return the given code snippet, properly indented on a new line.
	 */
	abstract public String genLine(String line);

	/**
	 * @return a code snippet that returns true if rhs is less than lhs.
	 */
	abstract public String genCmpLess( String lhs, String rhs );

	/**
     * @return a code snippet that returns true if lhs is greater than
     *   or equal to rhs.
     */
	abstract public String genCmpGtEq(String lhs, String rhs);
	
	/**
	 * @param operand
	 * @return a code snippet that negates the operand.
	 */
	abstract public String genNot( String operand );

	/**
	 * @return a code snippet that adds two values.
	 */
	abstract public String genAddition( String addend1, String addend2 );

	/**
	 * @return a code snippet that defines a local variable in a method.
	 * @param type the variable's type.
	 * @param name the name of the variable.
	 * @param initializer the variable's initial value.  May be null, in which case no initialization code is generated.
	 */
	abstract public String genLocalVar ( String type, String name, String initializer );

	/**
	 * @return a code snippet that defines an instance field.
	 * @param modifiers values of java.lang.reflect.Modifier that work here are PUBLIC|PRIVATE|PROTECTED, FINAL, STATIC
	 * @param type the field's type.
	 * @param name the name of the field.
	 * @param initializer the field's initial value.  May be null, in which case no initialization code is generated.
	 */
	abstract public String genInstanceField ( int modifiers, String type, String name, String initializer );

	/**
	 * @return a code snippet that creates a new object.
	 * @param type the new object's class.
	 * @param parameters an array of values (code snippets) to pass to the new object's constructor.
	 */
	abstract public String genNewObject( String type, String[] parameters );


	/**
	 * @return a code snippet that assigns a value to a variable.
	 * @param lvar the variable into which the value is stored.
	 * @param rvalue the value to store in the variable.
	 */
	abstract public String genAssignment( String lvar, String rvalue );

	/**
	 * @return a code snippet that casts a target expression to a new type.
	 * @param newType the type to cast to.
	 * @param target the expression whose value is to assume the new type.
	 */
	abstract public String genCast( String newType, String target );


	/**
	 * @return a code snippet that generates a comment.
	 * @param text the comment text.
	 */
	abstract public String genComment ( String text );


	/**
	 * @return a code snippet that gets the goal state of an i-node.
	 * @param p the i-node.
	 */
	abstract public String genGetGoalState ( Object p );


	/**
	 * @return a code snippet that starts a switch statement.
	 * @param selectionCriteron the expression to be switched on.
	 */
	abstract public String genBeginEnumeratedChoiceSet( String selectionCriterion );

	/**
	 * @return a code snippet that ends a switch statement.
	 */
	abstract public String genEndEnumeratedChoiceSet();

	/**
	 * @return a code snippet that starts a case in a multi-choice switch.
	 * @param selectionValue the value of this case.
	 */
	abstract public String genBeginChoiceCase( String selectionValue );

	/**
	 * @return a code snippet that generates the default case.
	 */
	abstract public String genDefaultChoiceCase();

	/**
	 * @return a code snippet that ends a case.
	 */
	abstract public String genEndChoiceCase();

	/**
	 * @return a code snippet that signals a runtime error.
	 * @param diagnostic the diagnostic content associated with the signal.
	 */
	abstract public String genSignalError ( String diagnostic );


	/**
	 * @return a code snippet that declares a method.
	 * @param modifiers values of java.lang.reflect.Modifier that work are PUBLIC, PRIVATE.
	 * @param returnClass the method's return type.
	 * @param name the method's name.
	 * @param plist an array of (type, name) parameter declarations.
	 * @param exceptions an array of exceptions that the method may throw.
	 * @note this method may change to emit the method header.
	 */
	abstract public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions );

	/**
	 * @return a code snippet that returns a value from a method.
	 * @param value the value to return.
	 */
	abstract public String genReturnValue( String value );

	/**
	 * @return a code snippet that represents the target's maximum integer value, the &quot;infinite&quot; cost.
	 */
	abstract public String genMaxIntValue();

	/**
	 * @return a code snippet that represents the target's null pointer value.
	 */
	abstract public String genNullPointer();

	/**
	 * @return a code snippet that generates a pre-test (while) loop.
	 */
	abstract public String genPreTestLoop( String test_condition );

	/**
	 * @return a code snippet that represents the target's generalized
	 *   container type, e.g., java.util.Vector or std::vector<void*>
	 */
	abstract public String genNaryContainerType(String base_type);
}
