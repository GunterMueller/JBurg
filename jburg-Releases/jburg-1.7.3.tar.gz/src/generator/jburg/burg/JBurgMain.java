package jburg.burg;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Hashtable;

import jburg.parser.*;

import antlr.CommonAST;
import antlr.Token;
import antlr.TokenStreamSelector;
import antlr.collections.AST;

public class JBurgMain
{
   public static void main(String[] args) 
   {

    boolean debugMode       = false;
    boolean syntaxCheckOnly = false;
	boolean dumpParseTree   = false;

    boolean logInfo = true;
    boolean logWarning = true;
    boolean logError = true;


    String strInputFile  = null;
    String strInputDir   = null;
    String strOutputFile = null;
    String strOutputDir  = null;

    int i;

	int errCount = 0;

    for ( i = 0; i < args.length; i++ )
    {
        if ( args[i].equalsIgnoreCase( "-g" ) )
        {
            debugMode = true;
        }
		else if ( args[i].equalsIgnoreCase( "-dumpspecification" ) )
        {
            dumpParseTree = true;
        }
        else if ( args[i].equalsIgnoreCase("-syntax") )
        {
            syntaxCheckOnly = true;
        }
        else if ( args[i].equalsIgnoreCase("-directory")  && i + 1 < args.length)
        {
            i++;
            strInputDir = strOutputDir = withFileSeparator(args[i]);
        }
        else if ( args[i].equalsIgnoreCase("-outputdir")  && i + 1 < args.length)
        {
            i++;
            strOutputDir = withFileSeparator(args[i]);
        }
        else if ( args[i].equalsIgnoreCase("-inputdir")  && i + 1 < args.length)
        {
            i++;
            strInputDir = withFileSeparator(args[i]);
        }
        else if ( args[i].equalsIgnoreCase("-specification") && i + 1 < args.length )
        {
            i++;
            strInputFile = args[i];
        }
        else if ( args[i].equalsIgnoreCase("-outputfile") && i + 1 < args.length )
        {
            i++;
            strOutputFile = args[i];
        }
        else if ( args[i].equalsIgnoreCase("-noInfo") )
        {
            logInfo = false;
        }
        else if ( args[i].equalsIgnoreCase("-quiet") )
        {
            logInfo = false;
            logWarning = false;
        }
        else if ( args[i].equalsIgnoreCase("-extraquiet") )
        {
            logInfo = false;
            logWarning = false;
            logError = false;
        }
        else
        {
            if ( strInputFile == null )
            {
                strInputFile = args[i];
            }
            else
            {
                if ( strOutputFile == null )
                    strOutputFile = args[i];
                else
				{
                    throw new IllegalArgumentException( "Unexpected argument \"" + args[i] + "\" at position " + i+1 );
				}
            }
        }
    }

	//  Input and output files must be specified.
	if ( strInputFile == null )
	{
        throw new IllegalArgumentException("No input grammar specified.");
	}
    else if ( strOutputFile == null && ! syntaxCheckOnly)
	{
        throw new IllegalArgumentException("No output file specified.");
	}

    Logger log = new Logger(logInfo, logWarning, logError);

    try 
    {
        //  Prepend the specified output directory, if necessary.
        if ( strInputDir != null )
            strInputFile = strInputDir + strInputFile;
        
        File sourceFile = new File(strInputFile);

        MacroProcessingStream token_stream = new MacroProcessingStream((sourceFile));
        JBurgParser parser = new JBurgParser(token_stream);

        parser.specification();

        CommonAST t = (CommonAST)parser.getAST();

		if ( !parser.parseSuccessful() || null == t  )
		{
			log.error("JBurg terminating due to parse errors.");
			System.exit(log.errorCount);
		}
        

		if ( dumpParseTree )
		{
			debugOut = new PrintStream( new FileOutputStream("dumpspec.xml") );

			debugOut.println("<?xml version=\"1.0\"?>");
			debugOut.println("<Specification>");
			dumpTree(t);
			debugOut.println("</Specification>");
		}

        if ( ! syntaxCheckOnly )
        {

            try
            {
                JBurgGenerator generator = new JBurgGenerator(t, log);
                generator.setDebugMode ( debugMode );

                int     iExtPos       = strOutputFile.lastIndexOf(".");
                String  strClassName  = strOutputFile.substring ( 0, iExtPos  );

                //  Prepend the specified output directory, if necessary.
                if ( strOutputDir != null )
                    strOutputFile = strOutputDir + strOutputFile;

                errCount = generator.generate( strClassName, new PrintStream(new FileOutputStream(strOutputFile) ) );

				//  This could be handled more gracefully.
				if ( errCount > 0 )
				{
					throw new IllegalStateException(
						String.valueOf(errCount ) +
						" errors detected while processing " +
						strInputFile
					);
				}
            }
            catch ( Exception e )
            {
                log.exception("Error trapped in generate phase:", e);
                System.exit(1);
            }
        }
    } 
    catch(Exception e) 
    {
        log.exception("Error trapped in parse phase:", e);
        System.exit(2);
    }
   }

    /**
     * @return the input string, with a file separator appended if it seems necessary.
     */
	private static String withFileSeparator ( String s )
	{
		if ( s.endsWith("/") || s.endsWith(File.separator) )
		{
			return s;
		}
		else
		{
			return s + File.separator; 
		}
	}

	static PrintStream debugOut = null;

	/**
	 *  Dump an ANTLR AST into an XML file.
	 */
	static private void dumpTree( AST root )
	{
		while ( root != null )
		{
			String id = translateASTType(root);
			String text = root.getText();

			debugOut.print("<");
			debugOut.print(id);

			if ( root.getType() != JBurgTokenTypes.BLOCK )
			{
				if ( text != null && text.length() > 0 )
				{
					debugOut.print ( " text=\"" + text + "\"" );
				}
				AST firstChild = root.getFirstChild();

				if ( firstChild != null )
				{
					debugOut.println(">");

					dumpTree( firstChild );

					debugOut.print("</");
					debugOut.print(id);
					debugOut.println(">");
				}
				else
				{
					debugOut.println( "/>" );
				}
			}
			else
			{
				debugOut.println( ">" );
				debugOut.println( "<![CDATA[" + root.getText() + "]]>" );
				debugOut.println( "</" + id + ">" );
			}


			root = root.getNextSibling();
		}
	}

	static private Hashtable s_JBurgTokenTypes = null;

	static public String translateASTType( AST p )
	{

		//  Populate the static list of token types.
		if ( s_JBurgTokenTypes == null )
		{
			s_JBurgTokenTypes = new Hashtable();

			Field[] fieldList = JBurgTokenTypes.class.getDeclaredFields();

			for ( int i = 0; i < fieldList.length; i++ )
			{
				if ( fieldList[i].getType().equals(Integer.TYPE ) )
				{
					int mods = fieldList[i].getModifiers();

					if ( Modifier.isPublic(mods) && Modifier.isStatic(mods) && Modifier.isFinal(mods) )
					{
						//  public final static int is a manifest constant.
						try
						{
							Integer key = (Integer) fieldList[i].get(null);

							s_JBurgTokenTypes.put( key, fieldList[i].getName() );
						}
						catch ( Exception ex )
						{
							//  mmmkay, maybe we won't use this one.
						}
					}
				}
			}
		}

		String result = s_JBurgTokenTypes.get(new Integer(p.getType())).toString();

		if ( result == null )
			result = Integer.toString( p.getType() );

		return result;
	}
	
	/**
	 *  This TokenStream implementation performs macro substitution
	 *  as it lexes the input.
	 *  Macros at the JBurg syntax level are id="new token stream" type,
	 *  the new token stream is re-lexed and injected into the token stream.
	 *  Macros at the block level are { "regex"="substitution text" } type,
	 *  they're handled as straight text substituions.
	 */
	static class MacroProcessingStream implements antlr.TokenStream, JBurgTokenTypes
    {
        JBurgANTLRLexer impl;

        MacroProcessingStream(File in)
        throws Exception
        {
            impl = new JBurgANTLRLexer(new FileInputStream(in));
    
            impl.mainSourceFile = in;
    
            JBurgANTLRLexer.selector =  new TokenStreamSelector();
            JBurgANTLRLexer.selector.addInputStream(impl, "main");
            JBurgANTLRLexer.selector.select("main");
        }
    
        public Token nextToken()
        throws antlr.TokenStreamException
        {
            Token result = null;
    
            do 
            {
                try
                {
                    result = JBurgANTLRLexer.selector.nextToken();
    
                    //  Check for a substitution.
                    switch ( result.getType() )
                    {
                    case IDENTIFIER:
                    {
                        //  An identifier at the JBurg syntax level can be replaced 
                        //  by a string of JBurg tokens, which are relexed.
                        java.util.Map<String,String> subs = impl.getCurrent().jburgSubstitutionText;
                        String id = result.getText();
    
                        if ( subs.containsKey(id ) )
                        {
                            result = null;  //  Discard the substituted token.
                            impl.pushMacroLexer(new JBurgANTLRLexer(new StringBufferInputStream(subs.get(id))));
                        }
                    }
                    case BLOCK:
                    {
                        //  A regex within a block can be replaced by substitution text.
                        //  The substitution text isn't relexed by JBurg, since the block
                        //  as a whole isn't being lexed in any meaningful way.
                        java.util.Map<String,String> subs = impl.getCurrent().blockSubstitutionText;
                        if ( !subs.isEmpty() )
                        {
                            String block_body = result.getText();
    
                            for ( String key: subs.keySet() )
                            {
                                block_body = block_body.replaceAll(key, subs.get(key));
                            }
    
                            result.setText(block_body);
                        }
                    }
                    }
                }
                catch ( antlr.TokenStreamRetryException retry )
                {
                    continue;
                }
    
            } while ( result == null );
    
            return result;
        }
    }
}
