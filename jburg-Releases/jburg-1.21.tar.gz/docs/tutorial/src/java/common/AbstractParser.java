package jburg.tutorial.common;

import java.util.List;
import java.util.LinkedList;

import org.antlr.runtime.*;
import org.antlr.runtime.tree.CommonTree;

import jburg.tutorial.second.secondLexer;

/**
 * AbstractParser is the superclass of the 
 * various example compilers' front ends;
 * it exposes a common API for the driver
 * program and handles errors.
 */
public abstract class AbstractParser extends Parser
{
    protected AbstractParser(TokenStream input, RecognizerSharedState state)
    {
        super(input, state);
    }

    /** Errors found during parsing. */
    private List<String> errors = new LinkedList<String>();

    /**
     * Parse the input file and return its AST.
     * Calls compilationUnit() using the parser-specific
     * data types for each front end.
     */
    public abstract CommonTree parse() throws Exception;

    /**
     * Override the default error handler and cache the diagnostics.
     */
    public void displayRecognitionError(String[] tokenNames, RecognitionException e)
    {
        String hdr = getErrorHeader(e);
        String msg = getErrorMessage(e, tokenNames);
        errors.add(hdr + " " + msg);
    }

    /**
     * @return parser diagnostics issued during the parse.
     */
    public List<String> getErrors()
    {
        return errors;
    }
}
