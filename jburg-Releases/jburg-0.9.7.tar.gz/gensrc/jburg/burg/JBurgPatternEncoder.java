/*  Generated Sun Mar 16 09:08:24 EST 2008 by JBurg version 0.9.5.4 */
package jburg.burg;


    import java.util.Vector;

    import jburg.parser.JBurgTokenTypes;
    import jburg.burg.emitlangs.EmitLang;
public class JBurgPatternEncoder implements JBurgTokenTypes
{

	java.util.Stack reducedValues = new java.util.Stack();


public static final int operatorId_NT = 1;

public static final int multipart_identifier_NT = 2;

public static final int operand_NT = 3;

public static final int operator_specification_NT = 4;

public static final int simple_identifier_NT = 5;

public static final int operand_list_NT = 6;

public static final int PatternMatcher_NT = 7;

public static final int nStates = 7;


public JBurgAnnotation label( antlr.collections.AST to_be_labelled)
{
	JBurgAnnotation result = null;
	if ( to_be_labelled != null )
	{
		result = new JBurgAnnotation(to_be_labelled,nStates + 1);
		
		result.left = label(((antlr.collections.AST)to_be_labelled.getFirstChild()));
		if ( ( ( (null == to_be_labelled || null == to_be_labelled.getFirstChild())? 0:  (null == to_be_labelled.getFirstChild().getNextSibling())? 1: 2) > 1 )  )
		{
			result.right = label(((antlr.collections.AST)to_be_labelled.getFirstChild().getNextSibling()));
			
		}
		this.computeCostMatrix(result);
		
	}
	return( result);
	
}


private void computeCostMatrix( JBurgAnnotation node)
{
	int iCost;
	switch( node.getOperator() )
	{case MULTIPART_IDENTIFIER:
		{
if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 0 && node.getOperator() == MULTIPART_IDENTIFIER )
{
	
	iCost = 1;
	;
	if ( ( node.getCost(multipart_identifier_NT) > iCost )  )
	{/* Matched MULTIPART_IDENTIFIER ==> multipart_identifier */
		node.reset(multipart_identifier_NT, iCost, 9);
		
	}
	
}
break;
		}
		case NON_TERMINAL_PARAMETER:
		{
if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 2 && node.getOperator() == NON_TERMINAL_PARAMETER && ( Integer.MAX_VALUE > node.left.getCost(simple_identifier_NT) )  && ( Integer.MAX_VALUE > node.right.getCost(simple_identifier_NT) )  )
{
	
	iCost =  ( (1 + node.left.getCost(simple_identifier_NT))  + node.right.getCost(simple_identifier_NT)) ;
	;
	if ( ( node.getCost(operand_NT) > iCost )  )
	{/* Matched NON_TERMINAL_PARAMETER ==> operand */
		node.reset(operand_NT, iCost, 7);
		node.addSubgoal(operand_NT, node.left, simple_identifier_NT);
		node.addSubgoal(operand_NT, node.right, simple_identifier_NT);
		
	}
	
}
break;
		}
		case PATTERN_SPECIFICATION:
		{
if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 2 && node.getOperator() == PATTERN_SPECIFICATION && ( Integer.MAX_VALUE > node.left.getCost(operatorId_NT) )  && ( Integer.MAX_VALUE > node.right.getCost(operand_list_NT) )  )
{
	
	iCost =  ( (1 + node.left.getCost(operatorId_NT))  + node.right.getCost(operand_list_NT)) ;
	;
	if ( ( node.getCost(PatternMatcher_NT) > iCost )  )
	{/* Matched PATTERN_SPECIFICATION ==> PatternMatcher */
		node.reset(PatternMatcher_NT, iCost, 2);
		node.addSubgoal(PatternMatcher_NT, node.left, operatorId_NT);
		node.addSubgoal(PatternMatcher_NT, node.right, operand_list_NT);
		
	}
	
}
break;
		}
		case OPERAND_LIST_KNOWN_ARITY:
		{
if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 2 && node.getOperator() == OPERAND_LIST_KNOWN_ARITY && ( Integer.MAX_VALUE > node.left.getCost(operand_NT) )  && ( Integer.MAX_VALUE > node.right.getCost(operand_NT) )  )
{
	
	iCost =  ( (1 + node.left.getCost(operand_NT))  + node.right.getCost(operand_NT)) ;
	;
	if ( ( node.getCost(operand_list_NT) > iCost )  )
	{/* Matched OPERAND_LIST_KNOWN_ARITY ==> operand_list */
		node.reset(operand_list_NT, iCost, 5);
		node.addSubgoal(operand_list_NT, node.left, operand_NT);
		node.addSubgoal(operand_list_NT, node.right, operand_NT);
		
	}
	
}

if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 1 && node.getOperator() == OPERAND_LIST_KNOWN_ARITY && ( Integer.MAX_VALUE > node.left.getCost(operand_NT) )  )
{
	
	iCost =  (1 + node.left.getCost(operand_NT)) ;
	;
	if ( ( node.getCost(operand_list_NT) > iCost )  )
	{/* Matched OPERAND_LIST_KNOWN_ARITY ==> operand_list */
		node.reset(operand_list_NT, iCost, 6);
		node.addSubgoal(operand_list_NT, node.left, operand_NT);
		
	}
	
}
break;
		}
		case TERMINAL_RULE:
		{
if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 1 && node.getOperator() == TERMINAL_RULE && ( Integer.MAX_VALUE > node.left.getCost(operatorId_NT) )  )
{
	
	iCost =  (1 + node.left.getCost(operatorId_NT)) ;
	;
	if ( ( node.getCost(PatternMatcher_NT) > iCost )  )
	{/* Matched TERMINAL_RULE ==> PatternMatcher */
		node.reset(PatternMatcher_NT, iCost, 3);
		node.addSubgoal(PatternMatcher_NT, node.left, operatorId_NT);
		
	}
	
}
break;
		}
		case IDENTIFIER:
		{
if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 0 && node.getOperator() == IDENTIFIER )
{
	
	iCost = 1;
	;
	if ( ( node.getCost(simple_identifier_NT) > iCost )  )
	{/* Matched IDENTIFIER ==> simple_identifier */
		node.reset(simple_identifier_NT, iCost, 8);
		closure_simple_identifier(node, iCost);
		
	}
	
}
break;
		}
		case OPERATOR_SPECIFICATION:
		{
if ( ( (null == node || null == node.leftChild())? 0:  (null == node.rightChild())? 1: 2) == 2 && node.getOperator() == OPERATOR_SPECIFICATION && ( Integer.MAX_VALUE > node.left.getCost(operatorId_NT) )  && ( Integer.MAX_VALUE > node.right.getCost(operand_list_NT) )  )
{
	
	iCost =  ( (1 + node.left.getCost(operatorId_NT))  + node.right.getCost(operand_list_NT)) ;
	;
	if ( ( node.getCost(operator_specification_NT) > iCost )  )
	{/* Matched OPERATOR_SPECIFICATION ==> operator_specification */
		node.reset(operator_specification_NT, iCost, 4);
		node.addSubgoal(operator_specification_NT, node.left, operatorId_NT);
		node.addSubgoal(operator_specification_NT, node.right, operand_list_NT);
		closure_operator_specification(node, iCost);
		
	}
	
}
break;
		}
		
	}
	
}


private void closure_simple_identifier( JBurgAnnotation p, int c)
{
	int iCost;
	
	iCost = c;
	;
	if ( ( p.getCost(operatorId_NT) > iCost )  )
	{p.reset(operatorId_NT, iCost, 1);
		p.recordAntecedent(operatorId_NT, simple_identifier_NT);
		
	}
	
}


private void closure_operator_specification( JBurgAnnotation p, int c)
{
	int iCost;
	
	iCost = c;
	;
	if ( ( p.getCost(operand_NT) > iCost )  )
	{p.reset(operand_NT, iCost, 1);
		p.recordAntecedent(operand_NT, operator_specification_NT);
		
	}
	
}


private JBurgPatternMatcher action_2( antlr.collections.AST p)
{

	JBurgPatternMatcher opid = (JBurgPatternMatcher)reducedValues.pop();


	JBurgPatternMatcher operands = (JBurgPatternMatcher)reducedValues.pop();

		{
		    JBurgPatternMatcher recognizer = JBurgPatternMatcher.matchOperator(opid.getIdentifier());
		    recognizer.addChild(operands);
		
		    return recognizer;
		}
}


private JBurgPatternMatcher action_3( antlr.collections.AST p)
{

	JBurgPatternMatcher terminalID = (JBurgPatternMatcher)reducedValues.pop();

		{
		    return JBurgPatternMatcher.matchOperator(terminalID.getIdentifier());
		}
}


private JBurgPatternMatcher action_4( antlr.collections.AST p)
{

	JBurgPatternMatcher opid = (JBurgPatternMatcher)reducedValues.pop();


	JBurgPatternMatcher operands = (JBurgPatternMatcher)reducedValues.pop();

		{
		    //  The presence of the operands node is checked by the cost computation
			//  (if the second node cannot be used as operands, its cost is infinite),
			//  so this recognizer need only check the operator.
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperator(opid.getIdentifier());
		
			//  The operand_list node is not part of the pattern per se;
			//  its children are the matchers for the sub-patterns.
			result.addChild( operands );
		
			return result;
		}
}


private JBurgPatternMatcher action_5( antlr.collections.AST p)
{

	JBurgPatternMatcher l1 = (JBurgPatternMatcher)reducedValues.pop();


	JBurgPatternMatcher r1 = (JBurgPatternMatcher)reducedValues.pop();

		{
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperandsOnly();
			result.addChild( l1 );
			result.addChild( r1 );
		
		    return result;
		}
}


private JBurgPatternMatcher action_6( antlr.collections.AST p)
{

	JBurgPatternMatcher onlyOperand = (JBurgPatternMatcher)reducedValues.pop();

		{
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperandsOnly();
			result.addChild( onlyOperand );
		
		    return result;
		}
}


private JBurgPatternMatcher action_7( antlr.collections.AST p)
{

	JBurgPatternMatcher state = (JBurgPatternMatcher)reducedValues.pop();


	JBurgPatternMatcher paramName = (JBurgPatternMatcher)reducedValues.pop();

		{
			//  Check precondition: there must be an available list of subgoals.
			if ( null == subgoals )
			{
				throw new IllegalStateException("Non-terminals may only be processed in pattern matching rules.");
			}
		
		    JBurgPatternMatcher result;
		    result = JBurgPatternMatcher.matchFiniteCost(state.getIdentifier());
		
			//  This subgoal's cost will be added to the overall cost of the pattern match.
			subgoals.add(0, new JBurgSubgoalRecord( paramName.getIdentifier(), state.getIdentifier(), result ) );
		
		    return result;
		}
}


private JBurgPatternMatcher action_8( antlr.collections.AST p)
{
		{
		    return JBurgPatternMatcher.matchIdentifier( p.getText() );
		}
}


private JBurgPatternMatcher action_9( antlr.collections.AST p)
{
		{
		    return JBurgPatternMatcher.matchIdentifier( p.getText() );
		}
}


private void dispatchAction( antlr.collections.AST p, int iRule) throws java.lang.Exception
{switch( iRule )
	{case 1:
		{/* Don't reduce or touch the stack. */
			break;
		}
		case 2:
		{reducedValues.push(this.action_2(p));
			break;
		}
		case 3:
		{reducedValues.push(this.action_3(p));
			break;
		}
		case 4:
		{reducedValues.push(this.action_4(p));
			break;
		}
		case 5:
		{reducedValues.push(this.action_5(p));
			break;
		}
		case 6:
		{reducedValues.push(this.action_6(p));
			break;
		}
		case 7:
		{reducedValues.push(this.action_7(p));
			break;
		}
		case 8:
		{reducedValues.push(this.action_8(p));
			break;
		}
		case 9:
		{reducedValues.push(this.action_9(p));
			break;
		}
		default:throw new IllegalStateException("Unmatched reduce action " + iRule);
		
	}
	
}


public void reduce( JBurgAnnotation p, int goalState) throws java.lang.Exception
{
	int iRule = -1;
	if ( ( goalState > 0 )  )
	{
		iRule = p.getRule(goalState);
		;
		
	}
	else
	{/* Find the minimum-cost path. */
		int minCost = Integer.MAX_VALUE;
		
		int i;
		for( 
		i = 0;
		i <= nStates;i++ )
		{
			if ( ( minCost > p.getCost(i) )  )
			{
				iRule = p.getRule(i);
				
				minCost = p.getCost(i);
				
				goalState = i;
				
			}
			
		}
		
	}
	if ( ( iRule > 0 )  )
	{
		reduceAntecedentStates(p, goalState);
		reduceSubgoals(p, goalState);
		dispatchAction ( (antlr.collections.AST)p.getNode(), iRule );
	}
	
	else
	{
		throw new IllegalStateException ( "Unable to find a rule to process \"" + p.toString() + "\", operator="+ String.valueOf(p.getOperator()) + ", goal=" + String.valueOf(goalState) );
	}
	
}


private void reduceSubgoals( JBurgAnnotation p, int goalState) throws java.lang.Exception
{/* Reduce subgoals in reverse order so they get pushed onto the stack *//* in the order expected by the action routines. */
	for ( int i = i = p.getSubgoalsSize(goalState) - 1; i >= 0; i-- )
	{
		JBurgSubgoal sg = (JBurgSubgoal) p.getSubgoals(goalState).elementAt(i);
		reduce ( sg.getNode(), sg.getGoalState());
	}
	
}


private void reduceAntecedentStates( JBurgAnnotation p, int goalState) throws java.lang.Exception
{
	int[] antecedentRules = new int[nStates];
	
	int[] antecedentStates = new int[nStates];
	
	int currentState = goalState;
	
	int antecedentIndex = 0;
	
	while ( p.hasAntecedent(currentState) )
	{
		currentState = p.getAntecedent(currentState);
		antecedentStates[antecedentIndex] = currentState;
		antecedentRules[antecedentIndex] = p.getRule(currentState);
		antecedentIndex++;
	}
	
	for ( --antecedentIndex; antecedentIndex >= 0; antecedentIndex-- )
	{
		reduceSubgoals( p, antecedentStates[antecedentIndex]);
		dispatchAction( p.getNode(), antecedentRules[antecedentIndex] );
	}
	
}


public void burm ( antlr.collections.AST root ) throws Exception
{

	JBurgAnnotation annotatedTree = label(root);
	reduce ( annotatedTree, 0);
}
/* BURM property, from the specification */

private Vector subgoals;


public void setSubgoals( Vector setting)
{
	this.subgoals = setting;
	
}


public Vector getSubgoals( )
{return( this.subgoals);
	
}


public Object getResult( )
{
	return reducedValues.pop();
	
}


/**
 *  JBurgAnnotation is a data structure internal to the
 *  JBurg-generated BURM that annotates a JBurgNode with
 *  information used for dynamic programming and reduction.
  */
class JBurgAnnotation
{
	/**
	 *  The cost/rule matrices are used during dynamic programming
	 *  to compute the most economical rules that can reduce
	 *  the input node.
	*/
	private int cost[];
	private int rule[];

	/**  Transformation rules may have antecedents: other states whose
	 *  output the transformation rule is intended to transform.
	 *  All such antecedent states must be executed in sequence when the rule is reduced.
	 */
	private int[] antecedentState = null;

	 /**
	 *  A node may have a specific goal state, set by its ancestor's
	 *  requirements for a certain type of input; or it may be at 
	 *  liberty to use the most locally-economical reduction.
	 */
	public java.util.Vector[] m_subgoals;

	/** *  This node's children (may be null).  */
	private JBurgAnnotation left;
	private JBurgAnnotation right;
	/**  The INode we're annotating.  */
	antlr.collections.AST m_node; 
	JBurgAnnotation ( antlr.collections.AST newNode, int nRules) 
	{
		m_node = newNode;
		rule   = new int[nRules];
		cost   = new int[nRules];
		//  Initial cost of all rules is "infinite"
		java.util.Arrays.fill ( cost, Integer.MAX_VALUE);
		//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array.
	}

	 /** @return this node's operator. */
	public int getOperator() { return m_node.getType(); }

	 /** @return this node's wrappedantlr.collections.AST. */ 
	public antlr.collections.AST getNode()  { return m_node; }

	/** @return the left child of this node.  */

	public JBurgAnnotation leftChild() { return left; }

	/** @return the right child of this node.  */

	public JBurgAnnotation rightChild() { return right; }

	/** @return the wrapped node's toString().  */
	public String toString() { return m_node.toString(); } 
	/** @return the current best cost to reach a goal state.  */
	public int getCost( int goalState ) { return cost[goalState]; }

	 /** Set the cost/rule configuration of a goal state.
	 * @throws IllegalArgumentException if this node has a fixed cost/rule.
	*/
	 public void reset ( int goalState, int cost, int rule )
	{
		this.cost[goalState] = cost;
		this.rule[goalState] = rule;
		//  We have a brand new rule, therefore it has no antecedents.
		if ( this.antecedentState != null )
		this.antecedentState[goalState] = 0;
		if ( m_subgoals != null && m_subgoals[goalState] != null )
		{
			m_subgoals[goalState].clear();
		}
	}

	/** * @return the rule to fire for a specific goal state. */
	public int getRule ( int goalState ) { return rule[goalState]; }

	 /**
	 *  A closure's transformation rule succeeded.
	 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
	 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
	 *  transition back to a goal state that has already been reduced).
	*/
	public void recordAntecedent ( int iGoalState, int newAntecedentState )
	{
		int antecedentRule = rule[newAntecedentState];
		//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled.
		if ( antecedentRule == 0 )
			throw new IllegalStateException ( "Attempting to record an unlabelled antecedent state." );
		if ( antecedentRule == 1 )
		{
			//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run.
			if ( antecedentState != null )
				antecedentState[iGoalState] = antecedentState[newAntecedentState];
			}
		else
		
			{
				if ( antecedentState == null )
					antecedentState = new int[rule.length];
			}
		antecedentState[iGoalState] = newAntecedentState;
	}

	 /** @return the antecedent to the given goal state. */
	public int getAntecedent(int iGoalState)
	{
		if ( antecedentState != null )
			return antecedentState[iGoalState];
		else
			return 0;
	}
	 /** @return true if the given goal state has an antecdent. */
	public boolean hasAntecedent ( int iGoalState )
		{ return ( antecedentState != null && getAntecedent(iGoalState) != 0 ); }
		public void addSubgoal ( int goalState, JBurgAnnotation node, int subGoal )
		{
			if ( m_subgoals == null )
			{
				m_subgoals = new java.util.Vector[rule.length];
			}
			if ( m_subgoals[goalState] == null )
			{
				m_subgoals[goalState] = new java.util.Vector();
			}
			m_subgoals[goalState].add(new JBurgSubgoal(node, subGoal));
		}
		public int getSubgoalsSize(int goalState)
		{
			if ( m_subgoals != null && m_subgoals[goalState] != null )
			{
				return m_subgoals[goalState].size();
			}
			else
			{
				return 0;
			}
		}
		public java.util.Vector getSubgoals(int goalState)
		{
			if ( m_subgoals == null )
			{
				throw new IllegalStateException("No subgoal records.");
			}
			return m_subgoals[goalState];
		}
	}

	public class JBurgSubgoal
	{
		JBurgAnnotation m_node;
		int m_goal_state;
		public JBurgSubgoal(JBurgAnnotation node, int goalState)
		{
			m_node = node;
			m_goal_state = goalState;
		}
		public JBurgAnnotation getNode() { return m_node; }
		public int getGoalState() { return m_goal_state; }
	}
}
