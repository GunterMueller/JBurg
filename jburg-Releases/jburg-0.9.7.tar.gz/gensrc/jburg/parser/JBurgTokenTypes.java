// $ANTLR 2.7.2: "jburg.g" -> "JBurgANTLRLexer.java"$

package jburg.parser;


public interface JBurgTokenTypes {
	int EOF = 1;
	int NULL_TREE_LOOKAHEAD = 3;
	int COST_FUNCTION = 4;
	int FUNCTION_CALL = 5;
	int HEADER_DECLARATION = 6;
	int IMPLEMENTS_INTERFACE_SPECIFICATION = 7;
	int INCLASS_DECLARATION = 8;
	int INODE_DECLARATION = 9;
	int LANGUAGE_DECLARATION = 10;
	int MULTIPART_IDENTIFIER = 11;
	int NON_TERMINAL_PARAMETER = 12;
	int OPERATOR_SPECIFICATION = 13;
	int OPERAND_LIST_KNOWN_ARITY = 14;
	int OPERAND_LIST_ARBITRARY_ARITY = 15;
	int PACKAGE_SPECIFICATION = 16;
	int PATTERN_SPECIFICATION = 17;
	int PATTERN_RULE = 18;
	int PROPERTY_SPECIFICATION = 19;
	int RETURN_DECLARATION = 20;
	int SIMPLE_COST_SPEC = 21;
	int SIMPLE_TRANSFORMATION_RULE = 22;
	int TRANSFORMATION_RULE = 23;
	int TERMINAL_RULE = 24;
	int TYPED_RETURN_DECLARATION = 25;
	int IDENTIFIER = 26;
	int LPAREN = 27;
	int RPAREN = 28;
	int BLOCK = 29;
	int COLON = 30;
	int LITERAL_header = 31;
	int LITERAL_INodeType = 32;
	int SEMI = 33;
	int LITERAL_Language = 34;
	int LITERAL_implements = 35;
	int PERIOD = 36;
	int STAR = 37;
	int COMMA = 38;
	int PLUS = 39;
	int LITERAL_package = 40;
	int LITERAL_BURMProperty = 41;
	int LITERAL_ReturnType = 42;
	int EQUALS = 43;
	int INT = 44;
	int LITERAL_void = 45;
	int STRING_LITERAL = 46;
	int WS = 47;
	int COMMENT = 48;
	int ML_COMMENT = 49;
	int DIGIT = 50;
}
