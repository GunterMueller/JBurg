package jburg.compiler.tl2.reducer;

import java.util.Vector;

import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.SWITCH;

public class TL2Switch
{
   private Vector matches = new Vector();
   private Vector targets = new Vector();

   private TL2InstructionList defaultTarget;
   private InstructionHandle  defaultHandle;

   public TL2Switch( int match, TL2InstructionList target )
   {
    addCase ( match, target );
   }

   public TL2Switch( TL2InstructionList defaultTarget )
   {
    setDefault ( defaultTarget );
   }

   public void addCase ( int match, TL2InstructionList target )
   {
    this.matches.insertElementAt ( new Integer(match), 0 );
    this.targets.insertElementAt ( target, 0 );
   }

   public InstructionHandle getDefault ()
   {
    return this.defaultHandle;
   }

   public void setDefault ( TL2InstructionList defaultTarget )
   {
    this.defaultTarget = defaultTarget;
    setDefaultHandle ( defaultTarget.getStart() );
   }

   public void setDefaultHandle ( InstructionHandle defaultHandle )
   {
    this.defaultHandle = defaultHandle;
   }

   public TL2InstructionList instructionList()
   {
    TL2InstructionList result = new TL2InstructionList();

    int[] swMatches = new int[matches.size()];

    InstructionHandle[] swTargets = new InstructionHandle[targets.size()];

    //  assert these two are the same length
    int gap = 3;

    for ( int i = 0; i < swMatches.length; i++ )
        swMatches[i] = ((Integer)matches.elementAt(i)).intValue();

    for ( int i = 0; i < swMatches.length; i++ )
    {
        TL2InstructionList nextList = (TL2InstructionList)targets.elementAt(i);
        swTargets[i] = nextList.getStart();
        result.append (nextList);
    }

    //  FIXME: This should be done in order.
    if ( defaultTarget != null )
        result.append ( defaultTarget );

    result.il.insert ( new SWITCH ( swMatches, swTargets, getDefault(), gap ) );

    return result;
   }
}
