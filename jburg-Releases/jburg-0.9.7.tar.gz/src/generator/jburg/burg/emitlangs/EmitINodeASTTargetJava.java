package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.util.Set;
import java.util.Hashtable;

import jburg.burg.JBurgGenerator;

/**
 *  This emitter wraps the user-specified BURM emitter
 *  to accept ANTLR AST nodes as input intermediate code nodes.
 *  It's used in simple compilers that work directly on the
 *  input AST.  JBurg itself is an example of such a compiler.
 */
public class EmitINodeASTTargetJava
	extends DelegatingEmitter
	implements EmitLang
{
	/**  The fully qualified name of the AST. */
	public static final String s_iNodeType = "antlr.collections.AST";


	public EmitINodeASTTargetJava(EmitLang emitter)
	{
		super(emitter);
	}

	public boolean accept(String name, String iNodeClass)
	{
		//  This class must be directly instantiated. 
		return false;
	}

	public String genGetNthChild( String node, int idx )
	{
		if ( !JBurgGenerator.isInitialParamName(node) )
		{
			//  No special handling necessary.
			return super.genGetNthChild(node, idx);
		}
		else
		{
			if ( 0 == idx )
			{
				return genCallMethod("node", "getFirstChild", null);
			}
			else if ( 1 == idx )
			{
				return genCallMethod(
					genCallMethod(
						"node", 
						"getFirstChild", 
						null
					),
					"getNextSibling",
					null
				);
			}
			else
			{
				throw new IllegalArgumentException( "Index out of range:" + Integer.toString(idx) );
			}
		}
	}

	public String genGetArity(String node)
	{
		//  FIXME: Hard-coded for 2 operands and languages with C-like ternary operators.
		String node1Check =
			genCheckPtr("node", true) + "||" + genCheckPtr( genGetNthChild(node,0), true);
		String node2Check = genCheckPtr  ( genGetNthChild(node, 1), true );

		return( 
			"( (" + node1Check + ")? 0: " + 
			"(" + node2Check +  ")? 1: 2)");
	}

	public String genGetOperator( String node)
	{
		return genCallMethod("node", "getType", null);
	}
}
