package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.util.Hashtable;
import java.util.Set;
import java.util.Vector;

import jburg.burg.JBurgGenerator;

/**
 *  DelegatingEmitter is an abstract base class
 *  that wraps a user-specified BURM emitter.
 *  Subclasses of DelegatingEmitter are add-ins
 *  of some sort to a BURM generation; for example,
 *  the JBurg's pattern-matching BURM uses the
 *  user-selected emitter, but uses its own input
 *  AST type to recognize pattern matching nodes.
 */
public abstract class DelegatingEmitter
	implements EmitLang
{
	/**
	 *  Underlying emitter
	 */
	EmitLang m_emitter;

	public DelegatingEmitter(EmitLang emitter)
	{
		m_emitter = emitter;
	}
	
	/**
	 * Subclasses must implement this.
	 */
	abstract public boolean accept(String languageName, String iNodeClassName );
	
	public void setRtInfo(JBurgGenerator parent, String opfname)
	{
	   m_emitter.setRtInfo(parent, opfname);
	}

	public void emitHeader(
			String strClassName, 
			String packageName, 
			String headerBlock, 
			Vector InterfaceNames, 
			boolean debugMode, 
			PrintStream output
		)
	{
		m_emitter.emitHeader(
			strClassName, 
			packageName, 
			headerBlock, 
			InterfaceNames, 
			debugMode, 
			output
		);
	}
	
	public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output)
	{
		m_emitter.emitInclass(strClassName, inclassBlocks, output);
	}

	public void emitTrailer(
			String strClassName, 
			String iNodeClass, 
			Set subgoals, 
			Hashtable burm_properties, 
			boolean debugMode, 
			PrintStream output
			)
	{
		m_emitter.emitTrailer(
			strClassName, 
			iNodeClass, 
			subgoals, 
			burm_properties, 
			debugMode, 
			output
		);
	}

	public String genPopFromStack(
			String stackName, 
			String paramType, 
			String paramName, 
			String tabs
			)
	{
		return m_emitter.genPopFromStack(stackName, paramType, paramName, tabs);
	}

	public String genPushToStack(String stackName, String value )
	{
		return m_emitter.genPushToStack(stackName, value );
	}
	
	public String genCheckPtr(String paramName, boolean checkForNull)
	{
		return m_emitter.genCheckPtr(paramName, checkForNull);
	}
	
	public String genAccessMember(String parentName, String memberName)
	{
		return m_emitter.genAccessMember(parentName, memberName);
	}
	
	public String genCallMethod(String parentName, String methodName, String[] params)
	{
		return m_emitter.genCallMethod(parentName, methodName, params);
	}
	
	public String genCmpEquality(String lhs, String rhs, boolean bEquality)
	{
		return m_emitter.genCmpEquality(lhs, rhs, bEquality);
	}

	public String genLogicalAnd(String lhs, String rhs)
	{
		return m_emitter.genLogicalAnd(lhs, rhs);
	}

	public String genIf( String condition )
	{	
		return m_emitter.genIf( condition );
	}

	public String genElse()
	{
		return m_emitter.genElse();
	}


	public String genBeginBlock()
	{
		return m_emitter.genBeginBlock();
	}

	public String genEndBlock()
	{
		return m_emitter.genEndBlock();
	}

	public String genEndStmt()
	{
		return m_emitter.genEndStmt();
	}

	public String genBeginLine()
	{
		return m_emitter.genBeginLine();
	}

	public String genCmpLess( String lhs, String rhs )
	{
		return m_emitter.genCmpLess( lhs, rhs );
	}

	public String genNot( String operand )
	{
		return m_emitter.genNot( operand );
	}

	public String genAddition( String addend1, String addend2 )
	{
		return m_emitter.genAddition( addend1, addend2 );
	}

	public String genLocalVar ( String type, String name, String initializer )
	{
		return m_emitter.genLocalVar ( type, name, initializer );
	}

	public String genInstanceField ( int modifiers, String type, String name, String initializer )
	{
		return m_emitter.genInstanceField ( modifiers, type, name, initializer );
	}

	public String genNewObject( String type, String[] parameters )
	{
		return m_emitter.genNewObject( type, parameters );
	}

	public String genAssignment( String lvar, String rvalue )
	{
		return m_emitter.genAssignment( lvar, rvalue );
	}

	public String genCast( String newType, String target )
	{
		return m_emitter.genCast( newType, target );
	}

	public String genComment ( String text )
	{
		return m_emitter.genComment ( text );
	}

	public String genGetGoalState ( Object p )
	{
		return m_emitter.genGetGoalState ( p );
	}

	public String genBeginEnumeratedChoiceSet( String selectionCriterion )
	{
		return m_emitter.genBeginEnumeratedChoiceSet( selectionCriterion );
	}

	public String genEndEnumeratedChoiceSet()
	{
		return m_emitter.genEndEnumeratedChoiceSet();
	}

	public String genBeginChoiceCase( String selectionValue )
	{
		return m_emitter.genBeginChoiceCase( selectionValue );
	}

	public String genDefaultChoiceCase()
	{
		return m_emitter.genDefaultChoiceCase();
	}

	public String genEndChoiceCase()
	{
		return m_emitter.genEndChoiceCase();
	}

	public String genSignalError ( String diagnostic )
	{
		return m_emitter.genSignalError ( diagnostic );
	}

	public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
	{
		return m_emitter. declareMethod( modifiers, returnClass, name, plist, exceptions );
	}

	public String genReturnValue( String value )
	{
		return m_emitter.genReturnValue( value );
	}

	public String genMaxIntValue()
	{
		return m_emitter.genMaxIntValue();
	}

	public String genNullPointer()
	{
		return m_emitter.genNullPointer();
	}

	public String genGetArity( String node )
	{
		return m_emitter.genGetArity( node );
	}

	public String genGetNthChild( String node, int idx )
	{
		return m_emitter.genGetNthChild( node, idx );
	}
	
	public String genGetOperator( String node )
	{
		return m_emitter.genGetOperator( node );
	}
}
