package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.util.Set;
import java.util.Hashtable;

import jburg.burg.JBurgGenerator;

/**
 *  This emitter accepts ANTLR3 Tree nodes as intermediate
 *  code, and emits Java.
 */
public class EmitAntlr3TargetJava
	extends EmitJava
	implements EmitLang
{
	/**  The fully qualified name of the AST. */
	public static final String s_iNodeType = "org.antlr.runtime.tree.Tree";

	public EmitAntlr3TargetJava()
	{
	}

	public boolean accept(String name, String iNodeClass)
	{
		return iNodeClass.equals(s_iNodeType);
	}

	public String genGetNthChild( String node, int idx )
	{
		if ( !JBurgGenerator.isInitialParamName(node) )
		{
			return super.genGetNthChild(node, idx);
		}
		else
		{
			return genCallMethod(
				node,
				"getChild", 
				new String[] { Integer.toString(idx) } 
			);
		}
	}

	public String genGetArity(String node)
	{
		return genCallMethod(node, "getChildCount", null);
	}

	public String genGetOperator( String node)
	{
		return genCallMethod(node, "getType", null);
	}
}
