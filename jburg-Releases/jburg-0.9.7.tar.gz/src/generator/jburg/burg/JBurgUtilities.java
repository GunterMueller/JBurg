package jburg.burg;
import java.lang.reflect.Method;
import java.util.Iterator;

public class JBurgUtilities
{
    /**
     *   Traverse the given collection (and any subcollections) 
     *   and apply the specified method to all elements.
     *   This applyToAll variant assumes that the method takes an Object parameter.
     */
    public static void applyToAll(
		Object actor,
	    java.util.AbstractCollection collection,
        String strMethodName) throws Exception
    {
        //  Assume the method has an Object parameter.
        applyToAll(actor, collection, strMethodName, Object.class);
    }

    /**
     *   Traverse the given collection (and any subcollections) 
	 *   and apply the specified method to all elements.
     *   @param strMethodName the method to apply.
     *   @param cParamType the class of the method's one parameter.
     */
    public static void applyToAll( Object actor, java.util.AbstractCollection collection,
        String strMethodName, Class cParmType) throws Exception
    {
        Method m = actor.getClass().getDeclaredMethod(strMethodName, new Class[] {cParmType });
        applyToAll(actor, collection, m);
    }

    /**
     *  Traverse the given collection (and any subcollections)
	 *  and apply the specified method to all elements.
     */
    private static void applyToAll( Object actor, java.util.AbstractCollection collection, Method m)
        throws Exception
    {
        Iterator it = collection.iterator();

        while (it.hasNext()) {
            Object o = it.next();

            if (o instanceof java.util.AbstractCollection) {
                applyToAll( actor, (java.util.AbstractCollection) o, m);
            } else {
                Object[] arglist = new Object[1];
                arglist[0] = o;
                m.invoke(actor, arglist);
            }
        }
    }
}
