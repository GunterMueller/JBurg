public interface ExprTokenTypes
{
	public static final int EQUALS=6;
    public static final int EOF=-1;
    public static final int WS=11;
    public static final int ID=5;
    public static final int PLUS=7;
    public static final int NEWLINE=4;
    public static final int STAR=9;
    public static final int MINUS=8;
    public static final int INT=10;
}
