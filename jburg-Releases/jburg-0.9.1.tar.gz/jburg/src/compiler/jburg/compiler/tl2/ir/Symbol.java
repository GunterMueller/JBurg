package jburg.compiler.tl2.ir;

import java.lang.reflect.Modifier;

import jburg.compiler.tl2.parser.TL2ParserConstants;

import jburg.compiler.tl2.semanticanalysis.SemanticConstants;
import jburg.compiler.tl2.semanticanalysis.AbstractClass;

import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.FieldGen;
import org.apache.bcel.generic.ObjectType;
import org.apache.bcel.generic.Type;

/**
 *  Symbols represent Java constructs such as fields, methods, and classes,
 *  which have some properties in common:
 *  <ul>
 *      <li>A name, e.g., "foo".
 *      <li>Storage class, e.g., <code>static</code>.
 *      <li>Access modifiers, e.g., <code>public</code>.
 *      <li>An associated AbstractClass type.
 *  </ul>
 *
 *  As such, Symbol objects are aggregated into AbstractClass and
 *  AbstractMethod objects; Symbols are used on their own as 
 *  "AbstractField" objects.
 *  <p><b>FIXME:</b> This class needs to be broken up into interfaces
 *  so this is not such an ad-hoc aggregation of &quot;stuff.&quot;
 */
public class Symbol
implements
   SemanticConstants,
   TL2ParserConstants,
   org.apache.bcel.Constants
{
   private String         name  = null;
   private AbstractClass  clazz = null;

   private boolean isFinal  = false;
   private boolean isStatic = false;

   private Object staticConstantInitializer = null;

   private int     accessLevel = SYMBOL_ACCESS_DEFAULT;

   private int arrayDimension = 0;

   /**  FieldGen used if this Symbol represents a field in the class. */
   FieldGen fieldGen;

   /*
    * Local variable slot number; -1 means this is not a local variable.
    */
   private int slotNumber = -1;

   public Symbol ()
   {
   }

   /**  Set the Symbol's name. */
   public void setName ( String name )
   {
    this.name = name;
   }

   /** @return the Symbol's name. */
   public String getName()
   {
    return this.name;
   }

   /**
	*  Set the Symbol's type to an object type.
	*  @param clazz -- an AbstractClass object of the correct type.
	*  @see AbstractClass#getAbstractClass
	*/
   public void setSymbolClass( AbstractClass clazz )
   {
    this.clazz = clazz;
   }

   /**
	*  Decode the parser's token type into a primitive type.
	*  @param pKind -- the parser's token type.
	*  @see tl2.jjt for possible primitive data types.
	*/
   public void setPrimitiveType ( int pKind )
   {
    switch ( pKind )
    {
        case BOOLEAN_TYPE:
            this.clazz = AbstractClass.BOOLEAN;
            break;
        case INT_TYPE:
            this.clazz = AbstractClass.INT;
            break;
        case DOUBLE_TYPE:
            this.clazz = AbstractClass.DOUBLE;
            break;
        case FLOAT_TYPE:
            this.clazz = AbstractClass.FLOAT;
            break;
        case VOID_TYPE:
            this.clazz = AbstractClass.VOID;
            break;
        default:
            throw new IllegalStateException ( String.valueOf(pKind) );
    }
   }

   /** @return this Symbol's type as an AbstractClass */
   public AbstractClass getSymbolClass()
   {
    return this.clazz;
   }

   /** 
	*  @return true if this Symbol is final.
	*  <br><b>FIXME:</b> This should be part of an interface.
	*/
   public boolean isFinal()
   {
    return this.isFinal;
   }

   /** 
	*  @return true if this Symbol is static.
	*  <br><b>FIXME:</b> This should be part of an interface.
	*/
   public boolean isStatic()
   {
    return this.isStatic;
   }

   /** 
	*  @return this Symbol's access level in BCEL format.
	*  <br><b>FIXME:</b> This should be part of an interface.
	*/
   public int getAccess()
   {
    return this.accessLevel;
   }


   /** 
	*  @return true if this Symbol is private.
	*  <br><b>FIXME:</b> This should be part of an interface.
	*/
   public boolean isPrivate()
   {
    return getAccess() == SYMBOL_ACCESS_PRIVATE;
   }

   /** 
	*  @return true if this Symbol is package private.
	*  <br><b>FIXME:</b> This should be part of an interface.
	*/
   public boolean isPackagePrivate()
   {
    return getAccess() == SYMBOL_ACCESS_DEFAULT;
   }

   /** 
	*  @return true if this Symbol is public.
	*  <br><b>FIXME:</b> This should be part of an interface.
	*/
   public boolean isPublic()
   {
    return getAccess() == SYMBOL_ACCESS_PUBLIC;
   }

   /**
    *  Called by the parser as it processes a declaration's set of modifier tokens.
    *  @param pKind - the Token kind of this modifier.
    */
   public void appendModifier ( int pKind )
   {
    switch ( pKind )
    {
        case PUBLIC:
            if ( getAccess() == SYMBOL_ACCESS_PRIVATE )
                throw new IllegalArgumentException ( "public or private may only be specified once." );
            else
                this.accessLevel = SYMBOL_ACCESS_PUBLIC;
            break;

        case PRIVATE:
            if ( getAccess() == SYMBOL_ACCESS_PUBLIC )
                throw new IllegalArgumentException ( "public or private may only be specified once." );
            else
                this.accessLevel = SYMBOL_ACCESS_PRIVATE;
            break;

        case STATIC:
            this.isStatic = true;
            break;

        case FINAL:
            this.isFinal = true;
            break;

        default:
            //  Shouldn't get here.
            throw new IllegalStateException( String.valueOf ( pKind ) );
    }
   }

   /**
    *  Translate java.lang.reflect modifiers to Symbol settings.
    *  Called during construction of compiler-level representations
    *  of method and field data.
    */
   public void setModifiers ( int modifiers )
   {
    if ( Modifier.isStatic(modifiers) )
        this.isStatic = true;

    if ( Modifier.isFinal(modifiers) )
        this.isFinal = true;

    if ( Modifier.isPrivate(modifiers) )
        this.accessLevel = SYMBOL_ACCESS_PRIVATE;

    if ( Modifier.isPublic(modifiers) )
        this.accessLevel = SYMBOL_ACCESS_PUBLIC;
   }

   /**
    * @return this Symbol's access modifiers, translated to BCEL format.
    */
   public int getAccesslevel()
   {
    int result = 0;

    if ( this.isPublic() )
        result = ACC_PUBLIC;
    else if ( this.isPrivate() )
        result = ACC_PRIVATE;

    if ( this.isFinal() )
        result |= ACC_FINAL;

    if ( this.isStatic() )
        result |= ACC_STATIC;

    return result;
   }

   /** @return this Symbol's BCEL type. */
   public Type getType()
   {
    return this.clazz.getType();
   }

   /**
    * Set this symbol's slot number, which
    * implies it's a local variable.
    */
   public void setSlotnumber(int slot)
   {
    this.slotNumber = slot;
   }

   /**
    *  @return this Symbol's slot number,
    *    or -1 if it's not a local variable.
    */
   public int getSlotnumber()
   {
    return this.slotNumber;
   }

   /** @return true if this is a local variable. */
   public boolean isLocal()
   {
    return getSlotnumber() > -1;
   }

   /**
    *  Called when the parser sees the "[]" pseudo-modifier
    *  on a declaration.  May be called many times.
    */
   public void setDimension ( int i)
   {
    this.arrayDimension = i;
    setSymbolClass ( getSymbolClass().getArrayType( this.arrayDimension ) );
   }

   public int getDimension()
   {
    return this.arrayDimension;
   }

   /**
    *  @return this Symbol's class signature.
    */
   public String getSignature()
   {
    return this.clazz.getSignature();
   }


   /**
    *  This Symbol represents a field; give it a FieldGen.
    */
   public void makeField ( ConstantPoolGen cp )
   {
    this.fieldGen = new FieldGen ( getAccesslevel(), getType(), getName(), cp );

    if ( hasIntValue() )
        this.fieldGen.setInitValue( intValue() );
   }

   /** @return this Symbol's FieldGen, assuming it is a field; null otherwise. */
   public FieldGen getFieldGen()
   {
    return this.fieldGen;
   }

   /**
    *
    */
   public void setIntValue ( int initializer )
   {
    this.staticConstantInitializer = new Integer(initializer);
   }

   public boolean hasIntValue()
   {
    return this.staticConstantInitializer != null && this.staticConstantInitializer instanceof Integer;
   }

   public int intValue()
   {
    return ((Integer)this.staticConstantInitializer).intValue();
   }
}
