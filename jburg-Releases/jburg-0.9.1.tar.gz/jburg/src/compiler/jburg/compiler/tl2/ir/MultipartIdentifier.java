package jburg.compiler.tl2.ir;

import jburg.compiler.tl2.parser.Token;

import java.util.Vector;

/**
 *  A MultipartIdentifier holds the parsed-out constituent
 *  identifiers of a sequence such as a.b.c.
 */

public class MultipartIdentifier
{
   Vector parts;

   private int limit;
   private TL2INode root;
   private TL2INode current;

   public MultipartIdentifier( Token t)
   {
    parts = new Vector();
    append(t);
   }

   public void append ( Token t )
   {
    parts.add ( t );
   }

   public int size()
   {
    return parts.size();
   }

   public Token elementAt(int idx)
   {
    return (Token)parts.elementAt(idx);
   }

   public boolean isEmpty()
   {
    return size() == 0;
   }

   /**
	*  @return the tokens recombined into their original a.b.c dotted format.
	*/
   public String toString()
   {
    StringBuffer result = new StringBuffer ( parts.elementAt(0).toString() );

    for ( int i = 1; i < parts.size(); i++ )
    {
        result.append (".");
        result.append ( parts.elementAt(i).toString() );
    }

    return result.toString();
   }
}
