// $ANTLR 2.7.7 (2006-11-01): "jburg.g" -> "JBurgParser.java"$

package jburg.parser;


import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.io.*;

import antlr.CommonAST;
import antlr.collections.AST;

public class JBurgParser extends antlr.LLkParser       implements JBurgTokenTypes
 {

    /*
     *  Error-handling code.
     */
    boolean parseOk = true;

	public void reportError(antlr.RecognitionException e)
	{
        super.reportError(e);
        parseOk = false;
	}

    public boolean parseSuccessful()
    {
        return this.parseOk;
    }

protected JBurgParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public JBurgParser(TokenBuffer tokenBuf) {
  this(tokenBuf,7);
}

protected JBurgParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public JBurgParser(TokenStream lexer) {
  this(lexer,7);
}

public JBurgParser(ParserSharedInputState state) {
  super(state,7);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void cost_function() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cost_function_AST = null;
		Token  funcId = null;
		AST funcId_AST = null;
		Token  functionBody = null;
		AST functionBody_AST = null;
		
		try {      // for error handling
			funcId = LT(1);
			funcId_AST = astFactory.create(funcId);
			match(IDENTIFIER);
			AST tmp1_AST = null;
			tmp1_AST = astFactory.create(LT(1));
			match(LPAREN);
			AST tmp2_AST = null;
			tmp2_AST = astFactory.create(LT(1));
			match(RPAREN);
			functionBody = LT(1);
			functionBody_AST = astFactory.create(functionBody);
			match(BLOCK);
			if ( inputState.guessing==0 ) {
				cost_function_AST = (AST)currentAST.root;
				
				cost_function_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(COST_FUNCTION)).add(funcId_AST).add(functionBody_AST));
				
				currentAST.root = cost_function_AST;
				currentAST.child = cost_function_AST!=null &&cost_function_AST.getFirstChild()!=null ?
					cost_function_AST.getFirstChild() : cost_function_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = cost_function_AST;
	}
	
	public final void cost_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cost_specification_AST = null;
		
		try {      // for error handling
			match(COLON);
			{
			if ((LA(1)==IDENTIFIER||LA(1)==INT) && (_tokenSet_1.member(LA(2)))) {
				simple_cost_spec();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN)) {
				function_call();
				astFactory.addASTChild(currentAST, returnAST);
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			cost_specification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = cost_specification_AST;
	}
	
	public final void simple_cost_spec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST simple_cost_spec_AST = null;
		Token  iCost = null;
		AST iCost_AST = null;
		AST sCost_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case INT:
			{
				iCost = LT(1);
				iCost_AST = astFactory.create(iCost);
				match(INT);
				if ( inputState.guessing==0 ) {
					simple_cost_spec_AST = (AST)currentAST.root;
					
					simple_cost_spec_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LITERAL_COST_SPEC)).add(iCost_AST));
					
					currentAST.root = simple_cost_spec_AST;
					currentAST.child = simple_cost_spec_AST!=null &&simple_cost_spec_AST.getFirstChild()!=null ?
						simple_cost_spec_AST.getFirstChild() : simple_cost_spec_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case IDENTIFIER:
			{
				multipart_identifier();
				sCost_AST = (AST)returnAST;
				if ( inputState.guessing==0 ) {
					simple_cost_spec_AST = (AST)currentAST.root;
					
					simple_cost_spec_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(SYMBOLIC_COST_SPEC)).add(sCost_AST));
					
					currentAST.root = simple_cost_spec_AST;
					currentAST.child = simple_cost_spec_AST!=null &&simple_cost_spec_AST.getFirstChild()!=null ?
						simple_cost_spec_AST.getFirstChild() : simple_cost_spec_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = simple_cost_spec_AST;
	}
	
	public final void function_call() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST function_call_AST = null;
		Token  funcId = null;
		AST funcId_AST = null;
		
		try {      // for error handling
			funcId = LT(1);
			funcId_AST = astFactory.create(funcId);
			match(IDENTIFIER);
			AST tmp4_AST = null;
			tmp4_AST = astFactory.create(LT(1));
			match(LPAREN);
			AST tmp5_AST = null;
			tmp5_AST = astFactory.create(LT(1));
			match(RPAREN);
			if ( inputState.guessing==0 ) {
				function_call_AST = (AST)currentAST.root;
				
				function_call_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(FUNCTION_CALL)).add(funcId_AST));
				
				currentAST.root = function_call_AST;
				currentAST.child = function_call_AST!=null &&function_call_AST.getFirstChild()!=null ?
					function_call_AST.getFirstChild() : function_call_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_2);
			} else {
			  throw ex;
			}
		}
		returnAST = function_call_AST;
	}
	
	public final void declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST declaration_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case DEFAULT_ERROR_HANDLER:
			{
				error_handler_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case IMPLEMENTS:
			{
				implements_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LANGUAGE:
			{
				language_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case HEADER:
			{
				header_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case INODE_TYPE:
			{
				inode_type_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case INODE_ADAPTER:
			{
				inode_adapter_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case PACKAGE:
			{
				package_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case BURM_PROPERTY:
			{
				property_specification();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case BLOCK:
			{
				inclass_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case RETURN_TYPE:
			{
				return_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case OPCODE_TYPE:
			{
				opcode_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case JBURG_MANIFEST_CONSTANT:
			{
				manifest_constant();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = declaration_AST;
	}
	
	public final void error_handler_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST error_handler_declaration_AST = null;
		Token  action = null;
		AST action_AST = null;
		
		try {      // for error handling
			AST tmp6_AST = null;
			tmp6_AST = astFactory.create(LT(1));
			match(DEFAULT_ERROR_HANDLER);
			action = LT(1);
			action_AST = astFactory.create(action);
			match(BLOCK);
			if ( inputState.guessing==0 ) {
				error_handler_declaration_AST = (AST)currentAST.root;
				
				error_handler_declaration_AST  = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(tmp6_AST)).add(action_AST));
				
				currentAST.root = error_handler_declaration_AST;
				currentAST.child = error_handler_declaration_AST!=null &&error_handler_declaration_AST.getFirstChild()!=null ?
					error_handler_declaration_AST.getFirstChild() : error_handler_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = error_handler_declaration_AST;
	}
	
	public final void implements_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST implements_declaration_AST = null;
		AST implements_interface_name_AST = null;
		
		try {      // for error handling
			AST tmp7_AST = null;
			tmp7_AST = astFactory.create(LT(1));
			match(IMPLEMENTS);
			multipart_identifier();
			implements_interface_name_AST = (AST)returnAST;
			AST tmp8_AST = null;
			tmp8_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				implements_declaration_AST = (AST)currentAST.root;
				
				implements_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(IMPLEMENTS_INTERFACE_SPECIFICATION)).add(implements_interface_name_AST));
				
				currentAST.root = implements_declaration_AST;
				currentAST.child = implements_declaration_AST!=null &&implements_declaration_AST.getFirstChild()!=null ?
					implements_declaration_AST.getFirstChild() : implements_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = implements_declaration_AST;
	}
	
	public final void language_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST language_declaration_AST = null;
		Token  lang_name = null;
		AST lang_name_AST = null;
		
		try {      // for error handling
			AST tmp9_AST = null;
			tmp9_AST = astFactory.create(LT(1));
			match(LANGUAGE);
			lang_name = LT(1);
			lang_name_AST = astFactory.create(lang_name);
			match(IDENTIFIER);
			AST tmp10_AST = null;
			tmp10_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				language_declaration_AST = (AST)currentAST.root;
				
					language_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LANGUAGE_DECLARATION)).add(lang_name_AST));
				
				currentAST.root = language_declaration_AST;
				currentAST.child = language_declaration_AST!=null &&language_declaration_AST.getFirstChild()!=null ?
					language_declaration_AST.getFirstChild() : language_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = language_declaration_AST;
	}
	
	public final void header_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST header_declaration_AST = null;
		Token  header_block = null;
		AST header_block_AST = null;
		
		try {      // for error handling
			AST tmp11_AST = null;
			tmp11_AST = astFactory.create(LT(1));
			match(HEADER);
			header_block = LT(1);
			header_block_AST = astFactory.create(header_block);
			match(BLOCK);
			if ( inputState.guessing==0 ) {
				header_declaration_AST = (AST)currentAST.root;
				
				header_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(HEADER_DECLARATION)).add(header_block_AST));
				
				currentAST.root = header_declaration_AST;
				currentAST.child = header_declaration_AST!=null &&header_declaration_AST.getFirstChild()!=null ?
					header_declaration_AST.getFirstChild() : header_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = header_declaration_AST;
	}
	
	public final void inode_type_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inode_type_declaration_AST = null;
		AST inode_type_AST = null;
		
		try {      // for error handling
			AST tmp12_AST = null;
			tmp12_AST = astFactory.create(LT(1));
			match(INODE_TYPE);
			multipart_identifier();
			inode_type_AST = (AST)returnAST;
			AST tmp13_AST = null;
			tmp13_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				inode_type_declaration_AST = (AST)currentAST.root;
				
				inode_type_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INODE_TYPE_DECLARATION)).add(inode_type_AST));
				
				currentAST.root = inode_type_declaration_AST;
				currentAST.child = inode_type_declaration_AST!=null &&inode_type_declaration_AST.getFirstChild()!=null ?
					inode_type_declaration_AST.getFirstChild() : inode_type_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = inode_type_declaration_AST;
	}
	
	public final void inode_adapter_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inode_adapter_declaration_AST = null;
		AST inode_adapter_class_AST = null;
		
		try {      // for error handling
			AST tmp14_AST = null;
			tmp14_AST = astFactory.create(LT(1));
			match(INODE_ADAPTER);
			multipart_identifier();
			inode_adapter_class_AST = (AST)returnAST;
			AST tmp15_AST = null;
			tmp15_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				inode_adapter_declaration_AST = (AST)currentAST.root;
				
				inode_adapter_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INODE_ADAPTER_DECLARATION)).add(inode_adapter_class_AST));
				
				currentAST.root = inode_adapter_declaration_AST;
				currentAST.child = inode_adapter_declaration_AST!=null &&inode_adapter_declaration_AST.getFirstChild()!=null ?
					inode_adapter_declaration_AST.getFirstChild() : inode_adapter_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = inode_adapter_declaration_AST;
	}
	
	public final void package_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST package_declaration_AST = null;
		AST package_name_AST = null;
		
		try {      // for error handling
			AST tmp16_AST = null;
			tmp16_AST = astFactory.create(LT(1));
			match(PACKAGE);
			multipart_identifier();
			package_name_AST = (AST)returnAST;
			AST tmp17_AST = null;
			tmp17_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				package_declaration_AST = (AST)currentAST.root;
				
				package_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PACKAGE_SPECIFICATION)).add(package_name_AST));
				
				currentAST.root = package_declaration_AST;
				currentAST.child = package_declaration_AST!=null &&package_declaration_AST.getFirstChild()!=null ?
					package_declaration_AST.getFirstChild() : package_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = package_declaration_AST;
	}
	
	public final void property_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST property_specification_AST = null;
		AST property_type_AST = null;
		Token  property_name = null;
		AST property_name_AST = null;
		
		try {      // for error handling
			AST tmp18_AST = null;
			tmp18_AST = astFactory.create(LT(1));
			match(BURM_PROPERTY);
			type_name();
			property_type_AST = (AST)returnAST;
			property_name = LT(1);
			property_name_AST = astFactory.create(property_name);
			match(IDENTIFIER);
			AST tmp19_AST = null;
			tmp19_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				property_specification_AST = (AST)currentAST.root;
				
				property_specification_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(PROPERTY_SPECIFICATION)).add(property_type_AST).add(property_name_AST));
				
				currentAST.root = property_specification_AST;
				currentAST.child = property_specification_AST!=null &&property_specification_AST.getFirstChild()!=null ?
					property_specification_AST.getFirstChild() : property_specification_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = property_specification_AST;
	}
	
	public final void inclass_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inclass_declaration_AST = null;
		Token  inclass_block = null;
		AST inclass_block_AST = null;
		
		try {      // for error handling
			inclass_block = LT(1);
			inclass_block_AST = astFactory.create(inclass_block);
			match(BLOCK);
			if ( inputState.guessing==0 ) {
				inclass_declaration_AST = (AST)currentAST.root;
				
					 inclass_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INCLASS_DECLARATION)).add(inclass_block_AST));
					
				currentAST.root = inclass_declaration_AST;
				currentAST.child = inclass_declaration_AST!=null &&inclass_declaration_AST.getFirstChild()!=null ?
					inclass_declaration_AST.getFirstChild() : inclass_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = inclass_declaration_AST;
	}
	
	public final void return_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST return_declaration_AST = null;
		AST return_type_AST = null;
		Token  state_name = null;
		AST state_name_AST = null;
		AST state_return_type_AST = null;
		
		try {      // for error handling
			if ((LA(1)==RETURN_TYPE) && (LA(2)==IDENTIFIER) && (_tokenSet_4.member(LA(3)))) {
				AST tmp20_AST = null;
				tmp20_AST = astFactory.create(LT(1));
				match(RETURN_TYPE);
				type_name();
				return_type_AST = (AST)returnAST;
				AST tmp21_AST = null;
				tmp21_AST = astFactory.create(LT(1));
				match(SEMI);
				if ( inputState.guessing==0 ) {
					return_declaration_AST = (AST)currentAST.root;
					
					return_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(RETURN_DECLARATION)).add(return_type_AST));
					
					currentAST.root = return_declaration_AST;
					currentAST.child = return_declaration_AST!=null &&return_declaration_AST.getFirstChild()!=null ?
						return_declaration_AST.getFirstChild() : return_declaration_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if ((LA(1)==RETURN_TYPE) && (LA(2)==IDENTIFIER) && (LA(3)==EQUALS)) {
				AST tmp22_AST = null;
				tmp22_AST = astFactory.create(LT(1));
				match(RETURN_TYPE);
				state_name = LT(1);
				state_name_AST = astFactory.create(state_name);
				match(IDENTIFIER);
				AST tmp23_AST = null;
				tmp23_AST = astFactory.create(LT(1));
				match(EQUALS);
				type_name();
				state_return_type_AST = (AST)returnAST;
				AST tmp24_AST = null;
				tmp24_AST = astFactory.create(LT(1));
				match(SEMI);
				if ( inputState.guessing==0 ) {
					return_declaration_AST = (AST)currentAST.root;
					
					return_declaration_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(TYPED_RETURN_DECLARATION)).add(state_name_AST).add(state_return_type_AST));
					
					currentAST.root = return_declaration_AST;
					currentAST.child = return_declaration_AST!=null &&return_declaration_AST.getFirstChild()!=null ?
						return_declaration_AST.getFirstChild() : return_declaration_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = return_declaration_AST;
	}
	
	public final void opcode_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST opcode_declaration_AST = null;
		AST opcodeType_AST = null;
		
		try {      // for error handling
			AST tmp25_AST = null;
			tmp25_AST = astFactory.create(LT(1));
			match(OPCODE_TYPE);
			multipart_identifier_java_only();
			opcodeType_AST = (AST)returnAST;
			AST tmp26_AST = null;
			tmp26_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				opcode_declaration_AST = (AST)currentAST.root;
				
				opcode_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(tmp25_AST)).add(opcodeType_AST));
				
				currentAST.root = opcode_declaration_AST;
				currentAST.child = opcode_declaration_AST!=null &&opcode_declaration_AST.getFirstChild()!=null ?
					opcode_declaration_AST.getFirstChild() : opcode_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = opcode_declaration_AST;
	}
	
	public final void manifest_constant() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST manifest_constant_AST = null;
		Token  constName = null;
		AST constName_AST = null;
		Token  constValue = null;
		AST constValue_AST = null;
		
		try {      // for error handling
			AST tmp27_AST = null;
			tmp27_AST = astFactory.create(LT(1));
			match(JBURG_MANIFEST_CONSTANT);
			constName = LT(1);
			constName_AST = astFactory.create(constName);
			match(IDENTIFIER);
			AST tmp28_AST = null;
			tmp28_AST = astFactory.create(LT(1));
			match(EQUALS);
			constValue = LT(1);
			constValue_AST = astFactory.create(constValue);
			match(INT);
			AST tmp29_AST = null;
			tmp29_AST = astFactory.create(LT(1));
			match(SEMI);
			if ( inputState.guessing==0 ) {
				manifest_constant_AST = (AST)currentAST.root;
				
				manifest_constant_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(MANIFEST_CONSTANT)).add(constName_AST).add(constValue_AST));
				
				currentAST.root = manifest_constant_AST;
				currentAST.child = manifest_constant_AST!=null &&manifest_constant_AST.getFirstChild()!=null ?
					manifest_constant_AST.getFirstChild() : manifest_constant_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_3);
			} else {
			  throw ex;
			}
		}
		returnAST = manifest_constant_AST;
	}
	
	public final void header_section() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST header_section_AST = null;
		
		try {      // for error handling
			{
			_loop10:
			do {
				if ((_tokenSet_5.member(LA(1)))) {
					declaration();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop10;
				}
				
			} while (true);
			}
			header_section_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = header_section_AST;
	}
	
	public final void multipart_identifier() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST multipart_identifier_AST = null;
		Token  firstPart = null;
		AST firstPart_AST = null;
		
		try {      // for error handling
			firstPart = LT(1);
			firstPart_AST = astFactory.create(firstPart);
			astFactory.addASTChild(currentAST, firstPart_AST);
			match(IDENTIFIER);
			{
			_loop21:
			do {
				if ((LA(1)==COLON||LA(1)==PERIOD)) {
					{
					switch ( LA(1)) {
					case PERIOD:
					{
						AST tmp30_AST = null;
						tmp30_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp30_AST);
						match(PERIOD);
						break;
					}
					case COLON:
					{
						{
						AST tmp31_AST = null;
						tmp31_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp31_AST);
						match(COLON);
						AST tmp32_AST = null;
						tmp32_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp32_AST);
						match(COLON);
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					AST tmp33_AST = null;
					tmp33_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp33_AST);
					match(IDENTIFIER);
				}
				else {
					break _loop21;
				}
				
			} while (true);
			}
			{
			switch ( LA(1)) {
			case STAR:
			{
				AST tmp34_AST = null;
				tmp34_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp34_AST);
				match(STAR);
				break;
			}
			case IDENTIFIER:
			case LPAREN:
			case RPAREN:
			case BLOCK:
			case SEMI:
			case COMMA:
			case PROLOGUE:
			case EXPLICIT_REDUCTION:
			case LANGLE:
			case RANGLE:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				multipart_identifier_AST = (AST)currentAST.root;
				
					   //  Coalesce all the child nodes' text.
				StringBuffer allText = new StringBuffer();
				
				AST current = firstPart_AST;
				
				while (current != null) 
						{
				allText.append(current.getText());
				current = current.getNextSibling();
						}
				
					   //  Synthesize an IDENTIFIER node, and
				//  give it the re-assembled multipart ID.
				multipart_identifier_AST = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(IDENTIFIER)));
					   multipart_identifier_AST.setText( allText.toString() );
				
				currentAST.root = multipart_identifier_AST;
				currentAST.child = multipart_identifier_AST!=null &&multipart_identifier_AST.getFirstChild()!=null ?
					multipart_identifier_AST.getFirstChild() : multipart_identifier_AST;
				currentAST.advanceChildToEnd();
			}
			multipart_identifier_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_6);
			} else {
			  throw ex;
			}
		}
		returnAST = multipart_identifier_AST;
	}
	
	public final void multipart_identifier_java_only() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST multipart_identifier_java_only_AST = null;
		Token  firstPart = null;
		AST firstPart_AST = null;
		
		try {      // for error handling
			firstPart = LT(1);
			firstPart_AST = astFactory.create(firstPart);
			astFactory.addASTChild(currentAST, firstPart_AST);
			match(IDENTIFIER);
			{
			switch ( LA(1)) {
			case PERIOD:
			{
				AST tmp35_AST = null;
				tmp35_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp35_AST);
				match(PERIOD);
				AST tmp36_AST = null;
				tmp36_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp36_AST);
				match(IDENTIFIER);
				break;
			}
			case LPAREN:
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				multipart_identifier_java_only_AST = (AST)currentAST.root;
				
					   //  Coalesce all the child nodes' text.
				StringBuffer allText = new StringBuffer();
				
				AST current = firstPart_AST;
				
				while (current != null) 
						{
				allText.append(current.getText());
				current = current.getNextSibling();
						}
				
					   //  Synthesize a node with an explict type.
				multipart_identifier_java_only_AST = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(IDENTIFIER)));
					   multipart_identifier_java_only_AST.setText( allText.toString() );
				
				currentAST.root = multipart_identifier_java_only_AST;
				currentAST.child = multipart_identifier_java_only_AST!=null &&multipart_identifier_java_only_AST.getFirstChild()!=null ?
					multipart_identifier_java_only_AST.getFirstChild() : multipart_identifier_java_only_AST;
				currentAST.advanceChildToEnd();
			}
			multipart_identifier_java_only_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_7);
			} else {
			  throw ex;
			}
		}
		returnAST = multipart_identifier_java_only_AST;
	}
	
	public final void operand_list() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operand_list_AST = null;
		AST manyop_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER||LA(2)==LPAREN||LA(2)==PERIOD) && (_tokenSet_8.member(LA(3)))) {
				operand();
				astFactory.addASTChild(currentAST, returnAST);
				{
				_loop28:
				do {
					if ((LA(1)==COMMA) && (LA(2)==IDENTIFIER) && (LA(3)==IDENTIFIER||LA(3)==LPAREN||LA(3)==PERIOD) && (_tokenSet_8.member(LA(4))) && (_tokenSet_9.member(LA(5))) && (_tokenSet_10.member(LA(6))) && (_tokenSet_11.member(LA(7)))) {
						match(COMMA);
						operand();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop28;
					}
					
				} while (true);
				}
				{
				switch ( LA(1)) {
				case COMMA:
				{
					match(COMMA);
					n_ary_operand();
					astFactory.addASTChild(currentAST, returnAST);
					break;
				}
				case RPAREN:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				if ( inputState.guessing==0 ) {
					operand_list_AST = (AST)currentAST.root;
					
					operand_list_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OPERAND_LIST)).add(operand_list_AST));
					
					currentAST.root = operand_list_AST;
					currentAST.child = operand_list_AST!=null &&operand_list_AST.getFirstChild()!=null ?
						operand_list_AST.getFirstChild() : operand_list_AST;
					currentAST.advanceChildToEnd();
				}
				operand_list_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER) && (LA(3)==STAR||LA(3)==PLUS)) {
				n_ary_operand();
				manyop_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				if ( inputState.guessing==0 ) {
					operand_list_AST = (AST)currentAST.root;
					
					operand_list_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OPERAND_LIST)).add(manyop_AST));
					
					currentAST.root = operand_list_AST;
					currentAST.child = operand_list_AST!=null &&operand_list_AST.getFirstChild()!=null ?
						operand_list_AST.getFirstChild() : operand_list_AST;
					currentAST.advanceChildToEnd();
				}
				operand_list_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_12);
			} else {
			  throw ex;
			}
		}
		returnAST = operand_list_AST;
	}
	
	public final void operand() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operand_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN||LA(2)==PERIOD)) {
				operator_specification();
				astFactory.addASTChild(currentAST, returnAST);
				operand_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER)) {
				parameter_decl();
				astFactory.addASTChild(currentAST, returnAST);
				operand_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = operand_AST;
	}
	
	public final void n_ary_operand() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST n_ary_operand_AST = null;
		AST at_least_one_operand_AST = null;
		AST arbitrary_operands_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER) && (LA(3)==PLUS)) {
				parameter_decl();
				at_least_one_operand_AST = (AST)returnAST;
				match(PLUS);
				if ( inputState.guessing==0 ) {
					n_ary_operand_AST = (AST)currentAST.root;
					
					n_ary_operand_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OPERAND_AT_LEAST_ONE_ARITY)).add(at_least_one_operand_AST));
					
					currentAST.root = n_ary_operand_AST;
					currentAST.child = n_ary_operand_AST!=null &&n_ary_operand_AST.getFirstChild()!=null ?
						n_ary_operand_AST.getFirstChild() : n_ary_operand_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER) && (LA(3)==STAR)) {
				parameter_decl();
				arbitrary_operands_AST = (AST)returnAST;
				match(STAR);
				if ( inputState.guessing==0 ) {
					n_ary_operand_AST = (AST)currentAST.root;
					
					n_ary_operand_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OPERAND_ARBITRARY_ARITY)).add(arbitrary_operands_AST));
					
					currentAST.root = n_ary_operand_AST;
					currentAST.child = n_ary_operand_AST!=null &&n_ary_operand_AST.getFirstChild()!=null ?
						n_ary_operand_AST.getFirstChild() : n_ary_operand_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_12);
			} else {
			  throw ex;
			}
		}
		returnAST = n_ary_operand_AST;
	}
	
	public final void operator_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operator_specification_AST = null;
		AST terminalId_AST = null;
		AST namedTerminalId_AST = null;
		Token  terminalName = null;
		AST terminalName_AST = null;
		AST operatorId_AST = null;
		AST operands_AST = null;
		
		try {      // for error handling
			boolean synPredMatched33 = false;
			if (((LA(1)==IDENTIFIER) && (LA(2)==LPAREN||LA(2)==PERIOD) && (LA(3)==IDENTIFIER||LA(3)==VOID) && (LA(4)==LPAREN||LA(4)==RPAREN) && (_tokenSet_14.member(LA(5))) && (_tokenSet_15.member(LA(6))) && (_tokenSet_16.member(LA(7))))) {
				int _m33 = mark();
				synPredMatched33 = true;
				inputState.guessing++;
				try {
					{
					multipart_identifier_java_only();
					match(LPAREN);
					match(VOID);
					match(RPAREN);
					}
				}
				catch (RecognitionException pe) {
					synPredMatched33 = false;
				}
				rewind(_m33);
inputState.guessing--;
			}
			if ( synPredMatched33 ) {
				multipart_identifier_java_only();
				terminalId_AST = (AST)returnAST;
				AST tmp41_AST = null;
				tmp41_AST = astFactory.create(LT(1));
				match(LPAREN);
				AST tmp42_AST = null;
				tmp42_AST = astFactory.create(LT(1));
				match(VOID);
				AST tmp43_AST = null;
				tmp43_AST = astFactory.create(LT(1));
				match(RPAREN);
				if ( inputState.guessing==0 ) {
					operator_specification_AST = (AST)currentAST.root;
					
					operator_specification_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(TERMINAL_PATTERN)).add(terminalId_AST));
					
					currentAST.root = operator_specification_AST;
					currentAST.child = operator_specification_AST!=null &&operator_specification_AST.getFirstChild()!=null ?
						operator_specification_AST.getFirstChild() : operator_specification_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				boolean synPredMatched35 = false;
				if (((LA(1)==IDENTIFIER) && (LA(2)==LPAREN||LA(2)==PERIOD) && (LA(3)==IDENTIFIER||LA(3)==VOID) && (LA(4)==LPAREN||LA(4)==RPAREN) && (LA(5)==IDENTIFIER||LA(5)==VOID) && (_tokenSet_17.member(LA(6))) && (_tokenSet_15.member(LA(7))))) {
					int _m35 = mark();
					synPredMatched35 = true;
					inputState.guessing++;
					try {
						{
						multipart_identifier_java_only();
						match(LPAREN);
						match(VOID);
						match(RPAREN);
						match(IDENTIFIER);
						}
					}
					catch (RecognitionException pe) {
						synPredMatched35 = false;
					}
					rewind(_m35);
inputState.guessing--;
				}
				if ( synPredMatched35 ) {
					multipart_identifier_java_only();
					namedTerminalId_AST = (AST)returnAST;
					AST tmp44_AST = null;
					tmp44_AST = astFactory.create(LT(1));
					match(LPAREN);
					AST tmp45_AST = null;
					tmp45_AST = astFactory.create(LT(1));
					match(VOID);
					AST tmp46_AST = null;
					tmp46_AST = astFactory.create(LT(1));
					match(RPAREN);
					terminalName = LT(1);
					terminalName_AST = astFactory.create(terminalName);
					match(IDENTIFIER);
					if ( inputState.guessing==0 ) {
						operator_specification_AST = (AST)currentAST.root;
						
						operator_specification_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(TERMINAL_PATTERN)).add(namedTerminalId_AST).add(terminalName_AST));
						
						currentAST.root = operator_specification_AST;
						currentAST.child = operator_specification_AST!=null &&operator_specification_AST.getFirstChild()!=null ?
							operator_specification_AST.getFirstChild() : operator_specification_AST;
						currentAST.advanceChildToEnd();
					}
				}
				else if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN||LA(2)==PERIOD) && (LA(3)==IDENTIFIER) && (LA(4)==IDENTIFIER||LA(4)==LPAREN||LA(4)==PERIOD) && (_tokenSet_18.member(LA(5))) && (_tokenSet_9.member(LA(6))) && (_tokenSet_10.member(LA(7)))) {
					multipart_identifier_java_only();
					operatorId_AST = (AST)returnAST;
					AST tmp47_AST = null;
					tmp47_AST = astFactory.create(LT(1));
					match(LPAREN);
					operand_list();
					operands_AST = (AST)returnAST;
					AST tmp48_AST = null;
					tmp48_AST = astFactory.create(LT(1));
					match(RPAREN);
					if ( inputState.guessing==0 ) {
						operator_specification_AST = (AST)currentAST.root;
						
						operator_specification_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(OPERATOR_SPECIFICATION)).add(operatorId_AST).add(operands_AST));
						
						currentAST.root = operator_specification_AST;
						currentAST.child = operator_specification_AST!=null &&operator_specification_AST.getFirstChild()!=null ?
							operator_specification_AST.getFirstChild() : operator_specification_AST;
						currentAST.advanceChildToEnd();
					}
				}
				else {
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
			}
			catch (RecognitionException ex) {
				if (inputState.guessing==0) {
					reportError(ex);
					recover(ex,_tokenSet_17);
				} else {
				  throw ex;
				}
			}
			returnAST = operator_specification_AST;
		}
		
	public final void parameter_decl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameter_decl_AST = null;
		Token  id1 = null;
		AST id1_AST = null;
		Token  id2 = null;
		AST id2_AST = null;
		
		try {      // for error handling
			id1 = LT(1);
			id1_AST = astFactory.create(id1);
			match(IDENTIFIER);
			id2 = LT(1);
			id2_AST = astFactory.create(id2);
			match(IDENTIFIER);
			if ( inputState.guessing==0 ) {
				parameter_decl_AST = (AST)currentAST.root;
				
					    parameter_decl_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(NON_TERMINAL_PARAMETER)).add(id1_AST).add(id2_AST));
					
				currentAST.root = parameter_decl_AST;
				currentAST.child = parameter_decl_AST!=null &&parameter_decl_AST.getFirstChild()!=null ?
					parameter_decl_AST.getFirstChild() : parameter_decl_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_19);
			} else {
			  throw ex;
			}
		}
		returnAST = parameter_decl_AST;
	}
	
	public final void pattern_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST pattern_declaration_AST = null;
		Token  name = null;
		AST name_AST = null;
		AST pattern_AST = null;
		
		try {      // for error handling
			AST tmp49_AST = null;
			tmp49_AST = astFactory.create(LT(1));
			match(PATTERN);
			name = LT(1);
			name_AST = astFactory.create(name);
			match(IDENTIFIER);
			pattern_specification();
			pattern_AST = (AST)returnAST;
			if ( inputState.guessing==0 ) {
				pattern_declaration_AST = (AST)currentAST.root;
				
				pattern_declaration_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(PATTERN_DECLARATION)).add(name_AST).add(pattern_AST));
				
				currentAST.root = pattern_declaration_AST;
				currentAST.child = pattern_declaration_AST!=null &&pattern_declaration_AST.getFirstChild()!=null ?
					pattern_declaration_AST.getFirstChild() : pattern_declaration_AST;
				currentAST.advanceChildToEnd();
			}
			AST tmp50_AST = null;
			tmp50_AST = astFactory.create(LT(1));
			match(SEMI);
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = pattern_declaration_AST;
	}
	
	public final void pattern_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST pattern_specification_AST = null;
		AST op_AST = null;
		
		try {      // for error handling
			operator_specification();
			op_AST = (AST)returnAST;
			if ( inputState.guessing==0 ) {
				pattern_specification_AST = (AST)currentAST.root;
				
						pattern_specification_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PATTERN_SPECIFICATION)).add(op_AST));
					
				currentAST.root = pattern_specification_AST;
				currentAST.child = pattern_specification_AST!=null &&pattern_specification_AST.getFirstChild()!=null ?
					pattern_specification_AST.getFirstChild() : pattern_specification_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_20);
			} else {
			  throw ex;
			}
		}
		returnAST = pattern_specification_AST;
	}
	
	public final void procedure_call() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST procedure_call_AST = null;
		AST id_AST = null;
		AST first_param_AST = null;
		AST next_param_AST = null;
		
		AST result = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(PROCEDURE_CALL)));
		
		
		try {      // for error handling
			multipart_identifier();
			id_AST = (AST)returnAST;
			if ( inputState.guessing==0 ) {
				result.addChild(id_AST);
			}
			AST tmp51_AST = null;
			tmp51_AST = astFactory.create(LT(1));
			match(LPAREN);
			{
			switch ( LA(1)) {
			case IDENTIFIER:
			case INT:
			case SHARP:
			{
				procedure_parameter();
				first_param_AST = (AST)returnAST;
				if ( inputState.guessing==0 ) {
					result.addChild(first_param_AST);
				}
				{
				_loop44:
				do {
					if ((LA(1)==COMMA)) {
						AST tmp52_AST = null;
						tmp52_AST = astFactory.create(LT(1));
						match(COMMA);
						procedure_parameter();
						next_param_AST = (AST)returnAST;
						if ( inputState.guessing==0 ) {
							result.addChild(next_param_AST);
						}
					}
					else {
						break _loop44;
					}
					
				} while (true);
				}
				break;
			}
			case RPAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			AST tmp53_AST = null;
			tmp53_AST = astFactory.create(LT(1));
			match(RPAREN);
			if ( inputState.guessing==0 ) {
				procedure_call_AST = (AST)currentAST.root;
				
				procedure_call_AST = result;
				
				currentAST.root = procedure_call_AST;
				currentAST.child = procedure_call_AST!=null &&procedure_call_AST.getFirstChild()!=null ?
					procedure_call_AST.getFirstChild() : procedure_call_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_21);
			} else {
			  throw ex;
			}
		}
		returnAST = procedure_call_AST;
	}
	
	public final void procedure_parameter() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST procedure_parameter_AST = null;
		Token  sharp = null;
		AST sharp_AST = null;
		AST id_AST = null;
		Token  numeric_literal = null;
		AST numeric_literal_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case IDENTIFIER:
			case SHARP:
			{
				{
				switch ( LA(1)) {
				case SHARP:
				{
					sharp = LT(1);
					sharp_AST = astFactory.create(sharp);
					match(SHARP);
					break;
				}
				case IDENTIFIER:
				{
					break;
				}
				default:
				{
					throw new NoViableAltException(LT(1), getFilename());
				}
				}
				}
				multipart_identifier();
				id_AST = (AST)returnAST;
				if ( inputState.guessing==0 ) {
					procedure_parameter_AST = (AST)currentAST.root;
					
					if ( sharp == null )
					procedure_parameter_AST = id_AST;
					else
					{
					String composite_param = "#" + id_AST.getText();
					procedure_parameter_AST = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(IDENTIFIER)));
					procedure_parameter_AST.setText(composite_param);
					}
					
					currentAST.root = procedure_parameter_AST;
					currentAST.child = procedure_parameter_AST!=null &&procedure_parameter_AST.getFirstChild()!=null ?
						procedure_parameter_AST.getFirstChild() : procedure_parameter_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case INT:
			{
				numeric_literal = LT(1);
				numeric_literal_AST = astFactory.create(numeric_literal);
				match(INT);
				if ( inputState.guessing==0 ) {
					procedure_parameter_AST = (AST)currentAST.root;
					
					procedure_parameter_AST = numeric_literal_AST;
					
					currentAST.root = procedure_parameter_AST;
					currentAST.child = procedure_parameter_AST!=null &&procedure_parameter_AST.getFirstChild()!=null ?
						procedure_parameter_AST.getFirstChild() : procedure_parameter_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_13);
			} else {
			  throw ex;
			}
		}
		returnAST = procedure_parameter_AST;
	}
	
	public final void prologue_section() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST prologue_section_AST = null;
		Token  b = null;
		AST b_AST = null;
		AST p_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case BLOCK:
			{
				b = LT(1);
				b_AST = astFactory.create(b);
				match(BLOCK);
				if ( inputState.guessing==0 ) {
					prologue_section_AST = (AST)currentAST.root;
					prologue_section_AST = b_AST;
					currentAST.root = prologue_section_AST;
					currentAST.child = prologue_section_AST!=null &&prologue_section_AST.getFirstChild()!=null ?
						prologue_section_AST.getFirstChild() : prologue_section_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case IDENTIFIER:
			{
				procedure_call();
				p_AST = (AST)returnAST;
				if ( inputState.guessing==0 ) {
					prologue_section_AST = (AST)currentAST.root;
					prologue_section_AST = p_AST;
					currentAST.root = prologue_section_AST;
					currentAST.child = prologue_section_AST!=null &&prologue_section_AST.getFirstChild()!=null ?
						prologue_section_AST.getFirstChild() : prologue_section_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_22);
			} else {
			  throw ex;
			}
		}
		returnAST = prologue_section_AST;
	}
	
	public final void type_name() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST type_name_AST = null;
		AST stem_AST = null;
		AST ptype_AST = null;
		
		try {      // for error handling
			multipart_identifier();
			stem_AST = (AST)returnAST;
			{
			switch ( LA(1)) {
			case LANGLE:
			{
				AST tmp54_AST = null;
				tmp54_AST = astFactory.create(LT(1));
				match(LANGLE);
				multipart_identifier();
				ptype_AST = (AST)returnAST;
				AST tmp55_AST = null;
				tmp55_AST = astFactory.create(LT(1));
				match(RANGLE);
				break;
			}
			case IDENTIFIER:
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				type_name_AST = (AST)currentAST.root;
				
				if ( null == ptype_AST )
				{
				type_name_AST = stem_AST;
				}
				else
				{
				StringBuffer buffer = new StringBuffer(stem_AST.getText());
				buffer.append("<");
				buffer.append(ptype_AST.getText());
				buffer.append(">");
				type_name_AST = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(IDENTIFIER)));
				type_name_AST.setText(buffer.toString());
				}
				
				currentAST.root = type_name_AST;
				currentAST.child = type_name_AST!=null &&type_name_AST.getFirstChild()!=null ?
					type_name_AST.getFirstChild() : type_name_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_23);
			} else {
			  throw ex;
			}
		}
		returnAST = type_name_AST;
	}
	
/**
 *  Reduce a rule.
 *  Rule types are:<ul>
 *  <li>  Pattern rules, which combine subgoals with other nodes further up the tree.
 *  <li>  Simple transformation rules.  Like iBurg's chain rules, simple transformation
 *        rules allow one goal to satisfy additional goals.
 *  <li>  Complex transformation rules, which allow the reducer to actively transform
 *        a subgoal to satisfy additional subgoals.
 *  </ul>
 */
	public final void rule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rule_AST = null;
		Token  nonTerminalRuleId = null;
		AST nonTerminalRuleId_AST = null;
		AST pattern_AST = null;
		AST cost_AST = null;
		AST action_AST = null;
		Token  simpleTransformationTarget = null;
		AST simpleTransformationTarget_AST = null;
		Token  simpleTransformationSource = null;
		AST simpleTransformationSource_AST = null;
		Token  transformationTarget = null;
		AST transformationTarget_AST = null;
		Token  transformationSource = null;
		AST transformationSource_AST = null;
		AST transformationCost_AST = null;
		AST transformationAction_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==LPAREN||LA(4)==PERIOD)) {
				nonTerminalRuleId = LT(1);
				nonTerminalRuleId_AST = astFactory.create(nonTerminalRuleId);
				match(IDENTIFIER);
				AST tmp56_AST = null;
				tmp56_AST = astFactory.create(LT(1));
				match(EQUALS);
				pattern_specification();
				pattern_AST = (AST)returnAST;
				cost_specification();
				cost_AST = (AST)returnAST;
				reduction_action();
				action_AST = (AST)returnAST;
				if ( inputState.guessing==0 ) {
					rule_AST = (AST)currentAST.root;
					
					rule_AST = (AST)astFactory.make( (new ASTArray(5)).add(astFactory.create(PATTERN_RULE)).add(nonTerminalRuleId_AST).add(pattern_AST).add(cost_AST).add(action_AST));
					
					currentAST.root = rule_AST;
					currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
						rule_AST.getFirstChild() : rule_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==SEMI)) {
				simpleTransformationTarget = LT(1);
				simpleTransformationTarget_AST = astFactory.create(simpleTransformationTarget);
				match(IDENTIFIER);
				match(EQUALS);
				simpleTransformationSource = LT(1);
				simpleTransformationSource_AST = astFactory.create(simpleTransformationSource);
				match(IDENTIFIER);
				match(SEMI);
				if ( inputState.guessing==0 ) {
					rule_AST = (AST)currentAST.root;
					
					rule_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(SIMPLE_TRANSFORMATION_RULE)).add(simpleTransformationTarget_AST).add(simpleTransformationSource_AST));
					
					currentAST.root = rule_AST;
					currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
						rule_AST.getFirstChild() : rule_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==COLON)) {
				transformationTarget = LT(1);
				transformationTarget_AST = astFactory.create(transformationTarget);
				match(IDENTIFIER);
				match(EQUALS);
				transformationSource = LT(1);
				transformationSource_AST = astFactory.create(transformationSource);
				match(IDENTIFIER);
				cost_specification();
				transformationCost_AST = (AST)returnAST;
				reduction_action();
				transformationAction_AST = (AST)returnAST;
				if ( inputState.guessing==0 ) {
					rule_AST = (AST)currentAST.root;
					
					rule_AST = (AST)astFactory.make( (new ASTArray(5)).add(astFactory.create(TRANSFORMATION_RULE)).add(transformationTarget_AST).add(transformationSource_AST).add(transformationCost_AST).add(transformationAction_AST));
					
					currentAST.root = rule_AST;
					currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
						rule_AST.getFirstChild() : rule_AST;
					currentAST.advanceChildToEnd();
				}
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = rule_AST;
	}
	
	public final void reduction_action() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST reduction_action_AST = null;
		AST prologue_AST = null;
		AST reducer_call_AST = null;
		Token  action = null;
		AST action_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case PROLOGUE:
			{
				AST tmp60_AST = null;
				tmp60_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp60_AST);
				match(PROLOGUE);
				prologue_section();
				prologue_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case BLOCK:
			case EXPLICIT_REDUCTION:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			{
			switch ( LA(1)) {
			case EXPLICIT_REDUCTION:
			{
				AST tmp61_AST = null;
				tmp61_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp61_AST);
				match(EXPLICIT_REDUCTION);
				procedure_call();
				reducer_call_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				AST tmp62_AST = null;
				tmp62_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp62_AST);
				match(SEMI);
				if ( inputState.guessing==0 ) {
					reduction_action_AST = (AST)currentAST.root;
					
					reduction_action_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(tmp61_AST)).add(reducer_call_AST));
					
					currentAST.root = reduction_action_AST;
					currentAST.child = reduction_action_AST!=null &&reduction_action_AST.getFirstChild()!=null ?
						reduction_action_AST.getFirstChild() : reduction_action_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			case BLOCK:
			{
				action = LT(1);
				action_AST = astFactory.create(action);
				astFactory.addASTChild(currentAST, action_AST);
				match(BLOCK);
				if ( inputState.guessing==0 ) {
					reduction_action_AST = (AST)currentAST.root;
					
					reduction_action_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(REDUCTION_ACTION)).add(action_AST));
					
					currentAST.root = reduction_action_AST;
					currentAST.child = reduction_action_AST!=null &&reduction_action_AST.getFirstChild()!=null ?
						reduction_action_AST.getFirstChild() : reduction_action_AST;
					currentAST.advanceChildToEnd();
				}
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			if ( inputState.guessing==0 ) {
				reduction_action_AST = (AST)currentAST.root;
				
				if ( prologue_AST != null )
				reduction_action_AST.addChild((AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PROLOGUE)).add(prologue_AST)));
				
			}
			reduction_action_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = reduction_action_AST;
	}
	
	public final void reduction_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST reduction_declaration_AST = null;
		Token  nonTerminalRuleId = null;
		AST nonTerminalRuleId_AST = null;
		Token  name = null;
		AST name_AST = null;
		AST cost_AST = null;
		AST r_AST = null;
		
		try {      // for error handling
			nonTerminalRuleId = LT(1);
			nonTerminalRuleId_AST = astFactory.create(nonTerminalRuleId);
			match(IDENTIFIER);
			AST tmp63_AST = null;
			tmp63_AST = astFactory.create(LT(1));
			match(EQUALS);
			AST tmp64_AST = null;
			tmp64_AST = astFactory.create(LT(1));
			match(PATTERN);
			name = LT(1);
			name_AST = astFactory.create(name);
			match(IDENTIFIER);
			cost_specification();
			cost_AST = (AST)returnAST;
			reduction_action();
			r_AST = (AST)returnAST;
			if ( inputState.guessing==0 ) {
				reduction_declaration_AST = (AST)currentAST.root;
				
				reduction_declaration_AST = (AST)astFactory.make( (new ASTArray(5)).add(astFactory.create(REDUCTION_DECLARATION)).add(nonTerminalRuleId_AST).add(name_AST).add(cost_AST).add(r_AST));
				
				currentAST.root = reduction_declaration_AST;
				currentAST.child = reduction_declaration_AST!=null &&reduction_declaration_AST.getFirstChild()!=null ?
					reduction_declaration_AST.getFirstChild() : reduction_declaration_AST;
				currentAST.advanceChildToEnd();
			}
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_0);
			} else {
			  throw ex;
			}
		}
		returnAST = reduction_declaration_AST;
	}
	
	public final void specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST specification_AST = null;
		
		try {      // for error handling
			header_section();
			astFactory.addASTChild(currentAST, returnAST);
			{
			_loop58:
			do {
				if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER)) {
					rule();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN)) {
					cost_function();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==PATTERN)) {
					pattern_declaration();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==PATTERN)) {
					reduction_declaration();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					break _loop58;
				}
				
			} while (true);
			}
			match(Token.EOF_TYPE);
			specification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			if (inputState.guessing==0) {
				reportError(ex);
				recover(ex,_tokenSet_24);
			} else {
			  throw ex;
			}
		}
		returnAST = specification_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"COST_FUNCTION",
		"FUNCTION_CALL",
		"HEADER_DECLARATION",
		"IMPLEMENTS_INTERFACE_SPECIFICATION",
		"INCLASS_DECLARATION",
		"INODE_ADAPTER_DECLARATION",
		"INODE_TYPE_DECLARATION",
		"LANGUAGE_DECLARATION",
		"MANIFEST_CONSTANT",
		"NON_TERMINAL_PARAMETER",
		"LITERAL_COST_SPEC",
		"OPERATOR_SPECIFICATION",
		"OPERAND_LIST",
		"OPERAND_AT_LEAST_ONE_ARITY",
		"OPERAND_ARBITRARY_ARITY",
		"PACKAGE_SPECIFICATION",
		"PATTERN_DECLARATION",
		"PATTERN_RULE",
		"PATTERN_SPECIFICATION",
		"PROCEDURE_CALL",
		"PROPERTY_SPECIFICATION",
		"REDUCTION_ACTION",
		"REDUCTION_DECLARATION",
		"RETURN_DECLARATION",
		"SIMPLE_TRANSFORMATION_RULE",
		"SYMBOLIC_COST_SPEC",
		"TRANSFORMATION_RULE",
		"TERMINAL_PATTERN",
		"TYPED_RETURN_DECLARATION",
		"an identifier",
		"LPAREN",
		"RPAREN",
		"a block of code",
		"COLON",
		"\"DefaultErrorHandler\"",
		"\"header\"",
		"\"implements\"",
		"SEMI",
		"\"INodeAdapter\"",
		"\"INodeType\"",
		"\"Language\"",
		"JBURG_MANIFEST_CONSTANT",
		"EQUALS",
		"INT",
		"PERIOD",
		"STAR",
		"\"OpcodeType\"",
		"COMMA",
		"\"void\"",
		"PLUS",
		"\"package\"",
		"\"Pattern\"",
		"SHARP",
		"\"BURMProperty\"",
		"\"ReturnType\"",
		"\"Prologue\"",
		"EXPLICIT_REDUCTION",
		"LANGLE",
		"RANGLE",
		"\"include\"",
		"WS",
		"DIRECTIVE_WS",
		"LBRACE",
		"RBRACE",
		"COMMENT",
		"ML_COMMENT",
		"DIGIT",
		"DIRECTIVE_STRING",
		"INCLUDE",
		"INCLUDE_PARAMETER",
		"INCLUDE_BLOCK_PARAM",
		"JBURG_DIRECTIVE"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 36028805608898562L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 1730226887998832640L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 1729382325629747200L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 487582631815282690L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 2306689770606034944L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 451553826206384128L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 8649165412237312000L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 2216203124736L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 6755442390728704L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 2535671382147072L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 52778954724999170L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 1782231649098924034L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	private static final long[] mk_tokenSet_12() {
		long[] data = { 34359738368L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
	private static final long[] mk_tokenSet_13() {
		long[] data = { 2251834173423616L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
	private static final long[] mk_tokenSet_14() {
		long[] data = { 6757770263003136L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
	private static final long[] mk_tokenSet_15() {
		long[] data = { 38423713732886530L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_15 = new BitSet(mk_tokenSet_15());
	private static final long[] mk_tokenSet_16() {
		long[] data = { 1768720850216812546L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_16 = new BitSet(mk_tokenSet_16());
	private static final long[] mk_tokenSet_17() {
		long[] data = { 2254170635632640L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_17 = new BitSet(mk_tokenSet_17());
	private static final long[] mk_tokenSet_18() {
		long[] data = { 16325591598891008L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_18 = new BitSet(mk_tokenSet_18());
	private static final long[] mk_tokenSet_19() {
		long[] data = { 11821983381585920L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_19 = new BitSet(mk_tokenSet_19());
	private static final long[] mk_tokenSet_20() {
		long[] data = { 2336462209024L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_20 = new BitSet(mk_tokenSet_20());
	private static final long[] mk_tokenSet_21() {
		long[] data = { 1152923772349579264L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_21 = new BitSet(mk_tokenSet_21());
	private static final long[] mk_tokenSet_22() {
		long[] data = { 1152921573326323712L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_22 = new BitSet(mk_tokenSet_22());
	private static final long[] mk_tokenSet_23() {
		long[] data = { 2207613190144L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_23 = new BitSet(mk_tokenSet_23());
	private static final long[] mk_tokenSet_24() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_24 = new BitSet(mk_tokenSet_24());
	
	}
