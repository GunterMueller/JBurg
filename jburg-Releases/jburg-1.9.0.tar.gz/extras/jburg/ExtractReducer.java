package jburg;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import jburg.parser.JBurgParser;
import static jburg.parser.JBurgTokenTypes.*;

import jburg.burg.MacroProcessingStream;

import antlr.collections.AST;

public class ExtractReducer 
{
    public static void main(String[] args)
    {
        if ( args.length < 1)
        {
            usage(1);
        }

        File specification = new File(args[0]);

        if ( !specification.exists() )
        {
            usage(2);
        }

        File interface_dst = new File("/tmp/interface.java");
        File reducer_dst   = new File("/tmp/reducer.java");

        new ExtractReducer().extract(specification, interface_dst, reducer_dst);
    }

    private static void usage(int exit_code)
    {
        System.err.println("usage: jburg.ExtractReducer <specification-file>");
        System.exit(exit_code);
    }

    private void extract(File specification, File interface_dst, File reducer_dst)
    {
        try
        {
            MacroProcessingStream token_stream = new MacroProcessingStream((specification));
            JBurgParser parser = new JBurgParser(token_stream);
            parser.specification();

            AST t = (AST)parser.getAST();

            if ( !parser.parseSuccessful() || null == t  )
            {
                System.out.println("ExtractReducer terminating due to parse errors.");
                System.exit(4);
            }

            extract(t, interface_dst, reducer_dst);
        }
        catch ( Exception ex )
        {
            ex.printStackTrace();
            System.exit(3);
        }
    }

    String iNodeClass;
    String defaultReturnType = null;
    String opcodeType;

    Map<String, String> returnTypeTable = new HashMap<String, String>();
    Map<String, AST> namedPatterns = new HashMap<String, AST>();


    private void extract(AST root, File interface_file, File reducer_file)
    throws java.io.IOException
    {
        PrintWriter if_out = new PrintWriter(new FileWriter(interface_file));
        PrintWriter red_out = new PrintWriter(new FileWriter(reducer_file));

        for (AST currentNode = root; currentNode != null; currentNode = currentNode.getNextSibling()) 
        {
            switch (currentNode.getType()) 
			{
            case COST_FUNCTION:
                {
                    String func_name = getIdentifierText(currentNode.getFirstChild());
                    String func_body = getCodeBlock(currentNode);
                    if_out.println("int " + func_name + "(" + iNodeClass + " __p);");
                    red_out.println("int " + func_name + "(" + iNodeClass + " __p)");
                    red_out.println(func_body);
                }
                break;

            case HEADER_DECLARATION:
                {
                    String header_block = stripBrackets(getCodeBlock(currentNode));
                    header_block = header_block.substring(1);
                    header_block = header_block.substring(0, header_block.length() - 2);
                    if_out.println(header_block);
                    red_out.println(header_block);

                    if_out.println("public interface Interface");
                    if_out.println("{");
                    red_out.println("public class Reducer");
                    red_out.println("{");
                }
                break;
                
            case INCLASS_DECLARATION:
				{
            		String ictxt = stripBrackets(getCodeBlock(currentNode));

                    red_out.println(ictxt);
            	}
				
				break;

            case INODE_ADAPTER_DECLARATION:
                /*
                if (this.iNodeAdapterClass == null)
				{
					this.iNodeAdapterClass = getIdentifierText(currentNode.getFirstChild());
				}
				else
				{
                    throw new IllegalArgumentException("INodeAdapter may only be specified once.");
				}
                */
				break;

            case INODE_TYPE_DECLARATION:

                if (this.iNodeClass == null)
				{
                    this.iNodeClass = getIdentifierText(currentNode.getFirstChild());
				}
                else
				{
                    throw new IllegalArgumentException("INodeType may only be specified once.");
				}

                break;
                
            case LANGUAGE_DECLARATION:

                //  TODO: Hard-wired to java-type output right now.
                /*
            	if ( null == this.emitLanguageName )
				{
            		this.emitLanguageName = currentNode.getFirstChild().getText();
				}
            	else
				{
            		throw new IllegalArgumentException("Language may only be specified once.");
				}
                */

            	break;

            case IMPLEMENTS_INTERFACE_SPECIFICATION:
                //m_InterfaceNames.addElement(getIdentifierText( currentNode.getFirstChild()) );

                break;

            case PACKAGE_SPECIFICATION:
                {
                    String package_name = getIdentifierText(currentNode.getFirstChild());
                    if_out.println( "package " + package_name + ";");
                    red_out.println( "package " + package_name + ";");
                }

                break;

            case PROPERTY_SPECIFICATION: 
                /*
				{
					String propertyType = getIdentifierText(currentNode.getFirstChild());
					String propertyName = currentNode.getFirstChild().getNextSibling().getText();
					burm_properties.put(propertyName, propertyType);

				}
                */
                break;

            case RETURN_DECLARATION:
            {
                String ret_type = getIdentifierText(currentNode.getFirstChild());
                if (this.defaultReturnType == null)
                {
                    this.defaultReturnType = ret_type;
                }
                else if ( !this.defaultReturnType.equals(ret_type) )
                {
                    throw new IllegalArgumentException( "ReturnType is " + this.defaultReturnType + ", cannot be reset to " + ret_type);
                }
            }

                break;

            case PATTERN_RULE:
                {
                    addReduction(currentNode);
                }
                break;

            case SIMPLE_TRANSFORMATION_RULE:
                //addSimpleTransformationRule(currentNode);

                break;

            case TRANSFORMATION_RULE:
                {
                    addReduction(currentNode);
                }
                break;

            case TYPED_RETURN_DECLARATION:

                String stateName = currentNode.getFirstChild().getText();
                String returnType = getIdentifierText(currentNode.getFirstChild()
                                                                .getNextSibling());

				//  Put the return declaration in the table, but only once per state.
                Object typeCollision = this.returnTypeTable.put(stateName, returnType);
				if ( null != typeCollision )
				{
                    throw new IllegalArgumentException(
						"A state may only specify one ReturnType."
					);
				}

                break;

            case PATTERN_DECLARATION:
                {
                    String pattern_name = currentNode.getFirstChild().getText();
                    namedPatterns.put(pattern_name, currentNode);
                }
                break;

            case REDUCTION_DECLARATION:
                {
                    addReduction(currentNode);
                }
                break;
            case DEFAULT_ERROR_HANDLER:
                //  TODO: include this.
                //this.defaultErrorHandler = getCodeBlock(currentNode);
                break;
                
            case OPCODE_TYPE:
                this.opcodeType = currentNode.getFirstChild().getText();
                break;

            default:
                throw new IllegalArgumentException("Unknown specification AST type " +
            											String.valueOf(currentNode.getType()));
            }
        }

        for ( Vector<ReductionDescriptor> reductions: reductionsByName.values() )
        {
            boolean generate_long_name = reductions.size() > 1;
            for ( ReductionDescriptor reduction: reductions )
            {
                if ( reduction.hasPrologue() )
                {
                    if_out.println(reduction.getPrologueSignature(generate_long_name) + ";");
                    red_out.println(reduction.getPrologueSignature(generate_long_name));
                    red_out.println(reduction.getPrologueBlock());
                    red_out.println();
                }

                if_out.println( reduction.getReductionSignature(generate_long_name) + ";");
                if_out.println();
                red_out.println( reduction.getReductionSignature(generate_long_name));
                red_out.println(reduction.getReductionBlock());
                red_out.println();
            }
        }

        if_out.println("}");
        if_out.close();

        red_out.println("}");
        red_out.close();
    }

    void addReduction(AST current)
    {
        ReductionDescriptor desc = new ReductionDescriptor(current);

        if ( !reductionsByName.containsKey(desc.reductionName) )
            reductionsByName.put(desc.reductionName, new Vector<ReductionDescriptor>());

        reductionsByName.get(desc.reductionName).add(desc);
    }

    Map<String, Vector<ReductionDescriptor>> reductionsByName = new HashMap<String, Vector<ReductionDescriptor>>();

    /**
     *  Get the payload of an identifier, with error checking.
     *  @return the identifier's text.
     */
    private String getIdentifierText(AST p)
    {
		if ( p.getType() != IDENTIFIER )
		{
			throw new IllegalStateException ( "Expected IDENTIFIER, found " + p.toStringTree() );
		}

        return p.getText();
    }

    /**
     *  @return the operator of a pattern or transformation rule.
     */
    String getOperator(AST ast)
    {
        int type = ast.getType();

        if ( PATTERN_RULE == type )
        {
            return ast.getFirstChild().getNextSibling().getFirstChild().getFirstChild().getText();
        }
        else
        {
            //  A transformation rule.
            return ast.getFirstChild().getNextSibling().getText();
        }
    }

    /**
     *  @return the goal state of a reduction.
     */
    String getGoalState(AST ast)
    {
        return ast.getFirstChild().getText();
    }

    /**
     *  @return the target's return type for
     *    a reduced state.  Returns the default
     *    return type if no specific return type
     *    has been specified.
     */
    String getTypeOfNonterminal(String goal_state)
    {
        if ( this.returnTypeTable.containsKey(goal_state) )
            return this.returnTypeTable.get(goal_state);
        else
            return this.defaultReturnType;
    }
    
    /**
	 *  @return the text of the parent AST's code block, which is represented as a BLOCK token.
	 */
	private String getCodeBlock( AST parent )
	{
		return getASTByType(parent, BLOCK).getText();
	}

    /**
     *  Strip the first and last brackets as they are part of our
     *  syntax, not part of the output semantics.
     *  @param block - a code block
     *  @return the code block stripped of its outer {} pair.
     */
    private String stripBrackets(String block)
    {
        int startchar = block.indexOf('{') + 1;
        int lentoend = block.lastIndexOf('}');
        return block.substring( startchar, lentoend-startchar );
    }

    /**
     *  @return the first child of the parent AST with the specified node type.
     */
    private AST getASTByType(AST parent, int node_type)
    {
        for ( AST current = parent.getFirstChild(); current != null; current = current.getNextSibling() )
        {
            if ( current.getType() == node_type )
                return current;
        }

        throw new IllegalStateException ( "AST " + parent.toString() + " has no child of node type " + node_type + "." );
    }

    private boolean hasASTOfType(AST parent, int node_type)
    {
        for ( AST current = parent.getFirstChild(); current != null; current = current.getNextSibling() )
        {
            if ( current.getType() == node_type )
                return true;
        }

        return false;
    }

    private Vector<ParameterDecl> findParameters(AST root)
    {
        Vector<ParameterDecl> result = new Vector<ParameterDecl>();
        Set<AST> visited = new HashSet<AST>();

        for ( AST child = root.getFirstChild(); child != null; child = child.getNextSibling() )
            findParameters(child, result, visited);
        return result;
    }

    private void findParameters(AST node, Vector<ParameterDecl> result, Set<AST> visited)
    {
        if ( visited.contains(node) )
            return;
        else
            visited.add(node);

        if ( node.getType() == NON_TERMINAL_PARAMETER )
        {
            ParameterDecl decl = new ParameterDecl();
            decl.type = getTypeOfNonterminal(getIdentifierText(node.getFirstChild()));
            decl.name = getIdentifierText(node.getFirstChild().getNextSibling());
            result.add(decl);
        }
        else if ( node.getType() == TERMINAL_PATTERN && node.getNumberOfChildren() == 2 ) 
        {
            ParameterDecl decl = new ParameterDecl();
            decl.type = this.iNodeClass;
            decl.name = getIdentifierText(node.getFirstChild().getNextSibling());
            result.add(decl);
        }
        else
        {
            for ( AST child = node.getFirstChild(); child != null; child = child.getNextSibling() )
            {
                findParameters(child, result, visited);
            }
        }
    }

    private class ReductionDescriptor
    {
        AST ast;

        String reducedState;
        String returnType;
        String reductionName;
        String prefix;

        Vector<ParameterDecl> parameters;

        ReductionDescriptor(AST ast)
        {
            this.ast = ast;
            this.reducedState = getGoalState(ast);
            this.returnType   = getTypeOfNonterminal(this.reducedState);

            switch ( ast.getType() )
            {
                case REDUCTION_DECLARATION:
                {
                    this.prefix = "reduce";
                    this.reductionName = ast.getFirstChild().getNextSibling().getText();
                    AST pattern_root = namedPatterns.get(this.reductionName);

                    if ( pattern_root == null )
                        throw new IllegalStateException("no pattern named " + this.reductionName);

                    this.parameters = findParameters(pattern_root);
                    break;
                }
                case PATTERN_RULE:
                {
                    this.prefix = "reduce";
                    AST pattern_root = pattern_root = ast.getFirstChild().getNextSibling().getFirstChild();
                    this.reductionName = pattern_root.getFirstChild().getText();
                    this.parameters = findParameters(pattern_root);
                    break;
                }
                case TRANSFORMATION_RULE:
                {
                    this.prefix = "transform";
                    String transformation_target = getIdentifierText(ast.getFirstChild());
                    String transformation_source = getIdentifierText(ast.getFirstChild().getNextSibling());
                    this.reductionName = transformation_source;

                    this.parameters = new Vector<ParameterDecl>();
                    ParameterDecl decl = new ParameterDecl();
                    decl.type = getTypeOfNonterminal(transformation_source);
                    decl.name = transformation_source;
                    break;
                }
                default:
                    throw new IllegalArgumentException("Unknown AST type " + ast.getType());
            }

        }

        public String getReductionSignature(boolean generate_long_name)
        {
            StringBuilder signature = new StringBuilder();
            signature.append("public ");
            signature.append(this.returnType);
            signature.append(" ");

            signature.append(this.prefix);
            signature.append("_");
            signature.append(this.reductionName);
            if ( generate_long_name )
            {
                signature.append("_to_");
                signature.append(this.reducedState);
            }

            signature.append("(");
            signature.append(iNodeClass);
            signature.append(" iNode");

            for ( ParameterDecl decl: this.parameters )
            {
                signature.append(", ");
                signature.append(decl.type);
                signature.append(" ");
                signature.append(decl.name);
            }

            signature.append(")");
            return signature.toString();
        }

        public String getReductionBlock()
        {
            return getCodeBlock( getASTByType(ast, REDUCTION_ACTION));
        }

        public boolean hasPrologue()
        {
            return hasASTOfType(getASTByType(ast, REDUCTION_ACTION), PROLOGUE);
        }

        public String getPrologueSignature(boolean generate_long_name)
        {
            StringBuilder result = new StringBuilder("public void prologue_" );
            result.append(this.reductionName );
            if ( generate_long_name )
            {
                result.append("_to_" );
                result.append(this.reducedState );
            }
            result.append("(" );
            result.append(iNodeClass );
            result.append(" iNode)");
            return result.toString();
        }

        public String getPrologueBlock()
        {
            return getCodeBlock(getASTByType(getASTByType(ast, REDUCTION_ACTION), PROLOGUE));
        }
    }

    private static class ParameterDecl
    {
        String type;
        String name;
    }
}

