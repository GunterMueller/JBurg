package jburg.compiler.tl2.reducer;

import jburg.compiler.tl2.semanticanalysis.AbstractClass;
import jburg.compiler.tl2.semanticanalysis.ClassAnalyzer;

import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.InstructionList;

import java.util.Vector;

public class FunctionParamInstructionList
extends TL2InstructionList
{
   Vector pTypes = new Vector();

   String         signature;
   AbstractClass  returnType;

   public FunctionParamInstructionList ( TL2InstructionList obj )
   {
    this.il    = obj.il;
    this.clazz = obj.clazz;

    appendSignature ( this.clazz );
   }

   public FunctionParamInstructionList()
   {
    this.il = new InstructionList();
   }

   public void appendSignature ( AbstractClass clazz )
   {
    pTypes.add(clazz);
   }

   public InstructionHandle insert ( TL2InstructionList il )
   {
    appendSignature(il.clazz);
    return super.insert(il);
   }

   public String analyzeConstructor(AbstractClass clazz)
   {
    return ClassAnalyzer.analyzeConstructor ( clazz, pTypes );
   }

   public void setReturnType ( AbstractClass c )
   {
    this.returnType = c;
   }

   AbstractClass getReturnType ()
   {
    return this.returnType;
   }

   public Vector getParameterTypes()
   {
    return this.pTypes;
   }

   public void setSignature ( String s )
   {
    this.signature = s;
   }

   String getSignature()
   {
    return this.signature;
   }
}
