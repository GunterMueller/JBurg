package jburg.compiler.tl2.semanticanalysis;

import jburg.compiler.tl2.ir.TL2INode;

public class TraverseAST
{
   public static void traverse ( TL2INode branch, SemanticVisitor visitor )
   {
    if ( branch != null )
    {
        visitor.preOrderVisit ( branch );

        traverse( branch.leftChild(), visitor );
        traverse( branch.rightChild(), visitor );

        visitor.postOrderVisit ( branch );
    }
   }
}
