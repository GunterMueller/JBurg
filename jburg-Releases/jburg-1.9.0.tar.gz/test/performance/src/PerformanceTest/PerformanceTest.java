package PerformanceTest;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 *  PerformanceTest reads a simple tree description language,
 *  builds a test tree, and invokes the specified BURM
 *  to rewrite the tree.
 */
public class PerformanceTest extends org.xml.sax.helpers.DefaultHandler
{
    Stack<Node>  nodeStack = new Stack<Node>();

    Map<String,Integer> opcodes = new HashMap<String,Integer>();

    Node rootNode;

    Object burm;

    String expectedResult = null;
    String expectedError  = null;

    static final int INVALID_COMMANDLINE = 100;
    static final int FAILED_NO_ERROR = INVALID_COMMANDLINE + 1;
    static final int FAILED_WRONG_OUTPUT = FAILED_NO_ERROR + 1;

    static final int FAILED_UNEXPECTED_EXCEPTION = 200;
    static final int FAILED_WRONG_ERROR = FAILED_UNEXPECTED_EXCEPTION + 1;

    boolean useJBurg2 = false;

    public static void main(String[] args)
    throws Exception
    {
        if ( args.length < 1 )
        {
            usage();
            System.exit(INVALID_COMMANDLINE);
        }

        String test_file = null;
        boolean use_JBurg2 = false;

        for ( int i = 0; i < args.length; i++ )
        {
            if ( args[i].equalsIgnoreCase("-1") )
            {
                use_JBurg2 = false;
            }
            else if ( args[i].equalsIgnoreCase("-2") )
            {
                use_JBurg2 = true;
            }
            else if ( args[i].equalsIgnoreCase("-h") )
            {
                usage();
                System.exit(0);
            }
            else
                test_file = args[i];
        }

        if ( test_file == null )
        {
            System.err.println("Test file must be specified.");
            usage();
            System.exit(1);
        }

        TestParser parser = new TestParser();
        {
        PerformanceTest testobj = new PerformanceTest(use_JBurg2);
        testobj.burm(parser.parse(test_file));
        }
    }

    static void usage()
    {
        System.out.println("usage: PerformanceTest <test spec file>");
    }

    private PerformanceTest(boolean useJBurg2)
    {
        this.useJBurg2 = useJBurg2;
    }

    /**
     *  Rewrite the test tree and get the result.
     *  @return the result of the tree rewrite.
     */
    @SuppressWarnings("unchecked")
    private void burm(Node rootNode)
    {
        long start_time = System.nanoTime();
        long end_time;

        try
        {
            if ( useJBurg2 )
            {
                PerformanceTestReducer2 burm2 = new PerformanceTestReducer2();
                burm2.label(rootNode);
                burm2.reduce(rootNode, PerformanceTestReducer2.Nonterminal.statement);
            }
            else
            {
                PerformanceTestReducer burm = new PerformanceTestReducer();
                burm.burm(rootNode);
            }
            end_time = System.nanoTime();

            System.out.printf("time: %10.2f msec.\n", (double)(end_time - start_time) / 1000000000.0);
         }
         catch ( Exception ex )
         {
            ex.printStackTrace();
         }
    }

    /**
     *  Load the symbolic name to opcode encodings.
     */
    private void loadOpcodes(String class_name)
    {
        try
        {
            Class<? extends Object> tokenTypes = Class.forName(class_name);
            //  Traverse the names of the OP_foo constants
            //  in AbcConstants and load their values.
            for ( Field f: tokenTypes.getFields())
            {
                String field_name = f.getName();
               try
               {
                   int field_value = f.getInt(null);
                   opcodes.put(field_name, field_value);
               }
               catch ( Exception noFieldValue)
               {
                   //  Ignore, continue...
               }
            }
        }
        catch ( Throwable no_class)
        {
            System.err.println("Unable to load " + class_name + ": " + no_class.getLocalizedMessage());
            no_class.printStackTrace();
        }
        
    }
}
