package PerformanceTest;

import java.util.Stack;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

public class TestParser extends org.xml.sax.helpers.DefaultHandler
{
    Stack<Node>  nodeStack = new Stack<Node>();
    Node rootNode;

    /**
     *  Parse the test specification.
     */
    Node parse(String spec_file)
    throws Exception
    {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
    
        SAXParser parser = factory.newSAXParser();
        java.io.InputStream input = new java.io.FileInputStream(spec_file);
        
        parser.parse(input, this);
        return rootNode;
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes)
    {
        if ( "BurmTest".equalsIgnoreCase(qName) )
        {
            //  Ignore, everything is hard-coded.
        }
        else if ( "Opcodes".equalsIgnoreCase(qName) )
        {
            // Ignore, caller gave us opcodes.
            // loadOpcodes(attributes.getValue("class"));
        }
        else if ( "Node".equalsIgnoreCase(qName) )
        {
            NodeType opcode = NodeType.valueOf(attributes.getValue("opcode"));

            Node node = new Node(opcode, attributes.getValue("userObject"));

            if ( !nodeStack.isEmpty() )
                nodeStack.peek().addChild(node);

            nodeStack.push(node);
        }
        else if ( 
            "grammar".equalsIgnoreCase(qName) ||
            "javaSupportFiles".equalsIgnoreCase(qName)
            )
        {
            //  build-time element, ignore.
        }
        else
            throw new IllegalArgumentException("Unknown node type " + qName);
    }

    @Override
    public void endElement(String uri,  String localName,  String qName)
    {
        if ( "Node".equalsIgnoreCase(qName) )
            this.rootNode = nodeStack.pop();
    }

    

}


