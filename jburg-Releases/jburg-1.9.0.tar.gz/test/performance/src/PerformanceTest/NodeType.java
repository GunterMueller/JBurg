package PerformanceTest;

public enum NodeType
{
     ADD,
     ASSIGN,
     BLOCK,
     IDENTIFIER,
     ID,
     INT,
     MULTIPLY,
     PAREN,
     PRINT,
}
