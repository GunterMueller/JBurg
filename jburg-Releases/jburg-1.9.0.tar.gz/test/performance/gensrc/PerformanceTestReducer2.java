
    package PerformanceTest;
    import java.util.HashMap;
    import java.util.Map;
    import java.util.Vector;
    import PerformanceTest.Node;
    import PerformanceTest.NodeType;
    import static PerformanceTest.NodeType.*;
    @SuppressWarnings("unchecked")

public class PerformanceTestReducer2
{
    public enum Nonterminal
    {
        expression,
        statement,
        name
    }

    public int label ( Node n )
    {
        switch(n.getNodeID())
        {
            case IDENTIFIER:
            {
                /* terminal IDENTIFIER, {State #0 {expression=(1 => Rule#9), name=(0 => Rule#10), statement=(1 => Rule#4)}} */
                n.setState(0);
            }
            break;
            case INT:
            {
                /* terminal INT, {State #1 {expression=(0 => Rule#8), statement=(0 => Rule#4)}} */
                n.setState(1);
            }
            break;
            case MULTIPLY:
            {
                switch(n.getChildCount())
                {
                    /* operator MULTIPLY(0+) */
                    default:
                    {
                        switch(labelVariableArity(n,0,1,-1))
                        {
                            case 0:
                            case 3:
                            case 4:
                            case 7:
                            n.setState(5);
                            break;
                            case 1:
                            case 2:
                            case 5:
                            case 6:
                            n.setState(5);
                            break;
                        }
                    }
                    break;
                }
            }
            break;
            case PRINT:
            {
                switch(n.getChildCount())
                {
                    /* operator PRINT(1) */
                    case 1:
                    {
                        switch(label(n.getChild(0)))
                        {
                            case 0:
                            n.setState(7);
                            break;
                        }
                    }
                    break;
                }
            }
            break;
            case PAREN:
            {
                switch(n.getChildCount())
                {
                    /* operator PAREN(1) */
                    case 1:
                    {
                        switch(label(n.getChild(0)))
                        {
                            case 0:
                            case 3:
                            case 4:
                            case 7:
                            n.setState(6);
                            break;
                            case 1:
                            case 2:
                            case 5:
                            case 6:
                            n.setState(6);
                            break;
                        }
                    }
                    break;
                }
            }
            break;
            case BLOCK:
            {
                switch(n.getChildCount())
                {
                    /* operator BLOCK(0+) */
                    default:
                    {
                        switch(labelVariableArity(n,0,1,-1))
                        {
                            case 0:
                            case 1:
                            case 2:
                            case 5:
                            case 6:
                            n.setState(4);
                            break;
                            case 3:
                            case 4:
                            case 7:
                            n.setState(4);
                            break;
                        }
                    }
                    break;
                }
            }
            break;
            case ASSIGN:
            {
                switch(n.getChildCount())
                {
                    /* operator ASSIGN(2) */
                    case 2:
                    {
                        switch(label(n.getChild(0)))
                        {
                            case 0:
                            switch(label(n.getChild(1)))
                            {
                                case 0:
                                case 3:
                                case 4:
                                case 7:
                                n.setState(3);
                                break;
                                case 1:
                                case 2:
                                case 5:
                                case 6:
                                n.setState(3);
                                break;
                            }
                            break;
                        }
                    }
                    break;
                }
            }
            break;
            case ADD:
            {
                switch(n.getChildCount())
                {
                    /* operator ADD(2) */
                    case 2:
                    {
                        switch(label(n.getChild(0)))
                        {
                            case 0:
                            case 3:
                            case 4:
                            case 7:
                            switch(label(n.getChild(1)))
                            {
                                case 0:
                                case 3:
                                case 4:
                                case 7:
                                n.setState(2);
                                break;
                                case 1:
                                case 2:
                                case 5:
                                case 6:
                                n.setState(2);
                                break;
                            }
                            break;
                            case 1:
                            case 2:
                            case 5:
                            case 6:
                            switch(label(n.getChild(1)))
                            {
                                case 0:
                                case 3:
                                case 4:
                                case 7:
                                n.setState(2);
                                break;
                                case 1:
                                case 2:
                                case 5:
                                case 6:
                                n.setState(2);
                                break;
                            }
                            break;
                        }
                    }
                    break;
                }
            }
            break;
        }
        return n.getState();
    }

    private int labelVariableArity(Node n, int start, int minKids, int defaultValue)
    {
        if ( n.getChildCount() - start < minKids )
            return defaultValue;

        int candidate = label(n.getChild(start));

        for ( int i = start+1; candidate != -1 && i < n.getChildCount(); i++ )
            /*
             * TODO: Need a state machine to get the correct end state
            if ( label(n.getChild(i)) != candidate )
                candidate = -1;
            */
            candidate = label(n.getChild(i));

        return candidate;
    }

    private Integer action_1 (Node n)
    {
        String lhs = ((String)reduce(n.getChild(0), Nonterminal.name));
        Integer rhs = ((Integer)reduce(n.getChild(1), Nonterminal.expression));
        {
            identifiers.put(lhs, rhs);
            return rhs;
        }
    }

    private Integer action_2 (Node n)
    {
        java.util.ArrayList<Integer> statements = new java.util.ArrayList<Integer>();
        for ( int __jburg2_synthetic_local_0 = 0; __jburg2_synthetic_local_0 < n.getChildCount(); __jburg2_synthetic_local_0++ )
        {
            statements.add(((Integer)reduce(n.getChild(__jburg2_synthetic_local_0), Nonterminal.statement)));
        }
        {
            return statements.get(statements.size() - 1);
        }
    }

    private Integer action_3 (Node n)
    {
        String name = ((String)reduce(n.getChild(0), Nonterminal.name));
        {
            Integer result = getValue(name);
            System.out.printf("%s = %s\n", name, result);
            return result;
        }
    }

    private Integer action_4 (Node n)
    {
        return ((Integer)reduce(n, Nonterminal.expression));
    }

    private Integer action_5 (Node n)
    {
        Integer lhs = ((Integer)reduce(n.getChild(0), Nonterminal.expression));
        Integer r = ((Integer)reduce(n.getChild(1), Nonterminal.expression));
        {
            return lhs.intValue() + r.intValue();
        }
    }

    private Integer action_6 (Node n)
    {
        java.util.ArrayList<Integer> exprs = new java.util.ArrayList<Integer>();
        for ( int __jburg2_synthetic_local_1 = 0; __jburg2_synthetic_local_1 < n.getChildCount(); __jburg2_synthetic_local_1++ )
        {
            exprs.add(((Integer)reduce(n.getChild(__jburg2_synthetic_local_1), Nonterminal.expression)));
        }
        {
            long result = 1;

            for ( Integer x: exprs)
                result *= x;

            return (int)result;
        }
    }

    private Integer action_7 (Node n)
    {
        Integer enclosed = ((Integer)reduce(n.getChild(0), Nonterminal.expression));
        {
            return enclosed;
        }
    }

    private Integer action_8 (Node n)
    {
        {
            return Integer.parseInt(n.getUserObject().toString());
        }
    }

    private Integer action_9 (Node n)
    {
        String name = ((String)reduce(n, Nonterminal.name));
        {
            return getValue(name);
        }
    }

    private String action_10 (Node n)
    {
        {
            return n.getUserObject().toString();
        }
    }

    public Object reduce ( Node n, Nonterminal goalState )
    {
        Object result = null;
        switch(n.getState())
        {
            /* {State #0 {expression=(1 => Rule#9), name=(0 => Rule#10), statement=(1 => Rule#4)}} */
            case 0:
            {
                switch(goalState)
                {
                    case expression:
                    {
                        result = action_9 (n);
                    }
                    break;
                    case name:
                    {
                        result = action_10 (n);
                    }
                    break;
                    case statement:
                    {
                        result = action_4 (n);
                    }
                    break;
                }
            }
            break;
            /* {State #1 {expression=(0 => Rule#8), statement=(0 => Rule#4)}} */
            case 1:
            {
                switch(goalState)
                {
                    case expression:
                    {
                        result = action_8 (n);
                    }
                    break;
                    case statement:
                    {
                        result = action_4 (n);
                    }
                    break;
                }
            }
            break;
            /* {State #2 {expression=(0 => Rule#5), statement=(0 => Rule#4)}} */
            case 2:
            {
                switch(goalState)
                {
                    case expression:
                    {
                        result = action_5 (n);
                    }
                    break;
                    case statement:
                    {
                        result = action_4 (n);
                    }
                    break;
                }
            }
            break;
            /* {State #3 {statement=(0 => Rule#1)}} */
            case 3:
            {
                switch(goalState)
                {
                    case statement:
                    {
                        result = action_1 (n);
                    }
                    break;
                }
            }
            break;
            /* {State #4 {statement=(0 => Rule#2)}} */
            case 4:
            {
                switch(goalState)
                {
                    case statement:
                    {
                        result = action_2 (n);
                    }
                    break;
                }
            }
            break;
            /* {State #5 {expression=(0 => Rule#6), statement=(0 => Rule#4)}} */
            case 5:
            {
                switch(goalState)
                {
                    case expression:
                    {
                        result = action_6 (n);
                    }
                    break;
                    case statement:
                    {
                        result = action_4 (n);
                    }
                    break;
                }
            }
            break;
            /* {State #6 {expression=(0 => Rule#7), statement=(0 => Rule#4)}} */
            case 6:
            {
                switch(goalState)
                {
                    case expression:
                    {
                        result = action_7 (n);
                    }
                    break;
                    case statement:
                    {
                        result = action_4 (n);
                    }
                    break;
                }
            }
            break;
            /* {State #7 {statement=(0 => Rule#3)}} */
            case 7:
            {
                switch(goalState)
                {
                    case statement:
                    {
                        result = action_3 (n);
                    }
                    break;
                }
            }
            break;
        }
        return result;
    }


        static Integer ZERO = new Integer(0);

        Map<Object, Integer> identifiers = new HashMap<Object,Integer>();

        Integer getValue(Object lhs)
        {
            Integer result = identifiers.get(lhs);

            return result != null ?  result: ZERO;
        }

}
