public class Test
{
	public static void main ( String[] argv )
	{
		System.out.println ( "inc(0) is " + IntCall.inc(0) );
		System.out.println ( "add(1,2) is " + IntCall.add(1, 2) );

		IStore is = new IStore();
		is.store(12);

	}
}

