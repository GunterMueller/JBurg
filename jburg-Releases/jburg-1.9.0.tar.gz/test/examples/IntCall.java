public class IntCall
{
	static int inc(int x)
	{
		return x + 1;
	}

	static int add ( int x, int y)
	{
		return x + y;
	}
}
