class BaseBURM
{
    protected int addCost(burmTest.TestINode addNode)
    {
        return 1;
    }

    protected int intLiteralCost(burmTest.TestINode lit)
    {
        return 1;
    }
}
