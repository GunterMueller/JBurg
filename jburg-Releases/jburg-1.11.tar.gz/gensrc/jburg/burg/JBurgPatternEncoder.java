
/*  Generated Sun Sep 09 11:37:34 EDT 2012 by JBurg version 1.10.1 */

package jburg.burg;


    import java.util.Set;
    import java.util.Vector;
    import jburg.parser.JBurgTokenTypes;
public class JBurgPatternEncoder implements JBurgTokenTypes
	
{
	java.util.Stack __reducedValues = new java.util.Stack();
	
	public static final int __operator_specification_NT = 1;
	public static final int __simple_identifier_NT = 2;
	public static final int __operand_NT = 3;
	public static final int nStates = 3;

	private static final JBurgSubgoal[][] ___subgoals_by_rule = 
	{
		null,
		{
			new JBurgSubgoal(__simple_identifier_NT,false,0,0),
		},
		{
			new JBurgSubgoal(__simple_identifier_NT,false,0,0),
			new JBurgSubgoal(__simple_identifier_NT,false,0,1),
		},
		{
			new JBurgSubgoal(__simple_identifier_NT,false,0,0),
			new JBurgSubgoal(__operand_NT,true,0,1),
		},
		{
			new JBurgSubgoal(__simple_identifier_NT,false,0,0),
			new JBurgSubgoal(__simple_identifier_NT,false,0,1),
		},
		{
			new JBurgSubgoal(__simple_identifier_NT,false,0,0,0),
			new JBurgSubgoal(__simple_identifier_NT,false,0,0,1),
		},
		{
			new JBurgSubgoal(__simple_identifier_NT,false,0,0,0),
			new JBurgSubgoal(__simple_identifier_NT,false,0,0,1),
		},
		null,
		null,
	};


	private int getArity(antlr.collections.AST n)
	{
		int result = 0;
		antlr.collections.AST cursor = n.getFirstChild();
		while (cursor != null) {
			result++;
			cursor = cursor.getNextSibling();
		}
	return result;
	}

	private antlr.collections.AST getNthChild(antlr.collections.AST n, int idx)
	{
		antlr.collections.AST result = n.getFirstChild();
		while (result != null && idx != 0 ) {
			idx--;
			result = result.getNextSibling();
		}
	return result;
	}
	
	public JBurgAnnotation label( antlr.collections.AST to_be_labelled)
	{
		JBurgAnnotation result = null;

		int i;

		int arity;

		result = this.getJBurgAnnotation(to_be_labelled);
		arity = getArity(to_be_labelled);
		i = 0;
		while ( ( arity > i ) )
		{
			result.addChild(this.label(((antlr.collections.AST)getNthChild(to_be_labelled, i))));
			i =  (i + 1) ;
		}
		return(result);
	}

	/* operator_specification = TERMINAL_PATTERN(simple_identifier) */
	
	private JBurgPatternMatcher action_1( antlr.collections.AST __p) throws java.lang.Exception
	{
		String terminalID = (String)__reducedValues.pop();
		{
		    if ( operators != null )
		        operators.add(terminalID);
		
		    return JBurgPatternMatcher.matchOperator(terminalID);
		}
	}

	/* operator_specification = TERMINAL_PATTERN(simple_identifier, simple_identifier) */
	
	private JBurgPatternMatcher action_2( antlr.collections.AST __p) throws java.lang.Exception
	{
		String terminal_name = (String)__reducedValues.pop();
		String terminalID = (String)__reducedValues.pop();
		{
		    if ( operators != null )
		        operators.add(terminalID);
		
		    JBurgPatternMatcher result = JBurgPatternMatcher.matchOperator(terminalID);
		    result.setParameterData(null, terminal_name);
		
		    if (namedTerminals != null )
		        namedTerminals.add(result);
		
		    return result;
		}
	}

	/* operator_specification = OPERATOR_SPECIFICATION(simple_identifier, OPERAND_LIST(operand+)) */
	
	private JBurgPatternMatcher action_3( antlr.collections.AST __p) throws java.lang.Exception
	{
		java.util.Vector<JBurgPatternMatcher> operands = (java.util.Vector<JBurgPatternMatcher>)__reducedValues.pop();
		String operator = (String)__reducedValues.pop();
		{
		    //  The presence of the operands node is checked by the cost computation
			//  (if the second node cannot be used as operands, its cost is infinite),
			//  so this recognizer need only check the operator.
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperator(operator);
			result.addAll( operands );
		
		    if ( operators != null )
		        operators.add(operator);
		
			return result;
		}
	}

	/* operand = NON_TERMINAL_PARAMETER(simple_identifier, simple_identifier) */
	
	private JBurgPatternMatcher action_4( antlr.collections.AST __p) throws java.lang.Exception
	{
		String paramName = (String)__reducedValues.pop();
		String state = (String)__reducedValues.pop();
		{
		    JBurgPatternMatcher result = JBurgPatternMatcher.matchFiniteCost(state);
		    result.setParameterData(state, paramName);
		
			//  This subgoal's cost will be added to the overall cost of the pattern match.
			subgoals.add(0, result);
		
		    return result;
		}
	}

	/* operand = OPERAND_AT_LEAST_ONE_ARITY(NON_TERMINAL_PARAMETER(simple_identifier, simple_identifier)) */
	
	private JBurgPatternMatcher action_5( antlr.collections.AST __p) throws java.lang.Exception
	{
		String paramName = (String)__reducedValues.pop();
		String state = (String)__reducedValues.pop();
		{
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperandAtLeastNTimes(1);
		    result.setParameterData(state, paramName);
		    subgoals.add(0, result);
		
		    return result;
		}
	}

	/* operand = OPERAND_ARBITRARY_ARITY(NON_TERMINAL_PARAMETER(simple_identifier, simple_identifier)) */
	
	private JBurgPatternMatcher action_6( antlr.collections.AST __p) throws java.lang.Exception
	{
		String paramName = (String)__reducedValues.pop();
		String state = (String)__reducedValues.pop();
		{
			JBurgPatternMatcher result = JBurgPatternMatcher.matchOperandAtLeastNTimes(0);
		    result.setParameterData(state, paramName);
		    subgoals.add(0, result);
		
		    return result;
		}
	}

	/* simple_identifier = IDENTIFIER(void) */
	
	private String action_7( antlr.collections.AST __p) throws java.lang.Exception
	{
		{
		    return __p.getText();
		}
	}

	/* operand = operator_specification */
	
	private JBurgPatternMatcher action_8( antlr.collections.AST __p) throws java.lang.Exception
	{
		return((JBurgPatternMatcher)__reducedValues.pop());
	}
	
	private void dispatchAction( JBurgAnnotation ___node, int iRule) throws java.lang.Exception
	{
		antlr.collections.AST __p = ___node.getNode();

		switch( iRule )
		{
			case 1:
			{
				__reducedValues.push(this.action_1(__p));
				break;
			}
			case 2:
			{
				__reducedValues.push(this.action_2(__p));
				break;
			}
			case 3:
			{
				__reducedValues.push(this.action_3(__p));
				break;
			}
			case 4:
			{
				__reducedValues.push(this.action_4(__p));
				break;
			}
			case 5:
			{
				__reducedValues.push(this.action_5(__p));
				break;
			}
			case 6:
			{
				__reducedValues.push(this.action_6(__p));
				break;
			}
			case 7:
			{
				__reducedValues.push(this.action_7(__p));
				break;
			}
			case 8:
			{
				this.reduceAntecedent(___node, __operator_specification_NT);
				__reducedValues.push(this.action_8(__p));
				break;
			}
			default:
			{
				throw new IllegalStateException("Unmatched reduce action " + iRule);
			}
		}
	}

	class JBurgAnnotation_IDENTIFIER_0 extends JBurgSpecializedAnnotation
	{
		JBurgAnnotation_IDENTIFIER_0(antlr.collections.AST node)
		{
			super(node);
		}
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __simple_identifier_NT:
				{
					return(1);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __simple_identifier_NT:
				{
					return(7);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(0);
		}
	}

	class JBurgAnnotation_NON_TERMINAL_PARAMETER_2 extends JBurgSpecializedAnnotation
	{
		private JBurgAnnotation subtree0;
		private JBurgAnnotation subtree1;
		JBurgAnnotation_NON_TERMINAL_PARAMETER_2(antlr.collections.AST node)
		{
			super(node);
		}
		private int cachedCostFor_operand = -1;
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					if ( cachedCostFor_operand == -1 )
					{
						cachedCostFor_operand = getCostForRule_55d15445(goalState);

					}
					return(cachedCostFor_operand);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCostForRule_55d15445(goalState);

					if ( ( bestCost > currentCost )  )
					{
						rule = 4;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(2);
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				case 0:
					return subtree0;
				case 1:
					return subtree1;
				default:
				{
					throw new IllegalStateException("Invalid index " + index);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
			if ( subtree0 == null )
				subtree0 = child;
			else if ( subtree1 == null )
				subtree1 = child;
			else
				throw new IllegalStateException("too many children");
		}
		
		private int getCostForRule_55d15445( int goalState)
		{

			return(normalizeCost((long)1 + (long) (((long)this.getNthChild(1).getCost(__simple_identifier_NT)) + ((long)this.getNthChild(0).getCost(__simple_identifier_NT))) ));
		}
	}

	class JBurgAnnotation_OPERAND_ARBITRARY_ARITY_1 extends JBurgSpecializedAnnotation
	{
		private JBurgAnnotation subtree0;
		JBurgAnnotation_OPERAND_ARBITRARY_ARITY_1(antlr.collections.AST node)
		{
			super(node);
		}
		private int cachedCostFor_operand = -1;
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					if ( cachedCostFor_operand == -1 )
					{
						cachedCostFor_operand = getCostForRule_21f3aa07(goalState);

					}
					return(cachedCostFor_operand);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCostForRule_21f3aa07(goalState);

					if ( ( bestCost > currentCost )  )
					{
						rule = 6;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(1);
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				case 0:
					return subtree0;
				default:
				{
					throw new IllegalStateException("Invalid index " + index);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
			if ( subtree0 == null )
				subtree0 = child;
			else
				throw new IllegalStateException("too many children");
		}
		
		private int getCostForRule_21f3aa07( int goalState)
		{
			JBurgAnnotation factoredPath_0 = (this.getNthChild(0).getArity() > 0? this.getNthChild(0).getNthChild(0): errorAnnotation);
			JBurgAnnotation factoredPath_1 = (this.getNthChild(0).getArity() > 1? this.getNthChild(0).getNthChild(1): errorAnnotation);

			if ( this.getNthChild(0).getArity() == 2 && this.getNthChild(0).getOperator() == NON_TERMINAL_PARAMETER )
				return(normalizeCost((long)1 + (long) (((long)factoredPath_1.getCost(__simple_identifier_NT)) + ((long)factoredPath_0.getCost(__simple_identifier_NT))) ));
			else
				return(Integer.MAX_VALUE);
		}
	}

	class JBurgAnnotation_OPERAND_AT_LEAST_ONE_ARITY_1 extends JBurgSpecializedAnnotation
	{
		private JBurgAnnotation subtree0;
		JBurgAnnotation_OPERAND_AT_LEAST_ONE_ARITY_1(antlr.collections.AST node)
		{
			super(node);
		}
		private int cachedCostFor_operand = -1;
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					if ( cachedCostFor_operand == -1 )
					{
						cachedCostFor_operand = getCostForRule_5a77a7f9(goalState);

					}
					return(cachedCostFor_operand);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCostForRule_5a77a7f9(goalState);

					if ( ( bestCost > currentCost )  )
					{
						rule = 5;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(1);
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				case 0:
					return subtree0;
				default:
				{
					throw new IllegalStateException("Invalid index " + index);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
			if ( subtree0 == null )
				subtree0 = child;
			else
				throw new IllegalStateException("too many children");
		}
		
		private int getCostForRule_5a77a7f9( int goalState)
		{
			JBurgAnnotation factoredPath_0 = (this.getNthChild(0).getArity() > 0? this.getNthChild(0).getNthChild(0): errorAnnotation);
			JBurgAnnotation factoredPath_1 = (this.getNthChild(0).getArity() > 1? this.getNthChild(0).getNthChild(1): errorAnnotation);

			if ( this.getNthChild(0).getArity() == 2 && this.getNthChild(0).getOperator() == NON_TERMINAL_PARAMETER )
				return(normalizeCost((long)1 + (long) (((long)factoredPath_1.getCost(__simple_identifier_NT)) + ((long)factoredPath_0.getCost(__simple_identifier_NT))) ));
			else
				return(Integer.MAX_VALUE);
		}
	}

	class JBurgAnnotation_OPERATOR_SPECIFICATION_2_n extends JBurgSpecializedAnnotation
	{
		private JBurgAnnotation subtree0;
		private JBurgAnnotation subtree1;
		private java.util.Vector<JBurgAnnotation> narySubtrees = new java.util.Vector<JBurgAnnotation>();
		JBurgAnnotation_OPERATOR_SPECIFICATION_2_n(antlr.collections.AST node)
		{
			super(node);
		}
		private int cachedCostFor_operator_specification = -1;
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					return(getCost(__operator_specification_NT));
				}
				case __operator_specification_NT:
				{
					if ( cachedCostFor_operator_specification == -1 )
					{
						cachedCostFor_operator_specification = getCostForRule_65b4fad5(goalState);

					}
					return(cachedCostFor_operator_specification);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCost(__operator_specification_NT);

					if ( ( bestCost > currentCost )  )
					{
						rule = 8;
					}
					return(rule);
				}
				case __operator_specification_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCostForRule_65b4fad5(goalState);

					if ( ( bestCost > currentCost )  )
					{
						rule = 3;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(2 + narySubtrees.size());
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				case 0:
					return subtree0;
				case 1:
					return subtree1;
				default:
				{
					return narySubtrees.get(index - 2);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
			if ( subtree0 == null )
				subtree0 = child;
			else if ( subtree1 == null )
				subtree1 = child;
			else
				narySubtrees.add(child);
		}
		
		private int getCostForRule_65b4fad5( int goalState)
		{

			if ( this.getArity() == 2 && (this.getNthChild(1).getArity() >= 1) && this.getNthChild(1).getOperator() == OPERAND_LIST )
				return(normalizeCost((long)1 + (long) (((long)getNaryCost(this.getNthChild(1), __operand_NT, 0)) + ((long)this.getNthChild(0).getCost(__simple_identifier_NT))) ));
			else
				return(Integer.MAX_VALUE);
		}
	}

	class JBurgAnnotation_TERMINAL_PATTERN_1 extends JBurgSpecializedAnnotation
	{
		private JBurgAnnotation subtree0;
		JBurgAnnotation_TERMINAL_PATTERN_1(antlr.collections.AST node)
		{
			super(node);
		}
		private int cachedCostFor_operator_specification = -1;
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					return(getCost(__operator_specification_NT));
				}
				case __operator_specification_NT:
				{
					if ( cachedCostFor_operator_specification == -1 )
					{
						cachedCostFor_operator_specification = getCostForRule_4a0c68c3(goalState);

					}
					return(cachedCostFor_operator_specification);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCost(__operator_specification_NT);

					if ( ( bestCost > currentCost )  )
					{
						rule = 8;
					}
					return(rule);
				}
				case __operator_specification_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCostForRule_4a0c68c3(goalState);

					if ( ( bestCost > currentCost )  )
					{
						rule = 1;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(1);
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				case 0:
					return subtree0;
				default:
				{
					throw new IllegalStateException("Invalid index " + index);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
			if ( subtree0 == null )
				subtree0 = child;
			else
				throw new IllegalStateException("too many children");
		}
		
		private int getCostForRule_4a0c68c3( int goalState)
		{

			return(normalizeCost((long)1 + (long)((long)this.getNthChild(0).getCost(__simple_identifier_NT))));
		}
	}

	class JBurgAnnotation_TERMINAL_PATTERN_2 extends JBurgSpecializedAnnotation
	{
		private JBurgAnnotation subtree0;
		private JBurgAnnotation subtree1;
		JBurgAnnotation_TERMINAL_PATTERN_2(antlr.collections.AST node)
		{
			super(node);
		}
		private int cachedCostFor_operator_specification = -1;
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					return(getCost(__operator_specification_NT));
				}
				case __operator_specification_NT:
				{
					if ( cachedCostFor_operator_specification == -1 )
					{
						cachedCostFor_operator_specification = getCostForRule_74b2002f(goalState);

					}
					return(cachedCostFor_operator_specification);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __operand_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCost(__operator_specification_NT);

					if ( ( bestCost > currentCost )  )
					{
						rule = 8;
					}
					return(rule);
				}
				case __operator_specification_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCostForRule_74b2002f(goalState);

					if ( ( bestCost > currentCost )  )
					{
						rule = 2;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(2);
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				case 0:
					return subtree0;
				case 1:
					return subtree1;
				default:
				{
					throw new IllegalStateException("Invalid index " + index);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
			if ( subtree0 == null )
				subtree0 = child;
			else if ( subtree1 == null )
				subtree1 = child;
			else
				throw new IllegalStateException("too many children");
		}
		
		private int getCostForRule_74b2002f( int goalState)
		{

			return(normalizeCost((long)1 + (long) (((long)this.getNthChild(1).getCost(__simple_identifier_NT)) + ((long)this.getNthChild(0).getCost(__simple_identifier_NT))) ));
		}
	}
	
	public JBurgAnnotation getJBurgAnnotation( antlr.collections.AST node)
	{
		switch( node.getType() )
		{
			case IDENTIFIER:
			{
				if ( getArity(node) == 0 )
					return(new JBurgAnnotation_IDENTIFIER_0(node));
				break;
			}
			case NON_TERMINAL_PARAMETER:
			{
				if ( getArity(node) == 2 )
					return(new JBurgAnnotation_NON_TERMINAL_PARAMETER_2(node));
				break;
			}
			case OPERAND_ARBITRARY_ARITY:
			{
				if ( getArity(node) == 1 )
					return(new JBurgAnnotation_OPERAND_ARBITRARY_ARITY_1(node));
				break;
			}
			case OPERAND_AT_LEAST_ONE_ARITY:
			{
				if ( getArity(node) == 1 )
					return(new JBurgAnnotation_OPERAND_AT_LEAST_ONE_ARITY_1(node));
				break;
			}
			case OPERATOR_SPECIFICATION:
			{
				if ( getArity(node) >= 2 )
					return(new JBurgAnnotation_OPERATOR_SPECIFICATION_2_n(node));
				break;
			}
			case TERMINAL_PATTERN:
			{
				if ( getArity(node) == 1 )
					return(new JBurgAnnotation_TERMINAL_PATTERN_1(node));
				if ( getArity(node) == 2 )
					return(new JBurgAnnotation_TERMINAL_PATTERN_2(node));
				break;
			}
		}
		return new JBurgAnnotationGeneral(node, nStates+1);
	}
	
	public void reduce( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		reduceAntecedent(p,goalState);
		/* Release the annotation's data. */
		p.release();
	}
	
	public void reduceAntecedent( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{int iRule = -1;
		if ( ( goalState > 0 )  )
		{iRule = p.getRule(goalState);
		}
		else
		{
			/* Find the minimum-cost path. */int minCost = Integer.MAX_VALUE;int i;for( i = 0;i <= nStates;i++ )
			{
				if ( ( minCost > p.getCost(i) )  )
				{iRule = p.getRule(i);minCost = p.getCost(i);goalState = i;
				}
			}
		}
		if ( ( iRule > 0 )  )
		{
			reduceSubgoals(p, iRule);
			dispatchAction(p, iRule );
		}
		else
		{
			throw new IllegalStateException ( "Unable to find a rule to process \"" + p.toString() + "\", operator="+ String.valueOf(p.getOperator()) + ", goal=" + String.valueOf(goalState) );
		}
	}
	
	private void reduceSubgoals( JBurgAnnotation p, int rule_num) throws java.lang.Exception
	{
		if ( ___subgoals_by_rule[rule_num] != null )
		{
			for ( JBurgSubgoal sg : ___subgoals_by_rule[rule_num] )
			{
				if ( !sg.isNary() )
				{
					reduce ( sg.getNode(p), sg.getGoalState());
				}
				else
				{
					/* Aggregate the operands of an n-ary operator into a single container. */
					JBurgAnnotation sub_parent = sg.getNode(p);
					java.util.Vector<Object> variadic_result = new java.util.Vector<Object>(sub_parent.getArity() - sg.startIndex);
					for ( int j = sg.startIndex; j < sub_parent.getArity(); j++ )
					{
						reduce(sub_parent.getNthChild(j), sg.getGoalState());
						variadic_result.add(__reducedValues.pop());
					}
					__reducedValues.push(variadic_result);
				}
			}
		}
	}
	
	private int getNaryCost( JBurgAnnotation node, int goalState, int start_index)
	{
		int accumCost = 0;
		for ( int i = start_index; i < node.getArity() && accumCost != Integer.MAX_VALUE; i++ )
		{
			int subCost = node.getNthChild(i).getCost(goalState);
			if ( subCost != Integer.MAX_VALUE )
				accumCost += subCost;
			else
				accumCost = Integer.MAX_VALUE;
		}
		return accumCost;
	}
	
	public void burm( antlr.collections.AST root) throws java.lang.Exception
	{
		/* Use the least-cost goal state available. */
		burm(root, 0);
	}
	
	public void burm( antlr.collections.AST root, int goal_state) throws java.lang.Exception
	{
		JBurgAnnotation annotatedTree = label(root);
		try
		{
			reduce ( annotatedTree, goal_state);
		}
		catch ( Exception cant_reduce )
		{
			this.__problemTree = annotatedTree;
			throw cant_reduce;
		}
	}
	private JBurgAnnotation __problemTree;
	
	public void dump( java.io.PrintWriter debug_output)
	{if ( null == __problemTree )
		{debug_output.println("<bailed reason=\"no problem tree\"/>");
			return;
		}debug_output.println("<jburg><label>");
		describeNode(__problemTree, debug_output);debug_output.println("</label></jburg>");
	}

void describeNode ( JBurgAnnotation node, java.io.PrintWriter debugOutput ) 
{
	if ( node == null ) return;
	String self_description;
	try {
		self_description = java.net.URLEncoder.encode(node.getNode().toString(),"UTF-8");
	} catch ( Exception cant_encode ) {self_description = node.getNode().toString();
	}
	debugOutput.print ( "<node operator=\"" + node.getNode().getType() + "\" selfDescription=\"" + self_description + "\">");

	for (int i = 0; i <= nStates ; i++ )
	{
		if ( node.getRule(i) != 0 )
		{
			debugOutput.print ( "<goal");
			debugOutput.print ( " name=\"" + stateName[i] + "\"");
			debugOutput.print ( " rule=\"" + node.getRule(i) + "\"");
			debugOutput.print ( " cost=\"" + node.getCost(i) + "\"");
			debugOutput.println ( "/>" );
		}
	}
	for (int i = 0; i < node.getArity(); i++ )
		describeNode ( node.getNthChild(i), debugOutput );
	debugOutput.println ( "</node>" );
}

	static final String[] stateName = new String[] { "" , "operator_specification", "simple_identifier", "operand"};

	/* BURM property, from the specification */
	
	private Vector<JBurgPatternMatcher> namedTerminals;
	
	public void setNamedterminals( Vector<JBurgPatternMatcher> setting)
	{this.namedTerminals = setting;
	}
	
	public Vector<JBurgPatternMatcher> getNamedterminals( )
	{return(this.namedTerminals);
	}
	/* BURM property, from the specification */
	
	private Set operators;
	
	public void setOperators( Set setting)
	{this.operators = setting;
	}
	
	public Set getOperators( )
	{return(this.operators);
	}
	/* BURM property, from the specification */
	
	private Vector<JBurgPatternMatcher> subgoals;
	
	public void setSubgoals( Vector<JBurgPatternMatcher> setting)
	{this.subgoals = setting;
	}
	
	public Vector<JBurgPatternMatcher> getSubgoals( )
	{return(this.subgoals);
	}
	
	public Object getResult( )
	{
		return __reducedValues.pop();
	}
	/* @return the input cost, limited to Integer.MAX_VALUE to avoid overflow. */
	
	public int normalizeCost( long c)
	{
		return(c < Integer.MAX_VALUE? (int) c: Integer.MAX_VALUE);
	}

	/** JBurgAnnotation is a data structure internal to the
	 *  JBurg-generated BURM that annotates a JBurgNode with
	 *  information used for dynamic programming and reduction.
	 */
	abstract class JBurgAnnotation
	{
		/**  The INode we're annotating.  */
		antlr.collections.AST m_node; 
		JBurgAnnotation ( antlr.collections.AST newNode)
		{
			m_node = newNode;
		}
		/** @return this node's operator. */
		public int getOperator() 
		{
			return m_node.getType(); 
		}
		/** @return this node's wrappedantlr.collections.AST. */ 
		public antlr.collections.AST getNode()  
		{
			return m_node; 
		}
		/** @return the nth child of this node.  */
		public abstract JBurgAnnotation getNthChild(int idx);
		/** @return this node's child count.  */
		public abstract int getArity();
		/** Add a new child to this node.  */
		public abstract void addChild(JBurgAnnotation new_child);
		/** Release this node's data.  */
		public abstract void release();
		/** @return the wrapped node's toString().  */
		public String toString() 
		{
			return m_node.toString(); 
		}
		/** @return the current best cost to reach a goal state.  */
		public abstract int getCost( int goalState ) ;
		 /** Set the cost/rule configuration of a goal state.
		 * @throws IllegalArgumentException if this node has a fixed cost/rule.*/
		 public abstract void reset ( int goalState, int cost, int rule );
		/** * @return the rule to fire for a specific goal state. */
		public abstract int getRule ( int goalState ) ;
		/**
		 *  A closure's transformation rule succeeded.
		 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
		 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
		 *  transition back to a goal state that has already been reduced).*/
		public abstract void recordAntecedent ( int iGoalState, int newAntecedentState );
	
	}

	abstract class JBurgSpecializedAnnotation extends JBurgAnnotation
	{
		JBurgSpecializedAnnotation(antlr.collections.AST node)
		{
			super(node);
		}
		public JBurgAnnotation getNthChild(int idx)
		{
			throw new IllegalStateException(this.getClass().getName() + " has no children.");
		}
		public void addChild(JBurgAnnotation new_child)
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot have children.");
		}
		public void reset ( int goalState, int cost, int rule )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot be reset.");
		}
		public void release ()
		{
		}
		public void recordAntecedent ( int iGoalState, int newAntecedentState )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot record antecedents.");
		}
	}

	class ErrorAnnotation extends JBurgSpecializedAnnotation
	{
		ErrorAnnotation()
		{
			super(null);
		}
		public int getRule(int state) { return -1; }
		public int getCost(int state) { return Integer.MAX_VALUE; }
		public int getArity() { return 0; }
	}
	final JBurgAnnotation errorAnnotation = new ErrorAnnotation();

	/**  JBurgAnnotation implementation used for general-purpose computation. */
	class JBurgAnnotationGeneral extends JBurgAnnotation
	{
		/** cost/rule matrices used during dynamic programming to compute
		 *  the most economical rules that can reduce  the input node.
		 */
		private int cost[];
		private int rule[];
		/**  Transformation rules may have antecedents: other states whose
		 *  output the transformation rule is intended to transform.
		 *  All such antecedent states must be executed in sequence when the rule is reduced.
		 */
		private int[] antecedentState = null;
		/** *  This node's children (may be empty).  */
		private java.util.Vector<JBurgAnnotation> m_children = null;
		JBurgAnnotationGeneral ( antlr.collections.AST newNode, int nRules) 
		{
			super(newNode);
			rule   = new int[nRules];
			cost   = new int[nRules];
			//  Initial cost of all rules is "infinite"
			java.util.Arrays.fill ( cost, Integer.MAX_VALUE);
			//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array.
		}
		/** @return this node's operator. */
		public int getOperator() 
		{
			return m_node.getType(); 
		}
		/** @return this node's wrappedantlr.collections.AST. */ 
		public antlr.collections.AST getNode()  
		{
			return m_node; 
		}
		/** @return the nth child of this node.  */
		public JBurgAnnotation getNthChild(int idx)
		{
			if ( m_children != null && m_children.size() > idx)
			{
				return (JBurgAnnotation) m_children.elementAt(idx);
			}
			else
			{
				throw new IllegalArgumentException( String.format("Index %d out of range opcode %s:", idx, this.getOperator() ));
			}
		}
		/** @return this node's child count.  */
		public int getArity()
		{
			return m_children != null? m_children.size():0;
		}
		/** Add a new child to this node.  */
		public void addChild(JBurgAnnotation new_child)
		{
			if (m_children == null)
			m_children = new java.util.Vector<JBurgAnnotation>();
			if (new_child != null)
			m_children.add(new_child);
		}
		/** Release this node's data.  */
		public void release()
		{
			m_children = null;
			cost = null;
			rule = null;
		}
		/** @return the wrapped node's toString().  */
		public String toString() 
		{
			return m_node.toString(); 
		}
		/** @return the current best cost to reach a goal state.  */
		public int getCost( int goalState ) 
		{
			return cost[goalState]; 
		}
		 /** Set the cost/rule configuration of a goal state.
		 * @throws IllegalArgumentException if this node has a fixed cost/rule.*/
		 public void reset ( int goalState, int cost, int rule )
		{
			this.cost[goalState] = cost;
			this.rule[goalState] = rule;
			//  We have a brand new rule, therefore it has no antecedents.
			if ( this.antecedentState != null )this.antecedentState[goalState] = 0;
		}
		/** * @return the rule to fire for a specific goal state. */
		public int getRule ( int goalState ) 
		{
			return rule[goalState]; 
		}
		/**
		 *  A closure's transformation rule succeeded.
		 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
		 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
		 *  transition back to a goal state that has already been reduced).*/
		public void recordAntecedent ( int iGoalState, int newAntecedentState )
		{
			int antecedentRule = rule[newAntecedentState];
			//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled.
			if ( antecedentRule == 0 )
			throw new IllegalStateException ( "Attempting to record an unlabelled antecedent state." );
			if ( antecedentRule == 1 )
			{
				//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run.
				if ( antecedentState != null )
				antecedentState[iGoalState] = antecedentState[newAntecedentState];
			}
			else
			{
				if ( antecedentState == null )
				antecedentState = new int[rule.length];
				antecedentState[iGoalState] = newAntecedentState;
			}
		}
	
	}
	
	static class JBurgSubgoal
	{
		private int goalState;
		private boolean isNary;
		private int startIndex;
		private int[] accessPath;
		
		public JBurgSubgoal( int goal_state, boolean is_nary, int start_index, int... access_path)
		{
			this.goalState = goal_state;
			this.isNary = is_nary;
			this.startIndex = start_index;
			this.accessPath = access_path;
		}
		public int getGoalState() { return this.goalState; }
		public boolean isNary() { return this.isNary; }
		public JBurgAnnotation getNode(JBurgAnnotation root)
		{
			JBurgAnnotation result = root;
			for ( int idx: this.accessPath )
				result = result.getNthChild(idx);
			return result;
		}
	
	}

}