/**
  * Header file to support JBurg whilst emitting C++
  */
#include <string>
#include <stdexcept>
#include <vector>
#include <cstdarg>

// strange as it looks, this does work (at least on my platform, VS.NET 2003)
// and I think it should work on any platform
#define MAX_INT_VALUE (-1^(1<<((sizeof(int)*8)-1)))
// and the inverse (might be useful!)
#define MIN_INT_VALUE (MAX_INT_VALUE+1)


template<class T>
class JBurgAnnotation
{

public:
	class JBurgSubgoal
	{
	public:
		JBurgSubgoal(const int subgoal_state, const bool is_nary, const int start_index, const std::vector<int> access_path):
            subgoalState(subgoal_state)
            , m_isNary(is_nary)
            , startIndex(start_index)
            , accessPath(access_path)
		{
		}

	public:

		/// @return the state to which the node must be reduced.
		const int getGoalState() const { return this->subgoalState; }
        ///  @return true if the node is n-ary.
        const bool isNary() const { return this->m_isNary; }
        ///  @return the node's start index.
        const int getStartIndex() const { return this->startIndex; }

        ///  @return the root node's child specified by the access path.
        JBurgAnnotation<T>* getNode(JBurgAnnotation<T>* root) const
        {
            JBurgAnnotation<T>* result = root;
            for ( int i = 0; i < accessPath.size(); i++ )
                result = result->getNthChild(accessPath[i]);
            return result;
        }

	private:
		int subgoalState;
        bool m_isNary;
        int startIndex;
        std::vector<int> accessPath;

	};

private:
	///  The node being labelled/reduced.
	T*					m_node;

	///  Denormalized data for ease of reference.
	///  FIXME: Could be static?
	int					nRules;

	///  Per-goal-state cost values.
	int					*cost;

	///  Per-goal-state cost values.
	int					*rule;

	///  Antecedent states of the a given state.
	std::vector<int> m_antecedent_states;

private:
	/*
	 * Subtree structure.
	 */
	std::vector< JBurgAnnotation<T>* > m_children;

/* c'tors & d'tor */
public:
	JBurgAnnotation(T* newNode, int nRules)
	{
		m_node = newNode;
		
		// initialise rules array
		rule = new int[nRules];
		memset(rule, 0, sizeof(int)*nRules);

		// init cost array
		cost = new int[nRules];
		for(int x=0; x<nRules; ++x)
		{
			cost[x] = MAX_INT_VALUE;
		}
		
		// initial rule for all sub-goals is undefined.
		
		// keep a copy of the array sizes, we don't know them otherwise! (unlike java we can't do array.length)
		this->nRules = nRules;
	}

	~JBurgAnnotation()
	{
		// assume that m_node is a reference & is deleted elsewhere
		if(rule) delete[] rule;
		if(cost) delete[] cost;
		
		for ( size_t i = 0; i < m_children.size(); i++ )
		{
			delete m_children[i];
		}
	}


protected:
	// Undefine the default constructor
	JBurgAnnotation();


/* methods */
public:
	int				getOperator()					{ return jburgsupp::getOperator(m_node); }
	T*				getNode()						{ return m_node; }
	std::string&	toString()						{ return m_node->getText(); }
	int				getCost(int goalState)			{ return cost[goalState]; }
	int				getRule(int goalState)			{ return rule[goalState]; }
	
	void reset(int goalState, int cost, int rule) {
		this->cost[goalState] = cost;
		this->rule[goalState] = rule;
	}

	const bool hasAntecedent( int goalState )
	{
		return m_antecedent_states.size() > goalState && m_antecedent_states[goalState] != 0;
	}

	const int getAntecedent( int goalState )
	{
		return m_antecedent_states[goalState];
	}

	void recordAntecedent(const int goal_state, const int antecedent_state)
	{
		if ( m_antecedent_states.size() <= goal_state )
		{
			m_antecedent_states.resize(nRules + 1);
		}
		m_antecedent_states[goal_state] = antecedent_state;
	}

	/**
	 *  @return the number of children of this node.
	 */
	size_t getArity()
	{
		return m_children.size();
	}

	/**
	 *  @return the child at the specified index.
	 *  @throw std::runtime_error if the child index is out of bounds.
	 */
	JBurgAnnotation<T>* getNthChild(const size_t idx)
	{
		if ( idx < getArity() )
		{
			return m_children[idx];
		}
		else
		{
			throw new std::runtime_error("getNthChild() index out of bounds.");
		}
	}

	/**
	 *  Add a new child node.
	 *  @post this node assumes ownership of the child node.
	 */
	void addChild(JBurgAnnotation<T>* new_child)
	{
		if ( new_child)
			m_children.push_back(new_child);
	}
	
};

//  Add up costs of a rule, guard against overflow.
int addAllCosts(int count, ...)
{
    va_list ap;
    int i;

    long accum = 0;
    va_start(ap, count); //Requires the last fixed parameter (to get the address)

    for ( i = 0; i < count; i++)
    {
        int x = va_arg(ap, int);
        if ( accum + x >= MAX_INT_VALUE )
            return MAX_INT_VALUE;
        accum += x;
    }
    va_end(ap);
    return (int)accum;
}

