package jburg.compiler.tl2.semanticanalysis;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import jburg.compiler.tl2.ir.MultipartIdentifier;
import jburg.compiler.tl2.ir.TL2INode;
import jburg.compiler.tl2.ir.Symbol;

import org.apache.bcel.generic.ClassGen;
import org.apache.bcel.generic.ArrayType;
import org.apache.bcel.generic.Type;
import org.apache.bcel.generic.ObjectType;

/**
 *  AbstractClass is the TL/2 compiler's view of a class, be it imported,
 *  defined in the input compilation unit(s), or specified by name in
 *  the program.
 *
 *  An AbstractClass consists of collection of reflection information
 *  from a Java Class (if the class in question is not under compilation)
 *  or a collection of compiler data (if the class is being compiled).
 *
 *  AbstractClass also maintains a per-thread map of known classes and
 *  their "nicknames," which are the short names of imported classes
 *  or java.lang classes, and the type names of the primitive types,
 *  such as int.
 */
public class AbstractClass
{
   /**
    *  The class' name.
    *  FIXME:  Should be a symbol to carry modifiers.
    */
   protected String className;

   /**
    *  The class' signature.
    *  @see #getSignature
    */
   protected String classSignature = null;

   /**
    *  The class' fields, as symbols.
    */
   private SymbolTable fields;

   /**
    *  The class' methods in TL/2 AbstractMethod format.
    */
   private AbstractMethod[] declaredMethods;

   /** Dimensionality of this class; 0 means not an array. */
   private int dimension = 0;

   /**
    *  Array variants of a class are stored relative to
    *  their base component, e.g., Foo[][] is found by
    *  resolving Foo and then indexing.
    */
   private Vector arrayVariants;

   /**
    *  Array variant class' back reference to the
    *  base component.
    */
   AbstractClass baseComponent;

   /**
    *  This is an array class from an external reference.
    */
   private boolean isJavaArrayClass = false;

   /*
    *  *********************
    *  **  Class Factory  **
    *  *********************
    *
    *  The class factory is a pair of static routines that the compiler uses
    *  in a way similar to the Class.forName() method; an identifier that
    *  may represent a class, or a Class object, can be passed into the
    *  factory to yield an AbstractClass.
    */

   /*
    *  Representations of primitive types as classes.
    */
   public static PrimitiveClass BOOLEAN = new PrimitiveClass("boolean", "Z");
   public static PrimitiveClass DOUBLE  = new PrimitiveClass("double",  "D");
   public static PrimitiveClass FLOAT   = new PrimitiveClass("float",   "F");
   public static PrimitiveClass INT     = new PrimitiveClass("int",     "I");
   public static PrimitiveClass SHORT   = new PrimitiveClass("short",   "S");
   public static PrimitiveClass VOID    = new PrimitiveClass("void",    "V");

   /*
    *  Representations of classes injected into the code by the compiler itself.
    */
   /** * java.lang.Integer as an AbstractClass */
   public static AbstractClass IntegerClass;

   /** * java.lang.Object as an AbstractClass */
   public static AbstractClass ObjectClass;

   /** * java.lang.String as an AbstractClass */
   public static AbstractClass StringClass;

   /** * java.lang.StringBuffer as an AbstractClass */
   public static AbstractClass StringBufferClass;

   /**
    *  Compilation proceeds on a thread per compilation basis, so a ThreadLocal
    *  object can find this compilation's class map.
    */
   static private ThreadLocal tlClassMap = new ThreadLocal();

   private static HashMap getClassMap()
   {
    return (HashMap)tlClassMap.get();
   }

   /**
    *  Initialize this compilation's class map, and initialize the static representations
    *  of the compiler-used and primitive classes if they have not already been initialized.
    *
    *  They cannot be initialized in static code because they must use the class factory to
    *  get AbstractClass representations of their fields' and methods' types; for this same
    *  reason, the initialization below is split into create/map/initialize phases so that
    *  classes that reference themselves won't cause the class factory to loop.
    */
   static synchronized void initializeClassMap()
   {
    HashMap classMap = new HashMap();
    tlClassMap.set(classMap);

    boolean initializeStaticClasses = false;

    if ( IntegerClass == null )
    {
        //  Static classes have not been initialized, do it now.
        initializeStaticClasses = true;

        IntegerClass = new AbstractClass();
        ObjectClass = new AbstractClass();
        StringClass = new AbstractClass();
        StringBufferClass = new AbstractClass();
    }

    classMap.put ( "Integer", IntegerClass );
    classMap.put ( "java.lang.Integer", IntegerClass );
    classMap.put ( "Object", ObjectClass );
    classMap.put ( "java.lang.Object", ObjectClass );
    classMap.put ( "String", StringClass );
    classMap.put ( "java.lang.String", StringClass );
    classMap.put ( "StringBuffer", StringBufferClass );
    classMap.put ( "java.lang.StringBuffer", StringBufferClass );

    classMap.put ( "boolean", AbstractClass.BOOLEAN );
    classMap.put ( "double",  AbstractClass.DOUBLE );
    classMap.put ( "float",   AbstractClass.FLOAT );
    classMap.put ( "int",     AbstractClass.INT );
    classMap.put ( "short",   AbstractClass.SHORT );
    classMap.put ( "void",    AbstractClass.VOID );

    if ( initializeStaticClasses )
    {
        IntegerClass.fromJavaClass(Integer.class );
        ObjectClass.fromJavaClass(Object.class );
        StringClass.fromJavaClass(String.class );
        StringBufferClass.fromJavaClass(StringBuffer.class );
    }

   }


   /**
    *  @param clazz - a Java Class object.
    *  @return the AbstractClass representation of the class.
    */
   static public AbstractClass getAbstractClass ( Class clazz )
   {

    if ( clazz.equals ( Integer.TYPE ) )
        return AbstractClass.INT;
    else if ( clazz.equals( Void.TYPE ) )
        return AbstractClass.VOID;
    else
    {
        //  An object type of some kind.

        String cName = clazz.getName();

        AbstractClass result = (AbstractClass)getClassMap().get ( cName );

        if ( result == null )
        {
            result = new AbstractClass();
            getClassMap().put ( cName, result );
            result.fromJavaClass(clazz);
        }

        return result;
    }
   }

   /**
    *  @return the AbstractClass that corresponds to the name specified.
    */
   static public AbstractClass getAbstractClass ( String rawName )
   {
    AbstractClass result;

    if ( rawName.equals("int") )
    {
        result = INT;
    }
    else if ( rawName.equals("double") )
    {
        result = DOUBLE;
    }
    else if ( rawName.equals("void") )
    {
        result = VOID;
    }
    else
    {
        result = (AbstractClass) getClassMap().get(rawName);

        if ( result == null )
        {
            //  Try to resolve this as a previously-unmapped Java class.
            Class clazz = null;

            try
            {
                clazz = Class.forName ( rawName );
                result = new AbstractClass();

                getClassMap().put ( rawName, result );

                result.fromJavaClass ( clazz );
            }
            catch ( Exception ex )
            {
                //  Last try: prepend "java.lang." for builtin classes.
                try
                {
                    String qualifiedName = "java.lang." + rawName;

                    result = (AbstractClass) getClassMap().get ( qualifiedName );

                    if ( result == null )
                    {
                        clazz = Class.forName ( qualifiedName );

                        result = new AbstractClass();

                        getClassMap().put ( qualifiedName, result );
                        getClassMap().put ( rawName, result );

                        result.fromJavaClass ( clazz );
                    }
                }
                catch ( Exception noMoreChances )
                {
                    // throw new UnknownClassException ( rawName );
                    throw new IllegalArgumentException ( "No class named " + rawName + " can be found." );
                }
            }
        }
    }

    return result;
   }

   /**
    *  Process an import specification by mapping its AbstractClass to its final identifier element.
    */
   public static void importSpecification(MultipartIdentifier id)
   {
    AbstractClass importedClass = getAbstractClass(id.toString());

    getClassMap().put( id.elementAt ( id.size() - 1 ).image, importedClass );
   }

   /**
    *  The AbstractClass constructor does nothing, so that the class factory can
    *  insert the AbstractClass into its maps before it begins analyzing the class;
    *  this avoids loops in cases where a class' fields or methods reference itself.
    */
   private AbstractClass ()
   {
   }

   /**
    *  Construct an AbstractClass of the specified dimensions; called by
    *  the array factory.
    *
    *  @param baseComponent - the underlying primitive/object component type.
    *  @param dimension - the number of dimensions this array has.
    */
   private AbstractClass ( AbstractClass baseComponent, int dimension )
   {
    this.className       = baseComponent.className;
    this.fields          = baseComponent.fields;
    this.declaredMethods = baseComponent.declaredMethods;

    this.dimension = dimension;

    this.baseComponent = baseComponent;
   }

   /**
    *  Populate this AbstractClass with information
    *  from a Java class.
    */
   private void fromJavaClass ( Class clazz )
   {
    this.className = clazz.getName();

    this.isJavaArrayClass = clazz.isArray();

    Method[] methods = clazz.getMethods();

    this.declaredMethods = new AbstractMethod[methods.length];

    for ( int i = 0; i < methods.length; i++ )
        this.declaredMethods[i] = new AbstractMethod(methods[i]);

    this.fields = new SymbolTable();

    Field[] allfields = clazz.getFields();

    for ( int j = 0; j < allfields.length; j++ )
    {
        Symbol s = new Symbol();
        s.setName ( allfields[j].getName() );
        s.setSymbolClass ( getAbstractClass ( allfields[j].getType() ) );
        s.setModifiers ( allfields[j].getModifiers() );

        this.fields.addSymbol(s);
    }
   }

   /**
    *   As the ClassAnalyzer begins processing a new class under compilation,
    *   it calls this method to create an AbstractClass representation of that
    *   class and insert it into the class map.
    */
   /* pkg private */
   static AbstractClass declareLocalClass ( ClassAnalyzer analyzer )
   {
    AbstractClass newClass = new AbstractClass();

    newClass.className = analyzer.getClassname();
    getClassMap().put ( newClass.className, newClass );

    return newClass;
   }

   /**
    *  When the ClassAnalyzer has collected all information about the new class'
    *  fields and methods, it calls this method to insert this information into
    *  the new class' AbstractClass shadow.
    */
   /* pkg private */
   static void initializeLocalClass ( ClassAnalyzer analyzer )
   {
    AbstractClass newClass = (AbstractClass)getClassMap().get ( analyzer.getClassname() );

    newClass.fields    = analyzer.getFieldSymbolTable();

    int      size = analyzer.numMethods();
    Iterator it   = analyzer.getMethods();

    newClass.declaredMethods = new AbstractMethod[size];

    for ( int i = 0;  i < size; i++ )
    {
        TL2INode nextMethodNode = (TL2INode)it.next();
        newClass.declaredMethods[i] = new AbstractMethod(nextMethodNode);
    }
   }

   public String getName()
   {
    return this.className;
   }

   public String getSignature()
   {
    if ( this.classSignature == null )
    {
        StringBuffer signature = new StringBuffer();

        if ( ! this.isJavaArrayClass )
            signature.append( "L" );

        signature.append( this.className.replace('.','/') );

        if ( ! this.isJavaArrayClass )
            signature.append( ";" );

        for ( int i = 0; i < this.dimension; i++ )
            signature.insert(0,"[");

        this.classSignature = signature.toString();
    }

    return this.classSignature;
   }

   public AbstractMethod[] getDeclaredMethods()
   {
    return this.declaredMethods;
   }

   public static final boolean STATIC_FIELD   = true;
   public static final boolean INSTANCE_FIELD = false;

   /**
    *  @return the Symbol that represents the class' field with
    *    the given name and static properties, or null if such
    *    a field doesn't exist.
    *
    * @throws IllegalStateException if the class has no fields,
    *   i.e., it's a primitive type.
    */
   public Symbol getField ( String fName, boolean wantsStatic )
   {
    if ( fields == null )
        throw new IllegalStateException
            ( "Primitive type " + this.className + " has no fields." );

    Symbol s = fields.getSymbol(fName);

    return (s != null && s.isStatic() == wantsStatic)? s : null;
   }

   /**
    *  @return the BCEL Type that corresponds to this class' type.
    */
   public Type getType()
   {
    if ( this.equals(AbstractClass.INT) )
        return Type.INT;
    else if ( this.equals(AbstractClass.BOOLEAN) )
        return Type.BOOLEAN;
    else if ( this.equals(AbstractClass.DOUBLE) )
        return Type.DOUBLE;
    else if ( this.equals(AbstractClass.FLOAT) )
        return Type.FLOAT;
    else if ( this.equals(AbstractClass.VOID) )
        return Type.VOID;
    else if ( this.dimension > 0 )
    {
        return new ArrayType ( this.getName(), this.dimension );
    }
    else
    {
        return new ObjectType ( this.getName() );
    }
   }

   /** @return true if this is an array type. */
   public boolean isArray()
   {
    return this.dimension > 0;
   }

   /** @return the non-array'd version of this type. */
   private AbstractClass getBaseComponent()
   {
    if ( this.baseComponent != null )
        return this.baseComponent;
    else
        return this;
   }

   /**
    *  @return An AbstractClass that is an array of this class'
    *  base component class, to the specified dimension.
    */
   public AbstractClass getArrayType ( int dimension )
   {
    AbstractClass base = getBaseComponent();

    if ( base.arrayVariants == null )
        base.arrayVariants = new Vector();

    Vector aVar = base.arrayVariants;

    if ( aVar.size() < dimension  )
    {
        aVar.setSize(dimension + 1);
    }

    if ( aVar.elementAt(dimension) == null )
    {
        aVar.setElementAt ( new AbstractClass ( base, dimension ), dimension );
    }

    return (AbstractClass)aVar.elementAt(dimension);
   }

   /**
    *  Search this class for a method of the specified name and signature.
    *  @param methodName - the name of the method to be found.
    *  @param fParams - the Vector that contains the method's parameters.
    *  @param wantsStatic - if set, then the method must be static.
    *  @return the AbstractMethod that most closely matches the input parameters.
    *  @throws NoSuchMethodException if no such method can be found.
    */
   public AbstractMethod getDeclaredMethod
    ( String methodName, Vector fParams, boolean wantsStatic )
   {
    AbstractMethod[] methods = this.declaredMethods;

    for ( int i = 0; i < methods.length; i++ )
    {
        if  ( (!wantsStatic || methods[i].isStatic() ) && methods[i].getName().equals ( methodName ) )
        {
            AbstractMethod candidateMethod = methods[i];

            Symbol[] mTypes = candidateMethod.getParameterTypes();

            //  Check parameter types.
            //  FIXME:  deal with overloading.

            if ( mTypes.length == fParams.size() )
            {
                int nthType;

                for ( nthType = 0; nthType < mTypes.length; nthType++ )
                {
                    AbstractClass nextParamClass = (AbstractClass) fParams.elementAt(nthType);
                    if ( !mTypes[nthType].getSymbolClass().isAssignableFrom ( nextParamClass ) )
                        break;
                }

                if ( nthType == mTypes.length )
                    return candidateMethod;
            }
        }
    }

	StringBuffer diagnosticSignature = new StringBuffer(methodName);
	diagnosticSignature.append("(");
	for ( int x = 0; x < fParams.size(); x++)
	{
		if ( x > 0 )
		{
			diagnosticSignature.append(",");
		}

		diagnosticSignature.append(fParams.elementAt(x).toString());
	}
	diagnosticSignature.append(")");

    throw new IllegalStateException
        ( "Class " + getName() + " does not contain a " + ((wantsStatic)?"static":"") + " method " + diagnosticSignature.toString() + "." );
   }

   /**
    *  PrimitiveClass objects represent primitive Java types, such as int.
    */
   public static class PrimitiveClass extends AbstractClass
   {
    /**
     *  Construct a primitive type's AbstractClass.
     *  @param primitiveName, e.g., "int"
     *  @param primitiveSignature - a primitive type's signature
     *    cannot be deduced by examining metadata, it's an a priori
     *    part of the Java language standard.
     */
       PrimitiveClass ( String primitiveName, String primitiveSignature )
    {
        this.className      = primitiveName;
        this.classSignature = primitiveSignature;
    }

    /**
     *  @throws IllegalStateException, a primitive type has no methods.
     */
    public AbstractMethod[] getDeclaredMethods()
    {
        throw new IllegalStateException
            ( "Primitive type " + this.className + " has no methods." );
    }

    /**
     *  @throws IllegalStateException, a primitive type has no fields.
     */
    public Symbol getField ( String fName, boolean wantsStatic )
    {
        throw new IllegalStateException
            ( "Primitive type " + this.className + " has no fields." );
    }
   }

   public boolean isAssignableFrom ( AbstractClass c2 )
   {
    return this.equals(c2);
   }

   public String toString()
   {
	   return this.className;
   }
}
