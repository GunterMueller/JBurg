package jburg.burg.emitlangs;

import java.io.PrintStream;
import java.lang.reflect.Modifier;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import jburg.burg.JBurgGenerator;
import jburg.burg.JBurgPatternMatcher;

import jburg.burg.inode.InodeAdapter;
import jburg.burg.emitlangs.EmitLang;

import jburg.parser.JBurgTokenTypes;

@SuppressWarnings({"nls","rawtypes"})
public class EmitJava implements EmitLang, JBurgTokenTypes  
{
	/**  The current block nesting depth. */
	private int blockCount = 0;

	/** Manifest constant signature snippet for a method that throws Exception.  */
	final static Class[] throwsException = new Class[] { Exception.class };
	/** Manifest constant signature snippet for a method that doens't throw.  */
	final static Class[] throwsNothing   = null;

	/** I-node adapter in use. */
	jburg.burg.inode.InodeAdapter inodeAdapter;
	
	/** Prefix to internal BURM names. */
	String internalPrefix = "__";

    /** Operator type, defaults to int */
    String operatorType = "int";
    
    public void setOpcodeType(String operator_type)
    {
        this.operatorType = operator_type;
    }
	
	private String reducerStack()
	{
	    return internalPrefix + "reducedValues";
	}
	
	private String subgoalArray()
	{
	    return internalPrefix + "_subgoals_by_rule";
	}
	
	/** 
	 *  Debugging aid, used while converting boilerplate code from
	 *  raw output of cut/pasted hand-built reducer logic to the
	 *  more language-independent format JBurg uses.
	 */
	public boolean noisyBlockCounts = "true".equalsIgnoreCase(System.getenv("JBURG_NOISY_BLOCK_COUNTS"));

    @Override
    public boolean supportsSpecializedAnnotations()
    {
        return true;
    }

    @Override
    public void emitHeader(
        String strClassName,
        String packageName,
        String headerBlock,
        String baseClassName,
        Vector<String> InterfaceNames,
        boolean debugMode,
        PrintStream output
        )
	{
		int i;

		if (packageName != null)
			output.print("\npackage " + packageName + ";\n\n");

		if (headerBlock != null) {
			//  Strip off the enclosing "{" and "}".
			output.print(headerBlock.substring(1,
						 headerBlock.length() - 2));
			output.print("\n");
		}

		output.print("public class " + strClassName);

        if ( baseClassName != null )
            output.print(" extends " + baseClassName);

		if (InterfaceNames.size() > 0) {
			output.print(" implements ");

			for (i = 0; i < InterfaceNames.size(); i++) {
				if (i > 0) {
					output.print(", ");
				}

				output.print(InterfaceNames.get(i));
			}
		}

		output.print( genLine(genBeginBlock()));
		output.print(genLine("java.util.Stack " + reducerStack() + " = new java.util.Stack();"));
	}
    
    /**
     *  Emit the static subgoal arrays.
     */
    public void emitStatics(int max_action, Map<Integer, Vector<JBurgPatternMatcher>> rules_by_action, PrintStream output)
    {
        output.println();
        output.print(genLine("private static final JBurgSubgoal[][] " + subgoalArray() + " = "));
        output.print(genBeginBlock());
        for ( int i = 0; i <= max_action; i++ )
        {
            if ( rules_by_action.containsKey(i))
            {
                output.print(genBeginBlock());
                
                //  Emit the subgoals in reverse order so they are reduced and pushed
                //  onto the stack in the correct order.
                Vector<JBurgPatternMatcher> matchers = rules_by_action.get(i); 
                for ( int j = matchers.size() -1; j >= 0; j--  )
                {
                    JBurgPatternMatcher matcher = matchers.elementAt(j);
                    output.print(genLine("new JBurgSubgoal("));
                    output.print(genGetGoalState(matcher.getSubgoal() ));
                    output.print(",");
                    if ( matcher.isNary() )
                    {
                        output.print("true,");
                        output.print(matcher.getPositionInParent());
                    }
                    else
                    {
                        output.print("false,0");
                    }
                    for (JBurgPatternMatcher.PathElement idx: matcher.generateAccessPath() )
                    {
                        output.print(",");
                        output.print(Integer.toString(idx.index));
                    }
                    
                    output.print("),");
                }
                output.print(genEndBlock());
                output.print(",");
            }
            else
            {
                output.print(genLine("null,"));
            }
        }
        output.print(genEndBlock());
        output.println(genEndStmt());
        output.println();
    }


	public void emitAnnotation(String iNodeClass, PrintStream output) 
	{
		output.print(genLine("/** JBurgAnnotation is a data structure internal to the"));
		output.print(genLine(" *  JBurg-generated BURM that annotates a JBurgNode with"));
		output.print(genLine(" *  information used for dynamic programming and reduction."));
		output.print(genLine(" */"));
		output.print(genLine("public abstract class JBurgAnnotation"));
		output.print(genBeginBlock());
		output.print(genLine("/**  The INode we're annotating.  */"));
		output.print(genLine(iNodeClass));
		output.print(" m_node; ");
		
		output.print(genLine("JBurgAnnotation ( "));
		output.print(iNodeClass);
		output.print(" newNode)");
		output.print(genBeginBlock());
		output.print(genLine("m_node = newNode;"));
		output.print(genEndBlock());

		output.print(genLine("/** @return this node's operator. */"));
		output.print(genLine("public " + this.operatorType + " getOperator() "));
        output.print(genBeginBlock());
        output.print(genLine("return " + inodeAdapter.genGetOperator("m_node", this) + "; "));
        output.print(genEndBlock());

		output.print(genLine("/** @return this node's wrapped"));
		output.print(iNodeClass);
		output.print(". */ ");
		output.print(genLine("public " + iNodeClass + " getNode()  "));
        output.print(genBeginBlock());
        output.print(genLine("return m_node; "));
        output.print(genEndBlock());

		output.print(genLine("/** @return the nth child of this node.  */"));
		output.print(genLine("public abstract JBurgAnnotation getNthChild(int idx);"));

		output.print(genLine("/** @return this node's child count.  */"));
		output.print(genLine("public abstract int getArity();"));

		output.print(genLine("/** Add a new child to this node.  */"));
		output.print(genLine("public abstract void addChild(JBurgAnnotation new_child);"));

		output.print(genLine("/** Release this node's data.  */"));
		output.print(genLine("public abstract void release();"));

		output.print(genLine("/** @return the wrapped node's toString().  */"));
		output.print(genLine("public String toString() "));
        output.print(genBeginBlock());
        output.print(genLine("return m_node.toString(); "));
        output.print(genEndBlock());
		output.print(genLine("/** @return the current best cost to reach a goal state.  */"));
		output.print(genLine("public abstract int getCost( int goalState ) ;"));
		output.print(genLine(" /** Set the cost/rule configuration of a goal state."));
		output.print(genLine(" * @throws IllegalArgumentException if this node has a fixed cost/rule.*/"));
		output.print(genLine(" public abstract void reset ( int goalState, int cost, int rule );"));
		output.print(genLine("/** * @return the rule to fire for a specific goal state. */"));
		output.print(genLine("public abstract int getRule ( int goalState ) ;"));
		output.print(genLine("/**"));
		output.print(genLine(" *  A closure's transformation rule succeeded."));
		output.print(genLine(" *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;"));
		output.print(genLine(" *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never "));
		output.print(genLine(" *  transition back to a goal state that has already been reduced).*/"));
		output.print(genLine("public abstract void recordAntecedent ( int iGoalState, int newAntecedentState );"));
		
		//  End of JBurgAnnotation
		output.print(genEndClass());

        //  Create the base class for the specialized annotations.
        output.println();
        output.print(genLine( "abstract class JBurgSpecializedAnnotation extends JBurgAnnotation"));
        output.print(genBeginBlock());
        output.print(genLine( String.format("JBurgSpecializedAnnotation(%s node)", iNodeClass)));
        output.print(genBeginBlock());
        output.print(genLine( "super(node);"));
        output.print(genEndBlock());

        output.print(genLine( "public JBurgAnnotation getNthChild(int idx)"));
        output.print(genBeginBlock());
        output.print(genLine(genThrow( "this.getClass().getName() + \" has no children.\"") + genEndStmt()));
        output.print(genEndBlock());

        output.print(genLine( "public void addChild(JBurgAnnotation new_child)"));
        output.print(genBeginBlock());
        output.print(genLine(genThrow( "this.getClass().getName() + \" cannot have children.\"") + genEndStmt()));
        output.print(genEndBlock());

        output.print(genLine( "public void reset ( int goalState, int cost, int rule )"));
        output.print(genBeginBlock());
        output.print(genLine(genThrow( "this.getClass().getName() + \" cannot be reset.\"") + genEndStmt()));
        output.print(genEndBlock());

        output.print(genLine( "public void release ()"));
        output.print(genBeginBlock());
        output.print(genEndBlock());

        output.print(genLine( "public void recordAntecedent ( int iGoalState, int newAntecedentState )"));
        output.print(genBeginBlock());
        output.print(genLine(genThrow( "this.getClass().getName() + \" cannot record antecedents.\"") + genEndStmt()));
        output.print(genEndBlock()); // recordAntecedent
        output.print(genEndBlock()); // class JBurgSpecializedAnnotation

        //  Emit the ErrorAnnotation class and singleton.
        output.println();
        output.print(genLine( "class ErrorAnnotation extends JBurgSpecializedAnnotation"));
        output.print(genBeginBlock());
        {
            output.print(genLine( "ErrorAnnotation()"));
            output.print(genBeginBlock());
            {
                output.print(genLine( "super(null);"));
            }
            output.print(genEndBlock());

            output.print(genLine( "public int getRule(int state) { return -1; }"));
            output.print(genLine( "public int getCost(int state) { return Integer.MAX_VALUE; }"));
            output.print(genLine( "public int getArity() { return 0; }"));
        }
        output.print(genEndBlock());

        output.print(genLine( "final JBurgAnnotation errorAnnotation = new ErrorAnnotation();"));
        output.println();

        //  Emit the general-purpose JBurgAnnotationGeneral class.
        output.print(genLine("/**  JBurgAnnotation implementation used for general-purpose computation. */"));
		output.print(genLine("class JBurgAnnotationGeneral extends JBurgAnnotation"));
		output.print(genBeginBlock());
		output.print(genLine("/** cost/rule matrices used during dynamic programming to compute"));
		output.print(genLine(" *  the most economical rules that can reduce  the input node."));
        output.print(genLine(" */"));
		output.print(genLine("private int cost[];"));
		output.print(genLine("private int rule[];"));

		output.print(genLine("/**  Transformation rules may have antecedents: other states whose"));
		output.print(genLine(" *  output the transformation rule is intended to transform."));
		output.print(genLine(" *  All such antecedent states must be executed in sequence when the rule is reduced."));
        output.print(genLine(" */"));
		output.print(genLine("private int[] antecedentState = null;"));

		output.print(genLine("/** *  This node's children (may be empty).  */"));
		output.print(genLine("private " + genNaryContainerType("JBurgAnnotation") + " m_children = null;"));
		
		output.print(genLine("JBurgAnnotationGeneral ( "));
		output.print(iNodeClass);
		output.print(" newNode, int nRules) ");
		output.print(genBeginBlock());
		output.print(genLine("super(newNode);"));
        output.print(genLine("rule   = new int[nRules];"));
        output.print(genLine("cost   = new int[nRules];"));
		output.print(genLine("//  Initial cost of all rules is \"infinite\""));
        output.print(genLine("java.util.Arrays.fill ( cost, Integer.MAX_VALUE);"));
		output.print(genLine("//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array."));
		output.print(genEndBlock());

		output.print(genLine("/** @return this node's operator. */"));
		output.print(genLine("public " + this.operatorType + " getOperator() "));
        output.print(genBeginBlock());
        output.print(genLine("return " + inodeAdapter.genGetOperator("m_node", this) + "; "));
        output.print(genEndBlock());

		output.print(genLine("/** @return this node's wrapped"));
		output.print(iNodeClass);
		output.print(". */ ");
		output.print(genLine("public " + iNodeClass + " getNode()  "));
        output.print(genBeginBlock());
        output.print(genLine("return m_node; "));
        output.print(genEndBlock());

		output.print(genLine("/** @return the nth child of this node.  */"));
		output.print(genLine("public JBurgAnnotation getNthChild(int idx)"));
		output.print(genBeginBlock());
	    output.print(genLine("if ( m_children != null && m_children.size() > idx)"));
		output.print(genBeginBlock());
	    output.print(genLine("return (JBurgAnnotation) m_children.elementAt(idx);"));
		output.print(genEndBlock());
	    output.print(genLine("else"));
		output.print(genBeginBlock());
	    output.print(genLine("throw new IllegalArgumentException( String.format(\"Index %d out of range opcode %s:\", idx, this.getOperator() ));"));
		output.print(genEndBlock());
		output.print(genEndBlock());

		output.print(genLine("/** @return this node's child count.  */"));
		output.print(genLine("public int getArity()"));
        output.print(genBeginBlock());
		output.print(genLine("return m_children != null? m_children.size():0;" ));
	    output.print(genEndBlock());

		output.print(genLine("/** Add a new child to this node.  */"));
		output.print(genLine("public void addChild(JBurgAnnotation new_child)"));
	    output.print(genBeginBlock());
	    output.print(genLine("if (m_children == null)"));
	    output.print(genLine("m_children = new " + genNaryContainerType("JBurgAnnotation") +"();"));
		output.print(genLine("if (new_child != null)"));
		output.print(genLine("m_children.add(new_child);"));
	    output.print(genEndBlock());

		output.print(genLine("/** Release this node's data.  */"));
		output.print(genLine("public void release()"));
	    output.print(genBeginBlock());
	    output.print(genLine("m_children = null;"));
	    output.print(genLine("cost = null;"));
	    output.print(genLine("rule = null;"));
	    output.print(genEndBlock());

		output.print(genLine("/** @return the wrapped node's toString().  */"));
		output.print(genLine("public String toString() "));
        output.print(genBeginBlock());
        output.print(genLine("return m_node.toString(); "));
        output.print(genEndBlock());
		output.print(genLine("/** @return the current best cost to reach a goal state.  */"));
		output.print(genLine("public int getCost( int goalState ) "));
        output.print(genBeginBlock());
        output.print(genLine("return cost[goalState]; "));
        output.print(genEndBlock());
		output.print(genLine(" /** Set the cost/rule configuration of a goal state."));
		output.print(genLine(" * @throws IllegalArgumentException if this node has a fixed cost/rule.*/"));
		output.print(genLine(" public void reset ( int goalState, int cost, int rule )"));
        output.print(genBeginBlock());
		output.print(genLine("this.cost[goalState] = cost;"));
		output.print(genLine("this.rule[goalState] = rule;"));
		output.print(genLine("//  We have a brand new rule, therefore it has no antecedents."));
		output.print(genLine("if ( this.antecedentState != null )this.antecedentState[goalState] = 0;"));
		output.print(genEndBlock());
		output.print(genLine("/** * @return the rule to fire for a specific goal state. */"));
		output.print(genLine("public int getRule ( int goalState ) "));
        output.print(genBeginBlock());
        output.print(genLine("return rule[goalState]; "));
        output.print(genEndBlock());
		output.print(genLine("/**"));
		output.print(genLine(" *  A closure's transformation rule succeeded."));
		output.print(genLine(" *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;"));
		output.print(genLine(" *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never "));
		output.print(genLine(" *  transition back to a goal state that has already been reduced).*/"));
		output.print(genLine("public void recordAntecedent ( int iGoalState, int newAntecedentState )"));
        output.print(genBeginBlock());
		output.print(genLine("int antecedentRule = rule[newAntecedentState];"));
		output.print(genLine("//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled."));
		output.print(genLine("if ( antecedentRule == 0 )"));
		output.print(genLine("throw new IllegalStateException ( \"Attempting to record an unlabelled antecedent state.\" );"));
		output.print(genLine("if ( antecedentRule == 1 )"));
        output.print(genBeginBlock());
		output.print(genLine( "//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run."));
		output.print(genLine("if ( antecedentState != null )"));
		output.print(genLine("antecedentState[iGoalState] = antecedentState[newAntecedentState];"));
		output.print(genEndBlock());
		output.print(genLine("else"));
		output.print(genBeginBlock());
		output.print(genLine("if ( antecedentState == null )"));
		output.print(genLine("antecedentState = new int[rule.length];"));
		output.print(genLine("antecedentState[iGoalState] = newAntecedentState;"));
		output.print(genEndBlock());
        output.print(genEndBlock());
		
		
		//  End of JBurgAnnotationGeneral
		output.print(genEndClass());

		//  class JBurgSubgoal
		output.print(genBeginLine());
		output.print(genLine("static class JBurgSubgoal"));
		output.print(genBeginBlock());
		output.print(genInstanceField(Modifier.PRIVATE, "int", "goalState", null));
		output.print(genInstanceField(Modifier.PRIVATE, "boolean", "isNary", null));
		output.print(genInstanceField(Modifier.PRIVATE, "int", "startIndex", null));
		output.print(genInstanceField(Modifier.PRIVATE, "int[]", "accessPath", null));
		
		final String[][] subgoal_ctor_formals = {
	        {"int", "goal_state"},
	        { "boolean", "is_nary"},
	        {"int", "start_index"},
	        {"int...", "access_path"}
		 };
		output.print(declareMethod(Modifier.PUBLIC, null, "JBurgSubgoal", subgoal_ctor_formals, throwsNothing));
		output.print(genBeginBlock());
		output.print(genLine("this.goalState = goal_state;"));
		output.print(genLine("this.isNary = is_nary;"));
		output.print(genLine("this.startIndex = start_index;"));
		output.print(genLine("this.accessPath = access_path;"));
		output.print(genEndBlock());
		
		output.print(genLine("public int getGoalState() { return this.goalState; }"));
		output.print(genLine("public boolean isNary() { return this.isNary; }"));
		
		output.print(genLine("public JBurgAnnotation getNode(JBurgAnnotation root)"));
        output.print(genBeginBlock());
        output.print(genLine("JBurgAnnotation result = root;"));
        output.print(genLine("for ( int idx: this.accessPath )"));
        output.print(genSingleLineBlock("result = result.getNthChild(idx);"));
        output.print(genLine("return result;"));
        output.print(genEndBlock());
		
		output.print(genEndClass());
	}

    @Override
	public void emitTrailer(
			String strClassName, 
			String iNodeClass, 
			Set<String> goalStateNames, 
			Map<String, String> burm_properties, 
			boolean debugMode, 
            String default_error_handler,
            Map<Integer,String> prologue_blocks,
			PrintStream output
		)
	{
		//  "i" is frequently used as a parameter to method calls in the reducer.
		final String[] iAsParameter =  { "i" };

		genBeginLine();
		genBeginLine();

		//  Common parameter list for reduction routines
		final String[][] reduction_plist = {
				{ "JBurgAnnotation", "p" },
				{ "int", "goalState" }
		};
		

		//  Emit reduce()
		output.print( declareMethod( Modifier.PUBLIC, "void", "reduce", reduction_plist, throwsException ));
		output.print( genBeginBlock() );
        {
            output.print(genLine("reduceAntecedent(p,goalState);"));
            output.print(genLine(genComment("Release the annotation's data.")));
            output.print(genLine("p.release();"));
        }
		output.print( genEndBlock() );

		//  Emit reduceAntecedent()
		output.print( declareMethod( Modifier.PUBLIC, "void", "reduceAntecedent", reduction_plist, throwsException ));
		output.print( genBeginBlock() );
		output.print( genLocalVar( "int", "iRule", "-1"));

		output.print( genLine(genIf ( genCmpLess( "goalState", "0" ))));
		output.print( genBeginBlock() );
		output.print(
			genAssignment(
				"iRule",
				genCallMethod( "p", "getRule", new String[] { "goalState" } )
				)
		);
		output.print( genEndBlock() );
		output.print( genElse() );
		output.print( genBeginBlock() );
		output.print( genLine(genComment ( "Find the minimum-cost path." )));
		output.print( genLocalVar ( "int", "minCost", genMaxIntValue() ) );
		output.print( genLocalVar ( "int", "i", null ) );

		output.print( genCountingLoop( "i", "0", "nStates", true ) );
		output.print( genBeginBlock() ); 
		output.print( 
			genLine(
				genIf(
					genCmpLess(
						"minCost",
						genCallMethod("p", "getCost", iAsParameter )
					)
				)
			)
		);
		output.print( genBeginBlock() );
		output.print( genAssignment( "iRule", genCallMethod( "p", "getRule", iAsParameter ) ));
		output.print( genAssignment( "minCost", genCallMethod( "p", "getCost", iAsParameter ) ));
		output.print( genAssignment( "goalState", "i" ) );
		output.print( genEndBlock() );
		output.print( genEndBlock() );
		output.print( genEndBlock() );

		//  Emit test for matched rule, and then emit a call to dispatch the reduction.
		output.print( genLine(genIf( genCmpLess( "iRule", "0" ))));
		output.print( genBeginBlock() );

        //  Any prologue code to emit?
        if ( prologue_blocks.size() > 0 )
        {
            output.print(genLine("dispatchPrologue ( (" + iNodeClass + ")p.getNode(), iRule );" ));
        }
		
		output.print(genLine("reduceSubgoals(p, iRule);" ) );
		
		//  Dispatch the action routine.
		output.print(genLine("dispatchAction(p, iRule );" ));

		//  Emit the else clause -- no rule found with finite cost, throw an exception.
		output.print( genEndBlock() );
		output.print(genLine("else"));
		output.print( genBeginBlock() );

		/*
		 * TODO: Save this as a breadcrumb
		if ( debugMode )
		{
			output.print(genStatement("debugOutput.print(\"<noRule"));
			output.print(genDebugAttr("operator", "String.valueOf(p.getOperator())"));
			output.print(genDebugAttr("goal", "stateName[goalState]"));
			output.print( "/>\\n\");");
		}
		*/

        if ( default_error_handler != null )
        {
            output.print(genLine(default_error_handler));
        }
        else
        {
            output.print(genLine("throw"));
            output.print(
                " new IllegalStateException ( \"Unable to find a rule to process \\\"\" + p.toString() + \"\\\", operator=\"" +
                "+ String.valueOf(p.getOperator()) + \", goal=\" + String.valueOf(goalState) );"
            );
        }
		output.print( genEndBlock() );

		output.print( genEndBlock() );

		//  Emit reduceSubgoals() code.

		output.print(
			declareMethod ( 
				Modifier.PRIVATE, 
				"void", 
				"reduceSubgoals", 
				new String[][] {
		                { "JBurgAnnotation", "p" },
		                { "int", "rule_num" }
		        }, 
				throwsException
			)
		);

		output.print(genBeginBlock());
		output.print(genLine("if ( " + subgoalArray() + "[rule_num] != null )"));
		
		output.print(genBeginBlock());

		output.print(genLine("for ( JBurgSubgoal sg : " + subgoalArray() + "[rule_num] )"));
		output.print(genBeginBlock());
		
		output.print(genLine("if ( !sg.isNary() )"));
		output.print( genBeginBlock() );
		output.print(genLine("reduce ( sg.getNode(p), sg.getGoalState());"));
		output.print( genEndBlock() );
		
	    //  For n-ary nodes, emit code that collects all the n-ary elements
        //  into a single aggregate data structure.
		output.print(genLine("else"));
        output.print( genBeginBlock() );
        output.print( genLine( genComment( "Aggregate the operands of an n-ary operator into a single container." ) ) );
        output.print( genLine("JBurgAnnotation sub_parent = sg.getNode(p);"));
        output.print( genLine( genNaryContainerType("Object") + " variadic_result = new " + genNaryContainerType("Object") + "(sub_parent.getArity() - sg.startIndex);"));
        output.print( genLine("for ( int j = sg.startIndex; j < sub_parent.getArity(); j++ )") );
        output.print( genBeginBlock() );
        output.print( genLine("reduce(sub_parent.getNthChild(j), sg.getGoalState());"));
        output.print( genLine("variadic_result.add(" + reducerStack() + ".pop());"));
        output.print( genEndBlock() );
        output.print( genLine( reducerStack() + ".push(variadic_result);"));
        output.print( genEndBlock() );

        output.print(genEndBlock());  //  end for
        output.print(genEndBlock());  //  end if
		output.print(genEndBlock()); // end reduceSubgoals

        /*
         *  dispatchPrologue
         */
        final String[][] prologue_plist = {
				{ iNodeClass, "p" },
				{ "int", "iRule" }
		};

        if ( prologue_blocks.size() > 0 )
        {
            output.print(
                declareMethod ( 
                    Modifier.PRIVATE, 
                    "void", 
                    "dispatchPrologue", 
                    prologue_plist, 
                    throwsException
                )
            );

            output.print(genBeginBlock());
            
            output.print(genLine(genSwitch("iRule")));
            output.print(genBeginBlock());

            for ( Integer rule: prologue_blocks.keySet() )
            {
                output.print(genLine(genCase( rule.toString() )));

                output.print(prologue_blocks.get(rule));

                output.print(genEndCase());
            }

            output.print(genEndSwitch());

            output.print(genEndBlock()); // end dispatchPrologue
        }

		/*
		 *  getNaryCost
		 */
        final String[][] getNaryCostFormals = {{"JBurgAnnotation", "node"}, {"int", "goalState" }, {"int", "start_index"}};
		output.print(declareMethod(Modifier.PRIVATE, "int", "getNaryCost", getNaryCostFormals, throwsNothing));
		output.print(genBeginBlock());
		output.print(genLine("int accumCost = 0;"));
		output.print(genLine("for ( int i = start_index; i < node.getArity() && accumCost != Integer.MAX_VALUE; i++ )"));
		output.print(genBeginBlock());
		output.print(genLine("int subCost = node.getNthChild(i).getCost(goalState);"));
		output.print(genLine("if ( subCost != Integer.MAX_VALUE )"));
		output.print(genSingleLineBlock("accumCost += subCost;"));
		output.print(genLine("else"));
		output.print(genSingleLineBlock("accumCost = Integer.MAX_VALUE;"));
		output.print(genEndBlock());
		output.print(genLine("return accumCost;"));
		output.print(genEndBlock());
		
		// burm(root)
		final String[][] simpleBurmFormals = {{iNodeClass,"root"}};
		output.print(declareMethod(Modifier.PUBLIC, "void", "burm", simpleBurmFormals, throwsException));
        output.print(genBeginBlock());
        output.print(genLine(genComment("Use the least-cost goal state available.")));
        output.print(genLine(genCallMethod(null, "burm", new String[] { "root", "0" } ) + ";"));
        output.print(genEndBlock());

        // burm(root, goal_state)
        final String[][] burmWithStateFormals = {{iNodeClass, "root"}, {"int","goal_state"}};
		output.print(declareMethod(Modifier.PUBLIC, "void", "burm", burmWithStateFormals, throwsException));
        output.print(genBeginBlock());
		output.print(genLine("JBurgAnnotation annotatedTree = label(root);"));

		if (debugMode)
		{
			output.print(genLine("try"));
            output.print(genBeginBlock());
		}

		output.print(genLine("reduce ( annotatedTree, goal_state);"));

		String problem_tree =  this.internalPrefix + "problemTree";
		
		if (debugMode)
        {
		    output.print(genEndBlock());
		    output.print(genLine("catch ( Exception cant_reduce )"));
            output.print(genBeginBlock());
		    output.print(genLine("this." + problem_tree + " = annotatedTree;"));
		    output.print(genLine("throw cant_reduce;"));
		    output.print(genEndBlock());
		}

        output.print(genEndBlock());

		if (debugMode) {
            output.print(this.genInstanceField(Modifier.PRIVATE, "JBurgAnnotation", problem_tree, null));
        }
		
		// Emit dump routines.
		if (debugMode) 
		{
            // dump()
		    String debug_output = "debug_output";
		    String[][] dump_plist = { {"java.io.PrintWriter", debug_output} };

		    output.print(this.declareMethod(Modifier.PUBLIC, "void", "dump", dump_plist, null));
		    output.print(this.genBeginBlock());
		    
		    output.print(genLine(this.genIf(this.genCmpEquality(this.genNullPointer(), problem_tree, true))));
		    output.print(this.genBeginBlock());
		    output.print(genLine(this.genCallMethod(debug_output, "print", new String[] { "\"<bailed reason=\\\"no problem tree\\\"/>\"" })));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genLine("return")));
		    output.print(this.genEndStmt());
		    output.print(this.genEndBlock());
		    
		    output.print(genLine(this.genCallMethod(debug_output, "print", new String[] { "\"<jburg>\"" } )));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genCallMethod(null, "dumpSubgoals", new String[] { debug_output } )));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genCallMethod(debug_output, "print", new String[] { "\"<label>\"" } )));
		    output.print(this.genEndStmt());
		    output.print(this.genLine(genCallMethod(null, "describeNode", new String[] {problem_tree, debug_output})));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genCallMethod(debug_output, "print", new String[] { "\"</label></jburg>\"" } )));
		    output.print(this.genEndStmt());

		    output.print(this.genEndBlock());

            // dump(<inode>)
            String node = "node";
		    output.print(this.declareMethod(Modifier.PUBLIC, "void", "dump", new String[][] { { iNodeClass, node}, {"java.io.PrintWriter", debug_output} }, null));
		    output.print(this.genBeginBlock());
            output.print(genLine("JBurgAnnotation anno = "));
		    output.print(this.genCallMethod(null, "label", new String[] { node } ));
		    output.print(this.genEndStmt());
            output.print(genLine(debug_output + ".println(\"<?xml version=\\\"1.0\\\"?>\");"));
            output.print(genLine(debug_output + ".println(\"<BurmDump date=\\\"\" + new java.util.Date() + \"\\\">\");"));
		    output.print(genLine(this.genCallMethod(debug_output, "println", new String[] { "\"<jburg>\"" } )));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genCallMethod(null, "dumpSubgoals", new String[] { debug_output } )));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genCallMethod(debug_output, "println", new String[] { "\"<label>\"" } )));
		    output.print(this.genEndStmt());
		    output.print(this.genLine(genCallMethod(null, "describeNode", new String[] {"anno", debug_output})));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genCallMethod(debug_output, "println", new String[] { "\"</label>\\n</jburg>\\n</BurmDump>\"" } )));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genCallMethod(debug_output, "flush", new String[] { })));
		    output.print(this.genEndStmt());
		    output.print(genLine(this.genEndBlock()));
		    
			//  describeNode(<annotation>, debug_out)
		    output.print(this.declareMethod(Modifier.PUBLIC, "void", "describeNode", new String[][] { { "JBurgAnnotation", node}, {"java.io.PrintWriter", debug_output} }, null));
		    output.print(this.genBeginBlock());
			output.print(genLine("if ( node == null ) return;"));
			output.print(genLine("String self_description;"));
            output.print(genLine("try"));
		    output.print(this.genBeginBlock());
            output.print(genLine("self_description = java.net.URLEncoder.encode(node.getNode().toString(),\"UTF-8\");"));
		    output.print(genLine(this.genEndBlock()));
            output.print(genLine("catch ( Exception cant_encode )"));
		    output.print(this.genBeginBlock());
            output.print(genLine("self_description = node.getNode().toString();"));
		    output.print(genLine(this.genEndBlock()));
            output.print(genLine(
                debug_output +
                ".print(\"<node operator=\\\"\" + " +
                inodeAdapter.genGetOperator("node.getNode()", this) +
                " + " +
                "\"\\\" selfDescription=\\\"\" + self_description + \"\\\">\");"
            ));
			output.print(genLine("for (int i = 0; i <= nStates ; i++ )"));
		    output.print(this.genBeginBlock());
            output.print(genLine("if ( node.getCost(i) < Integer.MAX_VALUE )"));
		    output.print(this.genBeginBlock());
			output.print(genLine(debug_output + ".print ( \"<goal\");"));
			output.print(genLine(debug_output + ".print ( \" name=\\\"\" + stateName[i] + \"\\\"\");"));
			output.print(genLine(debug_output + ".print ( \" rule=\\\"\" + node.getRule(i) + \"\\\"\");"));
			output.print(genLine(debug_output + ".print ( \" cost=\\\"\" + node.getCost(i) + \"\\\"\");"));
			output.print(genLine(debug_output+ ".println ( \"/>\" );"));
		    output.print(genLine(this.genEndBlock()));
		    output.print(genLine(this.genEndBlock()));
			output.print(genLine("for (int i = 0; i < node.getArity(); i++ )"));
			output.print(genLine("describeNode ( node.getNthChild(i)," + debug_output + ");"));
			output.print(genLine(debug_output + ".println ( \"</node>\" );"));
		    output.print(genLine(this.genEndBlock()));

            // dumpSubgoals()
		    output.print(this.declareMethod(Modifier.PRIVATE, "void", "dumpSubgoals", new String[][] { {"java.io.PrintWriter", debug_output} }, null));
		    output.print(genLine(this.genBeginBlock()));
            output.print(genLine("for ( int rule_num = 0; rule_num < ___subgoals_by_rule.length; rule_num++ )"));
            output.print(genLine("if ( ___subgoals_by_rule[rule_num] != null )"));
		    output.print(genLine(this.genBeginBlock()));
            output.print(genLine("debug_output.printf(\"<subgoals rule=\\\"%d\\\">\\n\", rule_num);"));

			output.print(genLine("for ( JBurgSubgoal sg : ___subgoals_by_rule[rule_num] )"));
		    output.print(genLine(this.genBeginBlock()));
            output.print(genLine("debug_output.printf(\"<subgoal goal=\\\"%s\\\" nary=\\\"%s\\\" startIndex=\\\"%s\\\"\", stateName[sg.getGoalState()], sg.isNary(), sg.startIndex);"));

            output.print(genLine("if ( sg.accessPath.length > 0 )"));
		    output.print(genLine(this.genBeginBlock()));
            output.print(genLine("debug_output.println(\">\");"));

            output.print(genLine("for ( int idx: sg.accessPath )"));
            output.print(genLine("debug_output.printf(\"<accessPath index=\\\"%d\\\"/>\\n\", idx);"));
		    output.print(genLine(this.genEndBlock()));
            output.print(genLine("else"));
		    output.print(genLine(this.genBeginBlock()));
            output.print(genLine("debug_output.println(\"/>\");"));
		    output.print(genLine(this.genEndBlock()));
            output.print(genLine("debug_output.printf(\"</subgoal>\\n\");"));
		    output.print(genLine(this.genEndBlock()));
            output.print(genLine("debug_output.printf(\"</subgoals>\\n\");"));
		    output.print(genLine(this.genEndBlock()));
		    output.print(genLine(this.genEndBlock()));

			//  Print a table of human-readable state names.
			output.print(
				"\n\n\tstatic final String[] stateName = new String[] { \"\" ");

			for ( String s: goalStateNames )
            {
				output.print(", \"" + s + "\"");
			}

			output.println("};");
		}

		//  Emit BURM properties and their get/set methods.
		for (String sName: burm_properties.keySet() )
		{
			String sType = burm_properties.get(sName).toString();

			//  Convert the property's name to canonical form, for inclusion
			//  in the get/set method names.
			StringBuffer canonicalName = new StringBuffer(sName.toLowerCase());
			canonicalName.setCharAt( 0, Character.toUpperCase( canonicalName.charAt( 0 )));

			output.print( genLine(genComment( "BURM property, from the specification")));
			output.print( genBeginLine() );
			output.print( genInstanceField( Modifier.PRIVATE, sType, sName, null ));

			String setDecl = declareMethod(
				Modifier.PUBLIC,
				"void",
				"set" + canonicalName,
				new String[][] {
					new String[] { sType, "setting" }
				},
				null
			);

			output.print( setDecl );
			output.print( genBeginBlock() );
			output.print( genAssignment( genAccessMember( "this", sName), "setting"));
			output.print( genEndBlock() );

			String getDecl = declareMethod( 
				Modifier.PUBLIC, 
				sType, 
				"get" + canonicalName, 
				new String[][]{}, 
				null 
			);

			output.print( getDecl );
			output.print( genBeginBlock() );
			output.print( genReturnValue( genAccessMember("this", sName ) ) );
			output.print( genEndStmt() );
			output.print( genEndBlock() );
		}

		//  Emit the getResult() method to get the final value off the stack.
		String getResultDecl = declareMethod(
				Modifier.PUBLIC,
				"Object",
				"getResult",
				new String[][] {
				},
				throwsNothing
			);

		output.print( getResultDecl );
		output.print( genBeginBlock() );
		output.print( genLine("return "));
		output.print( genCallMethod( reducerStack(), "pop", null ) );
		output.print( genEndStmt() );
		output.print( genEndBlock() );

        //  Emit normalizeCost()
        output.print(genLine(genComment("@return the input cost, limited to Integer.MAX_VALUE to avoid overflow.")));
        output.print(declareMethod( Modifier.PUBLIC, "int", "normalizeCost", new String[][] { {"long", "c"} }, throwsNothing));
        output.print(genBeginBlock());
        output.print(genLine(genReturnValue("c < Integer.MAX_VALUE? (int) c: Integer.MAX_VALUE")));
		output.print(genEndStmt() );
        output.print(genEndBlock()); // normalizeCost
        output.println();

		//  Emit the JBurgAnnotation inner class.
		emitAnnotation(iNodeClass, output);

		//  Close the class definition.
		output.print( genEndClass() );
	}

	public String genActionRoutineParameter(String stackName, String paramType, String paramName)
	{
		return genLine( String.format("%s %s = %s;", paramType, paramName, genPopFromStack(stackName, paramType)));
	}

    public String genPopFromStack(String stackName, String valueType)
    {
        return String.format("(%s)%s.pop()", valueType, stackName);
    }

	public String genPushToStack(String stackName, String value )
	{
		return String.format("%s.push(%s)", stackName, value);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCheckPtr(java.lang.String, boolean)
	 */
	public String genCheckPtr(String paramName, boolean checkForNull)
	{
		if(checkForNull)
			return new String(paramName + " == null");
		return new String(paramName + " != null");
	}

	public String genAccessMember(String parentName, String memberName)
	{
		return new String(parentName + "." + memberName);
	}

	public String genCallMethod(String parentName, String methodName, String[] params)
	{
		StringBuffer result = new StringBuffer();

		if ( parentName != null )
		{
			result.append( parentName );
			result.append( "." );
		}

		result.append( methodName );
		result.append( "(" );

		if ( params != null )
		{
			for ( int x = 0; x < params.length; ++x )
			{
				if ( x != 0)
				{
					result.append( ", " );
				}

				result.append( params[x] );
			}
		}

		result.append( ")" );

		return result.toString();
	}
	
	public EmitJava() {
		super();
	}

	public void setInodeAdapter(jburg.burg.inode.InodeAdapter adapter)
	{
		this.inodeAdapter = adapter;
	}
	
	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#emitInclass(java.lang.String, java.util.Vector, java.io.PrintStream)
	 */
	public void emitInclass(String strClassName, Vector inclassBlocks, PrintStream output) 
	{
		for(Object icb: inclassBlocks )
        {
			output.print("\n"+icb.toString()+"\n");
		}
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genCmpEquality(java.lang.String, java.lang.String, boolean)
	 */
	public String genCmpEquality(String lhs, String rhs, boolean bEquality)
	{
		return new String(lhs + ( bEquality==true ? " == " : " != " ) + rhs);
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#genLogicalAnd(java.lang.String, java.lang.String)
	 */
	public String genLogicalAnd(String lhs, String rhs)
	{
	   if ( lhs != null && rhs != null)
	       return new String(lhs + " && " + rhs);
	   else if ( null == lhs )
	       return rhs;
	   else
	       return lhs;
	}

	/* (non-Javadoc)
	 * @see jburg.burg.emitlangs.EmitLang#accept(java.lang.String)
	 */
	public boolean accept(String langName)
	{
        return "java".equalsIgnoreCase(langName);
	}

	public String genIf( String condition )
	{
		return "if ( " + condition + " )";
	}


	public String genBeginBlock()
	{
		//  Note: change to " " to get something like 1TBS.
		String leadingSpace = genBeginLine();

		blockCount++;
		if ( this.noisyBlockCounts )
		    trace ("<+ " + blockCount);
		return leadingSpace + "{";
	}

	public String genEndBlock()
	{
		blockCount--;
		
		if ( this.noisyBlockCounts )
		    trace("-> " + blockCount);

		if ( blockCount < 0 )
		{
			throw new IllegalStateException("Invalid block count " + String.valueOf(blockCount) );
		}
		

		return genBeginLine() + "}";
	}
	
	void trace(String msg)
	{
	    System.out.println(msg);
	    StackTraceElement[] stack = new Exception().getStackTrace();
	    for ( int i = 2; i < 5 && i < stack.length; i++)
	       System.out.println(stack[i]);
	}

	public String genBeginLine()
	{
		StringBuffer result = new StringBuffer("\n");

		for ( int i = 0; i < blockCount; i++ )
		{
			result.append("\t");
		}

		return result.toString();
	}

	public String genLine(String line)
	{
		return genBeginLine() + line;
	}
	
	private String genSingleLineBlock(String stmt)
	{
	    this.blockCount++;
	    try
	    {
	        return genLine(stmt);
	    }
	    finally
	    {
	        this.blockCount--;
	    }
	}

	public String genCmpLess( String lhs, String rhs )
	{
		return "( " + lhs + " > " + rhs + " ) ";
	}

	public String genCmpGtEq(String lhs, String rhs)
	{
	    return "(" + lhs + " >= " + rhs + ")";
	}
	public String genNot( String operand )
	{
		return "!(" + operand + ")";
	}

	public String genGetGoalState ( Object p )
	{
	   if ( p instanceof JBurgGenerator.JBurgRule )
           return "__" + ((JBurgGenerator.JBurgRule)p).getGoalState() + "_NT";
	   else
	       return "__" + p.toString() + "_NT";
	}

	public String genComment( String text )
	{
		return "/* " + text + " */";
	}

	public String genEndStmt()
	{
		return ";";
	}

	public String genAddition( String a1, String a2 )
	{
		if ( a1 == null || a1.equals("0") )
			return a2;
		if ( a2 == null || a2.equals("0") )
			return a1;
		else
			return " (" + a1 + " + " + a2 + ") ";
	}

	public String genAssignment( String lvar, String rvalue )
	{
		return String.format("%s = %s;", lvar, rvalue);
	}

	public String genCast( String newClass, String target )
	{
		return String.format("((%s)%s)", newClass, target);
	}

	public String genSwitch( String selectionCriterion )
	{
		return "switch( " + selectionCriterion + " )";
	}

	public String genEndSwitch()
	{
		return genEndBlock();
	}

	public String genCase( String criterionValue )
	{
		return genBeginLine() + "case " + criterionValue + ":" + genBeginBlock();
	}

	public String genEndCase()
	{
		return genLine("break;") + genEndBlock();
	}

	public String genElse()
	{
		return genBeginLine() + "else";
	}

	public String genLocalVar ( String type, String name, String initializer )
	{
		if ( initializer == null )
		{
			return String.format("%s %s;", type, name);
		}
		else
		{
			return String.format( "%s %s = %s;", type, name, initializer);
		}
	}

	
	/**
	 *  Declare a method.
	 *  @param modifiers - java.lang.reflect.Modifier flags for public/private visibility.
	 *  @param returnClass - the method's return type.  null if the method is a constructor.
	 *  @param name - the method's name.
	 *  @param plist - an array of type/name parameter declarations.
	 *  @param exceptions - exceptions the method may throw.  
	 *  @return a snippet with the method's declaration.
	 */
	public String declareMethod( int modifiers, String returnClass, String name, String[][] plist, Class[] exceptions )
	{       
		StringBuffer result = new StringBuffer();

		result.append( genBeginLine() );
		result.append( genBeginLine() );

		decodeModifiers(modifiers, result );

		if ( returnClass != null )
		{
            result.append( returnClass );
            result.append( " " );
		}
		
		result.append( name );
		result.append( "( " );

		for ( int i = 0; i < plist.length; i++ )
		{
			if ( plist[i].length != 2 )
			{
				throw new IllegalStateException( "Parameter list elements must be parameter pairs" );
			}

			if ( i > 0 )
			{
				result.append(", " );
			}

			result.append( plist[i][0] );
			result.append( " " );
			result.append( plist[i][1] );
		}

		result.append( ")" );

		if ( exceptions != null )
		{
			result.append( " throws " );

			for ( int j = 0; j < exceptions.length; j++ )
			{
				if ( j > 0 )
				{
					result.append( ", " );
				}

				result.append( exceptions[j].getName() );
			}
		}

		return result.toString();
	}

	public String genThrow( String diagnostic )
	{
		return "throw new IllegalStateException(" + diagnostic + ")";
	}

	public String genDefaultCase()
	{
		return "default:";
	}

	public String genReturnValue( String value )
	{
		return "return(" + value + ")";
	}

	public String genEndClass()
	{
		return genLine(genEndBlock());
	}

	public String genCountingLoop( String controlVar, String startValue, String endValue, boolean inclusive )
	{
		StringBuffer result = new StringBuffer();

		result.append( "for( " );
		result.append( genAssignment( controlVar, startValue ) );

		result.append( controlVar );
		result.append( (inclusive)? " <= ": " < " );
		result.append( endValue );
		result.append( ";" );

		result.append( controlVar );
		result.append( "++" );

		result.append( " )" );
				
		return result.toString();
	}

	public String genInstanceField ( int modifiers, String type, String name, String initializer )
	{
		StringBuffer result = new StringBuffer();

		decodeModifiers( modifiers, result );
		result.append( type );
		result.append( " " );
		result.append( name );

		if ( initializer != null )
		{
			result.append( " = " );
			result.append( initializer );
		}

		result.append( genEndStmt() );

		return genLine(result.toString());
	}

	private void decodeModifiers( int modifiers, StringBuffer result )
	{
		if ( Modifier.isPublic( modifiers ) )
		{
			result.append( "public " );
		}
		else if ( Modifier.isProtected( modifiers ) )
		{
			result.append( "protected " );
		}
		else if ( Modifier.isPrivate( modifiers ) )
		{
			result.append( "private " );
		}

		if ( Modifier.isStatic( modifiers ) )
		{
			result.append( "static " );
		}

		if ( Modifier.isFinal( modifiers ) )
		{
			result.append( "final " );
		}
	}

	public String genMaxIntValue()
	{
		return "Integer.MAX_VALUE";
	}

    @Override
	public String genNewObject( String type, String[] parameters )
	{
		StringBuffer result = new StringBuffer("new ");

		result.append(type);

		result.append("(");

		if (parameters != null )
		{
			for ( int i = 0; i < parameters.length; i++ )
			{
				if ( i > 0 )
				{
					result.append(",");
				}
				result.append(parameters[i]);
			}
		}

		result.append(")");

		return result.toString();
	}

    @Override
	public String genNullPointer()
	{
		return "null";
	}

    @Override
	public String genWhileLoop( String test_condition )
	{
		return "while ( " + test_condition + ")";
	}

    @Override
	public String genNaryContainerType(String base_type)
	{
		return "java.util.Vector<" + base_type + ">";
	}
	
    @Override
	public void setINodeType(String inode_type)
	{
	    //  No effect in the Java emitter.
	}

    @Override
    public String genOverflowSafeAdd(Object expr1, Object expr2)
    {
        return String.format("normalizeCost((long)%s + (long)%s)", expr1, expr2);
    }
}
