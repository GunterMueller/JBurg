package jburg;

import java.io.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.TreeMap;

import jburg.parser.JBurgParser;
import static jburg.parser.JBurgTokenTypes.*;

import jburg.burg.MacroProcessingStream;

import antlr.collections.AST;

/**
 *  ExtractReducerInterface analyzes a JBurg specification
 *  and generates an interface declaration for its reducer.
 */
public class ExtractReducerInterface
{
    public ExtractReducerInterface()
    {
    }

    /**
     *  Node type by operator, e.g., INodeType Add = AddNodeAndYouShouldntWriteASTsThisWay
     */
    private Map<String,String> nodeTypeByOperator = new HashMap<String,String>();

    /**
     *  Default node type, e.g., INodeType AST;
     */
    private String defaultNodeType = null;

    /**
     *  Production types, e.g., ReturnType expr = Integer;
     */
    private Map<String,String> productionTypeByNonterminal = new TreeMap<String,String>();
    /**
     *  Default production type, e.g., ReturnType Object;
     */
    private String defaultProductionType = null;

    private Set<AST> prologues  = new HashSet<AST>();
    private Set<AST> reductions = new HashSet<AST>();

    /**
     *  External entry point
     *  @param args - arg[0] is specification, arg[1] is destination.
     */
    public static void main(String[] args)
    {
        if ( args.length < 2)
        {
            usage(1);
        }

        File specification = new File(args[0]);

        if ( !specification.exists() )
        {
            usage(2);
        }

        File interface_dst   = new File(args[1]);

        new ExtractReducerInterface().extract(specification, interface_dst);

    }

    private static void usage(int exitCode)
    {
        System.err.println("Usage: jburg.ExtractReducerInterface <specification> <interface-destination>");

        if ( exitCode != 0 )
        {
            System.exit(exitCode);
        }
    }

    private void extract(File specification, File interface_dst)
    {
        try
        {
            MacroProcessingStream token_stream = new MacroProcessingStream((specification));
            JBurgParser parser = new JBurgParser(token_stream);
            parser.specification();

            AST t = (AST)parser.getAST();

            if ( !parser.parseSuccessful() || null == t  )
            {
                System.out.println("ExtractReducerInterface terminating due to parse errors.");
                System.exit(4);
            }

            extract(t, interface_dst);
        }
        catch ( Exception ex )
        {
            ex.printStackTrace();
            System.exit(3);
        }
    }

    private void extract(AST root, File interface_dst)
    throws Exception
    {
        PrintWriter out = new PrintWriter(new FileWriter(interface_dst));

        for (AST currentNode = root;
            currentNode != null;
            currentNode = currentNode.getNextSibling()) 
		{
            switch (currentNode.getType()) 
			{
                case INODE_TYPE_DECLARATION:
                {
                    if (this.defaultNodeType == null)
                        this.defaultNodeType = getFirstASTByType(currentNode, IDENTIFIER).getText();
                    else
                        throw new IllegalArgumentException("INodeType may only be specified once.");

                    break;
				}

                case RETURN_DECLARATION:
                {
                    if (this.defaultProductionType == null)
                        this.defaultProductionType = getFirstASTByType(currentNode, IDENTIFIER).getText();
                    else
                        throw new IllegalArgumentException("ReturnType may only be specified once.");
                    break;
                }

                case TYPED_RETURN_DECLARATION:
                {
                    AST ntNode = getFirstASTByType(currentNode, IDENTIFIER);
                    productionTypeByNonterminal.put(ntNode.getText(), getNextASTByType(currentNode, ntNode).getText());
                    break;
                }

                case PATTERN_RULE:
                case TRANSFORMATION_RULE:
                {
                    if ( hasChild(currentNode, EXPLICIT_REDUCTION) )
                        reductions.add(getFirstASTByType(currentNode, EXPLICIT_REDUCTION));
                    if ( hasChild(currentNode, PROLOGUE) )
                        prologues.add(getFirstASTByType(currentNode, PROLOGUE));
                    break;
                }
            }
        }

        out.printf("default node type %s\n", this.defaultNodeType);
        out.printf("default return type %s\n", this.defaultProductionType);
        out.printf("return types: %s\n", productionTypeByNonterminal);

        if ( this.prologues.size() > 0 )
        {
            out.printf("\nPrologues:");

            for ( AST p: this.prologues )
                out.println(p.toStringTree());
        }

        if ( this.reductions.size() > 0 )
        {
            out.printf("\nReductions:");

            for ( AST r: this.reductions )
                out.println(r.toStringTree());
        }

        out.flush();
        out.close();
    }

    private boolean hasChild(AST parent, int node_type)
    {
        for ( AST current = parent.getFirstChild(); current != null; current = current.getNextSibling() )
        {
            if ( current.getType() == node_type )
                return true;
        }

        return false;
    }

    private AST getFirstASTByType(AST parent, int node_type)
    {
        for ( AST current = parent.getFirstChild(); current != null; current = current.getNextSibling() )
        {
            if ( current.getType() == node_type )
                return current;
        }

        throw new IllegalStateException ( "AST " + parent.toString() + " has no child of node type " + node_type + "." );
    }

    private AST getNextASTByType(AST parent, AST cursor)
    {
        int node_type = -1;

        for ( AST current = parent.getFirstChild(); current != null; current = current.getNextSibling() )
        {
            if ( current == cursor )
                node_type = current.getType();
            else if ( current.getType() == node_type )
                return current;
        }

        throw new IllegalStateException ( "AST " + parent.toString() + " has no child of node type " + node_type + "." );
    }
}
