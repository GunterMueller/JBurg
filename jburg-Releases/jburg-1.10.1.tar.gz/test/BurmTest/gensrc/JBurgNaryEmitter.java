
/*  Generated Thu May 17 12:35:09 EDT 2012 by JBurg version 1.10.1 */

    import java.util.Vector;
    @SuppressWarnings("unchecked")
public class JBurgNaryEmitter implements burmTest.ArithmeticOpcodes
	
{
	java.util.Stack __reducedValues = new java.util.Stack();
	
	public static final int __expression_NT = 1;
	public static final int nStates = 1;

	private static final JBurgSubgoal[][] ___subgoals_by_rule = 
	{
		null,
		{
			new JBurgSubgoal(__expression_NT,false,0,0),
			new JBurgSubgoal(__expression_NT,false,0,1),
		},
		null,
		{
			new JBurgSubgoal(__expression_NT,true,0),
		},
		{
			new JBurgSubgoal(__expression_NT,true,0),
		},
	};


	
	public JBurgAnnotation label( burmTest.TestINode to_be_labelled)
	{
		JBurgAnnotation result = null;

		int i;

		int arity;

		result = this.getJBurgAnnotation(to_be_labelled);
		arity = to_be_labelled.getArity();
		i = 0;
		while ( ( arity > i ) )
		{
			result.addChild(this.label(((burmTest.TestINode)to_be_labelled.getNthChild(i))));
			i =  (i + 1) ;
		}
		return(result);
	}

	/* expression = ADD(expression, expression) */
	
	private Integer action_1( burmTest.TestINode __p) throws java.lang.Exception
	{
		Integer r = (Integer)__reducedValues.pop();
		Integer lhs = (Integer)__reducedValues.pop();
		{
		    return lhs.intValue() + r.intValue();
		}
	}

	/* expression = INT(void) */
	
	private Integer action_2( burmTest.TestINode __p) throws java.lang.Exception
	{
		{
		    return Integer.parseInt(__p.getUserObject().toString());
		}
	}

	/* expression = ADD(expression+) */
	
	private Integer action_3( burmTest.TestINode __p) throws java.lang.Exception
	{
		java.util.Vector<Integer> operands = (java.util.Vector<Integer>)__reducedValues.pop();
		{
		    int result = 0;
		
		    for ( Integer i: operands)
		        result += i.intValue();
		
		    return result;
		}
	}

	/* expression = PAREN(expression*) */
	
	private Integer action_4( burmTest.TestINode __p) throws java.lang.Exception
	{
		java.util.Vector<Integer> operands = (java.util.Vector<Integer>)__reducedValues.pop();
		{
		    int result = 0;
		
		    for ( Integer i: operands)
		        result += i.intValue();
		
		    return result;
		}
	}
	
	private void dispatchAction( JBurgAnnotation ___node, int iRule) throws java.lang.Exception
	{
		burmTest.TestINode __p = ___node.getNode();

		switch( iRule )
		{
			case 1:
			{
				__reducedValues.push(this.action_1(__p));
				break;
			}
			case 2:
			{
				__reducedValues.push(this.action_2(__p));
				break;
			}
			case 3:
			{
				__reducedValues.push(this.action_3(__p));
				break;
			}
			case 4:
			{
				__reducedValues.push(this.action_4(__p));
				break;
			}
			default:
			{
				throw new IllegalStateException("Unmatched reduce action " + iRule);
			}
		}
	}

	class JBurgAnnotation_ADD_1_n extends JBurgSpecializedAnnotation
	{
		private JBurgAnnotation subtree0;
		private java.util.Vector<JBurgAnnotation> narySubtrees = new java.util.Vector<JBurgAnnotation>();
		JBurgAnnotation_ADD_1_n(burmTest.TestINode node)
		{
			super(node);
		}
		private int cachedCostFor_expression = -1;
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __expression_NT:
				{
					if ( cachedCostFor_expression == -1 )
					{
						cachedCostFor_expression = getCostForRule_122e7820(goalState);

						int currentCost = normalizeCost((long)1 + (long)((long)getNaryCost(this, __expression_NT, 0)));

						if ( ( cachedCostFor_expression > currentCost )  )
							cachedCostFor_expression = currentCost;
					}
					return(cachedCostFor_expression);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __expression_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = getCostForRule_122e7820(goalState);

					if ( ( bestCost > currentCost )  )
					{
						bestCost = currentCost;
						rule = 1;
					}
					currentCost = normalizeCost((long)1 + (long)((long)getNaryCost(this, __expression_NT, 0)));
					if ( ( bestCost > currentCost )  )
					{
						rule = 3;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(1 + narySubtrees.size());
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				case 0:
					return subtree0;
				default:
				{
					return narySubtrees.get(index - 1);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
			if ( subtree0 == null )
				subtree0 = child;
			else
				narySubtrees.add(child);
		}
		
		private int getCostForRule_122e7820( int goalState)
		{

			if ( this.getArity() == 2 )
				return(normalizeCost((long)1 + (long) (((long)this.getNthChild(1).getCost(__expression_NT)) + ((long)this.getNthChild(0).getCost(__expression_NT))) ));
			else
				return(Integer.MAX_VALUE);
		}
	}

	class JBurgAnnotation_INT_0 extends JBurgSpecializedAnnotation
	{
		JBurgAnnotation_INT_0(burmTest.TestINode node)
		{
			super(node);
		}
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __expression_NT:
				{
					return(1);
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __expression_NT:
				{
					return(2);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(0);
		}
	}

	class JBurgAnnotation_PAREN_0_n extends JBurgSpecializedAnnotation
	{
		private java.util.Vector<JBurgAnnotation> narySubtrees = new java.util.Vector<JBurgAnnotation>();
		JBurgAnnotation_PAREN_0_n(burmTest.TestINode node)
		{
			super(node);
		}
		
		public int getCost( int goalState)
		{
			switch( goalState )
			{
				case __expression_NT:
				{
					return(normalizeCost((long)0 + (long)((long)getNaryCost(this, __expression_NT, 0))));
				}
			}
			return(Integer.MAX_VALUE);
		}
		
		public int getRule( int goalState)
		{
			switch( goalState )
			{
				case __expression_NT:
				{
					int rule = -1;

					int bestCost = Integer.MAX_VALUE;

					int currentCost = normalizeCost((long)0 + (long)((long)getNaryCost(this, __expression_NT, 0)));

					if ( ( bestCost > currentCost )  )
					{
						rule = 4;
					}
					return(rule);
				}
			}
			return(-1);
		}
		
		public int getArity( )
		{
			return(narySubtrees.size());
		}
		
		public JBurgAnnotation getNthChild( int index)
		{
			switch( index )
			{
				default:
				{
					return narySubtrees.get(index);
				}
			}
		}
		
		public void addChild( JBurgAnnotation child)
		{
				narySubtrees.add(child);
		}
	}
	
	public JBurgAnnotation getJBurgAnnotation( burmTest.TestINode node)
	{
		switch( node.getOperator() )
		{
			case ADD:
			{
				if ( node.getArity() >= 1 )
					return(new JBurgAnnotation_ADD_1_n(node));
				break;
			}
			case INT:
			{
				if ( node.getArity() == 0 )
					return(new JBurgAnnotation_INT_0(node));
				break;
			}
			case PAREN:
			{
				if ( node.getArity() >= 0 )
					return(new JBurgAnnotation_PAREN_0_n(node));
				break;
			}
		}
		return new JBurgAnnotationGeneral(node, nStates+1);
	}
	
	public void reduce( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{
		reduceAntecedent(p,goalState);
		/* Release the annotation's data. */
		p.release();
	}
	
	public void reduceAntecedent( JBurgAnnotation p, int goalState) throws java.lang.Exception
	{int iRule = -1;
		if ( ( goalState > 0 )  )
		{iRule = p.getRule(goalState);
		}
		else
		{
			/* Find the minimum-cost path. */int minCost = Integer.MAX_VALUE;int i;for( i = 0;i <= nStates;i++ )
			{
				if ( ( minCost > p.getCost(i) )  )
				{iRule = p.getRule(i);minCost = p.getCost(i);goalState = i;
				}
			}
		}
		if ( ( iRule > 0 )  )
		{
			reduceSubgoals(p, iRule);
			dispatchAction(p, iRule );
		}
		else
		{
			throw new IllegalStateException ( "Unable to find a rule to process \"" + p.toString() + "\", operator="+ String.valueOf(p.getOperator()) + ", goal=" + String.valueOf(goalState) );
		}
	}
	
	private void reduceSubgoals( JBurgAnnotation p, int rule_num) throws java.lang.Exception
	{
		if ( ___subgoals_by_rule[rule_num] != null )
		{
			for ( JBurgSubgoal sg : ___subgoals_by_rule[rule_num] )
			{
				if ( !sg.isNary() )
				{
					reduce ( sg.getNode(p), sg.getGoalState());
				}
				else
				{
					/* Aggregate the operands of an n-ary operator into a single container. */
					JBurgAnnotation sub_parent = sg.getNode(p);
					java.util.Vector<Object> variadic_result = new java.util.Vector<Object>(sub_parent.getArity() - sg.startIndex);
					for ( int j = sg.startIndex; j < sub_parent.getArity(); j++ )
					{
						reduce(sub_parent.getNthChild(j), sg.getGoalState());
						variadic_result.add(__reducedValues.pop());
					}
					__reducedValues.push(variadic_result);
				}
			}
		}
	}
	
	private int getNaryCost( JBurgAnnotation node, int goalState, int start_index)
	{
		int accumCost = 0;
		for ( int i = start_index; i < node.getArity() && accumCost != Integer.MAX_VALUE; i++ )
		{
			int subCost = node.getNthChild(i).getCost(goalState);
			if ( subCost != Integer.MAX_VALUE )
				accumCost += subCost;
			else
				accumCost = Integer.MAX_VALUE;
		}
		return accumCost;
	}
	
	public void burm( burmTest.TestINode root) throws java.lang.Exception
	{
		/* Use the least-cost goal state available. */
		burm(root, 0);
	}
	
	public void burm( burmTest.TestINode root, int goal_state) throws java.lang.Exception
	{
		JBurgAnnotation annotatedTree = label(root);
		reduce ( annotatedTree, goal_state);
	}
	
	public Object getResult( )
	{
		return __reducedValues.pop();
	}
	/* @return the input cost, limited to Integer.MAX_VALUE to avoid overflow. */
	
	public int normalizeCost( long c)
	{
		return(c < Integer.MAX_VALUE? (int) c: Integer.MAX_VALUE);
	}

	/** JBurgAnnotation is a data structure internal to the
	 *  JBurg-generated BURM that annotates a JBurgNode with
	 *  information used for dynamic programming and reduction.
	 */
	abstract class JBurgAnnotation
	{
		/**  The INode we're annotating.  */
		burmTest.TestINode m_node; 
		JBurgAnnotation ( burmTest.TestINode newNode)
		{
			m_node = newNode;
		}
		/** @return this node's operator. */
		public int getOperator() 
		{
			return m_node.getOperator(); 
		}
		/** @return this node's wrappedburmTest.TestINode. */ 
		public burmTest.TestINode getNode()  
		{
			return m_node; 
		}
		/** @return the nth child of this node.  */
		public abstract JBurgAnnotation getNthChild(int idx);
		/** @return this node's child count.  */
		public abstract int getArity();
		/** Add a new child to this node.  */
		public abstract void addChild(JBurgAnnotation new_child);
		/** Release this node's data.  */
		public abstract void release();
		/** @return the wrapped node's toString().  */
		public String toString() 
		{
			return m_node.toString(); 
		}
		/** @return the current best cost to reach a goal state.  */
		public abstract int getCost( int goalState ) ;
		 /** Set the cost/rule configuration of a goal state.
		 * @throws IllegalArgumentException if this node has a fixed cost/rule.*/
		 public abstract void reset ( int goalState, int cost, int rule );
		/** * @return the rule to fire for a specific goal state. */
		public abstract int getRule ( int goalState ) ;
		/**
		 *  A closure's transformation rule succeeded.
		 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
		 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
		 *  transition back to a goal state that has already been reduced).*/
		public abstract void recordAntecedent ( int iGoalState, int newAntecedentState );
	
	}

	abstract class JBurgSpecializedAnnotation extends JBurgAnnotation
	{
		JBurgSpecializedAnnotation(burmTest.TestINode node)
		{
			super(node);
		}
		public JBurgAnnotation getNthChild(int idx)
		{
			throw new IllegalStateException(this.getClass().getName() + " has no children.");
		}
		public void addChild(JBurgAnnotation new_child)
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot have children.");
		}
		public void reset ( int goalState, int cost, int rule )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot be reset.");
		}
		public void release ()
		{
		}
		public void recordAntecedent ( int iGoalState, int newAntecedentState )
		{
			throw new IllegalStateException(this.getClass().getName() + " cannot record antecedents.");
		}
	}

	class ErrorAnnotation extends JBurgSpecializedAnnotation
	{
		ErrorAnnotation()
		{
			super(null);
		}
		public int getRule(int state) { return -1; }
		public int getCost(int state) { return Integer.MAX_VALUE; }
		public int getArity() { return 0; }
	}
	final JBurgAnnotation errorAnnotation = new ErrorAnnotation();

	/**  JBurgAnnotation implementation used for general-purpose computation. */
	class JBurgAnnotationGeneral extends JBurgAnnotation
	{
		/** cost/rule matrices used during dynamic programming to compute
		 *  the most economical rules that can reduce  the input node.
		 */
		private int cost[];
		private int rule[];
		/**  Transformation rules may have antecedents: other states whose
		 *  output the transformation rule is intended to transform.
		 *  All such antecedent states must be executed in sequence when the rule is reduced.
		 */
		private int[] antecedentState = null;
		/** *  This node's children (may be empty).  */
		private java.util.Vector<JBurgAnnotation> m_children = null;
		JBurgAnnotationGeneral ( burmTest.TestINode newNode, int nRules) 
		{
			super(newNode);
			rule   = new int[nRules];
			cost   = new int[nRules];
			//  Initial cost of all rules is "infinite"
			java.util.Arrays.fill ( cost, Integer.MAX_VALUE);
			//  Initial rule for every goal is zero -- the JVM has zero-filled the rules array.
		}
		/** @return this node's operator. */
		public int getOperator() 
		{
			return m_node.getOperator(); 
		}
		/** @return this node's wrappedburmTest.TestINode. */ 
		public burmTest.TestINode getNode()  
		{
			return m_node; 
		}
		/** @return the nth child of this node.  */
		public JBurgAnnotation getNthChild(int idx)
		{
			if ( m_children != null && m_children.size() > idx)
			{
				return (JBurgAnnotation) m_children.elementAt(idx);
			}
			else
			{
				throw new IllegalArgumentException( String.format("Index %d out of range opcode %s:", idx, this.getOperator() ));
			}
		}
		/** @return this node's child count.  */
		public int getArity()
		{
			return m_children != null? m_children.size():0;
		}
		/** Add a new child to this node.  */
		public void addChild(JBurgAnnotation new_child)
		{
			if (m_children == null)
			m_children = new java.util.Vector<JBurgAnnotation>();
			if (new_child != null)
			m_children.add(new_child);
		}
		/** Release this node's data.  */
		public void release()
		{
			m_children = null;
			cost = null;
			rule = null;
		}
		/** @return the wrapped node's toString().  */
		public String toString() 
		{
			return m_node.toString(); 
		}
		/** @return the current best cost to reach a goal state.  */
		public int getCost( int goalState ) 
		{
			return cost[goalState]; 
		}
		 /** Set the cost/rule configuration of a goal state.
		 * @throws IllegalArgumentException if this node has a fixed cost/rule.*/
		 public void reset ( int goalState, int cost, int rule )
		{
			this.cost[goalState] = cost;
			this.rule[goalState] = rule;
			//  We have a brand new rule, therefore it has no antecedents.
			if ( this.antecedentState != null )this.antecedentState[goalState] = 0;
		}
		/** * @return the rule to fire for a specific goal state. */
		public int getRule ( int goalState ) 
		{
			return rule[goalState]; 
		}
		/**
		 *  A closure's transformation rule succeeded.
		 *  If this path is selected for reduction, then all the actions  must be run in sequence, beginning with the original;
		 *  so the order of the rules matters.  We disallow transformation rules with  cycles (a node should never 
		 *  transition back to a goal state that has already been reduced).*/
		public void recordAntecedent ( int iGoalState, int newAntecedentState )
		{
			int antecedentRule = rule[newAntecedentState];
			//  Sanity-check: we shouldn't be asked to record an antecedent state that hasn't been labelled.
			if ( antecedentRule == 0 )
			throw new IllegalStateException ( "Attempting to record an unlabelled antecedent state." );
			if ( antecedentRule == 1 )
			{
				//  Rule 1 is the simple transformation rule; it doesn't run,  but if it has antecedents, then they must run.
				if ( antecedentState != null )
				antecedentState[iGoalState] = antecedentState[newAntecedentState];
			}
			else
			{
				if ( antecedentState == null )
				antecedentState = new int[rule.length];
				antecedentState[iGoalState] = newAntecedentState;
			}
		}
	
	}
	
	static class JBurgSubgoal
	{
		private int goalState;
		private boolean isNary;
		private int startIndex;
		private int[] accessPath;
		
		public JBurgSubgoal( int goal_state, boolean is_nary, int start_index, int... access_path)
		{
			this.goalState = goal_state;
			this.isNary = is_nary;
			this.startIndex = start_index;
			this.accessPath = access_path;
		}
		public int getGoalState() { return this.goalState; }
		public boolean isNary() { return this.isNary; }
		public JBurgAnnotation getNode(JBurgAnnotation root)
		{
			JBurgAnnotation result = root;
			for ( int idx: this.accessPath )
				result = result.getNthChild(idx);
			return result;
		}
	
	}

}