package jburg.compiler.tl2;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.Reader;

import jburg.compiler.tl2.parser.TL2Parser;
import jburg.compiler.tl2.semanticanalysis.ClassAnalyzer;
import jburg.compiler.tl2.ir.Symbol;

import java.util.Iterator;


/**
 *  TL2Compiler is a static class that manages plumbing for
 *  the parsing and code emitting phases of the TL/2 compiler.
 */
public class TL2Compiler
{
   public static void main ( String[] args )
   {
    int argPos = 0;

    try
    {
        for ( int i = argPos; i < args.length; i++ )
        {
            String javaFileName = args[i];
            String className    = javaFileName.substring(0, javaFileName.lastIndexOf(".java") ) + ".class";

            FileReader input = new FileReader(javaFileName);
            FileOutputStream rawOutput = new FileOutputStream( className );
            DataOutputStream output    = new DataOutputStream ( rawOutput );

            compile(input, output);
            output.flush();
            rawOutput.flush();
        }
    }
    catch ( Exception ex )
    {
        ex.printStackTrace();
        System.exit(1);
    }
   }

   /**
    *  Compile an input file to a class.
    *  @param input - the Reader that supplies the Java code to be compiled.
    *  @param output - the DataOutputStream that returns the compiled class.
    */
   public static void compile ( Reader input, DataOutputStream output )
   throws Exception
   {
    /*
     *  The ClassAnalyzer is the compiler's root data structure;
     *  it collects information about the class' methods, fields,
     *  class level data (name, superclass, interfaces, access level);
     *  it initializes the AbstractClass subsystem for this thread of
     *  compilation; and it works with a JBurg-generated TL2Emitter
     *  and a BCEL ClassGen to generate bytecode.
     */
    ClassAnalyzer analyzer = new ClassAnalyzer();

    /*
     * Parse Phase: the parser is a JavaCC parser.
     */
    TL2Parser parser = new TL2Parser( input );
    parser.compilationUnit(analyzer);

    /*
     *  Semantic Analysis Phase: largely consists of
     *  deconstructing reference chains and assigning
     *  types to all references.
     *  Full-scale type checking happens as the TL2Emitter
     *  builds typed instruction sequences from the bottom up.
     */
    analyzer.analyze ();

    /*
     *  Code Generation Phase: the TL2Emitter drives the BCEL
     *  ClassGen, which dumps bytecode into the specified stream.
     */
    analyzer.generateJavaClass( output );
   }
}
