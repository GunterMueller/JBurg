package jburg.compiler;


import jburg.compiler.tl2.TL2Compiler;

import java.io.Reader;
import java.io.StringReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;

/**
 *  The InMemoryCompiler is a ClassLoader that creates Java classes
 *  in memory, using the TL/2 compiler to compile Java source into
 *  bytecode.
 */
public class InMemoryCompiler
extends java.lang.ClassLoader
{
   /**
    *  Compile Java source into a Class.
    *  @param program - the Java source.
    *  @return the generated class.
    *  @throws exceptions raised by the compiler.
    */
   public Class compile ( String program )
   throws Exception
   {
    byte[] rawClass = compile ( new StringReader(program) );
    return defineClass ( rawClass, 0, rawClass.length );
   }

   /**
    *  Compile Java source into a Class.
    *  @param className - the name of the class.
    *  @param input - a Reader that supplies the Java source.
    *  @return the generated class.
    *  @throws exceptions raised by the compiler.
    */
   public Class compile ( String className, Reader input )
   throws Exception
   {
    byte[] rawClass = compile ( input );
    return defineClass ( className, rawClass, 0, rawClass.length );
   }

   /**
    *  Internal method that calls the TL/2 compiler.
    *  @param a Reader that supplies Java source.
    *  @return a byte array of bytecode.
    */
   private byte[] compile ( Reader input )
   throws Exception
   {
    ByteArrayOutputStream output = new ByteArrayOutputStream();

    TL2Compiler.compile ( input, new DataOutputStream(output) );

    return output.toByteArray();
   }
}
