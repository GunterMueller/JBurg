// $ANTLR 2.7.7 (2006-11-01): "jburg.g" -> "JBurgParser.java"$

package jburg.parser;


import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import java.util.Hashtable;
import antlr.ASTFactory;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.io.*;

import antlr.CommonAST;
import antlr.collections.AST;

public class JBurgParser extends antlr.LLkParser       implements JBurgTokenTypes
 {

    /*
     *  Error-handling code.
     */
    boolean parseOk = true;

	public void reportError(antlr.RecognitionException e)
	{
        super.reportError(e);
        parseOk = false;
	}

    public boolean parseSuccessful()
    {
        return this.parseOk;
    }

protected JBurgParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public JBurgParser(TokenBuffer tokenBuf) {
  this(tokenBuf,20);
}

protected JBurgParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

public JBurgParser(TokenStream lexer) {
  this(lexer,20);
}

public JBurgParser(ParserSharedInputState state) {
  super(state,20);
  tokenNames = _tokenNames;
  buildTokenTypeASTClassMap();
  astFactory = new ASTFactory(getTokenTypeToASTClassMap());
}

	public final void cost_function() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cost_function_AST = null;
		Token  funcId = null;
		AST funcId_AST = null;
		Token  functionBody = null;
		AST functionBody_AST = null;
		
		try {      // for error handling
			funcId = LT(1);
			funcId_AST = astFactory.create(funcId);
			match(IDENTIFIER);
			AST tmp1_AST = null;
			tmp1_AST = astFactory.create(LT(1));
			match(LPAREN);
			AST tmp2_AST = null;
			tmp2_AST = astFactory.create(LT(1));
			match(RPAREN);
			functionBody = LT(1);
			functionBody_AST = astFactory.create(functionBody);
			match(BLOCK);
			cost_function_AST = (AST)currentAST.root;
			
			cost_function_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(COST_FUNCTION)).add(funcId_AST).add(functionBody_AST));
			
			currentAST.root = cost_function_AST;
			currentAST.child = cost_function_AST!=null &&cost_function_AST.getFirstChild()!=null ?
				cost_function_AST.getFirstChild() : cost_function_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
		returnAST = cost_function_AST;
	}
	
	public final void cost_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cost_specification_AST = null;
		
		try {      // for error handling
			match(COLON);
			{
			switch ( LA(1)) {
			case INT:
			{
				simple_cost_spec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			{
				function_call();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			cost_specification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_1);
		}
		returnAST = cost_specification_AST;
	}
	
	public final void simple_cost_spec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST simple_cost_spec_AST = null;
		Token  iCost = null;
		AST iCost_AST = null;
		
		try {      // for error handling
			iCost = LT(1);
			iCost_AST = astFactory.create(iCost);
			match(INT);
			simple_cost_spec_AST = (AST)currentAST.root;
			
			simple_cost_spec_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(SIMPLE_COST_SPEC)).add(iCost_AST));
			
			currentAST.root = simple_cost_spec_AST;
			currentAST.child = simple_cost_spec_AST!=null &&simple_cost_spec_AST.getFirstChild()!=null ?
				simple_cost_spec_AST.getFirstChild() : simple_cost_spec_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_1);
		}
		returnAST = simple_cost_spec_AST;
	}
	
	public final void function_call() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST function_call_AST = null;
		Token  funcId = null;
		AST funcId_AST = null;
		
		try {      // for error handling
			funcId = LT(1);
			funcId_AST = astFactory.create(funcId);
			match(IDENTIFIER);
			AST tmp4_AST = null;
			tmp4_AST = astFactory.create(LT(1));
			match(LPAREN);
			AST tmp5_AST = null;
			tmp5_AST = astFactory.create(LT(1));
			match(RPAREN);
			function_call_AST = (AST)currentAST.root;
			
			function_call_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(FUNCTION_CALL)).add(funcId_AST));
			
			currentAST.root = function_call_AST;
			currentAST.child = function_call_AST!=null &&function_call_AST.getFirstChild()!=null ?
				function_call_AST.getFirstChild() : function_call_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_1);
		}
		returnAST = function_call_AST;
	}
	
	public final void declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST declaration_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_implements:
			{
				implements_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_Language:
			{
				language_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_header:
			{
				header_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_INodeType:
			{
				inode_type_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_INodeAdapter:
			{
				inode_adapter_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_package:
			{
				package_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_BURMProperty:
			{
				property_specification();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case BLOCK:
			{
				inclass_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_ReturnType:
			{
				return_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_DefaultErrorHandler:
			{
				error_handler_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = declaration_AST;
	}
	
	public final void implements_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST implements_declaration_AST = null;
		AST implements_interface_name_AST = null;
		
		try {      // for error handling
			match(LITERAL_implements);
			multipart_identifier();
			implements_interface_name_AST = (AST)returnAST;
			AST tmp7_AST = null;
			tmp7_AST = astFactory.create(LT(1));
			match(SEMI);
			implements_declaration_AST = (AST)currentAST.root;
			
			implements_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(IMPLEMENTS_INTERFACE_SPECIFICATION)).add(implements_interface_name_AST));
			
			currentAST.root = implements_declaration_AST;
			currentAST.child = implements_declaration_AST!=null &&implements_declaration_AST.getFirstChild()!=null ?
				implements_declaration_AST.getFirstChild() : implements_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = implements_declaration_AST;
	}
	
	public final void language_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST language_declaration_AST = null;
		Token  lang_name = null;
		AST lang_name_AST = null;
		
		try {      // for error handling
			match(LITERAL_Language);
			lang_name = LT(1);
			lang_name_AST = astFactory.create(lang_name);
			match(IDENTIFIER);
			AST tmp9_AST = null;
			tmp9_AST = astFactory.create(LT(1));
			match(SEMI);
			language_declaration_AST = (AST)currentAST.root;
			
				language_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(LANGUAGE_DECLARATION)).add(lang_name_AST));
			
			currentAST.root = language_declaration_AST;
			currentAST.child = language_declaration_AST!=null &&language_declaration_AST.getFirstChild()!=null ?
				language_declaration_AST.getFirstChild() : language_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = language_declaration_AST;
	}
	
	public final void header_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST header_declaration_AST = null;
		Token  header_block = null;
		AST header_block_AST = null;
		
		try {      // for error handling
			match(LITERAL_header);
			header_block = LT(1);
			header_block_AST = astFactory.create(header_block);
			match(BLOCK);
			header_declaration_AST = (AST)currentAST.root;
			
			header_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(HEADER_DECLARATION)).add(header_block_AST));
			
			currentAST.root = header_declaration_AST;
			currentAST.child = header_declaration_AST!=null &&header_declaration_AST.getFirstChild()!=null ?
				header_declaration_AST.getFirstChild() : header_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = header_declaration_AST;
	}
	
	public final void inode_type_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inode_type_declaration_AST = null;
		AST inode_type_AST = null;
		
		try {      // for error handling
			match(LITERAL_INodeType);
			multipart_identifier();
			inode_type_AST = (AST)returnAST;
			AST tmp12_AST = null;
			tmp12_AST = astFactory.create(LT(1));
			match(SEMI);
			inode_type_declaration_AST = (AST)currentAST.root;
			
			inode_type_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INODE_TYPE_DECLARATION)).add(inode_type_AST));
			
			currentAST.root = inode_type_declaration_AST;
			currentAST.child = inode_type_declaration_AST!=null &&inode_type_declaration_AST.getFirstChild()!=null ?
				inode_type_declaration_AST.getFirstChild() : inode_type_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = inode_type_declaration_AST;
	}
	
	public final void inode_adapter_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inode_adapter_declaration_AST = null;
		AST inode_adapter_class_AST = null;
		
		try {      // for error handling
			match(LITERAL_INodeAdapter);
			multipart_identifier();
			inode_adapter_class_AST = (AST)returnAST;
			AST tmp14_AST = null;
			tmp14_AST = astFactory.create(LT(1));
			match(SEMI);
			inode_adapter_declaration_AST = (AST)currentAST.root;
			
			inode_adapter_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INODE_ADAPTER_DECLARATION)).add(inode_adapter_class_AST));
			
			currentAST.root = inode_adapter_declaration_AST;
			currentAST.child = inode_adapter_declaration_AST!=null &&inode_adapter_declaration_AST.getFirstChild()!=null ?
				inode_adapter_declaration_AST.getFirstChild() : inode_adapter_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = inode_adapter_declaration_AST;
	}
	
	public final void package_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST package_declaration_AST = null;
		AST package_name_AST = null;
		
		try {      // for error handling
			match(LITERAL_package);
			multipart_identifier();
			package_name_AST = (AST)returnAST;
			AST tmp16_AST = null;
			tmp16_AST = astFactory.create(LT(1));
			match(SEMI);
			package_declaration_AST = (AST)currentAST.root;
			
			package_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PACKAGE_SPECIFICATION)).add(package_name_AST));
			
			currentAST.root = package_declaration_AST;
			currentAST.child = package_declaration_AST!=null &&package_declaration_AST.getFirstChild()!=null ?
				package_declaration_AST.getFirstChild() : package_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = package_declaration_AST;
	}
	
	public final void property_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST property_specification_AST = null;
		AST property_type_AST = null;
		Token  property_name = null;
		AST property_name_AST = null;
		
		try {      // for error handling
			match(LITERAL_BURMProperty);
			multipart_identifier();
			property_type_AST = (AST)returnAST;
			property_name = LT(1);
			property_name_AST = astFactory.create(property_name);
			match(IDENTIFIER);
			AST tmp18_AST = null;
			tmp18_AST = astFactory.create(LT(1));
			match(SEMI);
			property_specification_AST = (AST)currentAST.root;
			
			property_specification_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(PROPERTY_SPECIFICATION)).add(property_type_AST).add(property_name_AST));
			
			currentAST.root = property_specification_AST;
			currentAST.child = property_specification_AST!=null &&property_specification_AST.getFirstChild()!=null ?
				property_specification_AST.getFirstChild() : property_specification_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = property_specification_AST;
	}
	
	public final void inclass_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inclass_declaration_AST = null;
		Token  inclass_block = null;
		AST inclass_block_AST = null;
		
		try {      // for error handling
			inclass_block = LT(1);
			inclass_block_AST = astFactory.create(inclass_block);
			match(BLOCK);
			inclass_declaration_AST = (AST)currentAST.root;
			
				 inclass_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(INCLASS_DECLARATION)).add(inclass_block_AST));
				
			currentAST.root = inclass_declaration_AST;
			currentAST.child = inclass_declaration_AST!=null &&inclass_declaration_AST.getFirstChild()!=null ?
				inclass_declaration_AST.getFirstChild() : inclass_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = inclass_declaration_AST;
	}
	
	public final void return_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST return_declaration_AST = null;
		AST return_type_AST = null;
		Token  state_name = null;
		AST state_name_AST = null;
		AST state_return_type_AST = null;
		
		try {      // for error handling
			if ((LA(1)==LITERAL_ReturnType) && (LA(2)==IDENTIFIER) && (_tokenSet_3.member(LA(3)))) {
				match(LITERAL_ReturnType);
				multipart_identifier();
				return_type_AST = (AST)returnAST;
				AST tmp20_AST = null;
				tmp20_AST = astFactory.create(LT(1));
				match(SEMI);
				return_declaration_AST = (AST)currentAST.root;
				
				return_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(RETURN_DECLARATION)).add(return_type_AST));
				
				currentAST.root = return_declaration_AST;
				currentAST.child = return_declaration_AST!=null &&return_declaration_AST.getFirstChild()!=null ?
					return_declaration_AST.getFirstChild() : return_declaration_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==LITERAL_ReturnType) && (LA(2)==IDENTIFIER) && (LA(3)==EQUALS)) {
				match(LITERAL_ReturnType);
				state_name = LT(1);
				state_name_AST = astFactory.create(state_name);
				match(IDENTIFIER);
				AST tmp22_AST = null;
				tmp22_AST = astFactory.create(LT(1));
				match(EQUALS);
				multipart_identifier();
				state_return_type_AST = (AST)returnAST;
				AST tmp23_AST = null;
				tmp23_AST = astFactory.create(LT(1));
				match(SEMI);
				return_declaration_AST = (AST)currentAST.root;
				
				return_declaration_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(TYPED_RETURN_DECLARATION)).add(state_name_AST).add(state_return_type_AST));
				
				currentAST.root = return_declaration_AST;
				currentAST.child = return_declaration_AST!=null &&return_declaration_AST.getFirstChild()!=null ?
					return_declaration_AST.getFirstChild() : return_declaration_AST;
				currentAST.advanceChildToEnd();
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = return_declaration_AST;
	}
	
	public final void error_handler_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST error_handler_declaration_AST = null;
		Token  action = null;
		AST action_AST = null;
		
		try {      // for error handling
			match(LITERAL_DefaultErrorHandler);
			action = LT(1);
			action_AST = astFactory.create(action);
			match(BLOCK);
			error_handler_declaration_AST = (AST)currentAST.root;
			
			error_handler_declaration_AST  = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(DEFAULT_ERROR_HANDLER)).add(action_AST));
			
			currentAST.root = error_handler_declaration_AST;
			currentAST.child = error_handler_declaration_AST!=null &&error_handler_declaration_AST.getFirstChild()!=null ?
				error_handler_declaration_AST.getFirstChild() : error_handler_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_2);
		}
		returnAST = error_handler_declaration_AST;
	}
	
	public final void header_section() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST header_section_AST = null;
		
		try {      // for error handling
			{
			int _cnt8=0;
			_loop8:
			do {
				if ((_tokenSet_4.member(LA(1)))) {
					declaration();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt8>=1 ) { break _loop8; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt8++;
			} while (true);
			}
			header_section_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_5);
		}
		returnAST = header_section_AST;
	}
	
	public final void multipart_identifier() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST multipart_identifier_AST = null;
		Token  firstPart = null;
		AST firstPart_AST = null;
		
		try {      // for error handling
			firstPart = LT(1);
			firstPart_AST = astFactory.create(firstPart);
			astFactory.addASTChild(currentAST, firstPart_AST);
			match(IDENTIFIER);
			{
			_loop19:
			do {
				if ((LA(1)==COLON||LA(1)==PERIOD)) {
					{
					switch ( LA(1)) {
					case PERIOD:
					{
						AST tmp25_AST = null;
						tmp25_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp25_AST);
						match(PERIOD);
						break;
					}
					case COLON:
					{
						{
						AST tmp26_AST = null;
						tmp26_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp26_AST);
						match(COLON);
						AST tmp27_AST = null;
						tmp27_AST = astFactory.create(LT(1));
						astFactory.addASTChild(currentAST, tmp27_AST);
						match(COLON);
						}
						break;
					}
					default:
					{
						throw new NoViableAltException(LT(1), getFilename());
					}
					}
					}
					AST tmp28_AST = null;
					tmp28_AST = astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp28_AST);
					match(IDENTIFIER);
				}
				else {
					break _loop19;
				}
				
			} while (true);
			}
			{
			switch ( LA(1)) {
			case STAR:
			{
				AST tmp29_AST = null;
				tmp29_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp29_AST);
				match(STAR);
				break;
			}
			case IDENTIFIER:
			case SEMI:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			multipart_identifier_AST = (AST)currentAST.root;
			
				   //  Coalesce all the child nodes' text.
			StringBuffer allText = new StringBuffer();
			
			AST current = firstPart_AST;
			
			while (current != null) 
					{
			allText.append(current.getText());
			current = current.getNextSibling();
					}
			
				   //  Synthesize a node with an explict type.
			multipart_identifier_AST = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(MULTIPART_IDENTIFIER)));
				   multipart_identifier_AST.setText( allText.toString() );
			
			currentAST.root = multipart_identifier_AST;
			currentAST.child = multipart_identifier_AST!=null &&multipart_identifier_AST.getFirstChild()!=null ?
				multipart_identifier_AST.getFirstChild() : multipart_identifier_AST;
			currentAST.advanceChildToEnd();
			multipart_identifier_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_6);
		}
		returnAST = multipart_identifier_AST;
	}
	
	public final void multipart_identifier_java_only() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST multipart_identifier_java_only_AST = null;
		Token  firstPart = null;
		AST firstPart_AST = null;
		
		try {      // for error handling
			firstPart = LT(1);
			firstPart_AST = astFactory.create(firstPart);
			astFactory.addASTChild(currentAST, firstPart_AST);
			match(IDENTIFIER);
			{
			switch ( LA(1)) {
			case PERIOD:
			{
				AST tmp30_AST = null;
				tmp30_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp30_AST);
				match(PERIOD);
				AST tmp31_AST = null;
				tmp31_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp31_AST);
				match(IDENTIFIER);
				break;
			}
			case LPAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			multipart_identifier_java_only_AST = (AST)currentAST.root;
			
				   //  Coalesce all the child nodes' text.
			StringBuffer allText = new StringBuffer();
			
			AST current = firstPart_AST;
			
			while (current != null) 
					{
			allText.append(current.getText());
			current = current.getNextSibling();
					}
			
				   //  Synthesize a node with an explict type.
			multipart_identifier_java_only_AST = (AST)astFactory.make( (new ASTArray(1)).add(astFactory.create(IDENTIFIER)));
				   multipart_identifier_java_only_AST.setText( allText.toString() );
			
			currentAST.root = multipart_identifier_java_only_AST;
			currentAST.child = multipart_identifier_java_only_AST!=null &&multipart_identifier_java_only_AST.getFirstChild()!=null ?
				multipart_identifier_java_only_AST.getFirstChild() : multipart_identifier_java_only_AST;
			currentAST.advanceChildToEnd();
			multipart_identifier_java_only_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_7);
		}
		returnAST = multipart_identifier_java_only_AST;
	}
	
	public final void operand_list() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operand_list_AST = null;
		AST manyop_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER||LA(2)==LPAREN||LA(2)==PERIOD) && (LA(3)==IDENTIFIER||LA(3)==RPAREN||LA(3)==COMMA)) {
				operand();
				astFactory.addASTChild(currentAST, returnAST);
				{
				_loop25:
				do {
					if ((LA(1)==COMMA)) {
						match(COMMA);
						operand();
						astFactory.addASTChild(currentAST, returnAST);
					}
					else {
						break _loop25;
					}
					
				} while (true);
				}
				operand_list_AST = (AST)currentAST.root;
				
				operand_list_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OPERAND_LIST_KNOWN_ARITY)).add(operand_list_AST));
				
				currentAST.root = operand_list_AST;
				currentAST.child = operand_list_AST!=null &&operand_list_AST.getFirstChild()!=null ?
					operand_list_AST.getFirstChild() : operand_list_AST;
				currentAST.advanceChildToEnd();
				operand_list_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER) && (LA(3)==PLUS)) {
				parameter_decl();
				manyop_AST = (AST)returnAST;
				astFactory.addASTChild(currentAST, returnAST);
				match(PLUS);
				operand_list_AST = (AST)currentAST.root;
				
				operand_list_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(OPERAND_LIST_ARBITRARY_ARITY)).add(manyop_AST));
				
				currentAST.root = operand_list_AST;
				currentAST.child = operand_list_AST!=null &&operand_list_AST.getFirstChild()!=null ?
					operand_list_AST.getFirstChild() : operand_list_AST;
				currentAST.advanceChildToEnd();
				operand_list_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_8);
		}
		returnAST = operand_list_AST;
	}
	
	public final void operand() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operand_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN||LA(2)==PERIOD)) {
				operator_specification();
				astFactory.addASTChild(currentAST, returnAST);
				operand_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER)) {
				parameter_decl();
				astFactory.addASTChild(currentAST, returnAST);
				operand_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_9);
		}
		returnAST = operand_AST;
	}
	
	public final void parameter_decl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameter_decl_AST = null;
		Token  id1 = null;
		AST id1_AST = null;
		Token  id2 = null;
		AST id2_AST = null;
		
		try {      // for error handling
			id1 = LT(1);
			id1_AST = astFactory.create(id1);
			match(IDENTIFIER);
			id2 = LT(1);
			id2_AST = astFactory.create(id2);
			match(IDENTIFIER);
			parameter_decl_AST = (AST)currentAST.root;
			
				    parameter_decl_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(NON_TERMINAL_PARAMETER)).add(id1_AST).add(id2_AST));
				
			currentAST.root = parameter_decl_AST;
			currentAST.child = parameter_decl_AST!=null &&parameter_decl_AST.getFirstChild()!=null ?
				parameter_decl_AST.getFirstChild() : parameter_decl_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_10);
		}
		returnAST = parameter_decl_AST;
	}
	
	public final void operator_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operator_specification_AST = null;
		AST operatorId_AST = null;
		AST operands_AST = null;
		
		try {      // for error handling
			multipart_identifier_java_only();
			operatorId_AST = (AST)returnAST;
			AST tmp34_AST = null;
			tmp34_AST = astFactory.create(LT(1));
			match(LPAREN);
			operand_list();
			operands_AST = (AST)returnAST;
			AST tmp35_AST = null;
			tmp35_AST = astFactory.create(LT(1));
			match(RPAREN);
			operator_specification_AST = (AST)currentAST.root;
			
			operator_specification_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(OPERATOR_SPECIFICATION)).add(operatorId_AST).add(operands_AST));
			
			currentAST.root = operator_specification_AST;
			currentAST.child = operator_specification_AST!=null &&operator_specification_AST.getFirstChild()!=null ?
				operator_specification_AST.getFirstChild() : operator_specification_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_11);
		}
		returnAST = operator_specification_AST;
	}
	
	public final void pattern_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST pattern_specification_AST = null;
		AST op_AST = null;
		
		try {      // for error handling
			operator_specification();
			op_AST = (AST)returnAST;
			pattern_specification_AST = (AST)currentAST.root;
			
					pattern_specification_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PATTERN_SPECIFICATION)).add(op_AST));
				
			currentAST.root = pattern_specification_AST;
			currentAST.child = pattern_specification_AST!=null &&pattern_specification_AST.getFirstChild()!=null ?
				pattern_specification_AST.getFirstChild() : pattern_specification_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_12);
		}
		returnAST = pattern_specification_AST;
	}
	
/**
 *  Reduce a rule.
 *  Rule types are:<ul>
 *  <li>  Pattern rules, which combine subgoals with other nodes further up the tree.
 *  <li>  Simple transformation rules.  Like iBurg's chain rules, simple transformation
 *        rules allow one goal to satisfy additional goals.
 *  <li>  Complex transformation rules, which allow the reducer to actively transform
 *        a subgoal to satisfy additional subgoals.
 *  <li>  A leaf node, with no children, can be used as a subgoal in either type 
 *        of transformation rule.
 *  </ul>
 */
	public final void rule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rule_AST = null;
		Token  nonTerminalRuleId = null;
		AST nonTerminalRuleId_AST = null;
		AST pattern_AST = null;
		AST cost_AST = null;
		AST action_AST = null;
		Token  simpleTransformationTarget = null;
		AST simpleTransformationTarget_AST = null;
		Token  simpleTransformationSource = null;
		AST simpleTransformationSource_AST = null;
		Token  transformationTarget = null;
		AST transformationTarget_AST = null;
		Token  transformationSource = null;
		AST transformationSource_AST = null;
		AST transformationCost_AST = null;
		AST transformationAction_AST = null;
		Token  terminalRuleId = null;
		AST terminalRuleId_AST = null;
		AST terminalId_AST = null;
		AST terminalCost_AST = null;
		AST terminalAction_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==LPAREN||LA(4)==PERIOD) && (LA(5)==IDENTIFIER) && (LA(6)==IDENTIFIER||LA(6)==LPAREN||LA(6)==PERIOD) && (_tokenSet_13.member(LA(7)))) {
				nonTerminalRuleId = LT(1);
				nonTerminalRuleId_AST = astFactory.create(nonTerminalRuleId);
				match(IDENTIFIER);
				AST tmp36_AST = null;
				tmp36_AST = astFactory.create(LT(1));
				match(EQUALS);
				pattern_specification();
				pattern_AST = (AST)returnAST;
				cost_specification();
				cost_AST = (AST)returnAST;
				reduction_action();
				action_AST = (AST)returnAST;
				rule_AST = (AST)currentAST.root;
				
				rule_AST = (AST)astFactory.make( (new ASTArray(5)).add(astFactory.create(PATTERN_RULE)).add(nonTerminalRuleId_AST).add(pattern_AST).add(cost_AST).add(action_AST));
				
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==SEMI)) {
				simpleTransformationTarget = LT(1);
				simpleTransformationTarget_AST = astFactory.create(simpleTransformationTarget);
				match(IDENTIFIER);
				match(EQUALS);
				simpleTransformationSource = LT(1);
				simpleTransformationSource_AST = astFactory.create(simpleTransformationSource);
				match(IDENTIFIER);
				match(SEMI);
				rule_AST = (AST)currentAST.root;
				
				rule_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(SIMPLE_TRANSFORMATION_RULE)).add(simpleTransformationTarget_AST).add(simpleTransformationSource_AST));
				
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==COLON)) {
				transformationTarget = LT(1);
				transformationTarget_AST = astFactory.create(transformationTarget);
				match(IDENTIFIER);
				match(EQUALS);
				transformationSource = LT(1);
				transformationSource_AST = astFactory.create(transformationSource);
				match(IDENTIFIER);
				cost_specification();
				transformationCost_AST = (AST)returnAST;
				reduction_action();
				transformationAction_AST = (AST)returnAST;
				rule_AST = (AST)currentAST.root;
				
					rule_AST = (AST)astFactory.make( (new ASTArray(5)).add(astFactory.create(TRANSFORMATION_RULE)).add(transformationTarget_AST).add(transformationSource_AST).add(transformationCost_AST).add(transformationAction_AST));
				
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==LPAREN||LA(4)==PERIOD) && (LA(5)==IDENTIFIER||LA(5)==LITERAL_void) && (LA(6)==LPAREN||LA(6)==RPAREN) && (LA(7)==COLON||LA(7)==LITERAL_void)) {
				terminalRuleId = LT(1);
				terminalRuleId_AST = astFactory.create(terminalRuleId);
				match(IDENTIFIER);
				match(EQUALS);
				multipart_identifier_java_only();
				terminalId_AST = (AST)returnAST;
				match(LPAREN);
				voidSpecification();
				match(RPAREN);
				cost_specification();
				terminalCost_AST = (AST)returnAST;
				reduction_action();
				terminalAction_AST = (AST)returnAST;
				rule_AST = (AST)currentAST.root;
				
				rule_AST = (AST)astFactory.make( (new ASTArray(5)).add(astFactory.create(TERMINAL_RULE)).add(terminalRuleId_AST).add((AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(TERMINAL_RULE)).add(terminalId_AST))).add(terminalCost_AST).add(terminalAction_AST));
				
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
		returnAST = rule_AST;
	}
	
	public final void reduction_action() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST reduction_action_AST = null;
		Token  prologue = null;
		AST prologue_AST = null;
		Token  action = null;
		AST action_AST = null;
		
		try {      // for error handling
			{
			switch ( LA(1)) {
			case LITERAL_Prologue:
			{
				AST tmp43_AST = null;
				tmp43_AST = astFactory.create(LT(1));
				astFactory.addASTChild(currentAST, tmp43_AST);
				match(LITERAL_Prologue);
				prologue = LT(1);
				prologue_AST = astFactory.create(prologue);
				astFactory.addASTChild(currentAST, prologue_AST);
				match(BLOCK);
				break;
			}
			case BLOCK:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			action = LT(1);
			action_AST = astFactory.create(action);
			astFactory.addASTChild(currentAST, action_AST);
			match(BLOCK);
			reduction_action_AST = (AST)currentAST.root;
			
			reduction_action_AST = (AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(REDUCTION_ACTION)).add(action_AST));
			if ( prologue != null )
			reduction_action_AST.addChild((AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(PROLOGUE)).add(prologue_AST)));
			
			currentAST.root = reduction_action_AST;
			currentAST.child = reduction_action_AST!=null &&reduction_action_AST.getFirstChild()!=null ?
				reduction_action_AST.getFirstChild() : reduction_action_AST;
			currentAST.advanceChildToEnd();
			reduction_action_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
		returnAST = reduction_action_AST;
	}
	
	public final void voidSpecification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST voidSpecification_AST = null;
		
		try {      // for error handling
			AST tmp44_AST = null;
			tmp44_AST = astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp44_AST);
			match(LITERAL_void);
			voidSpecification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_8);
		}
		returnAST = voidSpecification_AST;
	}
	
	public final void specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST specification_AST = null;
		
		try {      // for error handling
			header_section();
			astFactory.addASTChild(currentAST, returnAST);
			{
			int _cnt40=0;
			_loop40:
			do {
				if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER)) {
					rule();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN)) {
					cost_function();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==LITERAL_Pattern)) {
					pattern_declaration();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==LITERAL_Pattern)) {
					reduction_declaration();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt40>=1 ) { break _loop40; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt40++;
			} while (true);
			}
			match(Token.EOF_TYPE);
			specification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_14);
		}
		returnAST = specification_AST;
	}
	
	public final void pattern_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST pattern_declaration_AST = null;
		Token  name = null;
		AST name_AST = null;
		AST terminalId_AST = null;
		AST p_AST = null;
		
		try {      // for error handling
			match(LITERAL_Pattern);
			name = LT(1);
			name_AST = astFactory.create(name);
			match(IDENTIFIER);
			{
			if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN||LA(2)==PERIOD) && (LA(3)==IDENTIFIER||LA(3)==LITERAL_void) && (LA(4)==LPAREN||LA(4)==RPAREN) && (LA(5)==SEMI||LA(5)==LITERAL_void)) {
				multipart_identifier_java_only();
				terminalId_AST = (AST)returnAST;
				AST tmp47_AST = null;
				tmp47_AST = astFactory.create(LT(1));
				match(LPAREN);
				voidSpecification();
				AST tmp48_AST = null;
				tmp48_AST = astFactory.create(LT(1));
				match(RPAREN);
				pattern_declaration_AST = (AST)currentAST.root;
				
				pattern_declaration_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(PATTERN_DECLARATION)).add(name_AST).add((AST)astFactory.make( (new ASTArray(2)).add(astFactory.create(TERMINAL_RULE)).add(terminalId_AST))));
				
				currentAST.root = pattern_declaration_AST;
				currentAST.child = pattern_declaration_AST!=null &&pattern_declaration_AST.getFirstChild()!=null ?
					pattern_declaration_AST.getFirstChild() : pattern_declaration_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN||LA(2)==PERIOD) && (LA(3)==IDENTIFIER) && (LA(4)==IDENTIFIER||LA(4)==LPAREN||LA(4)==PERIOD) && (_tokenSet_13.member(LA(5)))) {
				pattern_specification();
				p_AST = (AST)returnAST;
				pattern_declaration_AST = (AST)currentAST.root;
				
				pattern_declaration_AST = (AST)astFactory.make( (new ASTArray(3)).add(astFactory.create(PATTERN_DECLARATION)).add(name_AST).add(p_AST));
				
				currentAST.root = pattern_declaration_AST;
				currentAST.child = pattern_declaration_AST!=null &&pattern_declaration_AST.getFirstChild()!=null ?
					pattern_declaration_AST.getFirstChild() : pattern_declaration_AST;
				currentAST.advanceChildToEnd();
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
			}
			AST tmp49_AST = null;
			tmp49_AST = astFactory.create(LT(1));
			match(SEMI);
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
		returnAST = pattern_declaration_AST;
	}
	
	public final void reduction_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST reduction_declaration_AST = null;
		Token  nonTerminalRuleId = null;
		AST nonTerminalRuleId_AST = null;
		Token  name = null;
		AST name_AST = null;
		AST cost_AST = null;
		AST r_AST = null;
		
		try {      // for error handling
			nonTerminalRuleId = LT(1);
			nonTerminalRuleId_AST = astFactory.create(nonTerminalRuleId);
			match(IDENTIFIER);
			AST tmp50_AST = null;
			tmp50_AST = astFactory.create(LT(1));
			match(EQUALS);
			match(LITERAL_Pattern);
			name = LT(1);
			name_AST = astFactory.create(name);
			match(IDENTIFIER);
			cost_specification();
			cost_AST = (AST)returnAST;
			reduction_action();
			r_AST = (AST)returnAST;
			reduction_declaration_AST = (AST)currentAST.root;
			
			reduction_declaration_AST = (AST)astFactory.make( (new ASTArray(5)).add(astFactory.create(REDUCTION_DECLARATION)).add(nonTerminalRuleId_AST).add(name_AST).add(cost_AST).add(r_AST));
			
			currentAST.root = reduction_declaration_AST;
			currentAST.child = reduction_declaration_AST!=null &&reduction_declaration_AST.getFirstChild()!=null ?
				reduction_declaration_AST.getFirstChild() : reduction_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			recover(ex,_tokenSet_0);
		}
		returnAST = reduction_declaration_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"COST_FUNCTION",
		"DEFAULT_ERROR_HANDLER",
		"FUNCTION_CALL",
		"HEADER_DECLARATION",
		"IMPLEMENTS_INTERFACE_SPECIFICATION",
		"INCLASS_DECLARATION",
		"INODE_ADAPTER_DECLARATION",
		"INODE_TYPE_DECLARATION",
		"LANGUAGE_DECLARATION",
		"MULTIPART_IDENTIFIER",
		"NON_TERMINAL_PARAMETER",
		"OPERATOR_SPECIFICATION",
		"OPERAND_LIST_KNOWN_ARITY",
		"OPERAND_LIST_ARBITRARY_ARITY",
		"PACKAGE_SPECIFICATION",
		"PATTERN_DECLARATION",
		"PATTERN_SPECIFICATION",
		"PATTERN_RULE",
		"PROLOGUE",
		"PROPERTY_SPECIFICATION",
		"REDUCTION_ACTION",
		"REDUCTION_DECLARATION",
		"RETURN_DECLARATION",
		"SIMPLE_COST_SPEC",
		"SIMPLE_TRANSFORMATION_RULE",
		"TRANSFORMATION_RULE",
		"TERMINAL_RULE",
		"TYPED_RETURN_DECLARATION",
		"an identifier",
		"LPAREN",
		"RPAREN",
		"a block of code",
		"COLON",
		"\"header\"",
		"\"INodeAdapter\"",
		"SEMI",
		"\"INodeType\"",
		"\"Language\"",
		"\"implements\"",
		"PERIOD",
		"STAR",
		"COMMA",
		"PLUS",
		"\"package\"",
		"\"BURMProperty\"",
		"\"ReturnType\"",
		"EQUALS",
		"\"DefaultErrorHandler\"",
		"\"Prologue\"",
		"INT",
		"\"Pattern\"",
		"\"void\"",
		"WS",
		"COMMENT",
		"ML_COMMENT",
		"DIGIT",
		"DIRECTIVE_STRING",
		"INCLUDE_DIRECTIVE",
		"ECHO_DIRECTIVE"
	};
	
	protected void buildTokenTypeASTClassMap() {
		tokenTypeToASTClassMap=null;
	};
	
	private static final long[] mk_tokenSet_0() {
		long[] data = { 18014402804449282L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_0 = new BitSet(mk_tokenSet_0());
	private static final long[] mk_tokenSet_1() {
		long[] data = { 4503633987108864L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_1 = new BitSet(mk_tokenSet_1());
	private static final long[] mk_tokenSet_2() {
		long[] data = { 21259508294615040L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_2 = new BitSet(mk_tokenSet_2());
	private static final long[] mk_tokenSet_3() {
		long[] data = { 27006754357248L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_3 = new BitSet(mk_tokenSet_3());
	private static final long[] mk_tokenSet_4() {
		long[] data = { 3245105490165760L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_4 = new BitSet(mk_tokenSet_4());
	private static final long[] mk_tokenSet_5() {
		long[] data = { 18014402804449280L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_5 = new BitSet(mk_tokenSet_5());
	private static final long[] mk_tokenSet_6() {
		long[] data = { 554050781184L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_6 = new BitSet(mk_tokenSet_6());
	private static final long[] mk_tokenSet_7() {
		long[] data = { 8589934592L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_7 = new BitSet(mk_tokenSet_7());
	private static final long[] mk_tokenSet_8() {
		long[] data = { 17179869184L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_8 = new BitSet(mk_tokenSet_8());
	private static final long[] mk_tokenSet_9() {
		long[] data = { 35201551958016L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_9 = new BitSet(mk_tokenSet_9());
	private static final long[] mk_tokenSet_10() {
		long[] data = { 105570296135680L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_10 = new BitSet(mk_tokenSet_10());
	private static final long[] mk_tokenSet_11() {
		long[] data = { 35820027248640L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_11 = new BitSet(mk_tokenSet_11());
	private static final long[] mk_tokenSet_12() {
		long[] data = { 618475290624L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_12 = new BitSet(mk_tokenSet_12());
	private static final long[] mk_tokenSet_13() {
		long[] data = { 105574591102976L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_13 = new BitSet(mk_tokenSet_13());
	private static final long[] mk_tokenSet_14() {
		long[] data = { 2L, 0L};
		return data;
	}
	public static final BitSet _tokenSet_14 = new BitSet(mk_tokenSet_14());
	
	}
