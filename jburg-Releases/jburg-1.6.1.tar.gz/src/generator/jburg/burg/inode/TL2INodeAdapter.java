package jburg.burg.inode;

class TL2INodeAdapter
    implements InodeAdapter
{
	public boolean accept(String inodeClassName)
	{
		return inodeClassName != null &&
			inodeClassName.equals("jburg.compiler.tl2.ir.TL2INode");
	}

	public String genGetArity(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getArity", null);
	}

	public String genGetNthChild(String stem, String index, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getNthChild", new String[] { index } );
	}

	public String genGetOperator(String stem, jburg.burg.emitlangs.EmitLang emitter)
	{
		return emitter.genCallMethod(stem, "getOperator", null);
	}

}
