package jburg.compiler.tl2.semanticanalysis;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Vector;

import jburg.compiler.tl2.ir.TL2INode;
import jburg.compiler.tl2.ir.Symbol;
import jburg.compiler.tl2.ir.TL2CompilerConstants;

/**
 *  AbstractMethod is the TL/2 compiler's view of a method's metadata.
 *  It consists of a collection of reflection information from a Method
 *  (if the method is from a class not under compilation) or a collection of
 *  compiler data (if the method is part of a class under compilation).
 */
public class AbstractMethod
   implements TL2CompilerConstants
{
   private Symbol methodSymbol;

   private Symbol[] methodParameters;

   /**
    *  Construct an AbstractMethod from an already-compiled class' reflection information.
    *  @param m - the java.lang.reflect.Method that has the reflection information.
    */
   public AbstractMethod ( Method m )
   {
    //  FIXME
    this.methodSymbol = new Symbol();
    this.methodSymbol.setName ( m.getName() );
    this.methodSymbol.setSymbolClass ( AbstractClass.getAbstractClass( m.getReturnType() ));
    this.methodSymbol.setModifiers ( m.getModifiers() );

    //  Extract parameter information.
    Class[] pTypes = m.getParameterTypes();

    this.methodParameters = new Symbol[pTypes.length];


    for ( int i = 0; i < pTypes.length; i++ )
    {
        this.methodParameters[i] = new Symbol();
        this.methodParameters[i].setSymbolClass(AbstractClass.getAbstractClass(pTypes[i]));
    }
   }


   /**
    *  Construct an AbstractMethod that belongs to a class under compilation.
    *  @param A TL2INode of type METHOD_DEFINITION.
    */
   public AbstractMethod ( TL2INode n )
   {
    this.methodSymbol = (Symbol) n.getAttribute ( METHOD_SYMBOL );

    Vector pParms = (Vector) n.getAttribute ( METHOD_PARAMETERS );

    this.methodParameters = new Symbol[pParms.size()];

    for ( int i = 0; i < this.methodParameters.length; i++ )
    {
        this.methodParameters[i] = (Symbol)pParms.elementAt(i);
    }
   }

   /** @return the method's name. */
   public String getName()
   {
    return this.methodSymbol.getName();
   }

   /** @return true if the method is static. */
   public boolean isStatic()
   {
    return this.methodSymbol.isStatic();
   }

   public Symbol getMethodSymbol()
   {
    return this.methodSymbol;
   }

   /**
    *  @return the method's return type as a TL/2 compiler-usable AbstractClass.
    */
   public AbstractClass getReturnType()
   {
    return this.methodSymbol.getSymbolClass();
   }

   public Symbol[] getParameterTypes()
   {
    return this.methodParameters;
   }

   public String getSignature()
   {
    StringBuffer result = new StringBuffer("(");

    for ( int i = 0; i < this.methodParameters.length; i++ )
    {
        AbstractClass clazz = this.methodParameters[i].getSymbolClass();
        result.append ( clazz.getSignature() );
    }

    result.append ( ")" );
    result.append ( getReturnType().getSignature() );

    return result.toString();
   }
}
