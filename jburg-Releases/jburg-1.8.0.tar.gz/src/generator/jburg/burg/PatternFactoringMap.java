package jburg.burg;

public class PatternFactoringMap
{

}
