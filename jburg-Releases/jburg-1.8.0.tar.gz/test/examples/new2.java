/**
 *  Test using operator new() as the head element of a reference chain.
 */
public class new2
{
	public int zuul()
	{
		return 12;
	}

	public static void main ( String[] argv )
	{
		new new2().zuul();
		System.out.println ( new Integer(1).toString() );
	}
}
