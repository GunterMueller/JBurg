/*  Generated Sat Apr 09 13:51:10 EDT 2011 by JBurg version 1.8.0 */

#include <iostream>
#include <string>
#include <stack>
#include <exception>
#include <memory>
#include <sstream>
namespace jburgsupp
{
	int getOperator( TestINode* node )
	{
			return node->getOperator();
	}
	
}
#include "jburgsupp.h"

    #include <iostream>

class JBurgCppTestEmitter: public ArithmeticTokenHolder
{
private:

	std::stack<void*> __reducedValues;

	int	*antecedentRules;

public:

	JBurgCppTestEmitter() {
		antecedentRules = new int[nStates];
	}

	~JBurgCppTestEmitter() {
		if( antecedentRules ) delete[] antecedentRules;
	}


public:
static const int __expression_NT = 1;
public:
static const int nStates = 1;


public: static std::vector<std::vector<JBurgAnnotation<TestINode>::JBurgSubgoal> > subgoals_by_rule283297960;

/* Static initializer code for the subgoals lookup table. */

public: class SubgoalsByRuleInitializerHack
{
	
	public: SubgoalsByRuleInitializerHack()
	{
		
		JBurgCppTestEmitter::subgoals_by_rule283297960.resize(4);
		std::vector<int> rule_2_pattern_1;
		rule_2_pattern_1.push_back(0);
		JBurgCppTestEmitter::subgoals_by_rule283297960[2].push_back(JBurgAnnotation<TestINode>::JBurgSubgoal(__expression_NT,false,0,rule_2_pattern_1));
		

		std::vector<int> rule_2_pattern_0;
		rule_2_pattern_0.push_back(1);
		JBurgCppTestEmitter::subgoals_by_rule283297960[2].push_back(JBurgAnnotation<TestINode>::JBurgSubgoal(__expression_NT,false,0,rule_2_pattern_0));
		

	}
	
	static SubgoalsByRuleInitializerHack init_hack283297960;
}
;


public:
JBurgAnnotation<TestINode>* label( TestINode* to_be_labelled )
{
	JBurgAnnotation<TestINode>* result = NULL;
	int i;
	int arity;
	if ( to_be_labelled )
	{
		result = new JBurgAnnotation<TestINode>(to_be_labelled,nStates + 1);
		arity = to_be_labelled->getArity();
		i = 0;
		while ( ( arity > i ) )
		{
			
			result->addChild(this->label(((TestINode*)to_be_labelled->getNthChild(i))));
			i =  (i + 1) ;
			
		}
		
		this->computeCostMatrix(result);
		
	}
	
	return (result);
	
}
private:
void computeCostMatrix( JBurgAnnotation<TestINode>* node )
{
	long iCost;
	switch( node->getOperator() )
	{
		case INT:
		{
			
			if ( node->getArity()==0 )
			{
				
				
				/* Try matching INT ==> expression */
if ( ( node->getCost(__expression_NT) > 1 )  && ( MAX_INT_VALUE > 1 )  )
				{
					
					node->reset(__expression_NT, 1, 3);
					
				}
				
			}
			break;
		}
		case ADD:
		{
			
			if ( node->getArity()==2 )
			{
				
				
				/* Try matching ADD ==> expression */
iCost =  ( (((long)1) + ((long)node->getNthChild(1)->getCost(__expression_NT)))  + ((long)node->getNthChild(0)->getCost(__expression_NT))) ;
				if ( ( node->getCost(__expression_NT) > iCost )  && ( MAX_INT_VALUE > iCost )  )
				{
					
					node->reset(__expression_NT, ((int)iCost), 2);
					
				}
				
			}
			break;
		}
		
	}
	
}

/* expression */
private:
int action_2( TestINode* __p )
{
	

	int r((int)__reducedValues.top());
	__reducedValues.pop();
	

	int l((int)__reducedValues.top());
	__reducedValues.pop();
	
		{
		    return l + r;
		}
}

/* expression */
private:
int action_3( TestINode* __p )
{
	
		{
		    return atoi(__p->getText().c_str());
		}
}
private:
void dispatchAction( TestINode* __p, int iRule )
{
	switch( iRule )
	{
		case 1:
		{
			/* Don't reduce or touch the stack. */

			break;
		}
		case 2:
		{
			__reducedValues.push( (void*)(this->action_2(__p)));
			break;
		}
		case 3:
		{
			__reducedValues.push( (void*)(this->action_3(__p)));
			break;
		}
		default:throw std::string("Unmatched reduce action " + iRule);
		
	}
	
}


	void reduce ( JBurgAnnotation<TestINode >* p, int goalState )
	{
		int iRule = -1;

		if ( goalState > 0 ) {
			iRule = p->getRule(goalState);
		} else {
			//  Find the minimum-cost path.
			int minCost = MAX_INT_VALUE;
			for (int i = 0; i <= nStates ; ++i ) {
				if ( p->getCost(i) < minCost ) {
					iRule = p->getRule(i);
					minCost = p->getCost(i);
					goalState = i;
				}
			}
		}

		if ( iRule > 0 )
		{
			
			reduceAntecedentStates(p, goalState);
			reduceSubgoals(p, iRule);

			dispatchAction ( p->getNode(), iRule );
		}
		else
		{
			std::stringstream s;
			s << "Unable to find a rule to process ";
			s << p->getNode()->toString();
			s << " (" << p->getOperator() << ") {" << goalState << "}";
			throw new std::runtime_error ( s.str() );
		}
	}

	void reduceAntecedentStates( JBurgAnnotation<TestINode >* p, int goalState)
	{
		int   currentState = goalState;
		std::vector<int> antecedent_states;
		std::vector<int> antecedent_rules;

		//  If X is antecedent of Y, then the reduce action
		//  for X must occur before the reduce action of Y.
		//  The antecdents must therefore be processed 
		//  from "back" to "front."
		while ( p->hasAntecedent(currentState)  )
		{
			currentState = p->getAntecedent(currentState);
			antecedent_states.push_back(currentState);
			antecedent_rules.push_back(p->getRule(currentState));
		}
		while ( ! antecedent_states.empty() )
		{
			reduceSubgoals(p, antecedent_rules.back());
			dispatchAction( p->getNode(), antecedent_rules.back());
			antecedent_states.pop_back();
			antecedent_rules.pop_back();
		}
	}
	void reduceSubgoals( JBurgAnnotation<TestINode >* p, int rule_num)
	{
		for ( int i = 0; i < subgoals_by_rule283297960[rule_num].size(); i++)
		{
			JBurgAnnotation<TestINode>::JBurgSubgoal sg = subgoals_by_rule283297960[rule_num][i];
			reduce ( sg.getNode(p), sg.getGoalState());
		}
	}

public:

	void burm ( TestINode* root )
	{		burm(root,0);	}	void burm ( TestINode* root, int goal_state )
	{
		JBurgAnnotation<TestINode >* annotatedTree = label(root);
		reduce ( annotatedTree, goal_state);
		delete annotatedTree;
	}

	void* getResult() {
		return __reducedValues.top();
	}

int getNaryCost( JBurgAnnotation<TestINode>* node, int goalState, int startIndex)
{
	int i = 0;
	int accum = 0;
	
	for ( i = startIndex; i < node->getArity(); i++ )
	{
		
		accum += node->getCost(goalState);
		
	}
	
	return (accum);
	
}


};
std::vector<std::vector<JBurgAnnotation<TestINode>::JBurgSubgoal> > JBurgCppTestEmitter::subgoals_by_rule283297960;
JBurgCppTestEmitter::SubgoalsByRuleInitializerHack JBurgCppTestEmitter::SubgoalsByRuleInitializerHack::init_hack283297960;
