// $ANTLR 2.7.1: "grammars/jburg.g" -> "JBurgParser.java"$

	package jburg;

import antlr.TokenBuffer;
import antlr.TokenStreamException;
import antlr.TokenStreamIOException;
import antlr.ANTLRException;
import antlr.LLkParser;
import antlr.Token;
import antlr.TokenStream;
import antlr.RecognitionException;
import antlr.NoViableAltException;
import antlr.MismatchedTokenException;
import antlr.SemanticException;
import antlr.ParserSharedInputState;
import antlr.collections.impl.BitSet;
import antlr.collections.AST;
import antlr.ASTPair;
import antlr.collections.impl.ASTArray;

import java.io.*;
import antlr.CommonAST;
import antlr.collections.AST;

class JBurgMain
{
	public static void main(String[] args) 
	{

		boolean debugMode       = false;
		boolean syntaxCheckOnly = false;

		String strInputFile  = args[0];
		String strOutputFile = args[1];

		int i;

		for ( i = 2; i < args.length; i++ )
		{
			if ( args[i].equalsIgnoreCase( "-g" ) )
			    debugMode = true;
			else if ( args[i].equalsIgnoreCase("-syntax") )
				syntaxCheckOnly = true;
		}

		try 
		{
			JBurgANTLRLexer lexer = new JBurgANTLRLexer(new FileInputStream(strInputFile));
			JBurgParser parser = new JBurgParser(lexer);
			parser.specification();
			
			CommonAST t = (CommonAST)parser.getAST();

			if ( ! syntaxCheckOnly )
			{

				try
				{
					JBurgGenerator generator = new JBurgGenerator(t);
					generator.setDebugMode ( debugMode );

					int     iExtPos       = strOutputFile.lastIndexOf(".");
					String  strClassName  = strOutputFile.substring ( 0, iExtPos  );

					generator.generate( strClassName, new PrintStream(new FileOutputStream(strOutputFile) ) );
				}
				catch ( Exception e )
				{
					e.printStackTrace();
					System.exit(1);
				}
			}
		} 
		catch(Exception e) 
		{
			e.printStackTrace();
			System.exit(2);
		}
	}
}

public class JBurgParser extends antlr.LLkParser
       implements JBurgTokenTypes
 {

protected JBurgParser(TokenBuffer tokenBuf, int k) {
  super(tokenBuf,k);
  tokenNames = _tokenNames;
}

public JBurgParser(TokenBuffer tokenBuf) {
  this(tokenBuf,6);
}

protected JBurgParser(TokenStream lexer, int k) {
  super(lexer,k);
  tokenNames = _tokenNames;
}

public JBurgParser(TokenStream lexer) {
  this(lexer,6);
}

public JBurgParser(ParserSharedInputState state) {
  super(state,6);
  tokenNames = _tokenNames;
}

	public final void cost_function() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cost_function_AST = null;
		Token  funcId = null;
		AST funcId_AST = null;
		Token  functionBody = null;
		AST functionBody_AST = null;
		
		try {      // for error handling
			funcId = LT(1);
			funcId_AST = (AST)astFactory.create(funcId);
			match(IDENTIFIER);
			AST tmp1_AST = null;
			tmp1_AST = (AST)astFactory.create(LT(1));
			match(LPAREN);
			AST tmp2_AST = null;
			tmp2_AST = (AST)astFactory.create(LT(1));
			match(RPAREN);
			functionBody = LT(1);
			functionBody_AST = (AST)astFactory.create(functionBody);
			match(BLOCK);
			cost_function_AST = (AST)currentAST.root;
			
					cost_function_AST = (AST)astFactory.make( (new ASTArray(3)).add((AST)astFactory.create(COST_FUNCTION)).add(funcId_AST).add(functionBody_AST));
				
			currentAST.root = cost_function_AST;
			currentAST.child = cost_function_AST!=null &&cost_function_AST.getFirstChild()!=null ?
				cost_function_AST.getFirstChild() : cost_function_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_0);
		}
		returnAST = cost_function_AST;
	}
	
	public final void cost_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST cost_specification_AST = null;
		
		try {      // for error handling
			AST tmp3_AST = null;
			tmp3_AST = (AST)astFactory.create(LT(1));
			match(COLON);
			{
			switch ( LA(1)) {
			case INT:
			{
				simple_cost_spec();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case IDENTIFIER:
			{
				function_call();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			cost_specification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_1);
		}
		returnAST = cost_specification_AST;
	}
	
	public final void simple_cost_spec() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST simple_cost_spec_AST = null;
		Token  iCost = null;
		AST iCost_AST = null;
		
		try {      // for error handling
			iCost = LT(1);
			iCost_AST = (AST)astFactory.create(iCost);
			match(INT);
			simple_cost_spec_AST = (AST)currentAST.root;
			
				    simple_cost_spec_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(SIMPLE_COST_SPEC)).add(iCost_AST));
				
			currentAST.root = simple_cost_spec_AST;
			currentAST.child = simple_cost_spec_AST!=null &&simple_cost_spec_AST.getFirstChild()!=null ?
				simple_cost_spec_AST.getFirstChild() : simple_cost_spec_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_1);
		}
		returnAST = simple_cost_spec_AST;
	}
	
	public final void function_call() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST function_call_AST = null;
		Token  funcId = null;
		AST funcId_AST = null;
		
		try {      // for error handling
			funcId = LT(1);
			funcId_AST = (AST)astFactory.create(funcId);
			match(IDENTIFIER);
			AST tmp4_AST = null;
			tmp4_AST = (AST)astFactory.create(LT(1));
			match(LPAREN);
			AST tmp5_AST = null;
			tmp5_AST = (AST)astFactory.create(LT(1));
			match(RPAREN);
			function_call_AST = (AST)currentAST.root;
			
					function_call_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(FUNCTION_CALL)).add(funcId_AST));
				
			currentAST.root = function_call_AST;
			currentAST.child = function_call_AST!=null &&function_call_AST.getFirstChild()!=null ?
				function_call_AST.getFirstChild() : function_call_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_1);
		}
		returnAST = function_call_AST;
	}
	
	public final void declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST declaration_AST = null;
		
		try {      // for error handling
			switch ( LA(1)) {
			case LITERAL_implements:
			{
				implements_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_header:
			{
				header_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_INodeType:
			{
				inode_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_package:
			{
				package_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_BURMProperty:
			{
				property_specification();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			case LITERAL_ReturnType:
			{
				return_declaration();
				astFactory.addASTChild(currentAST, returnAST);
				declaration_AST = (AST)currentAST.root;
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
		returnAST = declaration_AST;
	}
	
	public final void implements_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST implements_declaration_AST = null;
		AST implements_interface_name_AST = null;
		
		try {      // for error handling
			AST tmp6_AST = null;
			tmp6_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_implements);
			multipart_identifier();
			implements_interface_name_AST = (AST)returnAST;
			AST tmp7_AST = null;
			tmp7_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			implements_declaration_AST = (AST)currentAST.root;
			
					implements_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(IMPLEMENTS_INTERFACE_SPECIFICATION)).add(implements_interface_name_AST));
				
			currentAST.root = implements_declaration_AST;
			currentAST.child = implements_declaration_AST!=null &&implements_declaration_AST.getFirstChild()!=null ?
				implements_declaration_AST.getFirstChild() : implements_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
		returnAST = implements_declaration_AST;
	}
	
	public final void header_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST header_declaration_AST = null;
		Token  header_block = null;
		AST header_block_AST = null;
		
		try {      // for error handling
			AST tmp8_AST = null;
			tmp8_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_header);
			header_block = LT(1);
			header_block_AST = (AST)astFactory.create(header_block);
			match(BLOCK);
			header_declaration_AST = (AST)currentAST.root;
			
					header_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(HEADER_DECLARATION)).add(header_block_AST));
				
			currentAST.root = header_declaration_AST;
			currentAST.child = header_declaration_AST!=null &&header_declaration_AST.getFirstChild()!=null ?
				header_declaration_AST.getFirstChild() : header_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
		returnAST = header_declaration_AST;
	}
	
	public final void inode_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST inode_declaration_AST = null;
		AST inode_type_AST = null;
		
		try {      // for error handling
			AST tmp9_AST = null;
			tmp9_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_INodeType);
			multipart_identifier();
			inode_type_AST = (AST)returnAST;
			AST tmp10_AST = null;
			tmp10_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			inode_declaration_AST = (AST)currentAST.root;
			
					inode_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(INODE_DECLARATION)).add(inode_type_AST));
				
			currentAST.root = inode_declaration_AST;
			currentAST.child = inode_declaration_AST!=null &&inode_declaration_AST.getFirstChild()!=null ?
				inode_declaration_AST.getFirstChild() : inode_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
		returnAST = inode_declaration_AST;
	}
	
	public final void package_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST package_declaration_AST = null;
		AST package_name_AST = null;
		
		try {      // for error handling
			AST tmp11_AST = null;
			tmp11_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_package);
			multipart_identifier();
			package_name_AST = (AST)returnAST;
			AST tmp12_AST = null;
			tmp12_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			package_declaration_AST = (AST)currentAST.root;
			
					package_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(PACKAGE_SPECIFICATION)).add(package_name_AST));
				
			currentAST.root = package_declaration_AST;
			currentAST.child = package_declaration_AST!=null &&package_declaration_AST.getFirstChild()!=null ?
				package_declaration_AST.getFirstChild() : package_declaration_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
		returnAST = package_declaration_AST;
	}
	
	public final void property_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST property_specification_AST = null;
		AST property_type_AST = null;
		Token  property_name = null;
		AST property_name_AST = null;
		
		try {      // for error handling
			AST tmp13_AST = null;
			tmp13_AST = (AST)astFactory.create(LT(1));
			match(LITERAL_BURMProperty);
			multipart_identifier();
			property_type_AST = (AST)returnAST;
			property_name = LT(1);
			property_name_AST = (AST)astFactory.create(property_name);
			match(IDENTIFIER);
			AST tmp14_AST = null;
			tmp14_AST = (AST)astFactory.create(LT(1));
			match(SEMI);
			property_specification_AST = (AST)currentAST.root;
			
					property_specification_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(PROPERTY_SPECIFICATION)).add((AST)astFactory.make( (new ASTArray(2)).add(property_type_AST).add(property_name_AST))));
				
			currentAST.root = property_specification_AST;
			currentAST.child = property_specification_AST!=null &&property_specification_AST.getFirstChild()!=null ?
				property_specification_AST.getFirstChild() : property_specification_AST;
			currentAST.advanceChildToEnd();
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
		returnAST = property_specification_AST;
	}
	
	public final void return_declaration() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST return_declaration_AST = null;
		AST return_type_AST = null;
		Token  state_name = null;
		AST state_name_AST = null;
		AST state_return_type_AST = null;
		
		try {      // for error handling
			if ((LA(1)==LITERAL_ReturnType) && (LA(2)==IDENTIFIER) && (LA(3)==SEMI||LA(3)==PERIOD)) {
				AST tmp15_AST = null;
				tmp15_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_ReturnType);
				multipart_identifier();
				return_type_AST = (AST)returnAST;
				AST tmp16_AST = null;
				tmp16_AST = (AST)astFactory.create(LT(1));
				match(SEMI);
				return_declaration_AST = (AST)currentAST.root;
				
						return_declaration_AST = (AST)astFactory.make( (new ASTArray(2)).add((AST)astFactory.create(RETURN_DECLARATION)).add(return_type_AST));
					
				currentAST.root = return_declaration_AST;
				currentAST.child = return_declaration_AST!=null &&return_declaration_AST.getFirstChild()!=null ?
					return_declaration_AST.getFirstChild() : return_declaration_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==LITERAL_ReturnType) && (LA(2)==IDENTIFIER) && (LA(3)==EQUALS)) {
				AST tmp17_AST = null;
				tmp17_AST = (AST)astFactory.create(LT(1));
				match(LITERAL_ReturnType);
				state_name = LT(1);
				state_name_AST = (AST)astFactory.create(state_name);
				match(IDENTIFIER);
				AST tmp18_AST = null;
				tmp18_AST = (AST)astFactory.create(LT(1));
				match(EQUALS);
				multipart_identifier();
				state_return_type_AST = (AST)returnAST;
				AST tmp19_AST = null;
				tmp19_AST = (AST)astFactory.create(LT(1));
				match(SEMI);
				return_declaration_AST = (AST)currentAST.root;
				
						return_declaration_AST = (AST)astFactory.make( (new ASTArray(3)).add((AST)astFactory.create(TYPED_RETURN_DECLARATION)).add(state_name_AST).add(state_return_type_AST));
					
				currentAST.root = return_declaration_AST;
				currentAST.child = return_declaration_AST!=null &&return_declaration_AST.getFirstChild()!=null ?
					return_declaration_AST.getFirstChild() : return_declaration_AST;
				currentAST.advanceChildToEnd();
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_2);
		}
		returnAST = return_declaration_AST;
	}
	
	public final void header_section() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST header_section_AST = null;
		
		try {      // for error handling
			{
			int _cnt8=0;
			_loop8:
			do {
				if ((_tokenSet_3.member(LA(1)))) {
					declaration();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt8>=1 ) { break _loop8; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt8++;
			} while (true);
			}
			header_section_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_4);
		}
		returnAST = header_section_AST;
	}
	
	public final void multipart_identifier() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST multipart_identifier_AST = null;
		
		try {      // for error handling
			AST tmp20_AST = null;
			tmp20_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp20_AST);
			match(IDENTIFIER);
			{
			_loop14:
			do {
				if ((LA(1)==PERIOD)) {
					AST tmp21_AST = null;
					tmp21_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp21_AST);
					match(PERIOD);
					AST tmp22_AST = null;
					tmp22_AST = (AST)astFactory.create(LT(1));
					astFactory.addASTChild(currentAST, tmp22_AST);
					match(IDENTIFIER);
				}
				else {
					break _loop14;
				}
				
			} while (true);
			}
			multipart_identifier_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_5);
		}
		returnAST = multipart_identifier_AST;
	}
	
	public final void operand_list() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operand_list_AST = null;
		
		try {      // for error handling
			operand();
			astFactory.addASTChild(currentAST, returnAST);
			{
			switch ( LA(1)) {
			case COMMA:
			{
				AST tmp23_AST = null;
				tmp23_AST = (AST)astFactory.create(LT(1));
				match(COMMA);
				operand();
				astFactory.addASTChild(currentAST, returnAST);
				break;
			}
			case RPAREN:
			{
				break;
			}
			default:
			{
				throw new NoViableAltException(LT(1), getFilename());
			}
			}
			}
			operand_list_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_6);
		}
		returnAST = operand_list_AST;
	}
	
	public final void operand() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operand_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN)) {
				operator_specification();
				astFactory.addASTChild(currentAST, returnAST);
				operand_AST = (AST)currentAST.root;
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==IDENTIFIER)) {
				parameter_decl();
				astFactory.addASTChild(currentAST, returnAST);
				operand_AST = (AST)currentAST.root;
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_7);
		}
		returnAST = operand_AST;
	}
	
	public final void operator_specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST operator_specification_AST = null;
		Token  operatorId = null;
		AST operatorId_AST = null;
		
		try {      // for error handling
			operatorId = LT(1);
			operatorId_AST = (AST)astFactory.create(operatorId);
			astFactory.makeASTRoot(currentAST, operatorId_AST);
			match(IDENTIFIER);
			AST tmp24_AST = null;
			tmp24_AST = (AST)astFactory.create(LT(1));
			match(LPAREN);
			operand_list();
			astFactory.addASTChild(currentAST, returnAST);
			AST tmp25_AST = null;
			tmp25_AST = (AST)astFactory.create(LT(1));
			match(RPAREN);
			operator_specification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_8);
		}
		returnAST = operator_specification_AST;
	}
	
	public final void parameter_decl() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST parameter_decl_AST = null;
		
		try {      // for error handling
			AST tmp26_AST = null;
			tmp26_AST = (AST)astFactory.create(LT(1));
			astFactory.makeASTRoot(currentAST, tmp26_AST);
			match(IDENTIFIER);
			AST tmp27_AST = null;
			tmp27_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp27_AST);
			match(IDENTIFIER);
			parameter_decl_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_7);
		}
		returnAST = parameter_decl_AST;
	}
	
/**
 *  Reduce a rule.
 *  Rule types are:<ul>
 *  <li>  Pattern rules, which combine subgoals with other nodes further up the tree.
 *  <li>  Simple transformation rules.  Like iBurg's chain rules, simple transformation
 *        rules allow one goal to satisfy additional goals.
 *  <li>  Complex transformation rules, which allow the reducer to actively transform
 *        a subgoal to satisfy additional subgoals.
 *  <li>  A leaf node, with no children, can be used as a subgoal in either type 
 *        of transformation rule.
 *  </ul>
 */
	public final void rule() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST rule_AST = null;
		Token  nonTerminalRuleId = null;
		AST nonTerminalRuleId_AST = null;
		AST op_AST = null;
		AST cost_AST = null;
		Token  action = null;
		AST action_AST = null;
		Token  simpleTransformationTarget = null;
		AST simpleTransformationTarget_AST = null;
		Token  simpleTransformationSource = null;
		AST simpleTransformationSource_AST = null;
		Token  transformationTarget = null;
		AST transformationTarget_AST = null;
		Token  transformationSource = null;
		AST transformationSource_AST = null;
		AST transformationCost_AST = null;
		Token  transformationAction = null;
		AST transformationAction_AST = null;
		Token  terminalRuleId = null;
		AST terminalRuleId_AST = null;
		Token  terminalId = null;
		AST terminalId_AST = null;
		AST terminalCost_AST = null;
		Token  terminalAction = null;
		AST terminalAction_AST = null;
		
		try {      // for error handling
			if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==LPAREN) && (LA(5)==IDENTIFIER)) {
				nonTerminalRuleId = LT(1);
				nonTerminalRuleId_AST = (AST)astFactory.create(nonTerminalRuleId);
				match(IDENTIFIER);
				AST tmp28_AST = null;
				tmp28_AST = (AST)astFactory.create(LT(1));
				match(EQUALS);
				operator_specification();
				op_AST = (AST)returnAST;
				cost_specification();
				cost_AST = (AST)returnAST;
				action = LT(1);
				action_AST = (AST)astFactory.create(action);
				match(BLOCK);
				rule_AST = (AST)currentAST.root;
				
						rule_AST = (AST)astFactory.make( (new ASTArray(5)).add((AST)astFactory.create(PATTERN_RULE)).add(nonTerminalRuleId_AST).add(op_AST).add(cost_AST).add(action_AST));
					
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==SEMI)) {
				simpleTransformationTarget = LT(1);
				simpleTransformationTarget_AST = (AST)astFactory.create(simpleTransformationTarget);
				match(IDENTIFIER);
				AST tmp29_AST = null;
				tmp29_AST = (AST)astFactory.create(LT(1));
				match(EQUALS);
				simpleTransformationSource = LT(1);
				simpleTransformationSource_AST = (AST)astFactory.create(simpleTransformationSource);
				match(IDENTIFIER);
				AST tmp30_AST = null;
				tmp30_AST = (AST)astFactory.create(LT(1));
				match(SEMI);
				rule_AST = (AST)currentAST.root;
				
						rule_AST = (AST)astFactory.make( (new ASTArray(3)).add((AST)astFactory.create(SIMPLE_TRANSFORMATION_RULE)).add(simpleTransformationTarget_AST).add(simpleTransformationSource_AST));
					
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==COLON)) {
				transformationTarget = LT(1);
				transformationTarget_AST = (AST)astFactory.create(transformationTarget);
				match(IDENTIFIER);
				AST tmp31_AST = null;
				tmp31_AST = (AST)astFactory.create(LT(1));
				match(EQUALS);
				transformationSource = LT(1);
				transformationSource_AST = (AST)astFactory.create(transformationSource);
				match(IDENTIFIER);
				cost_specification();
				transformationCost_AST = (AST)returnAST;
				transformationAction = LT(1);
				transformationAction_AST = (AST)astFactory.create(transformationAction);
				match(BLOCK);
				rule_AST = (AST)currentAST.root;
				
						rule_AST = (AST)astFactory.make( (new ASTArray(5)).add((AST)astFactory.create(TRANSFORMATION_RULE)).add(transformationTarget_AST).add(transformationSource_AST).add(transformationCost_AST).add(transformationAction_AST));
					
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS) && (LA(3)==IDENTIFIER) && (LA(4)==LPAREN) && (LA(5)==LITERAL_void)) {
				terminalRuleId = LT(1);
				terminalRuleId_AST = (AST)astFactory.create(terminalRuleId);
				match(IDENTIFIER);
				AST tmp32_AST = null;
				tmp32_AST = (AST)astFactory.create(LT(1));
				match(EQUALS);
				terminalId = LT(1);
				terminalId_AST = (AST)astFactory.create(terminalId);
				match(IDENTIFIER);
				AST tmp33_AST = null;
				tmp33_AST = (AST)astFactory.create(LT(1));
				match(LPAREN);
				voidSpecification();
				AST tmp34_AST = null;
				tmp34_AST = (AST)astFactory.create(LT(1));
				match(RPAREN);
				cost_specification();
				terminalCost_AST = (AST)returnAST;
				terminalAction = LT(1);
				terminalAction_AST = (AST)astFactory.create(terminalAction);
				match(BLOCK);
				rule_AST = (AST)currentAST.root;
				
						rule_AST = (AST)astFactory.make( (new ASTArray(5)).add((AST)astFactory.create(TERMINAL_RULE)).add(terminalRuleId_AST).add(terminalId_AST).add(terminalCost_AST).add(terminalAction_AST));
					
				currentAST.root = rule_AST;
				currentAST.child = rule_AST!=null &&rule_AST.getFirstChild()!=null ?
					rule_AST.getFirstChild() : rule_AST;
				currentAST.advanceChildToEnd();
			}
			else {
				throw new NoViableAltException(LT(1), getFilename());
			}
			
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_0);
		}
		returnAST = rule_AST;
	}
	
	public final void voidSpecification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST voidSpecification_AST = null;
		
		try {      // for error handling
			AST tmp35_AST = null;
			tmp35_AST = (AST)astFactory.create(LT(1));
			astFactory.addASTChild(currentAST, tmp35_AST);
			match(LITERAL_void);
			voidSpecification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_6);
		}
		returnAST = voidSpecification_AST;
	}
	
	public final void specification() throws RecognitionException, TokenStreamException {
		
		returnAST = null;
		ASTPair currentAST = new ASTPair();
		AST specification_AST = null;
		
		try {      // for error handling
			header_section();
			astFactory.addASTChild(currentAST, returnAST);
			{
			int _cnt27=0;
			_loop27:
			do {
				if ((LA(1)==IDENTIFIER) && (LA(2)==EQUALS)) {
					rule();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else if ((LA(1)==IDENTIFIER) && (LA(2)==LPAREN)) {
					cost_function();
					astFactory.addASTChild(currentAST, returnAST);
				}
				else {
					if ( _cnt27>=1 ) { break _loop27; } else {throw new NoViableAltException(LT(1), getFilename());}
				}
				
				_cnt27++;
			} while (true);
			}
			AST tmp36_AST = null;
			tmp36_AST = (AST)astFactory.create(LT(1));
			match(Token.EOF_TYPE);
			specification_AST = (AST)currentAST.root;
		}
		catch (RecognitionException ex) {
			reportError(ex);
			consume();
			consumeUntil(_tokenSet_9);
		}
		returnAST = specification_AST;
	}
	
	
	public static final String[] _tokenNames = {
		"<0>",
		"EOF",
		"<2>",
		"NULL_TREE_LOOKAHEAD",
		"COST_FUNCTION",
		"FUNCTION_CALL",
		"HEADER_DECLARATION",
		"IMPLEMENTS_INTERFACE_SPECIFICATION",
		"INODE_DECLARATION",
		"PACKAGE_SPECIFICATION",
		"PATTERN_RULE",
		"PROPERTY_SPECIFICATION",
		"RETURN_DECLARATION",
		"SIMPLE_COST_SPEC",
		"SIMPLE_TRANSFORMATION_RULE",
		"TRANSFORMATION_RULE",
		"TERMINAL_RULE",
		"TYPED_RETURN_DECLARATION",
		"an identifier",
		"LPAREN",
		"RPAREN",
		"a block of code",
		"COLON",
		"\"header\"",
		"\"INodeType\"",
		"SEMI",
		"\"implements\"",
		"PERIOD",
		"COMMA",
		"\"package\"",
		"\"BURMProperty\"",
		"\"ReturnType\"",
		"EQUALS",
		"INT",
		"\"void\"",
		"STRING_LITERAL",
		"WS",
		"COMMENT",
		"ML_COMMENT",
		"DIGIT"
	};
	
	private static final long _tokenSet_0_data_[] = { 262146L, 0L };
	public static final BitSet _tokenSet_0 = new BitSet(_tokenSet_0_data_);
	private static final long _tokenSet_1_data_[] = { 2097152L, 0L };
	public static final BitSet _tokenSet_1 = new BitSet(_tokenSet_1_data_);
	private static final long _tokenSet_2_data_[] = { 3850633216L, 0L };
	public static final BitSet _tokenSet_2 = new BitSet(_tokenSet_2_data_);
	private static final long _tokenSet_3_data_[] = { 3850371072L, 0L };
	public static final BitSet _tokenSet_3 = new BitSet(_tokenSet_3_data_);
	private static final long _tokenSet_4_data_[] = { 262144L, 0L };
	public static final BitSet _tokenSet_4 = new BitSet(_tokenSet_4_data_);
	private static final long _tokenSet_5_data_[] = { 33816576L, 0L };
	public static final BitSet _tokenSet_5 = new BitSet(_tokenSet_5_data_);
	private static final long _tokenSet_6_data_[] = { 1048576L, 0L };
	public static final BitSet _tokenSet_6 = new BitSet(_tokenSet_6_data_);
	private static final long _tokenSet_7_data_[] = { 269484032L, 0L };
	public static final BitSet _tokenSet_7 = new BitSet(_tokenSet_7_data_);
	private static final long _tokenSet_8_data_[] = { 273678336L, 0L };
	public static final BitSet _tokenSet_8 = new BitSet(_tokenSet_8_data_);
	private static final long _tokenSet_9_data_[] = { 2L, 0L };
	public static final BitSet _tokenSet_9 = new BitSet(_tokenSet_9_data_);
	
	}
