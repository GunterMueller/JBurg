import jburg.mjava.InMemoryCompiler;

import java.lang.reflect.*;

public class HelloInMemory
{
	public static void main ( String[] argv )
		throws Exception
	{
		InMemoryCompiler compiler = new InMemoryCompiler();

		Class clazz = compiler.compile
			(
				"public class Hello {" +
				"  public String toString()" +
				"  { return ( \"Hello from memory!\" ); }" +
				"}"
			);

		Object foo = clazz.newInstance();
		System.out.println(foo.toString());
	}
}
