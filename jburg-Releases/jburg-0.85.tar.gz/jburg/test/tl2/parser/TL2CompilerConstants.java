package jburg.test.tl2.parser;

public interface TL2CompilerConstants
{
	public static final int NO_OPCODE = -1;


	public static final int ARRAY_REFERENCE = 20005;
	public static final int COMPILATION_UNIT = 20010;
	public static final int CONS_CELL = 20000;
	public static final int CONSTRUCTOR_DEFINITION = 20030;
	public static final int ELIDED_NODE = 20300;
	public static final int FIELD_DEFINITION = 21000;
	public static final int INITIALIZE_NON_FINAL = 22150;
	public static final int INVOKE_METHOD = 22300;
	public static final int INVOKE_SPECIAL_METHOD = 22100;
	public static final int INVOKE_STATIC_METHOD = 22200;
	public static final int LOCAL_DEFINITION = 22700;
	public static final int METHOD_CALL = 24000;
	public static final int METHOD_DEFINITION = 24020;
	public static final int PARAMETER_LIST = 25000;
	public static final int QUALIFIED_NAME = 25100;

	public static final int REFERENCE_LOCAL  = 32000;
	public static final int REFERENCE_MEMBER = 32100;
	public static final int REFERENCE_STATIC = 32200;
	public static final int REFERENCE_STATIC_METHOD = 32220;
	public static final int REFERENCE_THIS   = 32300;

	public static final int STRING_LITERAL = 28000;
	public static final int THEN_ELSE = 30000;
	public static final int TYPE_SPECIFIER = 30500;


	/*
	 *  Keys used to access node properties.
	 */
	public static final String AD_HOC_COMPILATION_RESULT = "ad hoc result";
	public static final String CATCH_CLASS = "catch class";
	public static final String CATCH_VARIABLE = "catch variable";
	public static final String EXCEPTION_HANDLER = "exception handler";
	public static final String FIELD_SYMBOL = "field name";
	public static final String IDENTIFIER_SYMBOL = "resolved identifier";
	public static final String IDENTIFIER_QUALIFIED_NAME = "qualified name";
	public static final String METHOD_PARAMETERS = "method parameters";
	public static final String METHOD_NAME = "method name";
	public static final String METHOD_RETURN_TYPE = "method return type";
	public static final String METHOD_SIGNATURE = "method signature";
	public static final String METHOD_SYMBOL = "method symbol";
	public static final String METHOD_SYMBOL_TABLE = "method symbol table";
	public static final String PARAMETER_TYPES = "parameter types";
	public static final String PARENT_REFERENCE = "parent reference";
	public static final String NODE_CLASS = "class";
	public static final String NODE_STATIC_CLASS = "static class";
	public static final String QUALIFIED_SYMBOL = "qualified name";
	public static final String RETURN_TYPE_SPECIFIER = "return type specifier";
}

