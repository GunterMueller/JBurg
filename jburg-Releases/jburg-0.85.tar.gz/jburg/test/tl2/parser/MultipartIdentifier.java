package jburg.test.tl2.parser;

import java.util.Vector;

public class MultipartIdentifier
{
	Vector parts;

	private int limit;
	private TL2INode root;
	private TL2INode current;

	public MultipartIdentifier( Token t)
	{
		parts = new Vector();
		append(t);
	}

	public void append ( Token t )
	{
		parts.add ( t );
	}

	public int size()
	{
		return parts.size();
	}

	public Token elementAt(int idx)
	{
		return (Token)parts.elementAt(idx);
	}

	public boolean isEmpty()
	{
		return size() == 0;
	}

	public String toString()
	{
		StringBuffer result = new StringBuffer ( parts.elementAt(0).toString() );

		for ( int i = 1; i < parts.size(); i++ )
		{
			result.append (".");
			result.append ( parts.elementAt(i).toString() );
		}

		return result.toString();
	}
}
