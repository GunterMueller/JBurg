package jburg.test.tl2.reducer;

/**
 *  A TL2InstructionList encapsulates a BCEL InstructionList,
 *  supporting some additional properties (type, as an AbstractClass,
 *  and success/failure branch targets).
 */
import java.util.Iterator;
import java.util.Vector;

import jburg.test.tl2.semanticanalysis.AbstractClass;
import jburg.test.tl2.semanticanalysis.Symbol;

import org.apache.bcel.generic.BranchInstruction;
import org.apache.bcel.generic.BranchHandle;
import org.apache.bcel.generic.Instruction;
import org.apache.bcel.generic.InstructionHandle;
import org.apache.bcel.generic.InstructionList;
import org.apache.bcel.generic.Type;

public class TL2InstructionList
{
	protected InstructionList  il;
	protected AbstractClass    clazz;

	protected Vector successTargets;
	protected Vector failureTargets;

	static final boolean FAILURE_TARGET = false;
	static final boolean DEFAULT_TARGET = false;
	static final boolean SUCCESS_TARGET = true;

	private Symbol symbol;

	public TL2InstructionList ()
	{
		this.il = new InstructionList ();
	}

	public TL2InstructionList ( InstructionList il )
	{
		this.il = il;
	}


	public TL2InstructionList ( TL2InstructionList i1, TL2InstructionList i2 )
	{
		this();
		append(i1);
		append(i2);
	}

	public TL2InstructionList ( Instruction ix )
	{
		this.il = new InstructionList ( ix );
	}

	public void setAbstractClass(AbstractClass clazz)
	{
		this.clazz = clazz;
	}

	public AbstractClass getAbstractClass()
	{
		return this.clazz;
	}

	public Type getType()
	{
		return this.clazz.getType();
	}

	public void append ( TL2InstructionList il2 )
	{
		inheritTargets(il2);
		this.il.append(il2.il);
	}


	public InstructionHandle append ( InstructionHandle idx, Instruction i2 )
	{
		return this.il.append(idx, i2);
	}

	public InstructionHandle append ( Instruction i2 )
	{
		return this.il.append(i2);
	}



	public InstructionHandle append ( BranchInstruction i2 )
	{
		return this.il.append(i2);
	}

	public InstructionHandle insert ( TL2InstructionList il2 )
	{
		inheritTargets(il2);
		return this.il.insert(il2.il);
	}


	public InstructionHandle insert ( InstructionHandle idx, TL2InstructionList il2 )
	{
		inheritTargets(il2);
		return this.il.insert(idx, il2.il);
	}

	public InstructionHandle insert ( Instruction i2 )
	{
		return this.il.insert(i2);
	}

	public InstructionHandle insert ( InstructionHandle idx, Instruction i2 )
	{
		return this.il.insert(idx, i2);
	}
	
	public InstructionList getInstructionList()
	{
		return this.il;
	}

	public InstructionHandle getStart()
	{
		return this.il.getStart();
	}


	public InstructionHandle getEnd()
	{
		return this.il.getEnd();
	}

	private void inheritTargets ( TL2InstructionList l2 )
	{
		if ( l2.successTargets != null )
		{
			if ( this.successTargets != null )
				this.successTargets.addAll(l2.successTargets);
			else
				this.successTargets = (Vector)l2.successTargets.clone();
		}

		if ( l2.failureTargets != null )
		{
			if ( this.failureTargets != null )
				this.failureTargets.addAll(l2.failureTargets);
			else
				this.failureTargets = (Vector)l2.failureTargets.clone();
		}
	}

	public void appendBranch ( BranchInstruction b, boolean targetType )
	{
		il.append ( b );
		if ( targetType == FAILURE_TARGET )
		{
			if ( this.failureTargets == null )
				this.failureTargets = new Vector();
			this.failureTargets.add( b );
		}
		else
		{
			if ( this.successTargets == null )
				this.successTargets = new Vector();
			this.successTargets.add ( b );
		}
	}

	public void setTarget ( InstructionHandle ih )
	{
		setTarget ( ih, FAILURE_TARGET );
	}

	public void setTarget ( InstructionHandle ih, boolean targetType )
	{
		//  Fast noop exit.
		if ( targetType == FAILURE_TARGET && failureTargets == null )
			return;
		else if ( targetType == SUCCESS_TARGET && successTargets == null )
			return;

		Iterator it;

		if ( targetType  == FAILURE_TARGET )
			it = failureTargets.iterator();
		else
			it = successTargets.iterator();

		while ( it.hasNext() )
		{
			BranchInstruction b = (BranchInstruction) it.next();
			b.setTarget ( ih );
		}

		//  This instruction sequence's target is set, clean out the
		//  forward reference lists.
		if ( targetType  == FAILURE_TARGET )
			failureTargets.clear();
		else
			successTargets.clear();
	}

	public void setSymbol ( Symbol s )
	{
		this.symbol = s;
	}

	public Symbol getSymbol()
	{
		return this.symbol;
	}

	void finalizeBranchTargets()
	{
		//  FIXME: Only do this for a void method,
		//  otherwise unfinalized branch targets are GIGO.
		setTarget ( getEnd(), DEFAULT_TARGET );
	}

	/**
	 *  This TL2InstructionList is a switch, loop, or 
	 *  other target for an unlabelled GOTO; clean out
	 *  the input list of GOTOs and assign their target
	 *  to branch to the end of this instruction list
	 *  (which is usually an artificial NOP).
	 *
	 *  FIXME: Investigate just putting these GOTOs on
	 *  this lists' false targets?
	 *
	 *  @param unlabelled_gotos - a Vector of BranchHandle representations of GOTOs.
	 */
	void fixUnlabelledGOTOs ( Vector unlabelled_gotos )
	{
		if ( ! unlabelled_gotos.isEmpty() )
		{
			for (int i = 0; i < unlabelled_gotos.size(); i++ )
			{
				BranchHandle nextGOTO = (BranchHandle) unlabelled_gotos.elementAt(i);
				nextGOTO.setTarget ( getEnd() );
			}

			unlabelled_gotos.clear();
		}
	}
}
