package jburg.test.tl2.semanticanalysis;

public interface SemanticConstants 
{
	public static final int SYMBOL_ACCESS_DEFAULT = 20100;
	public static final int SYMBOL_ACCESS_PRIVATE = 20200;
	public static final int SYMBOL_ACCESS_PUBLIC  = 20300;
}
