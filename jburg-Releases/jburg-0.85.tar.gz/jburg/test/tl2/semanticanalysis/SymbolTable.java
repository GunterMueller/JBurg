package jburg.test.tl2.semanticanalysis;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import jburg.test.tl2.parser.TL2INode;

import org.apache.bcel.generic.ConstantPoolGen;
import org.apache.bcel.generic.FieldGen;

/**
 *  SymbolTable objects hold tables of symbols declared
 *  in a class or method, and their initializers.
 */
public class SymbolTable
{

	/**  Declared symbols. */
	private HashMap symbols = new HashMap();

	/**  Initializers for symbols, keyed by the symbol itself. */
	private HashMap initializers = new HashMap();

	public SymbolTable()
	{
	}

	/**
	 *  Add a method's parameters to its symbol table.
	 */
	public void addParameters ( Vector methodParams )
	{
		for ( int i = 0; i < methodParams.size(); i++ )
		{
			Symbol s = (Symbol)methodParams.elementAt(i);
			s.setSlotnumber(size());
			addSymbol (s);
		}
	}

	/**
	 *  Add a symbol to this symbol table.
	 *  @return the previous symbol by this name, or null.
	 */
	public Symbol addSymbol ( Symbol s )
	{
		return addSymbol ( s, null );
	}

	/**
	 *  Add a symbol to this symbol table.
	 *  @param s - the symbol to add
	 *  @param initializer - the symbol's initialization code, 
	 *    or null if it's not initialized.
	 *  @return the previous symbol by this name, or null.
	 */
	public Symbol addSymbol ( Symbol s, TL2INode initializer )
	{
		Symbol result = (Symbol)this.symbols.put ( s.getName(), s );

		if ( initializer != null )
		{
			initializers.put ( s, initializer );
		}
		else
		{
			//  FIXME: remove any previous initializer.
		}

		return result;
	}

	/** @return the Symbol with the given name, or null. */
	public Symbol getSymbol(Object identifierName)
	{
		return (Symbol)this.symbols.get ( identifierName );
	}

	/** @return an Iterator that walks the symbol table's Symbols. */
	public Iterator iterator()
	{
		return this.symbols.values().iterator();
	}

	/** @return the size of the table of Symbol objects. */
	public int size()
	{
		return this.symbols.size();
	}

	/** @return the initializer for a symbol, or null if it has no initializer. */
	public TL2INode getInitializer ( Symbol s )
	{
		return (TL2INode)initializers.get(s);
	}
}
