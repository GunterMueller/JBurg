package jburg.test.tl2.semanticanalysis;

import jburg.test.tl2.parser.TL2INode;

public interface SemanticVisitor
{
	void preOrderVisit  (TL2INode p);
	void postOrderVisit (TL2INode p);
}
