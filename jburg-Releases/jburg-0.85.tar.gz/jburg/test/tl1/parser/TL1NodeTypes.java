package jburg.test.tl1.parser;

/**
 *  Node types for ASTs not directly represented as a token type.
 */
public interface TL1NodeTypes
{
	public final static int CONS_CELL        = 20000;
	public final static int BUILTIN_FUNCTION = 20001;
	public final static int STRING_LITERAL   = 20010;
	public final static int THEN_ELSE        = 20020;

	public final static int NO_OPCODE = -100;
}
