package jburg.test.tl1.runtime;

import java.util.Hashtable;

public class Runtime
{
    private Hashtable symtab = new Hashtable();

	public void put ( String key, Object value )
	{
		symtab.put(key.toUpperCase(), value);
	}

	public Object get ( String key )
	{
		Object result = symtab.get(key.toUpperCase());
		return result;
	}

	public void println ( Object s )
	{
		System.out.println(s.toString());
	}

	public Object now()
	{
		return new java.util.Date();
	}
}
